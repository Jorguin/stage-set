define(["exports"], (function(exports) {
	"use strict";
	// @ts-ignore
	try {
		self["workbox:core:7.4.0"] && _();
	} catch (e) {}
	/*
	Copyright 2019 Google LLC
	Use of this source code is governed by an MIT-style
	license that can be found in the LICENSE file or at
	https://opensource.org/licenses/MIT.
	*/
	const logger = (() => {
		// Don't overwrite this value if it's already set.
		// See https://github.com/GoogleChrome/workbox/pull/2284#issuecomment-560470923
		if (!("__WB_DISABLE_DEV_LOGS" in globalThis)) {
			self.__WB_DISABLE_DEV_LOGS = false;
		}
		let inGroup = false;
		const methodToColorMap = {
			debug: `#7f8c8d`,
			log: `#2ecc71`,
			warn: `#f39c12`,
			error: `#c0392b`,
			groupCollapsed: `#3498db`,
			groupEnd: null
		};
		const print = function(method, args) {
			if (self.__WB_DISABLE_DEV_LOGS) {
				return;
			}
			if (method === "groupCollapsed") {
				// Safari doesn't print all console.groupCollapsed() arguments:
				// https://bugs.webkit.org/show_bug.cgi?id=182754
				if (/^((?!chrome|android).)*safari/i.test(navigator.userAgent)) {
					console[method](...args);
					return;
				}
			}
			const styles = [
				`background: ${methodToColorMap[method]}`,
				`border-radius: 0.5em`,
				`color: white`,
				`font-weight: bold`,
				`padding: 2px 0.5em`
			];
			// When in a group, the workbox prefix is not displayed.
			const logPrefix = inGroup ? [] : ["%cworkbox", styles.join(";")];
			console[method](...logPrefix, ...args);
			if (method === "groupCollapsed") {
				inGroup = true;
			}
			if (method === "groupEnd") {
				inGroup = false;
			}
		};
		// eslint-disable-next-line @typescript-eslint/ban-types
		const api = {};
		const loggerMethods = Object.keys(methodToColorMap);
		for (const key of loggerMethods) {
			const method = key;
			api[method] = (...args) => {
				print(method, args);
			};
		}
		return api;
	})();
	/*
	Copyright 2018 Google LLC
	
	Use of this source code is governed by an MIT-style
	license that can be found in the LICENSE file or at
	https://opensource.org/licenses/MIT.
	*/
	const messages$1 = {
		"invalid-value": ({ paramName, validValueDescription, value }) => {
			if (!paramName || !validValueDescription) {
				throw new Error(`Unexpected input to 'invalid-value' error.`);
			}
			return `The '${paramName}' parameter was given a value with an ` + `unexpected value. ${validValueDescription} Received a value of ` + `${JSON.stringify(value)}.`;
		},
		"not-an-array": ({ moduleName, className, funcName, paramName }) => {
			if (!moduleName || !className || !funcName || !paramName) {
				throw new Error(`Unexpected input to 'not-an-array' error.`);
			}
			return `The parameter '${paramName}' passed into ` + `'${moduleName}.${className}.${funcName}()' must be an array.`;
		},
		"incorrect-type": ({ expectedType, paramName, moduleName, className, funcName }) => {
			if (!expectedType || !paramName || !moduleName || !funcName) {
				throw new Error(`Unexpected input to 'incorrect-type' error.`);
			}
			const classNameStr = className ? `${className}.` : "";
			return `The parameter '${paramName}' passed into ` + `'${moduleName}.${classNameStr}` + `${funcName}()' must be of type ${expectedType}.`;
		},
		"incorrect-class": ({ expectedClassName, paramName, moduleName, className, funcName, isReturnValueProblem }) => {
			if (!expectedClassName || !moduleName || !funcName) {
				throw new Error(`Unexpected input to 'incorrect-class' error.`);
			}
			const classNameStr = className ? `${className}.` : "";
			if (isReturnValueProblem) {
				return `The return value from ` + `'${moduleName}.${classNameStr}${funcName}()' ` + `must be an instance of class ${expectedClassName}.`;
			}
			return `The parameter '${paramName}' passed into ` + `'${moduleName}.${classNameStr}${funcName}()' ` + `must be an instance of class ${expectedClassName}.`;
		},
		"missing-a-method": ({ expectedMethod, paramName, moduleName, className, funcName }) => {
			if (!expectedMethod || !paramName || !moduleName || !className || !funcName) {
				throw new Error(`Unexpected input to 'missing-a-method' error.`);
			}
			return `${moduleName}.${className}.${funcName}() expected the ` + `'${paramName}' parameter to expose a '${expectedMethod}' method.`;
		},
		"add-to-cache-list-unexpected-type": ({ entry }) => {
			return `An unexpected entry was passed to ` + `'workbox-precaching.PrecacheController.addToCacheList()' The entry ` + `'${JSON.stringify(entry)}' isn't supported. You must supply an array of ` + `strings with one or more characters, objects with a url property or ` + `Request objects.`;
		},
		"add-to-cache-list-conflicting-entries": ({ firstEntry, secondEntry }) => {
			if (!firstEntry || !secondEntry) {
				throw new Error(`Unexpected input to ` + `'add-to-cache-list-duplicate-entries' error.`);
			}
			return `Two of the entries passed to ` + `'workbox-precaching.PrecacheController.addToCacheList()' had the URL ` + `${firstEntry} but different revision details. Workbox is ` + `unable to cache and version the asset correctly. Please remove one ` + `of the entries.`;
		},
		"plugin-error-request-will-fetch": ({ thrownErrorMessage }) => {
			if (!thrownErrorMessage) {
				throw new Error(`Unexpected input to ` + `'plugin-error-request-will-fetch', error.`);
			}
			return `An error was thrown by a plugins 'requestWillFetch()' method. ` + `The thrown error message was: '${thrownErrorMessage}'.`;
		},
		"invalid-cache-name": ({ cacheNameId, value }) => {
			if (!cacheNameId) {
				throw new Error(`Expected a 'cacheNameId' for error 'invalid-cache-name'`);
			}
			return `You must provide a name containing at least one character for ` + `setCacheDetails({${cacheNameId}: '...'}). Received a value of ` + `'${JSON.stringify(value)}'`;
		},
		"unregister-route-but-not-found-with-method": ({ method }) => {
			if (!method) {
				throw new Error(`Unexpected input to ` + `'unregister-route-but-not-found-with-method' error.`);
			}
			return `The route you're trying to unregister was not  previously ` + `registered for the method type '${method}'.`;
		},
		"unregister-route-route-not-registered": () => {
			return `The route you're trying to unregister was not previously ` + `registered.`;
		},
		"queue-replay-failed": ({ name }) => {
			return `Replaying the background sync queue '${name}' failed.`;
		},
		"duplicate-queue-name": ({ name }) => {
			return `The Queue name '${name}' is already being used. ` + `All instances of backgroundSync.Queue must be given unique names.`;
		},
		"expired-test-without-max-age": ({ methodName, paramName }) => {
			return `The '${methodName}()' method can only be used when the ` + `'${paramName}' is used in the constructor.`;
		},
		"unsupported-route-type": ({ moduleName, className, funcName, paramName }) => {
			return `The supplied '${paramName}' parameter was an unsupported type. ` + `Please check the docs for ${moduleName}.${className}.${funcName} for ` + `valid input types.`;
		},
		"not-array-of-class": ({ value, expectedClass, moduleName, className, funcName, paramName }) => {
			return `The supplied '${paramName}' parameter must be an array of ` + `'${expectedClass}' objects. Received '${JSON.stringify(value)},'. ` + `Please check the call to ${moduleName}.${className}.${funcName}() ` + `to fix the issue.`;
		},
		"max-entries-or-age-required": ({ moduleName, className, funcName }) => {
			return `You must define either config.maxEntries or config.maxAgeSeconds` + `in ${moduleName}.${className}.${funcName}`;
		},
		"statuses-or-headers-required": ({ moduleName, className, funcName }) => {
			return `You must define either config.statuses or config.headers` + `in ${moduleName}.${className}.${funcName}`;
		},
		"invalid-string": ({ moduleName, funcName, paramName }) => {
			if (!paramName || !moduleName || !funcName) {
				throw new Error(`Unexpected input to 'invalid-string' error.`);
			}
			return `When using strings, the '${paramName}' parameter must start with ` + `'http' (for cross-origin matches) or '/' (for same-origin matches). ` + `Please see the docs for ${moduleName}.${funcName}() for ` + `more info.`;
		},
		"channel-name-required": () => {
			return `You must provide a channelName to construct a ` + `BroadcastCacheUpdate instance.`;
		},
		"invalid-responses-are-same-args": () => {
			return `The arguments passed into responsesAreSame() appear to be ` + `invalid. Please ensure valid Responses are used.`;
		},
		"expire-custom-caches-only": () => {
			return `You must provide a 'cacheName' property when using the ` + `expiration plugin with a runtime caching strategy.`;
		},
		"unit-must-be-bytes": ({ normalizedRangeHeader }) => {
			if (!normalizedRangeHeader) {
				throw new Error(`Unexpected input to 'unit-must-be-bytes' error.`);
			}
			return `The 'unit' portion of the Range header must be set to 'bytes'. ` + `The Range header provided was "${normalizedRangeHeader}"`;
		},
		"single-range-only": ({ normalizedRangeHeader }) => {
			if (!normalizedRangeHeader) {
				throw new Error(`Unexpected input to 'single-range-only' error.`);
			}
			return `Multiple ranges are not supported. Please use a  single start ` + `value, and optional end value. The Range header provided was ` + `"${normalizedRangeHeader}"`;
		},
		"invalid-range-values": ({ normalizedRangeHeader }) => {
			if (!normalizedRangeHeader) {
				throw new Error(`Unexpected input to 'invalid-range-values' error.`);
			}
			return `The Range header is missing both start and end values. At least ` + `one of those values is needed. The Range header provided was ` + `"${normalizedRangeHeader}"`;
		},
		"no-range-header": () => {
			return `No Range header was found in the Request provided.`;
		},
		"range-not-satisfiable": ({ size, start, end }) => {
			return `The start (${start}) and end (${end}) values in the Range are ` + `not satisfiable by the cached response, which is ${size} bytes.`;
		},
		"attempt-to-cache-non-get-request": ({ url, method }) => {
			return `Unable to cache '${url}' because it is a '${method}' request and ` + `only 'GET' requests can be cached.`;
		},
		"cache-put-with-no-response": ({ url }) => {
			return `There was an attempt to cache '${url}' but the response was not ` + `defined.`;
		},
		"no-response": ({ url, error }) => {
			let message = `The strategy could not generate a response for '${url}'.`;
			if (error) {
				message += ` The underlying error is ${error}.`;
			}
			return message;
		},
		"bad-precaching-response": ({ url, status }) => {
			return `The precaching request for '${url}' failed` + (status ? ` with an HTTP status of ${status}.` : `.`);
		},
		"non-precached-url": ({ url }) => {
			return `createHandlerBoundToURL('${url}') was called, but that URL is ` + `not precached. Please pass in a URL that is precached instead.`;
		},
		"add-to-cache-list-conflicting-integrities": ({ url }) => {
			return `Two of the entries passed to ` + `'workbox-precaching.PrecacheController.addToCacheList()' had the URL ` + `${url} with different integrity values. Please remove one of them.`;
		},
		"missing-precache-entry": ({ cacheName, url }) => {
			return `Unable to find a precached response in ${cacheName} for ${url}.`;
		},
		"cross-origin-copy-response": ({ origin }) => {
			return `workbox-core.copyResponse() can only be used with same-origin ` + `responses. It was passed a response with origin ${origin}.`;
		},
		"opaque-streams-source": ({ type }) => {
			const message = `One of the workbox-streams sources resulted in an ` + `'${type}' response.`;
			if (type === "opaqueredirect") {
				return `${message} Please do not use a navigation request that results ` + `in a redirect as a source.`;
			}
			return `${message} Please ensure your sources are CORS-enabled.`;
		}
	};
	/*
	Copyright 2018 Google LLC
	
	Use of this source code is governed by an MIT-style
	license that can be found in the LICENSE file or at
	https://opensource.org/licenses/MIT.
	*/
	const generatorFunction = (code, details = {}) => {
		const message = messages$1[code];
		if (!message) {
			throw new Error(`Unable to find message for code '${code}'.`);
		}
		return message(details);
	};
	const messageGenerator = generatorFunction;
	/*
	Copyright 2018 Google LLC
	
	Use of this source code is governed by an MIT-style
	license that can be found in the LICENSE file or at
	https://opensource.org/licenses/MIT.
	*/
	/**
	* Workbox errors should be thrown with this class.
	* This allows use to ensure the type easily in tests,
	* helps developers identify errors from workbox
	* easily and allows use to optimise error
	* messages correctly.
	*
	* @private
	*/
	class WorkboxError extends Error {
		/**
		*
		* @param {string} errorCode The error code that
		* identifies this particular error.
		* @param {Object=} details Any relevant arguments
		* that will help developers identify issues should
		* be added as a key on the context object.
		*/
		constructor(errorCode, details) {
			const message = messageGenerator(errorCode, details);
			super(message);
			this.name = errorCode;
			this.details = details;
		}
	}
	/*
	Copyright 2018 Google LLC
	
	Use of this source code is governed by an MIT-style
	license that can be found in the LICENSE file or at
	https://opensource.org/licenses/MIT.
	*/
	/*
	* This method throws if the supplied value is not an array.
	* The destructed values are required to produce a meaningful error for users.
	* The destructed and restructured object is so it's clear what is
	* needed.
	*/
	const isArray = (value, details) => {
		if (!Array.isArray(value)) {
			throw new WorkboxError("not-an-array", details);
		}
	};
	const hasMethod = (object, expectedMethod, details) => {
		const type = typeof object[expectedMethod];
		if (type !== "function") {
			details["expectedMethod"] = expectedMethod;
			throw new WorkboxError("missing-a-method", details);
		}
	};
	const isType = (object, expectedType, details) => {
		if (typeof object !== expectedType) {
			details["expectedType"] = expectedType;
			throw new WorkboxError("incorrect-type", details);
		}
	};
	const isInstance = (object, expectedClass, details) => {
		if (!(object instanceof expectedClass)) {
			details["expectedClassName"] = expectedClass.name;
			throw new WorkboxError("incorrect-class", details);
		}
	};
	const isOneOf = (value, validValues, details) => {
		if (!validValues.includes(value)) {
			details["validValueDescription"] = `Valid values are ${JSON.stringify(validValues)}.`;
			throw new WorkboxError("invalid-value", details);
		}
	};
	const isArrayOfClass = (value, expectedClass, details) => {
		const error = new WorkboxError("not-array-of-class", details);
		if (!Array.isArray(value)) {
			throw error;
		}
		for (const item of value) {
			if (!(item instanceof expectedClass)) {
				throw error;
			}
		}
	};
	const finalAssertExports = {
		hasMethod,
		isArray,
		isInstance,
		isOneOf,
		isType,
		isArrayOfClass
	};
	// @ts-ignore
	try {
		self["workbox:routing:7.4.0"] && _();
	} catch (e) {}
	/*
	Copyright 2018 Google LLC
	
	Use of this source code is governed by an MIT-style
	license that can be found in the LICENSE file or at
	https://opensource.org/licenses/MIT.
	*/
	/**
	* The default HTTP method, 'GET', used when there's no specific method
	* configured for a route.
	*
	* @type {string}
	*
	* @private
	*/
	const defaultMethod = "GET";
	/**
	* The list of valid HTTP methods associated with requests that could be routed.
	*
	* @type {Array<string>}
	*
	* @private
	*/
	const validMethods = [
		"DELETE",
		"GET",
		"HEAD",
		"PATCH",
		"POST",
		"PUT"
	];
	/*
	Copyright 2018 Google LLC
	
	Use of this source code is governed by an MIT-style
	license that can be found in the LICENSE file or at
	https://opensource.org/licenses/MIT.
	*/
	/**
	* @param {function()|Object} handler Either a function, or an object with a
	* 'handle' method.
	* @return {Object} An object with a handle method.
	*
	* @private
	*/
	const normalizeHandler = (handler) => {
		if (handler && typeof handler === "object") {
			{
				finalAssertExports.hasMethod(handler, "handle", {
					moduleName: "workbox-routing",
					className: "Route",
					funcName: "constructor",
					paramName: "handler"
				});
			}
			return handler;
		} else {
			{
				finalAssertExports.isType(handler, "function", {
					moduleName: "workbox-routing",
					className: "Route",
					funcName: "constructor",
					paramName: "handler"
				});
			}
			return { handle: handler };
		}
	};
	/*
	Copyright 2018 Google LLC
	
	Use of this source code is governed by an MIT-style
	license that can be found in the LICENSE file or at
	https://opensource.org/licenses/MIT.
	*/
	/**
	* A `Route` consists of a pair of callback functions, "match" and "handler".
	* The "match" callback determine if a route should be used to "handle" a
	* request by returning a non-falsy value if it can. The "handler" callback
	* is called when there is a match and should return a Promise that resolves
	* to a `Response`.
	*
	* @memberof workbox-routing
	*/
	class Route {
		/**
		* Constructor for Route class.
		*
		* @param {workbox-routing~matchCallback} match
		* A callback function that determines whether the route matches a given
		* `fetch` event by returning a non-falsy value.
		* @param {workbox-routing~handlerCallback} handler A callback
		* function that returns a Promise resolving to a Response.
		* @param {string} [method='GET'] The HTTP method to match the Route
		* against.
		*/
		constructor(match, handler, method = defaultMethod) {
			{
				finalAssertExports.isType(match, "function", {
					moduleName: "workbox-routing",
					className: "Route",
					funcName: "constructor",
					paramName: "match"
				});
				if (method) {
					finalAssertExports.isOneOf(method, validMethods, { paramName: "method" });
				}
			}
			// These values are referenced directly by Router so cannot be
			// altered by minificaton.
			this.handler = normalizeHandler(handler);
			this.match = match;
			this.method = method;
		}
		/**
		*
		* @param {workbox-routing-handlerCallback} handler A callback
		* function that returns a Promise resolving to a Response
		*/
		setCatchHandler(handler) {
			this.catchHandler = normalizeHandler(handler);
		}
	}
	/*
	Copyright 2018 Google LLC
	
	Use of this source code is governed by an MIT-style
	license that can be found in the LICENSE file or at
	https://opensource.org/licenses/MIT.
	*/
	/**
	* RegExpRoute makes it easy to create a regular expression based
	* {@link workbox-routing.Route}.
	*
	* For same-origin requests the RegExp only needs to match part of the URL. For
	* requests against third-party servers, you must define a RegExp that matches
	* the start of the URL.
	*
	* @memberof workbox-routing
	* @extends workbox-routing.Route
	*/
	class RegExpRoute extends Route {
		/**
		* If the regular expression contains
		* [capture groups]{@link https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/RegExp#grouping-back-references},
		* the captured values will be passed to the
		* {@link workbox-routing~handlerCallback} `params`
		* argument.
		*
		* @param {RegExp} regExp The regular expression to match against URLs.
		* @param {workbox-routing~handlerCallback} handler A callback
		* function that returns a Promise resulting in a Response.
		* @param {string} [method='GET'] The HTTP method to match the Route
		* against.
		*/
		constructor(regExp, handler, method) {
			{
				finalAssertExports.isInstance(regExp, RegExp, {
					moduleName: "workbox-routing",
					className: "RegExpRoute",
					funcName: "constructor",
					paramName: "pattern"
				});
			}
			const match = ({ url }) => {
				const result = regExp.exec(url.href);
				// Return immediately if there's no match.
				if (!result) {
					return;
				}
				// Require that the match start at the first character in the URL string
				// if it's a cross-origin request.
				// See https://github.com/GoogleChrome/workbox/issues/281 for the context
				// behind this behavior.
				if (url.origin !== location.origin && result.index !== 0) {
					{
						logger.debug(`The regular expression '${regExp.toString()}' only partially matched ` + `against the cross-origin URL '${url.toString()}'. RegExpRoute's will only ` + `handle cross-origin requests if they match the entire URL.`);
					}
					return;
				}
				// If the route matches, but there aren't any capture groups defined, then
				// this will return [], which is truthy and therefore sufficient to
				// indicate a match.
				// If there are capture groups, then it will return their values.
				return result.slice(1);
			};
			super(match, handler, method);
		}
	}
	/*
	Copyright 2018 Google LLC
	
	Use of this source code is governed by an MIT-style
	license that can be found in the LICENSE file or at
	https://opensource.org/licenses/MIT.
	*/
	const getFriendlyURL = (url) => {
		const urlObj = new URL(String(url), location.href);
		// See https://github.com/GoogleChrome/workbox/issues/2323
		// We want to include everything, except for the origin if it's same-origin.
		return urlObj.href.replace(new RegExp(`^${location.origin}`), "");
	};
	/*
	Copyright 2018 Google LLC
	
	Use of this source code is governed by an MIT-style
	license that can be found in the LICENSE file or at
	https://opensource.org/licenses/MIT.
	*/
	/**
	* The Router can be used to process a `FetchEvent` using one or more
	* {@link workbox-routing.Route}, responding with a `Response` if
	* a matching route exists.
	*
	* If no route matches a given a request, the Router will use a "default"
	* handler if one is defined.
	*
	* Should the matching Route throw an error, the Router will use a "catch"
	* handler if one is defined to gracefully deal with issues and respond with a
	* Request.
	*
	* If a request matches multiple routes, the **earliest** registered route will
	* be used to respond to the request.
	*
	* @memberof workbox-routing
	*/
	class Router {
		/**
		* Initializes a new Router.
		*/
		constructor() {
			this._routes = new Map();
			this._defaultHandlerMap = new Map();
		}
		/**
		* @return {Map<string, Array<workbox-routing.Route>>} routes A `Map` of HTTP
		* method name ('GET', etc.) to an array of all the corresponding `Route`
		* instances that are registered.
		*/
		get routes() {
			return this._routes;
		}
		/**
		* Adds a fetch event listener to respond to events when a route matches
		* the event's request.
		*/
		addFetchListener() {
			// See https://github.com/Microsoft/TypeScript/issues/28357#issuecomment-436484705
			self.addEventListener("fetch", (event) => {
				const { request } = event;
				const responsePromise = this.handleRequest({
					request,
					event
				});
				if (responsePromise) {
					event.respondWith(responsePromise);
				}
			});
		}
		/**
		* Adds a message event listener for URLs to cache from the window.
		* This is useful to cache resources loaded on the page prior to when the
		* service worker started controlling it.
		*
		* The format of the message data sent from the window should be as follows.
		* Where the `urlsToCache` array may consist of URL strings or an array of
		* URL string + `requestInit` object (the same as you'd pass to `fetch()`).
		*
		* ```
		* {
		*   type: 'CACHE_URLS',
		*   payload: {
		*     urlsToCache: [
		*       './script1.js',
		*       './script2.js',
		*       ['./script3.js', {mode: 'no-cors'}],
		*     ],
		*   },
		* }
		* ```
		*/
		addCacheListener() {
			// See https://github.com/Microsoft/TypeScript/issues/28357#issuecomment-436484705
			self.addEventListener("message", (event) => {
				// event.data is type 'any'
				// eslint-disable-next-line @typescript-eslint/no-unsafe-member-access
				if (event.data && event.data.type === "CACHE_URLS") {
					// eslint-disable-next-line @typescript-eslint/no-unsafe-assignment
					const { payload } = event.data;
					{
						logger.debug(`Caching URLs from the window`, payload.urlsToCache);
					}
					const requestPromises = Promise.all(payload.urlsToCache.map((entry) => {
						if (typeof entry === "string") {
							entry = [entry];
						}
						const request = new Request(...entry);
						return this.handleRequest({
							request,
							event
						});
						// TODO(philipwalton): TypeScript errors without this typecast for
						// some reason (probably a bug). The real type here should work but
						// doesn't: `Array<Promise<Response> | undefined>`.
					}));
					event.waitUntil(requestPromises);
					// If a MessageChannel was used, reply to the message on success.
					if (event.ports && event.ports[0]) {
						void requestPromises.then(() => event.ports[0].postMessage(true));
					}
				}
			});
		}
		/**
		* Apply the routing rules to a FetchEvent object to get a Response from an
		* appropriate Route's handler.
		*
		* @param {Object} options
		* @param {Request} options.request The request to handle.
		* @param {ExtendableEvent} options.event The event that triggered the
		*     request.
		* @return {Promise<Response>|undefined} A promise is returned if a
		*     registered route can handle the request. If there is no matching
		*     route and there's no `defaultHandler`, `undefined` is returned.
		*/
		handleRequest({ request, event }) {
			{
				finalAssertExports.isInstance(request, Request, {
					moduleName: "workbox-routing",
					className: "Router",
					funcName: "handleRequest",
					paramName: "options.request"
				});
			}
			const url = new URL(request.url, location.href);
			if (!url.protocol.startsWith("http")) {
				{
					logger.debug(`Workbox Router only supports URLs that start with 'http'.`);
				}
				return;
			}
			const sameOrigin = url.origin === location.origin;
			const { params, route } = this.findMatchingRoute({
				event,
				request,
				sameOrigin,
				url
			});
			let handler = route && route.handler;
			const debugMessages = [];
			{
				if (handler) {
					debugMessages.push([`Found a route to handle this request:`, route]);
					if (params) {
						debugMessages.push([`Passing the following params to the route's handler:`, params]);
					}
				}
			}
			// If we don't have a handler because there was no matching route, then
			// fall back to defaultHandler if that's defined.
			const method = request.method;
			if (!handler && this._defaultHandlerMap.has(method)) {
				{
					debugMessages.push(`Failed to find a matching route. Falling ` + `back to the default handler for ${method}.`);
				}
				handler = this._defaultHandlerMap.get(method);
			}
			if (!handler) {
				{
					// No handler so Workbox will do nothing. If logs is set of debug
					// i.e. verbose, we should print out this information.
					logger.debug(`No route found for: ${getFriendlyURL(url)}`);
				}
				return;
			}
			{
				// We have a handler, meaning Workbox is going to handle the route.
				// print the routing details to the console.
				logger.groupCollapsed(`Router is responding to: ${getFriendlyURL(url)}`);
				debugMessages.forEach((msg) => {
					if (Array.isArray(msg)) {
						logger.log(...msg);
					} else {
						logger.log(msg);
					}
				});
				logger.groupEnd();
			}
			// Wrap in try and catch in case the handle method throws a synchronous
			// error. It should still callback to the catch handler.
			let responsePromise;
			try {
				responsePromise = handler.handle({
					url,
					request,
					event,
					params
				});
			} catch (err) {
				responsePromise = Promise.reject(err);
			}
			// Get route's catch handler, if it exists
			const catchHandler = route && route.catchHandler;
			if (responsePromise instanceof Promise && (this._catchHandler || catchHandler)) {
				responsePromise = responsePromise.catch(async (err) => {
					// If there's a route catch handler, process that first
					if (catchHandler) {
						{
							// Still include URL here as it will be async from the console group
							// and may not make sense without the URL
							logger.groupCollapsed(`Error thrown when responding to: ` + ` ${getFriendlyURL(url)}. Falling back to route's Catch Handler.`);
							logger.error(`Error thrown by:`, route);
							logger.error(err);
							logger.groupEnd();
						}
						try {
							return await catchHandler.handle({
								url,
								request,
								event,
								params
							});
						} catch (catchErr) {
							if (catchErr instanceof Error) {
								err = catchErr;
							}
						}
					}
					if (this._catchHandler) {
						{
							// Still include URL here as it will be async from the console group
							// and may not make sense without the URL
							logger.groupCollapsed(`Error thrown when responding to: ` + ` ${getFriendlyURL(url)}. Falling back to global Catch Handler.`);
							logger.error(`Error thrown by:`, route);
							logger.error(err);
							logger.groupEnd();
						}
						return this._catchHandler.handle({
							url,
							request,
							event
						});
					}
					throw err;
				});
			}
			return responsePromise;
		}
		/**
		* Checks a request and URL (and optionally an event) against the list of
		* registered routes, and if there's a match, returns the corresponding
		* route along with any params generated by the match.
		*
		* @param {Object} options
		* @param {URL} options.url
		* @param {boolean} options.sameOrigin The result of comparing `url.origin`
		*     against the current origin.
		* @param {Request} options.request The request to match.
		* @param {Event} options.event The corresponding event.
		* @return {Object} An object with `route` and `params` properties.
		*     They are populated if a matching route was found or `undefined`
		*     otherwise.
		*/
		findMatchingRoute({ url, sameOrigin, request, event }) {
			const routes = this._routes.get(request.method) || [];
			for (const route of routes) {
				let params;
				// route.match returns type any, not possible to change right now.
				// eslint-disable-next-line @typescript-eslint/no-unsafe-assignment
				const matchResult = route.match({
					url,
					sameOrigin,
					request,
					event
				});
				if (matchResult) {
					{
						// Warn developers that using an async matchCallback is almost always
						// not the right thing to do.
						if (matchResult instanceof Promise) {
							logger.warn(`While routing ${getFriendlyURL(url)}, an async ` + `matchCallback function was used. Please convert the ` + `following route to use a synchronous matchCallback function:`, route);
						}
					}
					// See https://github.com/GoogleChrome/workbox/issues/2079
					// eslint-disable-next-line @typescript-eslint/no-unsafe-assignment
					params = matchResult;
					if (Array.isArray(params) && params.length === 0) {
						// Instead of passing an empty array in as params, use undefined.
						params = undefined;
					} else if (matchResult.constructor === Object && Object.keys(matchResult).length === 0) {
						// Instead of passing an empty object in as params, use undefined.
						params = undefined;
					} else if (typeof matchResult === "boolean") {
						// For the boolean value true (rather than just something truth-y),
						// don't set params.
						// See https://github.com/GoogleChrome/workbox/pull/2134#issuecomment-513924353
						params = undefined;
					}
					// Return early if have a match.
					return {
						route,
						params
					};
				}
			}
			// If no match was found above, return and empty object.
			return {};
		}
		/**
		* Define a default `handler` that's called when no routes explicitly
		* match the incoming request.
		*
		* Each HTTP method ('GET', 'POST', etc.) gets its own default handler.
		*
		* Without a default handler, unmatched requests will go against the
		* network as if there were no service worker present.
		*
		* @param {workbox-routing~handlerCallback} handler A callback
		* function that returns a Promise resulting in a Response.
		* @param {string} [method='GET'] The HTTP method to associate with this
		* default handler. Each method has its own default.
		*/
		setDefaultHandler(handler, method = defaultMethod) {
			this._defaultHandlerMap.set(method, normalizeHandler(handler));
		}
		/**
		* If a Route throws an error while handling a request, this `handler`
		* will be called and given a chance to provide a response.
		*
		* @param {workbox-routing~handlerCallback} handler A callback
		* function that returns a Promise resulting in a Response.
		*/
		setCatchHandler(handler) {
			this._catchHandler = normalizeHandler(handler);
		}
		/**
		* Registers a route with the router.
		*
		* @param {workbox-routing.Route} route The route to register.
		*/
		registerRoute(route) {
			{
				finalAssertExports.isType(route, "object", {
					moduleName: "workbox-routing",
					className: "Router",
					funcName: "registerRoute",
					paramName: "route"
				});
				finalAssertExports.hasMethod(route, "match", {
					moduleName: "workbox-routing",
					className: "Router",
					funcName: "registerRoute",
					paramName: "route"
				});
				finalAssertExports.isType(route.handler, "object", {
					moduleName: "workbox-routing",
					className: "Router",
					funcName: "registerRoute",
					paramName: "route"
				});
				finalAssertExports.hasMethod(route.handler, "handle", {
					moduleName: "workbox-routing",
					className: "Router",
					funcName: "registerRoute",
					paramName: "route.handler"
				});
				finalAssertExports.isType(route.method, "string", {
					moduleName: "workbox-routing",
					className: "Router",
					funcName: "registerRoute",
					paramName: "route.method"
				});
			}
			if (!this._routes.has(route.method)) {
				this._routes.set(route.method, []);
			}
			// Give precedence to all of the earlier routes by adding this additional
			// route to the end of the array.
			this._routes.get(route.method).push(route);
		}
		/**
		* Unregisters a route with the router.
		*
		* @param {workbox-routing.Route} route The route to unregister.
		*/
		unregisterRoute(route) {
			if (!this._routes.has(route.method)) {
				throw new WorkboxError("unregister-route-but-not-found-with-method", { method: route.method });
			}
			const routeIndex = this._routes.get(route.method).indexOf(route);
			if (routeIndex > -1) {
				this._routes.get(route.method).splice(routeIndex, 1);
			} else {
				throw new WorkboxError("unregister-route-route-not-registered");
			}
		}
	}
	/*
	Copyright 2019 Google LLC
	
	Use of this source code is governed by an MIT-style
	license that can be found in the LICENSE file or at
	https://opensource.org/licenses/MIT.
	*/
	let defaultRouter;
	/**
	* Creates a new, singleton Router instance if one does not exist. If one
	* does already exist, that instance is returned.
	*
	* @private
	* @return {Router}
	*/
	const getOrCreateDefaultRouter = () => {
		if (!defaultRouter) {
			defaultRouter = new Router();
			// The helpers that use the default Router assume these listeners exist.
			defaultRouter.addFetchListener();
			defaultRouter.addCacheListener();
		}
		return defaultRouter;
	};
	/*
	Copyright 2019 Google LLC
	
	Use of this source code is governed by an MIT-style
	license that can be found in the LICENSE file or at
	https://opensource.org/licenses/MIT.
	*/
	/**
	* Easily register a RegExp, string, or function with a caching
	* strategy to a singleton Router instance.
	*
	* This method will generate a Route for you if needed and
	* call {@link workbox-routing.Router#registerRoute}.
	*
	* @param {RegExp|string|workbox-routing.Route~matchCallback|workbox-routing.Route} capture
	* If the capture param is a `Route`, all other arguments will be ignored.
	* @param {workbox-routing~handlerCallback} [handler] A callback
	* function that returns a Promise resulting in a Response. This parameter
	* is required if `capture` is not a `Route` object.
	* @param {string} [method='GET'] The HTTP method to match the Route
	* against.
	* @return {workbox-routing.Route} The generated `Route`.
	*
	* @memberof workbox-routing
	*/
	function registerRoute(capture, handler, method) {
		let route;
		if (typeof capture === "string") {
			const captureUrl = new URL(capture, location.href);
			{
				if (!(capture.startsWith("/") || capture.startsWith("http"))) {
					throw new WorkboxError("invalid-string", {
						moduleName: "workbox-routing",
						funcName: "registerRoute",
						paramName: "capture"
					});
				}
				// We want to check if Express-style wildcards are in the pathname only.
				// TODO: Remove this log message in v4.
				const valueToCheck = capture.startsWith("http") ? captureUrl.pathname : capture;
				// See https://github.com/pillarjs/path-to-regexp#parameters
				const wildcards = "[*:?+]";
				if (new RegExp(`${wildcards}`).exec(valueToCheck)) {
					logger.debug(`The '$capture' parameter contains an Express-style wildcard ` + `character (${wildcards}). Strings are now always interpreted as ` + `exact matches; use a RegExp for partial or wildcard matches.`);
				}
			}
			const matchCallback = ({ url }) => {
				{
					if (url.pathname === captureUrl.pathname && url.origin !== captureUrl.origin) {
						logger.debug(`${capture} only partially matches the cross-origin URL ` + `${url.toString()}. This route will only handle cross-origin requests ` + `if they match the entire URL.`);
					}
				}
				return url.href === captureUrl.href;
			};
			// If `capture` is a string then `handler` and `method` must be present.
			route = new Route(matchCallback, handler, method);
		} else if (capture instanceof RegExp) {
			// If `capture` is a `RegExp` then `handler` and `method` must be present.
			route = new RegExpRoute(capture, handler, method);
		} else if (typeof capture === "function") {
			// If `capture` is a function then `handler` and `method` must be present.
			route = new Route(capture, handler, method);
		} else if (capture instanceof Route) {
			route = capture;
		} else {
			throw new WorkboxError("unsupported-route-type", {
				moduleName: "workbox-routing",
				funcName: "registerRoute",
				paramName: "capture"
			});
		}
		const defaultRouter = getOrCreateDefaultRouter();
		defaultRouter.registerRoute(route);
		return route;
	}
	/*
	Copyright 2018 Google LLC
	
	Use of this source code is governed by an MIT-style
	license that can be found in the LICENSE file or at
	https://opensource.org/licenses/MIT.
	*/
	const _cacheNameDetails = {
		googleAnalytics: "googleAnalytics",
		precache: "precache-v2",
		prefix: "workbox",
		runtime: "runtime",
		suffix: typeof registration !== "undefined" ? registration.scope : ""
	};
	const _createCacheName = (cacheName) => {
		return [
			_cacheNameDetails.prefix,
			cacheName,
			_cacheNameDetails.suffix
		].filter((value) => value && value.length > 0).join("-");
	};
	const eachCacheNameDetail = (fn) => {
		for (const key of Object.keys(_cacheNameDetails)) {
			fn(key);
		}
	};
	const cacheNames = {
		updateDetails: (details) => {
			eachCacheNameDetail((key) => {
				if (typeof details[key] === "string") {
					_cacheNameDetails[key] = details[key];
				}
			});
		},
		getGoogleAnalyticsName: (userCacheName) => {
			return userCacheName || _createCacheName(_cacheNameDetails.googleAnalytics);
		},
		getPrecacheName: (userCacheName) => {
			return userCacheName || _createCacheName(_cacheNameDetails.precache);
		},
		getPrefix: () => {
			return _cacheNameDetails.prefix;
		},
		getRuntimeName: (userCacheName) => {
			return userCacheName || _createCacheName(_cacheNameDetails.runtime);
		},
		getSuffix: () => {
			return _cacheNameDetails.suffix;
		}
	};
	/*
	Copyright 2019 Google LLC
	Use of this source code is governed by an MIT-style
	license that can be found in the LICENSE file or at
	https://opensource.org/licenses/MIT.
	*/
	/**
	* A helper function that prevents a promise from being flagged as unused.
	*
	* @private
	**/
	function dontWaitFor(promise) {
		// Effective no-op.
		void promise.then(() => {});
	}
	/*
	Copyright 2018 Google LLC
	
	Use of this source code is governed by an MIT-style
	license that can be found in the LICENSE file or at
	https://opensource.org/licenses/MIT.
	*/
	// Callbacks to be executed whenever there's a quota error.
	// Can't change Function type right now.
	// eslint-disable-next-line @typescript-eslint/ban-types
	const quotaErrorCallbacks = new Set();
	/*
	Copyright 2019 Google LLC
	
	Use of this source code is governed by an MIT-style
	license that can be found in the LICENSE file or at
	https://opensource.org/licenses/MIT.
	*/
	/**
	* Adds a function to the set of quotaErrorCallbacks that will be executed if
	* there's a quota error.
	*
	* @param {Function} callback
	* @memberof workbox-core
	*/
	// Can't change Function type
	// eslint-disable-next-line @typescript-eslint/ban-types
	function registerQuotaErrorCallback(callback) {
		{
			finalAssertExports.isType(callback, "function", {
				moduleName: "workbox-core",
				funcName: "register",
				paramName: "callback"
			});
		}
		quotaErrorCallbacks.add(callback);
		{
			logger.log("Registered a callback to respond to quota errors.", callback);
		}
	}
	function _extends() {
		return _extends = Object.assign ? Object.assign.bind() : function(n) {
			for (var e = 1; e < arguments.length; e++) {
				var t = arguments[e];
				for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]);
			}
			return n;
		}, _extends.apply(null, arguments);
	}
	const instanceOfAny = (object, constructors) => constructors.some((c) => object instanceof c);
	let idbProxyableTypes;
	let cursorAdvanceMethods;
	// This is a function to prevent it throwing up in node environments.
	function getIdbProxyableTypes() {
		return idbProxyableTypes || (idbProxyableTypes = [
			IDBDatabase,
			IDBObjectStore,
			IDBIndex,
			IDBCursor,
			IDBTransaction
		]);
	}
	// This is a function to prevent it throwing up in node environments.
	function getCursorAdvanceMethods() {
		return cursorAdvanceMethods || (cursorAdvanceMethods = [
			IDBCursor.prototype.advance,
			IDBCursor.prototype.continue,
			IDBCursor.prototype.continuePrimaryKey
		]);
	}
	const cursorRequestMap = new WeakMap();
	const transactionDoneMap = new WeakMap();
	const transactionStoreNamesMap = new WeakMap();
	const transformCache = new WeakMap();
	const reverseTransformCache = new WeakMap();
	function promisifyRequest(request) {
		const promise = new Promise((resolve, reject) => {
			const unlisten = () => {
				request.removeEventListener("success", success);
				request.removeEventListener("error", error);
			};
			const success = () => {
				resolve(wrap(request.result));
				unlisten();
			};
			const error = () => {
				reject(request.error);
				unlisten();
			};
			request.addEventListener("success", success);
			request.addEventListener("error", error);
		});
		promise.then((value) => {
			// Since cursoring reuses the IDBRequest (*sigh*), we cache it for later retrieval
			// (see wrapFunction).
			if (value instanceof IDBCursor) {
				cursorRequestMap.set(value, request);
			}
			// Catching to avoid "Uncaught Promise exceptions"
		}).catch(() => {});
		// This mapping exists in reverseTransformCache but doesn't doesn't exist in transformCache. This
		// is because we create many promises from a single IDBRequest.
		reverseTransformCache.set(promise, request);
		return promise;
	}
	function cacheDonePromiseForTransaction(tx) {
		// Early bail if we've already created a done promise for this transaction.
		if (transactionDoneMap.has(tx)) return;
		const done = new Promise((resolve, reject) => {
			const unlisten = () => {
				tx.removeEventListener("complete", complete);
				tx.removeEventListener("error", error);
				tx.removeEventListener("abort", error);
			};
			const complete = () => {
				resolve();
				unlisten();
			};
			const error = () => {
				reject(tx.error || new DOMException("AbortError", "AbortError"));
				unlisten();
			};
			tx.addEventListener("complete", complete);
			tx.addEventListener("error", error);
			tx.addEventListener("abort", error);
		});
		// Cache it for later retrieval.
		transactionDoneMap.set(tx, done);
	}
	let idbProxyTraps = {
		get(target, prop, receiver) {
			if (target instanceof IDBTransaction) {
				// Special handling for transaction.done.
				if (prop === "done") return transactionDoneMap.get(target);
				// Polyfill for objectStoreNames because of Edge.
				if (prop === "objectStoreNames") {
					return target.objectStoreNames || transactionStoreNamesMap.get(target);
				}
				// Make tx.store return the only store in the transaction, or undefined if there are many.
				if (prop === "store") {
					return receiver.objectStoreNames[1] ? undefined : receiver.objectStore(receiver.objectStoreNames[0]);
				}
			}
			// Else transform whatever we get back.
			return wrap(target[prop]);
		},
		set(target, prop, value) {
			target[prop] = value;
			return true;
		},
		has(target, prop) {
			if (target instanceof IDBTransaction && (prop === "done" || prop === "store")) {
				return true;
			}
			return prop in target;
		}
	};
	function replaceTraps(callback) {
		idbProxyTraps = callback(idbProxyTraps);
	}
	function wrapFunction(func) {
		// Due to expected object equality (which is enforced by the caching in `wrap`), we
		// only create one new func per func.
		// Edge doesn't support objectStoreNames (booo), so we polyfill it here.
		if (func === IDBDatabase.prototype.transaction && !("objectStoreNames" in IDBTransaction.prototype)) {
			return function(storeNames, ...args) {
				const tx = func.call(unwrap(this), storeNames, ...args);
				transactionStoreNamesMap.set(tx, storeNames.sort ? storeNames.sort() : [storeNames]);
				return wrap(tx);
			};
		}
		// Cursor methods are special, as the behaviour is a little more different to standard IDB. In
		// IDB, you advance the cursor and wait for a new 'success' on the IDBRequest that gave you the
		// cursor. It's kinda like a promise that can resolve with many values. That doesn't make sense
		// with real promises, so each advance methods returns a new promise for the cursor object, or
		// undefined if the end of the cursor has been reached.
		if (getCursorAdvanceMethods().includes(func)) {
			return function(...args) {
				// Calling the original function with the proxy as 'this' causes ILLEGAL INVOCATION, so we use
				// the original object.
				func.apply(unwrap(this), args);
				return wrap(cursorRequestMap.get(this));
			};
		}
		return function(...args) {
			// Calling the original function with the proxy as 'this' causes ILLEGAL INVOCATION, so we use
			// the original object.
			return wrap(func.apply(unwrap(this), args));
		};
	}
	function transformCachableValue(value) {
		if (typeof value === "function") return wrapFunction(value);
		// This doesn't return, it just creates a 'done' promise for the transaction,
		// which is later returned for transaction.done (see idbObjectHandler).
		if (value instanceof IDBTransaction) cacheDonePromiseForTransaction(value);
		if (instanceOfAny(value, getIdbProxyableTypes())) return new Proxy(value, idbProxyTraps);
		// Return the same value back if we're not going to transform it.
		return value;
	}
	function wrap(value) {
		// We sometimes generate multiple promises from a single IDBRequest (eg when cursoring), because
		// IDB is weird and a single IDBRequest can yield many responses, so these can't be cached.
		if (value instanceof IDBRequest) return promisifyRequest(value);
		// If we've already transformed this value before, reuse the transformed value.
		// This is faster, but it also provides object equality.
		if (transformCache.has(value)) return transformCache.get(value);
		const newValue = transformCachableValue(value);
		// Not all types are transformed.
		// These may be primitive types, so they can't be WeakMap keys.
		if (newValue !== value) {
			transformCache.set(value, newValue);
			reverseTransformCache.set(newValue, value);
		}
		return newValue;
	}
	const unwrap = (value) => reverseTransformCache.get(value);
	/**
	* Open a database.
	*
	* @param name Name of the database.
	* @param version Schema version.
	* @param callbacks Additional callbacks.
	*/
	function openDB(name, version, { blocked, upgrade, blocking, terminated } = {}) {
		const request = indexedDB.open(name, version);
		const openPromise = wrap(request);
		if (upgrade) {
			request.addEventListener("upgradeneeded", (event) => {
				upgrade(wrap(request.result), event.oldVersion, event.newVersion, wrap(request.transaction), event);
			});
		}
		if (blocked) {
			request.addEventListener("blocked", (event) => blocked(
				// Casting due to https://github.com/microsoft/TypeScript-DOM-lib-generator/pull/1405
				event.oldVersion,
				event.newVersion,
				event
			));
		}
		openPromise.then((db) => {
			if (terminated) db.addEventListener("close", () => terminated());
			if (blocking) {
				db.addEventListener("versionchange", (event) => blocking(event.oldVersion, event.newVersion, event));
			}
		}).catch(() => {});
		return openPromise;
	}
	/**
	* Delete a database.
	*
	* @param name Name of the database.
	*/
	function deleteDB(name, { blocked } = {}) {
		const request = indexedDB.deleteDatabase(name);
		if (blocked) {
			request.addEventListener("blocked", (event) => blocked(
				// Casting due to https://github.com/microsoft/TypeScript-DOM-lib-generator/pull/1405
				event.oldVersion,
				event
			));
		}
		return wrap(request).then(() => undefined);
	}
	const readMethods = [
		"get",
		"getKey",
		"getAll",
		"getAllKeys",
		"count"
	];
	const writeMethods = [
		"put",
		"add",
		"delete",
		"clear"
	];
	const cachedMethods = new Map();
	function getMethod(target, prop) {
		if (!(target instanceof IDBDatabase && !(prop in target) && typeof prop === "string")) {
			return;
		}
		if (cachedMethods.get(prop)) return cachedMethods.get(prop);
		const targetFuncName = prop.replace(/FromIndex$/, "");
		const useIndex = prop !== targetFuncName;
		const isWrite = writeMethods.includes(targetFuncName);
		if (!(targetFuncName in (useIndex ? IDBIndex : IDBObjectStore).prototype) || !(isWrite || readMethods.includes(targetFuncName))) {
			return;
		}
		const method = async function(storeName, ...args) {
			// isWrite ? 'readwrite' : undefined gzipps better, but fails in Edge :(
			const tx = this.transaction(storeName, isWrite ? "readwrite" : "readonly");
			let target = tx.store;
			if (useIndex) target = target.index(args.shift());
			// Must reject if op rejects.
			// If it's a write operation, must reject if tx.done rejects.
			// Must reject with op rejection first.
			// Must resolve with op value.
			// Must handle both promises (no unhandled rejections)
			return (await Promise.all([target[targetFuncName](...args), isWrite && tx.done]))[0];
		};
		cachedMethods.set(prop, method);
		return method;
	}
	replaceTraps((oldTraps) => _extends({}, oldTraps, {
		get: (target, prop, receiver) => getMethod(target, prop) || oldTraps.get(target, prop, receiver),
		has: (target, prop) => !!getMethod(target, prop) || oldTraps.has(target, prop)
	}));
	// @ts-ignore
	try {
		self["workbox:expiration:7.4.0"] && _();
	} catch (e) {}
	/*
	Copyright 2018 Google LLC
	
	Use of this source code is governed by an MIT-style
	license that can be found in the LICENSE file or at
	https://opensource.org/licenses/MIT.
	*/
	const DB_NAME = "workbox-expiration";
	const CACHE_OBJECT_STORE = "cache-entries";
	const normalizeURL = (unNormalizedUrl) => {
		const url = new URL(unNormalizedUrl, location.href);
		url.hash = "";
		return url.href;
	};
	/**
	* Returns the timestamp model.
	*
	* @private
	*/
	class CacheTimestampsModel {
		/**
		*
		* @param {string} cacheName
		*
		* @private
		*/
		constructor(cacheName) {
			this._db = null;
			this._cacheName = cacheName;
		}
		/**
		* Performs an upgrade of indexedDB.
		*
		* @param {IDBPDatabase<CacheDbSchema>} db
		*
		* @private
		*/
		_upgradeDb(db) {
			// TODO(philipwalton): EdgeHTML doesn't support arrays as a keyPath, so we
			// have to use the `id` keyPath here and create our own values (a
			// concatenation of `url + cacheName`) instead of simply using
			// `keyPath: ['url', 'cacheName']`, which is supported in other browsers.
			const objStore = db.createObjectStore(CACHE_OBJECT_STORE, { keyPath: "id" });
			// TODO(philipwalton): once we don't have to support EdgeHTML, we can
			// create a single index with the keyPath `['cacheName', 'timestamp']`
			// instead of doing both these indexes.
			objStore.createIndex("cacheName", "cacheName", { unique: false });
			objStore.createIndex("timestamp", "timestamp", { unique: false });
		}
		/**
		* Performs an upgrade of indexedDB and deletes deprecated DBs.
		*
		* @param {IDBPDatabase<CacheDbSchema>} db
		*
		* @private
		*/
		_upgradeDbAndDeleteOldDbs(db) {
			this._upgradeDb(db);
			if (this._cacheName) {
				void deleteDB(this._cacheName);
			}
		}
		/**
		* @param {string} url
		* @param {number} timestamp
		*
		* @private
		*/
		async setTimestamp(url, timestamp) {
			url = normalizeURL(url);
			const entry = {
				url,
				timestamp,
				cacheName: this._cacheName,
				// Creating an ID from the URL and cache name won't be necessary once
				// Edge switches to Chromium and all browsers we support work with
				// array keyPaths.
				id: this._getId(url)
			};
			const db = await this.getDb();
			const tx = db.transaction(CACHE_OBJECT_STORE, "readwrite", { durability: "relaxed" });
			await tx.store.put(entry);
			await tx.done;
		}
		/**
		* Returns the timestamp stored for a given URL.
		*
		* @param {string} url
		* @return {number | undefined}
		*
		* @private
		*/
		async getTimestamp(url) {
			const db = await this.getDb();
			const entry = await db.get(CACHE_OBJECT_STORE, this._getId(url));
			return entry === null || entry === void 0 ? void 0 : entry.timestamp;
		}
		/**
		* Iterates through all the entries in the object store (from newest to
		* oldest) and removes entries once either `maxCount` is reached or the
		* entry's timestamp is less than `minTimestamp`.
		*
		* @param {number} minTimestamp
		* @param {number} maxCount
		* @return {Array<string>}
		*
		* @private
		*/
		async expireEntries(minTimestamp, maxCount) {
			const db = await this.getDb();
			let cursor = await db.transaction(CACHE_OBJECT_STORE).store.index("timestamp").openCursor(null, "prev");
			const entriesToDelete = [];
			let entriesNotDeletedCount = 0;
			while (cursor) {
				const result = cursor.value;
				// TODO(philipwalton): once we can use a multi-key index, we
				// won't have to check `cacheName` here.
				if (result.cacheName === this._cacheName) {
					// Delete an entry if it's older than the max age or
					// if we already have the max number allowed.
					if (minTimestamp && result.timestamp < minTimestamp || maxCount && entriesNotDeletedCount >= maxCount) {
						// TODO(philipwalton): we should be able to delete the
						// entry right here, but doing so causes an iteration
						// bug in Safari stable (fixed in TP). Instead we can
						// store the keys of the entries to delete, and then
						// delete the separate transactions.
						// https://github.com/GoogleChrome/workbox/issues/1978
						// cursor.delete();
						// We only need to return the URL, not the whole entry.
						entriesToDelete.push(cursor.value);
					} else {
						entriesNotDeletedCount++;
					}
				}
				cursor = await cursor.continue();
			}
			// TODO(philipwalton): once the Safari bug in the following issue is fixed,
			// we should be able to remove this loop and do the entry deletion in the
			// cursor loop above:
			// https://github.com/GoogleChrome/workbox/issues/1978
			const urlsDeleted = [];
			for (const entry of entriesToDelete) {
				await db.delete(CACHE_OBJECT_STORE, entry.id);
				urlsDeleted.push(entry.url);
			}
			return urlsDeleted;
		}
		/**
		* Takes a URL and returns an ID that will be unique in the object store.
		*
		* @param {string} url
		* @return {string}
		*
		* @private
		*/
		_getId(url) {
			// Creating an ID from the URL and cache name won't be necessary once
			// Edge switches to Chromium and all browsers we support work with
			// array keyPaths.
			return this._cacheName + "|" + normalizeURL(url);
		}
		/**
		* Returns an open connection to the database.
		*
		* @private
		*/
		async getDb() {
			if (!this._db) {
				this._db = await openDB(DB_NAME, 1, { upgrade: this._upgradeDbAndDeleteOldDbs.bind(this) });
			}
			return this._db;
		}
	}
	/*
	Copyright 2018 Google LLC
	
	Use of this source code is governed by an MIT-style
	license that can be found in the LICENSE file or at
	https://opensource.org/licenses/MIT.
	*/
	/**
	* The `CacheExpiration` class allows you define an expiration and / or
	* limit on the number of responses stored in a
	* [`Cache`](https://developer.mozilla.org/en-US/docs/Web/API/Cache).
	*
	* @memberof workbox-expiration
	*/
	class CacheExpiration {
		/**
		* To construct a new CacheExpiration instance you must provide at least
		* one of the `config` properties.
		*
		* @param {string} cacheName Name of the cache to apply restrictions to.
		* @param {Object} config
		* @param {number} [config.maxEntries] The maximum number of entries to cache.
		* Entries used the least will be removed as the maximum is reached.
		* @param {number} [config.maxAgeSeconds] The maximum age of an entry before
		* it's treated as stale and removed.
		* @param {Object} [config.matchOptions] The [`CacheQueryOptions`](https://developer.mozilla.org/en-US/docs/Web/API/Cache/delete#Parameters)
		* that will be used when calling `delete()` on the cache.
		*/
		constructor(cacheName, config = {}) {
			this._isRunning = false;
			this._rerunRequested = false;
			{
				finalAssertExports.isType(cacheName, "string", {
					moduleName: "workbox-expiration",
					className: "CacheExpiration",
					funcName: "constructor",
					paramName: "cacheName"
				});
				if (!(config.maxEntries || config.maxAgeSeconds)) {
					throw new WorkboxError("max-entries-or-age-required", {
						moduleName: "workbox-expiration",
						className: "CacheExpiration",
						funcName: "constructor"
					});
				}
				if (config.maxEntries) {
					finalAssertExports.isType(config.maxEntries, "number", {
						moduleName: "workbox-expiration",
						className: "CacheExpiration",
						funcName: "constructor",
						paramName: "config.maxEntries"
					});
				}
				if (config.maxAgeSeconds) {
					finalAssertExports.isType(config.maxAgeSeconds, "number", {
						moduleName: "workbox-expiration",
						className: "CacheExpiration",
						funcName: "constructor",
						paramName: "config.maxAgeSeconds"
					});
				}
			}
			this._maxEntries = config.maxEntries;
			this._maxAgeSeconds = config.maxAgeSeconds;
			this._matchOptions = config.matchOptions;
			this._cacheName = cacheName;
			this._timestampModel = new CacheTimestampsModel(cacheName);
		}
		/**
		* Expires entries for the given cache and given criteria.
		*/
		async expireEntries() {
			if (this._isRunning) {
				this._rerunRequested = true;
				return;
			}
			this._isRunning = true;
			const minTimestamp = this._maxAgeSeconds ? Date.now() - this._maxAgeSeconds * 1e3 : 0;
			const urlsExpired = await this._timestampModel.expireEntries(minTimestamp, this._maxEntries);
			// Delete URLs from the cache
			const cache = await self.caches.open(this._cacheName);
			for (const url of urlsExpired) {
				await cache.delete(url, this._matchOptions);
			}
			{
				if (urlsExpired.length > 0) {
					logger.groupCollapsed(`Expired ${urlsExpired.length} ` + `${urlsExpired.length === 1 ? "entry" : "entries"} and removed ` + `${urlsExpired.length === 1 ? "it" : "them"} from the ` + `'${this._cacheName}' cache.`);
					logger.log(`Expired the following ${urlsExpired.length === 1 ? "URL" : "URLs"}:`);
					urlsExpired.forEach((url) => logger.log(`    ${url}`));
					logger.groupEnd();
				} else {
					logger.debug(`Cache expiration ran and found no entries to remove.`);
				}
			}
			this._isRunning = false;
			if (this._rerunRequested) {
				this._rerunRequested = false;
				dontWaitFor(this.expireEntries());
			}
		}
		/**
		* Update the timestamp for the given URL. This ensures the when
		* removing entries based on maximum entries, most recently used
		* is accurate or when expiring, the timestamp is up-to-date.
		*
		* @param {string} url
		*/
		async updateTimestamp(url) {
			{
				finalAssertExports.isType(url, "string", {
					moduleName: "workbox-expiration",
					className: "CacheExpiration",
					funcName: "updateTimestamp",
					paramName: "url"
				});
			}
			await this._timestampModel.setTimestamp(url, Date.now());
		}
		/**
		* Can be used to check if a URL has expired or not before it's used.
		*
		* This requires a look up from IndexedDB, so can be slow.
		*
		* Note: This method will not remove the cached entry, call
		* `expireEntries()` to remove indexedDB and Cache entries.
		*
		* @param {string} url
		* @return {boolean}
		*/
		async isURLExpired(url) {
			if (!this._maxAgeSeconds) {
				{
					throw new WorkboxError(`expired-test-without-max-age`, {
						methodName: "isURLExpired",
						paramName: "maxAgeSeconds"
					});
				}
			} else {
				const timestamp = await this._timestampModel.getTimestamp(url);
				const expireOlderThan = Date.now() - this._maxAgeSeconds * 1e3;
				return timestamp !== undefined ? timestamp < expireOlderThan : true;
			}
		}
		/**
		* Removes the IndexedDB object store used to keep track of cache expiration
		* metadata.
		*/
		async delete() {
			// Make sure we don't attempt another rerun if we're called in the middle of
			// a cache expiration.
			this._rerunRequested = false;
			await this._timestampModel.expireEntries(Infinity);
		}
	}
	/*
	Copyright 2018 Google LLC
	
	Use of this source code is governed by an MIT-style
	license that can be found in the LICENSE file or at
	https://opensource.org/licenses/MIT.
	*/
	/**
	* This plugin can be used in a `workbox-strategy` to regularly enforce a
	* limit on the age and / or the number of cached requests.
	*
	* It can only be used with `workbox-strategy` instances that have a
	* [custom `cacheName` property set](/web/tools/workbox/guides/configure-workbox#custom_cache_names_in_strategies).
	* In other words, it can't be used to expire entries in strategy that uses the
	* default runtime cache name.
	*
	* Whenever a cached response is used or updated, this plugin will look
	* at the associated cache and remove any old or extra responses.
	*
	* When using `maxAgeSeconds`, responses may be used *once* after expiring
	* because the expiration clean up will not have occurred until *after* the
	* cached response has been used. If the response has a "Date" header, then
	* a light weight expiration check is performed and the response will not be
	* used immediately.
	*
	* When using `maxEntries`, the entry least-recently requested will be removed
	* from the cache first.
	*
	* @memberof workbox-expiration
	*/
	class ExpirationPlugin {
		/**
		* @param {ExpirationPluginOptions} config
		* @param {number} [config.maxEntries] The maximum number of entries to cache.
		* Entries used the least will be removed as the maximum is reached.
		* @param {number} [config.maxAgeSeconds] The maximum age of an entry before
		* it's treated as stale and removed.
		* @param {Object} [config.matchOptions] The [`CacheQueryOptions`](https://developer.mozilla.org/en-US/docs/Web/API/Cache/delete#Parameters)
		* that will be used when calling `delete()` on the cache.
		* @param {boolean} [config.purgeOnQuotaError] Whether to opt this cache in to
		* automatic deletion if the available storage quota has been exceeded.
		*/
		constructor(config = {}) {
			/**
			* A "lifecycle" callback that will be triggered automatically by the
			* `workbox-strategies` handlers when a `Response` is about to be returned
			* from a [Cache](https://developer.mozilla.org/en-US/docs/Web/API/Cache) to
			* the handler. It allows the `Response` to be inspected for freshness and
			* prevents it from being used if the `Response`'s `Date` header value is
			* older than the configured `maxAgeSeconds`.
			*
			* @param {Object} options
			* @param {string} options.cacheName Name of the cache the response is in.
			* @param {Response} options.cachedResponse The `Response` object that's been
			*     read from a cache and whose freshness should be checked.
			* @return {Response} Either the `cachedResponse`, if it's
			*     fresh, or `null` if the `Response` is older than `maxAgeSeconds`.
			*
			* @private
			*/
			this.cachedResponseWillBeUsed = async ({ event, request, cacheName, cachedResponse }) => {
				if (!cachedResponse) {
					return null;
				}
				const isFresh = this._isResponseDateFresh(cachedResponse);
				// Expire entries to ensure that even if the expiration date has
				// expired, it'll only be used once.
				const cacheExpiration = this._getCacheExpiration(cacheName);
				dontWaitFor(cacheExpiration.expireEntries());
				// Update the metadata for the request URL to the current timestamp,
				// but don't `await` it as we don't want to block the response.
				const updateTimestampDone = cacheExpiration.updateTimestamp(request.url);
				if (event) {
					try {
						event.waitUntil(updateTimestampDone);
					} catch (error) {
						{
							// The event may not be a fetch event; only log the URL if it is.
							if ("request" in event) {
								logger.warn(`Unable to ensure service worker stays alive when ` + `updating cache entry for ` + `'${getFriendlyURL(event.request.url)}'.`);
							}
						}
					}
				}
				return isFresh ? cachedResponse : null;
			};
			/**
			* A "lifecycle" callback that will be triggered automatically by the
			* `workbox-strategies` handlers when an entry is added to a cache.
			*
			* @param {Object} options
			* @param {string} options.cacheName Name of the cache that was updated.
			* @param {string} options.request The Request for the cached entry.
			*
			* @private
			*/
			this.cacheDidUpdate = async ({ cacheName, request }) => {
				{
					finalAssertExports.isType(cacheName, "string", {
						moduleName: "workbox-expiration",
						className: "Plugin",
						funcName: "cacheDidUpdate",
						paramName: "cacheName"
					});
					finalAssertExports.isInstance(request, Request, {
						moduleName: "workbox-expiration",
						className: "Plugin",
						funcName: "cacheDidUpdate",
						paramName: "request"
					});
				}
				const cacheExpiration = this._getCacheExpiration(cacheName);
				await cacheExpiration.updateTimestamp(request.url);
				await cacheExpiration.expireEntries();
			};
			{
				if (!(config.maxEntries || config.maxAgeSeconds)) {
					throw new WorkboxError("max-entries-or-age-required", {
						moduleName: "workbox-expiration",
						className: "Plugin",
						funcName: "constructor"
					});
				}
				if (config.maxEntries) {
					finalAssertExports.isType(config.maxEntries, "number", {
						moduleName: "workbox-expiration",
						className: "Plugin",
						funcName: "constructor",
						paramName: "config.maxEntries"
					});
				}
				if (config.maxAgeSeconds) {
					finalAssertExports.isType(config.maxAgeSeconds, "number", {
						moduleName: "workbox-expiration",
						className: "Plugin",
						funcName: "constructor",
						paramName: "config.maxAgeSeconds"
					});
				}
			}
			this._config = config;
			this._maxAgeSeconds = config.maxAgeSeconds;
			this._cacheExpirations = new Map();
			if (config.purgeOnQuotaError) {
				registerQuotaErrorCallback(() => this.deleteCacheAndMetadata());
			}
		}
		/**
		* A simple helper method to return a CacheExpiration instance for a given
		* cache name.
		*
		* @param {string} cacheName
		* @return {CacheExpiration}
		*
		* @private
		*/
		_getCacheExpiration(cacheName) {
			if (cacheName === cacheNames.getRuntimeName()) {
				throw new WorkboxError("expire-custom-caches-only");
			}
			let cacheExpiration = this._cacheExpirations.get(cacheName);
			if (!cacheExpiration) {
				cacheExpiration = new CacheExpiration(cacheName, this._config);
				this._cacheExpirations.set(cacheName, cacheExpiration);
			}
			return cacheExpiration;
		}
		/**
		* @param {Response} cachedResponse
		* @return {boolean}
		*
		* @private
		*/
		_isResponseDateFresh(cachedResponse) {
			if (!this._maxAgeSeconds) {
				// We aren't expiring by age, so return true, it's fresh
				return true;
			}
			// Check if the 'date' header will suffice a quick expiration check.
			// See https://github.com/GoogleChromeLabs/sw-toolbox/issues/164 for
			// discussion.
			const dateHeaderTimestamp = this._getDateHeaderTimestamp(cachedResponse);
			if (dateHeaderTimestamp === null) {
				// Unable to parse date, so assume it's fresh.
				return true;
			}
			// If we have a valid headerTime, then our response is fresh iff the
			// headerTime plus maxAgeSeconds is greater than the current time.
			const now = Date.now();
			return dateHeaderTimestamp >= now - this._maxAgeSeconds * 1e3;
		}
		/**
		* This method will extract the data header and parse it into a useful
		* value.
		*
		* @param {Response} cachedResponse
		* @return {number|null}
		*
		* @private
		*/
		_getDateHeaderTimestamp(cachedResponse) {
			if (!cachedResponse.headers.has("date")) {
				return null;
			}
			const dateHeader = cachedResponse.headers.get("date");
			const parsedDate = new Date(dateHeader);
			const headerTime = parsedDate.getTime();
			// If the Date header was invalid for some reason, parsedDate.getTime()
			// will return NaN.
			if (isNaN(headerTime)) {
				return null;
			}
			return headerTime;
		}
		/**
		* This is a helper method that performs two operations:
		*
		* - Deletes *all* the underlying Cache instances associated with this plugin
		* instance, by calling caches.delete() on your behalf.
		* - Deletes the metadata from IndexedDB used to keep track of expiration
		* details for each Cache instance.
		*
		* When using cache expiration, calling this method is preferable to calling
		* `caches.delete()` directly, since this will ensure that the IndexedDB
		* metadata is also cleanly removed and open IndexedDB instances are deleted.
		*
		* Note that if you're *not* using cache expiration for a given cache, calling
		* `caches.delete()` and passing in the cache's name should be sufficient.
		* There is no Workbox-specific method needed for cleanup in that case.
		*/
		async deleteCacheAndMetadata() {
			// Do this one at a time instead of all at once via `Promise.all()` to
			// reduce the chance of inconsistency if a promise rejects.
			for (const [cacheName, cacheExpiration] of this._cacheExpirations) {
				await self.caches.delete(cacheName);
				await cacheExpiration.delete();
			}
			// Reset this._cacheExpirations to its initial state.
			this._cacheExpirations = new Map();
		}
	}
	// @ts-ignore
	try {
		self["workbox:cacheable-response:7.4.0"] && _();
	} catch (e) {}
	/*
	Copyright 2018 Google LLC
	
	Use of this source code is governed by an MIT-style
	license that can be found in the LICENSE file or at
	https://opensource.org/licenses/MIT.
	*/
	/**
	* This class allows you to set up rules determining what
	* status codes and/or headers need to be present in order for a
	* [`Response`](https://developer.mozilla.org/en-US/docs/Web/API/Response)
	* to be considered cacheable.
	*
	* @memberof workbox-cacheable-response
	*/
	class CacheableResponse {
		/**
		* To construct a new CacheableResponse instance you must provide at least
		* one of the `config` properties.
		*
		* If both `statuses` and `headers` are specified, then both conditions must
		* be met for the `Response` to be considered cacheable.
		*
		* @param {Object} config
		* @param {Array<number>} [config.statuses] One or more status codes that a
		* `Response` can have and be considered cacheable.
		* @param {Object<string,string>} [config.headers] A mapping of header names
		* and expected values that a `Response` can have and be considered cacheable.
		* If multiple headers are provided, only one needs to be present.
		*/
		constructor(config = {}) {
			{
				if (!(config.statuses || config.headers)) {
					throw new WorkboxError("statuses-or-headers-required", {
						moduleName: "workbox-cacheable-response",
						className: "CacheableResponse",
						funcName: "constructor"
					});
				}
				if (config.statuses) {
					finalAssertExports.isArray(config.statuses, {
						moduleName: "workbox-cacheable-response",
						className: "CacheableResponse",
						funcName: "constructor",
						paramName: "config.statuses"
					});
				}
				if (config.headers) {
					finalAssertExports.isType(config.headers, "object", {
						moduleName: "workbox-cacheable-response",
						className: "CacheableResponse",
						funcName: "constructor",
						paramName: "config.headers"
					});
				}
			}
			this._statuses = config.statuses;
			this._headers = config.headers;
		}
		/**
		* Checks a response to see whether it's cacheable or not, based on this
		* object's configuration.
		*
		* @param {Response} response The response whose cacheability is being
		* checked.
		* @return {boolean} `true` if the `Response` is cacheable, and `false`
		* otherwise.
		*/
		isResponseCacheable(response) {
			{
				finalAssertExports.isInstance(response, Response, {
					moduleName: "workbox-cacheable-response",
					className: "CacheableResponse",
					funcName: "isResponseCacheable",
					paramName: "response"
				});
			}
			let cacheable = true;
			if (this._statuses) {
				cacheable = this._statuses.includes(response.status);
			}
			if (this._headers && cacheable) {
				cacheable = Object.keys(this._headers).some((headerName) => {
					return response.headers.get(headerName) === this._headers[headerName];
				});
			}
			{
				if (!cacheable) {
					logger.groupCollapsed(`The request for ` + `'${getFriendlyURL(response.url)}' returned a response that does ` + `not meet the criteria for being cached.`);
					logger.groupCollapsed(`View cacheability criteria here.`);
					logger.log(`Cacheable statuses: ` + JSON.stringify(this._statuses));
					logger.log(`Cacheable headers: ` + JSON.stringify(this._headers, null, 2));
					logger.groupEnd();
					const logFriendlyHeaders = {};
					response.headers.forEach((value, key) => {
						logFriendlyHeaders[key] = value;
					});
					logger.groupCollapsed(`View response status and headers here.`);
					logger.log(`Response status: ${response.status}`);
					logger.log(`Response headers: ` + JSON.stringify(logFriendlyHeaders, null, 2));
					logger.groupEnd();
					logger.groupCollapsed(`View full response details here.`);
					logger.log(response.headers);
					logger.log(response);
					logger.groupEnd();
					logger.groupEnd();
				}
			}
			return cacheable;
		}
	}
	/*
	Copyright 2018 Google LLC
	
	Use of this source code is governed by an MIT-style
	license that can be found in the LICENSE file or at
	https://opensource.org/licenses/MIT.
	*/
	/**
	* A class implementing the `cacheWillUpdate` lifecycle callback. This makes it
	* easier to add in cacheability checks to requests made via Workbox's built-in
	* strategies.
	*
	* @memberof workbox-cacheable-response
	*/
	class CacheableResponsePlugin {
		/**
		* To construct a new CacheableResponsePlugin instance you must provide at
		* least one of the `config` properties.
		*
		* If both `statuses` and `headers` are specified, then both conditions must
		* be met for the `Response` to be considered cacheable.
		*
		* @param {Object} config
		* @param {Array<number>} [config.statuses] One or more status codes that a
		* `Response` can have and be considered cacheable.
		* @param {Object<string,string>} [config.headers] A mapping of header names
		* and expected values that a `Response` can have and be considered cacheable.
		* If multiple headers are provided, only one needs to be present.
		*/
		constructor(config) {
			/**
			* @param {Object} options
			* @param {Response} options.response
			* @return {Response|null}
			* @private
			*/
			this.cacheWillUpdate = async ({ response }) => {
				if (this._cacheableResponse.isResponseCacheable(response)) {
					return response;
				}
				return null;
			};
			this._cacheableResponse = new CacheableResponse(config);
		}
	}
	// @ts-ignore
	try {
		self["workbox:strategies:7.4.0"] && _();
	} catch (e) {}
	/*
	Copyright 2018 Google LLC
	
	Use of this source code is governed by an MIT-style
	license that can be found in the LICENSE file or at
	https://opensource.org/licenses/MIT.
	*/
	const cacheOkAndOpaquePlugin = { 
	/**
	* Returns a valid response (to allow caching) if the status is 200 (OK) or
	* 0 (opaque).
	*
	* @param {Object} options
	* @param {Response} options.response
	* @return {Response|null}
	*
	* @private
	*/
cacheWillUpdate: async ({ response }) => {
		if (response.status === 200 || response.status === 0) {
			return response;
		}
		return null;
	} };
	/*
	Copyright 2020 Google LLC
	Use of this source code is governed by an MIT-style
	license that can be found in the LICENSE file or at
	https://opensource.org/licenses/MIT.
	*/
	function stripParams(fullURL, ignoreParams) {
		const strippedURL = new URL(fullURL);
		for (const param of ignoreParams) {
			strippedURL.searchParams.delete(param);
		}
		return strippedURL.href;
	}
	/**
	* Matches an item in the cache, ignoring specific URL params. This is similar
	* to the `ignoreSearch` option, but it allows you to ignore just specific
	* params (while continuing to match on the others).
	*
	* @private
	* @param {Cache} cache
	* @param {Request} request
	* @param {Object} matchOptions
	* @param {Array<string>} ignoreParams
	* @return {Promise<Response|undefined>}
	*/
	async function cacheMatchIgnoreParams(cache, request, ignoreParams, matchOptions) {
		const strippedRequestURL = stripParams(request.url, ignoreParams);
		// If the request doesn't include any ignored params, match as normal.
		if (request.url === strippedRequestURL) {
			return cache.match(request, matchOptions);
		}
		// Otherwise, match by comparing keys
		const keysOptions = Object.assign(Object.assign({}, matchOptions), { ignoreSearch: true });
		const cacheKeys = await cache.keys(request, keysOptions);
		for (const cacheKey of cacheKeys) {
			const strippedCacheKeyURL = stripParams(cacheKey.url, ignoreParams);
			if (strippedRequestURL === strippedCacheKeyURL) {
				return cache.match(cacheKey, matchOptions);
			}
		}
		return;
	}
	/*
	Copyright 2018 Google LLC
	
	Use of this source code is governed by an MIT-style
	license that can be found in the LICENSE file or at
	https://opensource.org/licenses/MIT.
	*/
	/**
	* The Deferred class composes Promises in a way that allows for them to be
	* resolved or rejected from outside the constructor. In most cases promises
	* should be used directly, but Deferreds can be necessary when the logic to
	* resolve a promise must be separate.
	*
	* @private
	*/
	class Deferred {
		/**
		* Creates a promise and exposes its resolve and reject functions as methods.
		*/
		constructor() {
			this.promise = new Promise((resolve, reject) => {
				this.resolve = resolve;
				this.reject = reject;
			});
		}
	}
	/*
	Copyright 2018 Google LLC
	
	Use of this source code is governed by an MIT-style
	license that can be found in the LICENSE file or at
	https://opensource.org/licenses/MIT.
	*/
	/**
	* Runs all of the callback functions, one at a time sequentially, in the order
	* in which they were registered.
	*
	* @memberof workbox-core
	* @private
	*/
	async function executeQuotaErrorCallbacks() {
		{
			logger.log(`About to run ${quotaErrorCallbacks.size} ` + `callbacks to clean up caches.`);
		}
		for (const callback of quotaErrorCallbacks) {
			await callback();
			{
				logger.log(callback, "is complete.");
			}
		}
		{
			logger.log("Finished running callbacks.");
		}
	}
	/*
	Copyright 2019 Google LLC
	Use of this source code is governed by an MIT-style
	license that can be found in the LICENSE file or at
	https://opensource.org/licenses/MIT.
	*/
	/**
	* Returns a promise that resolves and the passed number of milliseconds.
	* This utility is an async/await-friendly version of `setTimeout`.
	*
	* @param {number} ms
	* @return {Promise}
	* @private
	*/
	function timeout(ms) {
		return new Promise((resolve) => setTimeout(resolve, ms));
	}
	/*
	Copyright 2020 Google LLC
	
	Use of this source code is governed by an MIT-style
	license that can be found in the LICENSE file or at
	https://opensource.org/licenses/MIT.
	*/
	function toRequest(input) {
		return typeof input === "string" ? new Request(input) : input;
	}
	/**
	* A class created every time a Strategy instance calls
	* {@link workbox-strategies.Strategy~handle} or
	* {@link workbox-strategies.Strategy~handleAll} that wraps all fetch and
	* cache actions around plugin callbacks and keeps track of when the strategy
	* is "done" (i.e. all added `event.waitUntil()` promises have resolved).
	*
	* @memberof workbox-strategies
	*/
	class StrategyHandler {
		/**
		* Creates a new instance associated with the passed strategy and event
		* that's handling the request.
		*
		* The constructor also initializes the state that will be passed to each of
		* the plugins handling this request.
		*
		* @param {workbox-strategies.Strategy} strategy
		* @param {Object} options
		* @param {Request|string} options.request A request to run this strategy for.
		* @param {ExtendableEvent} options.event The event associated with the
		*     request.
		* @param {URL} [options.url]
		* @param {*} [options.params] The return value from the
		*     {@link workbox-routing~matchCallback} (if applicable).
		*/
		constructor(strategy, options) {
			this._cacheKeys = {};
			/**
			* The request the strategy is performing (passed to the strategy's
			* `handle()` or `handleAll()` method).
			* @name request
			* @instance
			* @type {Request}
			* @memberof workbox-strategies.StrategyHandler
			*/
			/**
			* The event associated with this request.
			* @name event
			* @instance
			* @type {ExtendableEvent}
			* @memberof workbox-strategies.StrategyHandler
			*/
			/**
			* A `URL` instance of `request.url` (if passed to the strategy's
			* `handle()` or `handleAll()` method).
			* Note: the `url` param will be present if the strategy was invoked
			* from a workbox `Route` object.
			* @name url
			* @instance
			* @type {URL|undefined}
			* @memberof workbox-strategies.StrategyHandler
			*/
			/**
			* A `param` value (if passed to the strategy's
			* `handle()` or `handleAll()` method).
			* Note: the `param` param will be present if the strategy was invoked
			* from a workbox `Route` object and the
			* {@link workbox-routing~matchCallback} returned
			* a truthy value (it will be that value).
			* @name params
			* @instance
			* @type {*|undefined}
			* @memberof workbox-strategies.StrategyHandler
			*/
			{
				finalAssertExports.isInstance(options.event, ExtendableEvent, {
					moduleName: "workbox-strategies",
					className: "StrategyHandler",
					funcName: "constructor",
					paramName: "options.event"
				});
			}
			Object.assign(this, options);
			this.event = options.event;
			this._strategy = strategy;
			this._handlerDeferred = new Deferred();
			this._extendLifetimePromises = [];
			// Copy the plugins list (since it's mutable on the strategy),
			// so any mutations don't affect this handler instance.
			this._plugins = [...strategy.plugins];
			this._pluginStateMap = new Map();
			for (const plugin of this._plugins) {
				this._pluginStateMap.set(plugin, {});
			}
			this.event.waitUntil(this._handlerDeferred.promise);
		}
		/**
		* Fetches a given request (and invokes any applicable plugin callback
		* methods) using the `fetchOptions` (for non-navigation requests) and
		* `plugins` defined on the `Strategy` object.
		*
		* The following plugin lifecycle methods are invoked when using this method:
		* - `requestWillFetch()`
		* - `fetchDidSucceed()`
		* - `fetchDidFail()`
		*
		* @param {Request|string} input The URL or request to fetch.
		* @return {Promise<Response>}
		*/
		async fetch(input) {
			const { event } = this;
			let request = toRequest(input);
			if (request.mode === "navigate" && event instanceof FetchEvent && event.preloadResponse) {
				const possiblePreloadResponse = await event.preloadResponse;
				if (possiblePreloadResponse) {
					{
						logger.log(`Using a preloaded navigation response for ` + `'${getFriendlyURL(request.url)}'`);
					}
					return possiblePreloadResponse;
				}
			}
			// If there is a fetchDidFail plugin, we need to save a clone of the
			// original request before it's either modified by a requestWillFetch
			// plugin or before the original request's body is consumed via fetch().
			const originalRequest = this.hasCallback("fetchDidFail") ? request.clone() : null;
			try {
				for (const cb of this.iterateCallbacks("requestWillFetch")) {
					request = await cb({
						request: request.clone(),
						event
					});
				}
			} catch (err) {
				if (err instanceof Error) {
					throw new WorkboxError("plugin-error-request-will-fetch", { thrownErrorMessage: err.message });
				}
			}
			// The request can be altered by plugins with `requestWillFetch` making
			// the original request (most likely from a `fetch` event) different
			// from the Request we make. Pass both to `fetchDidFail` to aid debugging.
			const pluginFilteredRequest = request.clone();
			try {
				let fetchResponse;
				// See https://github.com/GoogleChrome/workbox/issues/1796
				fetchResponse = await fetch(request, request.mode === "navigate" ? undefined : this._strategy.fetchOptions);
				if ("development" !== "production") {
					logger.debug(`Network request for ` + `'${getFriendlyURL(request.url)}' returned a response with ` + `status '${fetchResponse.status}'.`);
				}
				for (const callback of this.iterateCallbacks("fetchDidSucceed")) {
					fetchResponse = await callback({
						event,
						request: pluginFilteredRequest,
						response: fetchResponse
					});
				}
				return fetchResponse;
			} catch (error) {
				{
					logger.log(`Network request for ` + `'${getFriendlyURL(request.url)}' threw an error.`, error);
				}
				// `originalRequest` will only exist if a `fetchDidFail` callback
				// is being used (see above).
				if (originalRequest) {
					await this.runCallbacks("fetchDidFail", {
						error,
						event,
						originalRequest: originalRequest.clone(),
						request: pluginFilteredRequest.clone()
					});
				}
				throw error;
			}
		}
		/**
		* Calls `this.fetch()` and (in the background) runs `this.cachePut()` on
		* the response generated by `this.fetch()`.
		*
		* The call to `this.cachePut()` automatically invokes `this.waitUntil()`,
		* so you do not have to manually call `waitUntil()` on the event.
		*
		* @param {Request|string} input The request or URL to fetch and cache.
		* @return {Promise<Response>}
		*/
		async fetchAndCachePut(input) {
			const response = await this.fetch(input);
			const responseClone = response.clone();
			void this.waitUntil(this.cachePut(input, responseClone));
			return response;
		}
		/**
		* Matches a request from the cache (and invokes any applicable plugin
		* callback methods) using the `cacheName`, `matchOptions`, and `plugins`
		* defined on the strategy object.
		*
		* The following plugin lifecycle methods are invoked when using this method:
		* - cacheKeyWillBeUsed()
		* - cachedResponseWillBeUsed()
		*
		* @param {Request|string} key The Request or URL to use as the cache key.
		* @return {Promise<Response|undefined>} A matching response, if found.
		*/
		async cacheMatch(key) {
			const request = toRequest(key);
			let cachedResponse;
			const { cacheName, matchOptions } = this._strategy;
			const effectiveRequest = await this.getCacheKey(request, "read");
			const multiMatchOptions = Object.assign(Object.assign({}, matchOptions), { cacheName });
			cachedResponse = await caches.match(effectiveRequest, multiMatchOptions);
			{
				if (cachedResponse) {
					logger.debug(`Found a cached response in '${cacheName}'.`);
				} else {
					logger.debug(`No cached response found in '${cacheName}'.`);
				}
			}
			for (const callback of this.iterateCallbacks("cachedResponseWillBeUsed")) {
				cachedResponse = await callback({
					cacheName,
					matchOptions,
					cachedResponse,
					request: effectiveRequest,
					event: this.event
				}) || undefined;
			}
			return cachedResponse;
		}
		/**
		* Puts a request/response pair in the cache (and invokes any applicable
		* plugin callback methods) using the `cacheName` and `plugins` defined on
		* the strategy object.
		*
		* The following plugin lifecycle methods are invoked when using this method:
		* - cacheKeyWillBeUsed()
		* - cacheWillUpdate()
		* - cacheDidUpdate()
		*
		* @param {Request|string} key The request or URL to use as the cache key.
		* @param {Response} response The response to cache.
		* @return {Promise<boolean>} `false` if a cacheWillUpdate caused the response
		* not be cached, and `true` otherwise.
		*/
		async cachePut(key, response) {
			const request = toRequest(key);
			// Run in the next task to avoid blocking other cache reads.
			// https://github.com/w3c/ServiceWorker/issues/1397
			await timeout(0);
			const effectiveRequest = await this.getCacheKey(request, "write");
			{
				if (effectiveRequest.method && effectiveRequest.method !== "GET") {
					throw new WorkboxError("attempt-to-cache-non-get-request", {
						url: getFriendlyURL(effectiveRequest.url),
						method: effectiveRequest.method
					});
				}
				// See https://github.com/GoogleChrome/workbox/issues/2818
				const vary = response.headers.get("Vary");
				if (vary) {
					logger.debug(`The response for ${getFriendlyURL(effectiveRequest.url)} ` + `has a 'Vary: ${vary}' header. ` + `Consider setting the {ignoreVary: true} option on your strategy ` + `to ensure cache matching and deletion works as expected.`);
				}
			}
			if (!response) {
				{
					logger.error(`Cannot cache non-existent response for ` + `'${getFriendlyURL(effectiveRequest.url)}'.`);
				}
				throw new WorkboxError("cache-put-with-no-response", { url: getFriendlyURL(effectiveRequest.url) });
			}
			const responseToCache = await this._ensureResponseSafeToCache(response);
			if (!responseToCache) {
				{
					logger.debug(`Response '${getFriendlyURL(effectiveRequest.url)}' ` + `will not be cached.`, responseToCache);
				}
				return false;
			}
			const { cacheName, matchOptions } = this._strategy;
			const cache = await self.caches.open(cacheName);
			const hasCacheUpdateCallback = this.hasCallback("cacheDidUpdate");
			const oldResponse = hasCacheUpdateCallback ? await cacheMatchIgnoreParams(
				// TODO(philipwalton): the `__WB_REVISION__` param is a precaching
				// feature. Consider into ways to only add this behavior if using
				// precaching.
				cache,
				effectiveRequest.clone(),
				["__WB_REVISION__"],
				matchOptions
			) : null;
			{
				logger.debug(`Updating the '${cacheName}' cache with a new Response ` + `for ${getFriendlyURL(effectiveRequest.url)}.`);
			}
			try {
				await cache.put(effectiveRequest, hasCacheUpdateCallback ? responseToCache.clone() : responseToCache);
			} catch (error) {
				if (error instanceof Error) {
					// See https://developer.mozilla.org/en-US/docs/Web/API/DOMException#exception-QuotaExceededError
					if (error.name === "QuotaExceededError") {
						await executeQuotaErrorCallbacks();
					}
					throw error;
				}
			}
			for (const callback of this.iterateCallbacks("cacheDidUpdate")) {
				await callback({
					cacheName,
					oldResponse,
					newResponse: responseToCache.clone(),
					request: effectiveRequest,
					event: this.event
				});
			}
			return true;
		}
		/**
		* Checks the list of plugins for the `cacheKeyWillBeUsed` callback, and
		* executes any of those callbacks found in sequence. The final `Request`
		* object returned by the last plugin is treated as the cache key for cache
		* reads and/or writes. If no `cacheKeyWillBeUsed` plugin callbacks have
		* been registered, the passed request is returned unmodified
		*
		* @param {Request} request
		* @param {string} mode
		* @return {Promise<Request>}
		*/
		async getCacheKey(request, mode) {
			const key = `${request.url} | ${mode}`;
			if (!this._cacheKeys[key]) {
				let effectiveRequest = request;
				for (const callback of this.iterateCallbacks("cacheKeyWillBeUsed")) {
					effectiveRequest = toRequest(await callback({
						mode,
						request: effectiveRequest,
						event: this.event,
						// params has a type any can't change right now.
						params: this.params
					}));
				}
				this._cacheKeys[key] = effectiveRequest;
			}
			return this._cacheKeys[key];
		}
		/**
		* Returns true if the strategy has at least one plugin with the given
		* callback.
		*
		* @param {string} name The name of the callback to check for.
		* @return {boolean}
		*/
		hasCallback(name) {
			for (const plugin of this._strategy.plugins) {
				if (name in plugin) {
					return true;
				}
			}
			return false;
		}
		/**
		* Runs all plugin callbacks matching the given name, in order, passing the
		* given param object (merged ith the current plugin state) as the only
		* argument.
		*
		* Note: since this method runs all plugins, it's not suitable for cases
		* where the return value of a callback needs to be applied prior to calling
		* the next callback. See
		* {@link workbox-strategies.StrategyHandler#iterateCallbacks}
		* below for how to handle that case.
		*
		* @param {string} name The name of the callback to run within each plugin.
		* @param {Object} param The object to pass as the first (and only) param
		*     when executing each callback. This object will be merged with the
		*     current plugin state prior to callback execution.
		*/
		async runCallbacks(name, param) {
			for (const callback of this.iterateCallbacks(name)) {
				// TODO(philipwalton): not sure why `any` is needed. It seems like
				// this should work with `as WorkboxPluginCallbackParam[C]`.
				await callback(param);
			}
		}
		/**
		* Accepts a callback and returns an iterable of matching plugin callbacks,
		* where each callback is wrapped with the current handler state (i.e. when
		* you call each callback, whatever object parameter you pass it will
		* be merged with the plugin's current state).
		*
		* @param {string} name The name fo the callback to run
		* @return {Array<Function>}
		*/
		*iterateCallbacks(name) {
			for (const plugin of this._strategy.plugins) {
				if (typeof plugin[name] === "function") {
					const state = this._pluginStateMap.get(plugin);
					const statefulCallback = (param) => {
						const statefulParam = Object.assign(Object.assign({}, param), { state });
						// TODO(philipwalton): not sure why `any` is needed. It seems like
						// this should work with `as WorkboxPluginCallbackParam[C]`.
						return plugin[name](statefulParam);
					};
					yield statefulCallback;
				}
			}
		}
		/**
		* Adds a promise to the
		* [extend lifetime promises]{@link https://w3c.github.io/ServiceWorker/#extendableevent-extend-lifetime-promises}
		* of the event associated with the request being handled (usually a
		* `FetchEvent`).
		*
		* Note: you can await
		* {@link workbox-strategies.StrategyHandler~doneWaiting}
		* to know when all added promises have settled.
		*
		* @param {Promise} promise A promise to add to the extend lifetime promises
		*     of the event that triggered the request.
		*/
		waitUntil(promise) {
			this._extendLifetimePromises.push(promise);
			return promise;
		}
		/**
		* Returns a promise that resolves once all promises passed to
		* {@link workbox-strategies.StrategyHandler~waitUntil}
		* have settled.
		*
		* Note: any work done after `doneWaiting()` settles should be manually
		* passed to an event's `waitUntil()` method (not this handler's
		* `waitUntil()` method), otherwise the service worker thread may be killed
		* prior to your work completing.
		*/
		async doneWaiting() {
			while (this._extendLifetimePromises.length) {
				const promises = this._extendLifetimePromises.splice(0);
				const result = await Promise.allSettled(promises);
				const firstRejection = result.find((i) => i.status === "rejected");
				if (firstRejection) {
					throw firstRejection.reason;
				}
			}
		}
		/**
		* Stops running the strategy and immediately resolves any pending
		* `waitUntil()` promises.
		*/
		destroy() {
			this._handlerDeferred.resolve(null);
		}
		/**
		* This method will call cacheWillUpdate on the available plugins (or use
		* status === 200) to determine if the Response is safe and valid to cache.
		*
		* @param {Request} options.request
		* @param {Response} options.response
		* @return {Promise<Response|undefined>}
		*
		* @private
		*/
		async _ensureResponseSafeToCache(response) {
			let responseToCache = response;
			let pluginsUsed = false;
			for (const callback of this.iterateCallbacks("cacheWillUpdate")) {
				responseToCache = await callback({
					request: this.request,
					response: responseToCache,
					event: this.event
				}) || undefined;
				pluginsUsed = true;
				if (!responseToCache) {
					break;
				}
			}
			if (!pluginsUsed) {
				if (responseToCache && responseToCache.status !== 200) {
					responseToCache = undefined;
				}
				{
					if (responseToCache) {
						if (responseToCache.status !== 200) {
							if (responseToCache.status === 0) {
								logger.warn(`The response for '${this.request.url}' ` + `is an opaque response. The caching strategy that you're ` + `using will not cache opaque responses by default.`);
							} else {
								logger.debug(`The response for '${this.request.url}' ` + `returned a status code of '${response.status}' and won't ` + `be cached as a result.`);
							}
						}
					}
				}
			}
			return responseToCache;
		}
	}
	/*
	Copyright 2020 Google LLC
	
	Use of this source code is governed by an MIT-style
	license that can be found in the LICENSE file or at
	https://opensource.org/licenses/MIT.
	*/
	/**
	* An abstract base class that all other strategy classes must extend from:
	*
	* @memberof workbox-strategies
	*/
	class Strategy {
		/**
		* Creates a new instance of the strategy and sets all documented option
		* properties as public instance properties.
		*
		* Note: if a custom strategy class extends the base Strategy class and does
		* not need more than these properties, it does not need to define its own
		* constructor.
		*
		* @param {Object} [options]
		* @param {string} [options.cacheName] Cache name to store and retrieve
		* requests. Defaults to the cache names provided by
		* {@link workbox-core.cacheNames}.
		* @param {Array<Object>} [options.plugins] [Plugins]{@link https://developers.google.com/web/tools/workbox/guides/using-plugins}
		* to use in conjunction with this caching strategy.
		* @param {Object} [options.fetchOptions] Values passed along to the
		* [`init`](https://developer.mozilla.org/en-US/docs/Web/API/WindowOrWorkerGlobalScope/fetch#Parameters)
		* of [non-navigation](https://github.com/GoogleChrome/workbox/issues/1796)
		* `fetch()` requests made by this strategy.
		* @param {Object} [options.matchOptions] The
		* [`CacheQueryOptions`]{@link https://w3c.github.io/ServiceWorker/#dictdef-cachequeryoptions}
		* for any `cache.match()` or `cache.put()` calls made by this strategy.
		*/
		constructor(options = {}) {
			/**
			* Cache name to store and retrieve
			* requests. Defaults to the cache names provided by
			* {@link workbox-core.cacheNames}.
			*
			* @type {string}
			*/
			this.cacheName = cacheNames.getRuntimeName(options.cacheName);
			/**
			* The list
			* [Plugins]{@link https://developers.google.com/web/tools/workbox/guides/using-plugins}
			* used by this strategy.
			*
			* @type {Array<Object>}
			*/
			this.plugins = options.plugins || [];
			/**
			* Values passed along to the
			* [`init`]{@link https://developer.mozilla.org/en-US/docs/Web/API/WindowOrWorkerGlobalScope/fetch#Parameters}
			* of all fetch() requests made by this strategy.
			*
			* @type {Object}
			*/
			this.fetchOptions = options.fetchOptions;
			/**
			* The
			* [`CacheQueryOptions`]{@link https://w3c.github.io/ServiceWorker/#dictdef-cachequeryoptions}
			* for any `cache.match()` or `cache.put()` calls made by this strategy.
			*
			* @type {Object}
			*/
			this.matchOptions = options.matchOptions;
		}
		/**
		* Perform a request strategy and returns a `Promise` that will resolve with
		* a `Response`, invoking all relevant plugin callbacks.
		*
		* When a strategy instance is registered with a Workbox
		* {@link workbox-routing.Route}, this method is automatically
		* called when the route matches.
		*
		* Alternatively, this method can be used in a standalone `FetchEvent`
		* listener by passing it to `event.respondWith()`.
		*
		* @param {FetchEvent|Object} options A `FetchEvent` or an object with the
		*     properties listed below.
		* @param {Request|string} options.request A request to run this strategy for.
		* @param {ExtendableEvent} options.event The event associated with the
		*     request.
		* @param {URL} [options.url]
		* @param {*} [options.params]
		*/
		handle(options) {
			const [responseDone] = this.handleAll(options);
			return responseDone;
		}
		/**
		* Similar to {@link workbox-strategies.Strategy~handle}, but
		* instead of just returning a `Promise` that resolves to a `Response` it
		* it will return an tuple of `[response, done]` promises, where the former
		* (`response`) is equivalent to what `handle()` returns, and the latter is a
		* Promise that will resolve once any promises that were added to
		* `event.waitUntil()` as part of performing the strategy have completed.
		*
		* You can await the `done` promise to ensure any extra work performed by
		* the strategy (usually caching responses) completes successfully.
		*
		* @param {FetchEvent|Object} options A `FetchEvent` or an object with the
		*     properties listed below.
		* @param {Request|string} options.request A request to run this strategy for.
		* @param {ExtendableEvent} options.event The event associated with the
		*     request.
		* @param {URL} [options.url]
		* @param {*} [options.params]
		* @return {Array<Promise>} A tuple of [response, done]
		*     promises that can be used to determine when the response resolves as
		*     well as when the handler has completed all its work.
		*/
		handleAll(options) {
			// Allow for flexible options to be passed.
			if (options instanceof FetchEvent) {
				options = {
					event: options,
					request: options.request
				};
			}
			const event = options.event;
			const request = typeof options.request === "string" ? new Request(options.request) : options.request;
			const params = "params" in options ? options.params : undefined;
			const handler = new StrategyHandler(this, {
				event,
				request,
				params
			});
			const responseDone = this._getResponse(handler, request, event);
			const handlerDone = this._awaitComplete(responseDone, handler, request, event);
			// Return an array of promises, suitable for use with Promise.all().
			return [responseDone, handlerDone];
		}
		async _getResponse(handler, request, event) {
			await handler.runCallbacks("handlerWillStart", {
				event,
				request
			});
			let response = undefined;
			try {
				response = await this._handle(request, handler);
				// The "official" Strategy subclasses all throw this error automatically,
				// but in case a third-party Strategy doesn't, ensure that we have a
				// consistent failure when there's no response or an error response.
				if (!response || response.type === "error") {
					throw new WorkboxError("no-response", { url: request.url });
				}
			} catch (error) {
				if (error instanceof Error) {
					for (const callback of handler.iterateCallbacks("handlerDidError")) {
						response = await callback({
							error,
							event,
							request
						});
						if (response) {
							break;
						}
					}
				}
				if (!response) {
					throw error;
				} else {
					logger.log(`While responding to '${getFriendlyURL(request.url)}', ` + `an ${error instanceof Error ? error.toString() : ""} error occurred. Using a fallback response provided by ` + `a handlerDidError plugin.`);
				}
			}
			for (const callback of handler.iterateCallbacks("handlerWillRespond")) {
				response = await callback({
					event,
					request,
					response
				});
			}
			return response;
		}
		async _awaitComplete(responseDone, handler, request, event) {
			let response;
			let error;
			try {
				response = await responseDone;
			} catch (error) {}
			try {
				await handler.runCallbacks("handlerDidRespond", {
					event,
					request,
					response
				});
				await handler.doneWaiting();
			} catch (waitUntilError) {
				if (waitUntilError instanceof Error) {
					error = waitUntilError;
				}
			}
			await handler.runCallbacks("handlerDidComplete", {
				event,
				request,
				response,
				error
			});
			handler.destroy();
			if (error) {
				throw error;
			}
		}
	}
	/**
	* Classes extending the `Strategy` based class should implement this method,
	* and leverage the {@link workbox-strategies.StrategyHandler}
	* arg to perform all fetching and cache logic, which will ensure all relevant
	* cache, cache options, fetch options and plugins are used (per the current
	* strategy instance).
	*
	* @name _handle
	* @instance
	* @abstract
	* @function
	* @param {Request} request
	* @param {workbox-strategies.StrategyHandler} handler
	* @return {Promise<Response>}
	*
	* @memberof workbox-strategies.Strategy
	*/
	/*
	Copyright 2018 Google LLC
	
	Use of this source code is governed by an MIT-style
	license that can be found in the LICENSE file or at
	https://opensource.org/licenses/MIT.
	*/
	const messages = {
		strategyStart: (strategyName, request) => `Using ${strategyName} to respond to '${getFriendlyURL(request.url)}'`,
		printFinalResponse: (response) => {
			if (response) {
				logger.groupCollapsed(`View the final response here.`);
				logger.log(response || "[No response returned]");
				logger.groupEnd();
			}
		}
	};
	/*
	Copyright 2018 Google LLC
	
	Use of this source code is governed by an MIT-style
	license that can be found in the LICENSE file or at
	https://opensource.org/licenses/MIT.
	*/
	/**
	* An implementation of a
	* [network first](https://developer.chrome.com/docs/workbox/caching-strategies-overview/#network-first-falling-back-to-cache)
	* request strategy.
	*
	* By default, this strategy will cache responses with a 200 status code as
	* well as [opaque responses](https://developer.chrome.com/docs/workbox/caching-resources-during-runtime/#opaque-responses).
	* Opaque responses are are cross-origin requests where the response doesn't
	* support [CORS](https://enable-cors.org/).
	*
	* If the network request fails, and there is no cache match, this will throw
	* a `WorkboxError` exception.
	*
	* @extends workbox-strategies.Strategy
	* @memberof workbox-strategies
	*/
	class NetworkFirst extends Strategy {
		/**
		* @param {Object} [options]
		* @param {string} [options.cacheName] Cache name to store and retrieve
		* requests. Defaults to cache names provided by
		* {@link workbox-core.cacheNames}.
		* @param {Array<Object>} [options.plugins] [Plugins]{@link https://developers.google.com/web/tools/workbox/guides/using-plugins}
		* to use in conjunction with this caching strategy.
		* @param {Object} [options.fetchOptions] Values passed along to the
		* [`init`](https://developer.mozilla.org/en-US/docs/Web/API/WindowOrWorkerGlobalScope/fetch#Parameters)
		* of [non-navigation](https://github.com/GoogleChrome/workbox/issues/1796)
		* `fetch()` requests made by this strategy.
		* @param {Object} [options.matchOptions] [`CacheQueryOptions`](https://w3c.github.io/ServiceWorker/#dictdef-cachequeryoptions)
		* @param {number} [options.networkTimeoutSeconds] If set, any network requests
		* that fail to respond within the timeout will fallback to the cache.
		*
		* This option can be used to combat
		* "[lie-fi]{@link https://developers.google.com/web/fundamentals/performance/poor-connectivity/#lie-fi}"
		* scenarios.
		*/
		constructor(options = {}) {
			super(options);
			// If this instance contains no plugins with a 'cacheWillUpdate' callback,
			// prepend the `cacheOkAndOpaquePlugin` plugin to the plugins list.
			if (!this.plugins.some((p) => "cacheWillUpdate" in p)) {
				this.plugins.unshift(cacheOkAndOpaquePlugin);
			}
			this._networkTimeoutSeconds = options.networkTimeoutSeconds || 0;
			{
				if (this._networkTimeoutSeconds) {
					finalAssertExports.isType(this._networkTimeoutSeconds, "number", {
						moduleName: "workbox-strategies",
						className: this.constructor.name,
						funcName: "constructor",
						paramName: "networkTimeoutSeconds"
					});
				}
			}
		}
		/**
		* @private
		* @param {Request|string} request A request to run this strategy for.
		* @param {workbox-strategies.StrategyHandler} handler The event that
		*     triggered the request.
		* @return {Promise<Response>}
		*/
		async _handle(request, handler) {
			const logs = [];
			{
				finalAssertExports.isInstance(request, Request, {
					moduleName: "workbox-strategies",
					className: this.constructor.name,
					funcName: "handle",
					paramName: "makeRequest"
				});
			}
			const promises = [];
			let timeoutId;
			if (this._networkTimeoutSeconds) {
				const { id, promise } = this._getTimeoutPromise({
					request,
					logs,
					handler
				});
				timeoutId = id;
				promises.push(promise);
			}
			const networkPromise = this._getNetworkPromise({
				timeoutId,
				request,
				logs,
				handler
			});
			promises.push(networkPromise);
			const response = await handler.waitUntil((async () => {
				// Promise.race() will resolve as soon as the first promise resolves.
				return await handler.waitUntil(Promise.race(promises)) || await networkPromise;
			})());
			{
				logger.groupCollapsed(messages.strategyStart(this.constructor.name, request));
				for (const log of logs) {
					logger.log(log);
				}
				messages.printFinalResponse(response);
				logger.groupEnd();
			}
			if (!response) {
				throw new WorkboxError("no-response", { url: request.url });
			}
			return response;
		}
		/**
		* @param {Object} options
		* @param {Request} options.request
		* @param {Array} options.logs A reference to the logs array
		* @param {Event} options.event
		* @return {Promise<Response>}
		*
		* @private
		*/
		_getTimeoutPromise({ request, logs, handler }) {
			let timeoutId;
			const timeoutPromise = new Promise((resolve) => {
				const onNetworkTimeout = async () => {
					{
						logs.push(`Timing out the network response at ` + `${this._networkTimeoutSeconds} seconds.`);
					}
					resolve(await handler.cacheMatch(request));
				};
				timeoutId = setTimeout(onNetworkTimeout, this._networkTimeoutSeconds * 1e3);
			});
			return {
				promise: timeoutPromise,
				id: timeoutId
			};
		}
		/**
		* @param {Object} options
		* @param {number|undefined} options.timeoutId
		* @param {Request} options.request
		* @param {Array} options.logs A reference to the logs Array.
		* @param {Event} options.event
		* @return {Promise<Response>}
		*
		* @private
		*/
		async _getNetworkPromise({ timeoutId, request, logs, handler }) {
			let error;
			let response;
			try {
				response = await handler.fetchAndCachePut(request);
			} catch (fetchError) {
				if (fetchError instanceof Error) {
					error = fetchError;
				}
			}
			if (timeoutId) {
				clearTimeout(timeoutId);
			}
			{
				if (response) {
					logs.push(`Got response from network.`);
				} else {
					logs.push(`Unable to get a response from the network. Will respond ` + `with a cached response.`);
				}
			}
			if (error || !response) {
				response = await handler.cacheMatch(request);
				{
					if (response) {
						logs.push(`Found a cached response in the '${this.cacheName}'` + ` cache.`);
					} else {
						logs.push(`No response found in the '${this.cacheName}' cache.`);
					}
				}
			}
			return response;
		}
	}
	/*
	Copyright 2019 Google LLC
	
	Use of this source code is governed by an MIT-style
	license that can be found in the LICENSE file or at
	https://opensource.org/licenses/MIT.
	*/
	/**
	* Claim any currently available clients once the service worker
	* becomes active. This is normally used in conjunction with `skipWaiting()`.
	*
	* @memberof workbox-core
	*/
	function clientsClaim() {
		self.addEventListener("activate", () => self.clients.claim());
	}
	/*
	Copyright 2020 Google LLC
	Use of this source code is governed by an MIT-style
	license that can be found in the LICENSE file or at
	https://opensource.org/licenses/MIT.
	*/
	/**
	* A utility method that makes it easier to use `event.waitUntil` with
	* async functions and return the result.
	*
	* @param {ExtendableEvent} event
	* @param {Function} asyncFn
	* @return {Function}
	* @private
	*/
	function waitUntil(event, asyncFn) {
		const returnPromise = asyncFn();
		event.waitUntil(returnPromise);
		return returnPromise;
	}
	// @ts-ignore
	try {
		self["workbox:precaching:7.4.0"] && _();
	} catch (e) {}
	/*
	Copyright 2018 Google LLC
	
	Use of this source code is governed by an MIT-style
	license that can be found in the LICENSE file or at
	https://opensource.org/licenses/MIT.
	*/
	// Name of the search parameter used to store revision info.
	const REVISION_SEARCH_PARAM = "__WB_REVISION__";
	/**
	* Converts a manifest entry into a versioned URL suitable for precaching.
	*
	* @param {Object|string} entry
	* @return {string} A URL with versioning info.
	*
	* @private
	* @memberof workbox-precaching
	*/
	function createCacheKey(entry) {
		if (!entry) {
			throw new WorkboxError("add-to-cache-list-unexpected-type", { entry });
		}
		// If a precache manifest entry is a string, it's assumed to be a versioned
		// URL, like '/app.abcd1234.js'. Return as-is.
		if (typeof entry === "string") {
			const urlObject = new URL(entry, location.href);
			return {
				cacheKey: urlObject.href,
				url: urlObject.href
			};
		}
		const { revision, url } = entry;
		if (!url) {
			throw new WorkboxError("add-to-cache-list-unexpected-type", { entry });
		}
		// If there's just a URL and no revision, then it's also assumed to be a
		// versioned URL.
		if (!revision) {
			const urlObject = new URL(url, location.href);
			return {
				cacheKey: urlObject.href,
				url: urlObject.href
			};
		}
		// Otherwise, construct a properly versioned URL using the custom Workbox
		// search parameter along with the revision info.
		const cacheKeyURL = new URL(url, location.href);
		const originalURL = new URL(url, location.href);
		cacheKeyURL.searchParams.set(REVISION_SEARCH_PARAM, revision);
		return {
			cacheKey: cacheKeyURL.href,
			url: originalURL.href
		};
	}
	/*
	Copyright 2020 Google LLC
	
	Use of this source code is governed by an MIT-style
	license that can be found in the LICENSE file or at
	https://opensource.org/licenses/MIT.
	*/
	/**
	* A plugin, designed to be used with PrecacheController, to determine the
	* of assets that were updated (or not updated) during the install event.
	*
	* @private
	*/
	class PrecacheInstallReportPlugin {
		constructor() {
			this.updatedURLs = [];
			this.notUpdatedURLs = [];
			this.handlerWillStart = async ({ request, state }) => {
				// TODO: `state` should never be undefined...
				if (state) {
					state.originalRequest = request;
				}
			};
			this.cachedResponseWillBeUsed = async ({ event, state, cachedResponse }) => {
				if (event.type === "install") {
					if (state && state.originalRequest && state.originalRequest instanceof Request) {
						// TODO: `state` should never be undefined...
						const url = state.originalRequest.url;
						if (cachedResponse) {
							this.notUpdatedURLs.push(url);
						} else {
							this.updatedURLs.push(url);
						}
					}
				}
				return cachedResponse;
			};
		}
	}
	/*
	Copyright 2020 Google LLC
	
	Use of this source code is governed by an MIT-style
	license that can be found in the LICENSE file or at
	https://opensource.org/licenses/MIT.
	*/
	/**
	* A plugin, designed to be used with PrecacheController, to translate URLs into
	* the corresponding cache key, based on the current revision info.
	*
	* @private
	*/
	class PrecacheCacheKeyPlugin {
		constructor({ precacheController }) {
			this.cacheKeyWillBeUsed = async ({ request, params }) => {
				// Params is type any, can't change right now.
				/* eslint-disable */
				const cacheKey = (params === null || params === void 0 ? void 0 : params.cacheKey) || this._precacheController.getCacheKeyForURL(request.url);
				/* eslint-enable */
				return cacheKey ? new Request(cacheKey, { headers: request.headers }) : request;
			};
			this._precacheController = precacheController;
		}
	}
	/*
	Copyright 2018 Google LLC
	
	Use of this source code is governed by an MIT-style
	license that can be found in the LICENSE file or at
	https://opensource.org/licenses/MIT.
	*/
	/**
	* @param {string} groupTitle
	* @param {Array<string>} deletedURLs
	*
	* @private
	*/
	const logGroup = (groupTitle, deletedURLs) => {
		logger.groupCollapsed(groupTitle);
		for (const url of deletedURLs) {
			logger.log(url);
		}
		logger.groupEnd();
	};
	/**
	* @param {Array<string>} deletedURLs
	*
	* @private
	* @memberof workbox-precaching
	*/
	function printCleanupDetails(deletedURLs) {
		const deletionCount = deletedURLs.length;
		if (deletionCount > 0) {
			logger.groupCollapsed(`During precaching cleanup, ` + `${deletionCount} cached ` + `request${deletionCount === 1 ? " was" : "s were"} deleted.`);
			logGroup("Deleted Cache Requests", deletedURLs);
			logger.groupEnd();
		}
	}
	/*
	Copyright 2018 Google LLC
	
	Use of this source code is governed by an MIT-style
	license that can be found in the LICENSE file or at
	https://opensource.org/licenses/MIT.
	*/
	/**
	* @param {string} groupTitle
	* @param {Array<string>} urls
	*
	* @private
	*/
	function _nestedGroup(groupTitle, urls) {
		if (urls.length === 0) {
			return;
		}
		logger.groupCollapsed(groupTitle);
		for (const url of urls) {
			logger.log(url);
		}
		logger.groupEnd();
	}
	/**
	* @param {Array<string>} urlsToPrecache
	* @param {Array<string>} urlsAlreadyPrecached
	*
	* @private
	* @memberof workbox-precaching
	*/
	function printInstallDetails(urlsToPrecache, urlsAlreadyPrecached) {
		const precachedCount = urlsToPrecache.length;
		const alreadyPrecachedCount = urlsAlreadyPrecached.length;
		if (precachedCount || alreadyPrecachedCount) {
			let message = `Precaching ${precachedCount} file${precachedCount === 1 ? "" : "s"}.`;
			if (alreadyPrecachedCount > 0) {
				message += ` ${alreadyPrecachedCount} ` + `file${alreadyPrecachedCount === 1 ? " is" : "s are"} already cached.`;
			}
			logger.groupCollapsed(message);
			_nestedGroup(`View newly precached URLs.`, urlsToPrecache);
			_nestedGroup(`View previously precached URLs.`, urlsAlreadyPrecached);
			logger.groupEnd();
		}
	}
	/*
	Copyright 2019 Google LLC
	
	Use of this source code is governed by an MIT-style
	license that can be found in the LICENSE file or at
	https://opensource.org/licenses/MIT.
	*/
	let supportStatus;
	/**
	* A utility function that determines whether the current browser supports
	* constructing a new `Response` from a `response.body` stream.
	*
	* @return {boolean} `true`, if the current browser can successfully
	*     construct a `Response` from a `response.body` stream, `false` otherwise.
	*
	* @private
	*/
	function canConstructResponseFromBodyStream() {
		if (supportStatus === undefined) {
			const testResponse = new Response("");
			if ("body" in testResponse) {
				try {
					new Response(testResponse.body);
					supportStatus = true;
				} catch (error) {
					supportStatus = false;
				}
			}
			supportStatus = false;
		}
		return supportStatus;
	}
	/*
	Copyright 2019 Google LLC
	
	Use of this source code is governed by an MIT-style
	license that can be found in the LICENSE file or at
	https://opensource.org/licenses/MIT.
	*/
	/**
	* Allows developers to copy a response and modify its `headers`, `status`,
	* or `statusText` values (the values settable via a
	* [`ResponseInit`]{@link https://developer.mozilla.org/en-US/docs/Web/API/Response/Response#Syntax}
	* object in the constructor).
	* To modify these values, pass a function as the second argument. That
	* function will be invoked with a single object with the response properties
	* `{headers, status, statusText}`. The return value of this function will
	* be used as the `ResponseInit` for the new `Response`. To change the values
	* either modify the passed parameter(s) and return it, or return a totally
	* new object.
	*
	* This method is intentionally limited to same-origin responses, regardless of
	* whether CORS was used or not.
	*
	* @param {Response} response
	* @param {Function} modifier
	* @memberof workbox-core
	*/
	async function copyResponse(response, modifier) {
		let origin = null;
		// If response.url isn't set, assume it's cross-origin and keep origin null.
		if (response.url) {
			const responseURL = new URL(response.url);
			origin = responseURL.origin;
		}
		if (origin !== self.location.origin) {
			throw new WorkboxError("cross-origin-copy-response", { origin });
		}
		const clonedResponse = response.clone();
		// Create a fresh `ResponseInit` object by cloning the headers.
		const responseInit = {
			headers: new Headers(clonedResponse.headers),
			status: clonedResponse.status,
			statusText: clonedResponse.statusText
		};
		// Apply any user modifications.
		const modifiedResponseInit = responseInit;
		// Create the new response from the body stream and `ResponseInit`
		// modifications. Note: not all browsers support the Response.body stream,
		// so fall back to reading the entire body into memory as a blob.
		const body = canConstructResponseFromBodyStream() ? clonedResponse.body : await clonedResponse.blob();
		return new Response(body, modifiedResponseInit);
	}
	/*
	Copyright 2020 Google LLC
	
	Use of this source code is governed by an MIT-style
	license that can be found in the LICENSE file or at
	https://opensource.org/licenses/MIT.
	*/
	/**
	* A {@link workbox-strategies.Strategy} implementation
	* specifically designed to work with
	* {@link workbox-precaching.PrecacheController}
	* to both cache and fetch precached assets.
	*
	* Note: an instance of this class is created automatically when creating a
	* `PrecacheController`; it's generally not necessary to create this yourself.
	*
	* @extends workbox-strategies.Strategy
	* @memberof workbox-precaching
	*/
	class PrecacheStrategy extends Strategy {
		/**
		*
		* @param {Object} [options]
		* @param {string} [options.cacheName] Cache name to store and retrieve
		* requests. Defaults to the cache names provided by
		* {@link workbox-core.cacheNames}.
		* @param {Array<Object>} [options.plugins] {@link https://developers.google.com/web/tools/workbox/guides/using-plugins|Plugins}
		* to use in conjunction with this caching strategy.
		* @param {Object} [options.fetchOptions] Values passed along to the
		* {@link https://developer.mozilla.org/en-US/docs/Web/API/WindowOrWorkerGlobalScope/fetch#Parameters|init}
		* of all fetch() requests made by this strategy.
		* @param {Object} [options.matchOptions] The
		* {@link https://w3c.github.io/ServiceWorker/#dictdef-cachequeryoptions|CacheQueryOptions}
		* for any `cache.match()` or `cache.put()` calls made by this strategy.
		* @param {boolean} [options.fallbackToNetwork=true] Whether to attempt to
		* get the response from the network if there's a precache miss.
		*/
		constructor(options = {}) {
			options.cacheName = cacheNames.getPrecacheName(options.cacheName);
			super(options);
			this._fallbackToNetwork = options.fallbackToNetwork === false ? false : true;
			// Redirected responses cannot be used to satisfy a navigation request, so
			// any redirected response must be "copied" rather than cloned, so the new
			// response doesn't contain the `redirected` flag. See:
			// https://bugs.chromium.org/p/chromium/issues/detail?id=669363&desc=2#c1
			this.plugins.push(PrecacheStrategy.copyRedirectedCacheableResponsesPlugin);
		}
		/**
		* @private
		* @param {Request|string} request A request to run this strategy for.
		* @param {workbox-strategies.StrategyHandler} handler The event that
		*     triggered the request.
		* @return {Promise<Response>}
		*/
		async _handle(request, handler) {
			const response = await handler.cacheMatch(request);
			if (response) {
				return response;
			}
			// If this is an `install` event for an entry that isn't already cached,
			// then populate the cache.
			if (handler.event && handler.event.type === "install") {
				return await this._handleInstall(request, handler);
			}
			// Getting here means something went wrong. An entry that should have been
			// precached wasn't found in the cache.
			return await this._handleFetch(request, handler);
		}
		async _handleFetch(request, handler) {
			let response;
			const params = handler.params || {};
			// Fall back to the network if we're configured to do so.
			if (this._fallbackToNetwork) {
				{
					logger.warn(`The precached response for ` + `${getFriendlyURL(request.url)} in ${this.cacheName} was not ` + `found. Falling back to the network.`);
				}
				const integrityInManifest = params.integrity;
				const integrityInRequest = request.integrity;
				const noIntegrityConflict = !integrityInRequest || integrityInRequest === integrityInManifest;
				// Do not add integrity if the original request is no-cors
				// See https://github.com/GoogleChrome/workbox/issues/3096
				response = await handler.fetch(new Request(request, { integrity: request.mode !== "no-cors" ? integrityInRequest || integrityInManifest : undefined }));
				// It's only "safe" to repair the cache if we're using SRI to guarantee
				// that the response matches the precache manifest's expectations,
				// and there's either a) no integrity property in the incoming request
				// or b) there is an integrity, and it matches the precache manifest.
				// See https://github.com/GoogleChrome/workbox/issues/2858
				// Also if the original request users no-cors we don't use integrity.
				// See https://github.com/GoogleChrome/workbox/issues/3096
				if (integrityInManifest && noIntegrityConflict && request.mode !== "no-cors") {
					this._useDefaultCacheabilityPluginIfNeeded();
					const wasCached = await handler.cachePut(request, response.clone());
					{
						if (wasCached) {
							logger.log(`A response for ${getFriendlyURL(request.url)} ` + `was used to "repair" the precache.`);
						}
					}
				}
			} else {
				// This shouldn't normally happen, but there are edge cases:
				// https://github.com/GoogleChrome/workbox/issues/1441
				throw new WorkboxError("missing-precache-entry", {
					cacheName: this.cacheName,
					url: request.url
				});
			}
			{
				const cacheKey = params.cacheKey || await handler.getCacheKey(request, "read");
				// Workbox is going to handle the route.
				// print the routing details to the console.
				logger.groupCollapsed(`Precaching is responding to: ` + getFriendlyURL(request.url));
				logger.log(`Serving the precached url: ${getFriendlyURL(cacheKey instanceof Request ? cacheKey.url : cacheKey)}`);
				logger.groupCollapsed(`View request details here.`);
				logger.log(request);
				logger.groupEnd();
				logger.groupCollapsed(`View response details here.`);
				logger.log(response);
				logger.groupEnd();
				logger.groupEnd();
			}
			return response;
		}
		async _handleInstall(request, handler) {
			this._useDefaultCacheabilityPluginIfNeeded();
			const response = await handler.fetch(request);
			// Make sure we defer cachePut() until after we know the response
			// should be cached; see https://github.com/GoogleChrome/workbox/issues/2737
			const wasCached = await handler.cachePut(request, response.clone());
			if (!wasCached) {
				// Throwing here will lead to the `install` handler failing, which
				// we want to do if *any* of the responses aren't safe to cache.
				throw new WorkboxError("bad-precaching-response", {
					url: request.url,
					status: response.status
				});
			}
			return response;
		}
		/**
		* This method is complex, as there a number of things to account for:
		*
		* The `plugins` array can be set at construction, and/or it might be added to
		* to at any time before the strategy is used.
		*
		* At the time the strategy is used (i.e. during an `install` event), there
		* needs to be at least one plugin that implements `cacheWillUpdate` in the
		* array, other than `copyRedirectedCacheableResponsesPlugin`.
		*
		* - If this method is called and there are no suitable `cacheWillUpdate`
		* plugins, we need to add `defaultPrecacheCacheabilityPlugin`.
		*
		* - If this method is called and there is exactly one `cacheWillUpdate`, then
		* we don't have to do anything (this might be a previously added
		* `defaultPrecacheCacheabilityPlugin`, or it might be a custom plugin).
		*
		* - If this method is called and there is more than one `cacheWillUpdate`,
		* then we need to check if one is `defaultPrecacheCacheabilityPlugin`. If so,
		* we need to remove it. (This situation is unlikely, but it could happen if
		* the strategy is used multiple times, the first without a `cacheWillUpdate`,
		* and then later on after manually adding a custom `cacheWillUpdate`.)
		*
		* See https://github.com/GoogleChrome/workbox/issues/2737 for more context.
		*
		* @private
		*/
		_useDefaultCacheabilityPluginIfNeeded() {
			let defaultPluginIndex = null;
			let cacheWillUpdatePluginCount = 0;
			for (const [index, plugin] of this.plugins.entries()) {
				// Ignore the copy redirected plugin when determining what to do.
				if (plugin === PrecacheStrategy.copyRedirectedCacheableResponsesPlugin) {
					continue;
				}
				// Save the default plugin's index, in case it needs to be removed.
				if (plugin === PrecacheStrategy.defaultPrecacheCacheabilityPlugin) {
					defaultPluginIndex = index;
				}
				if (plugin.cacheWillUpdate) {
					cacheWillUpdatePluginCount++;
				}
			}
			if (cacheWillUpdatePluginCount === 0) {
				this.plugins.push(PrecacheStrategy.defaultPrecacheCacheabilityPlugin);
			} else if (cacheWillUpdatePluginCount > 1 && defaultPluginIndex !== null) {
				// Only remove the default plugin; multiple custom plugins are allowed.
				this.plugins.splice(defaultPluginIndex, 1);
			}
			// Nothing needs to be done if cacheWillUpdatePluginCount is 1
		}
	}
	PrecacheStrategy.defaultPrecacheCacheabilityPlugin = { async cacheWillUpdate({ response }) {
		if (!response || response.status >= 400) {
			return null;
		}
		return response;
	} };
	PrecacheStrategy.copyRedirectedCacheableResponsesPlugin = { async cacheWillUpdate({ response }) {
		return response.redirected ? await copyResponse(response) : response;
	} };
	/*
	Copyright 2019 Google LLC
	
	Use of this source code is governed by an MIT-style
	license that can be found in the LICENSE file or at
	https://opensource.org/licenses/MIT.
	*/
	/**
	* Performs efficient precaching of assets.
	*
	* @memberof workbox-precaching
	*/
	class PrecacheController {
		/**
		* Create a new PrecacheController.
		*
		* @param {Object} [options]
		* @param {string} [options.cacheName] The cache to use for precaching.
		* @param {string} [options.plugins] Plugins to use when precaching as well
		* as responding to fetch events for precached assets.
		* @param {boolean} [options.fallbackToNetwork=true] Whether to attempt to
		* get the response from the network if there's a precache miss.
		*/
		constructor({ cacheName, plugins = [], fallbackToNetwork = true } = {}) {
			this._urlsToCacheKeys = new Map();
			this._urlsToCacheModes = new Map();
			this._cacheKeysToIntegrities = new Map();
			this._strategy = new PrecacheStrategy({
				cacheName: cacheNames.getPrecacheName(cacheName),
				plugins: [...plugins, new PrecacheCacheKeyPlugin({ precacheController: this })],
				fallbackToNetwork
			});
			// Bind the install and activate methods to the instance.
			this.install = this.install.bind(this);
			this.activate = this.activate.bind(this);
		}
		/**
		* @type {workbox-precaching.PrecacheStrategy} The strategy created by this controller and
		* used to cache assets and respond to fetch events.
		*/
		get strategy() {
			return this._strategy;
		}
		/**
		* Adds items to the precache list, removing any duplicates and
		* stores the files in the
		* {@link workbox-core.cacheNames|"precache cache"} when the service
		* worker installs.
		*
		* This method can be called multiple times.
		*
		* @param {Array<Object|string>} [entries=[]] Array of entries to precache.
		*/
		precache(entries) {
			this.addToCacheList(entries);
			if (!this._installAndActiveListenersAdded) {
				self.addEventListener("install", this.install);
				self.addEventListener("activate", this.activate);
				this._installAndActiveListenersAdded = true;
			}
		}
		/**
		* This method will add items to the precache list, removing duplicates
		* and ensuring the information is valid.
		*
		* @param {Array<workbox-precaching.PrecacheController.PrecacheEntry|string>} entries
		*     Array of entries to precache.
		*/
		addToCacheList(entries) {
			{
				finalAssertExports.isArray(entries, {
					moduleName: "workbox-precaching",
					className: "PrecacheController",
					funcName: "addToCacheList",
					paramName: "entries"
				});
			}
			const urlsToWarnAbout = [];
			for (const entry of entries) {
				// See https://github.com/GoogleChrome/workbox/issues/2259
				if (typeof entry === "string") {
					urlsToWarnAbout.push(entry);
				} else if (entry && entry.revision === undefined) {
					urlsToWarnAbout.push(entry.url);
				}
				const { cacheKey, url } = createCacheKey(entry);
				const cacheMode = typeof entry !== "string" && entry.revision ? "reload" : "default";
				if (this._urlsToCacheKeys.has(url) && this._urlsToCacheKeys.get(url) !== cacheKey) {
					throw new WorkboxError("add-to-cache-list-conflicting-entries", {
						firstEntry: this._urlsToCacheKeys.get(url),
						secondEntry: cacheKey
					});
				}
				if (typeof entry !== "string" && entry.integrity) {
					if (this._cacheKeysToIntegrities.has(cacheKey) && this._cacheKeysToIntegrities.get(cacheKey) !== entry.integrity) {
						throw new WorkboxError("add-to-cache-list-conflicting-integrities", { url });
					}
					this._cacheKeysToIntegrities.set(cacheKey, entry.integrity);
				}
				this._urlsToCacheKeys.set(url, cacheKey);
				this._urlsToCacheModes.set(url, cacheMode);
				if (urlsToWarnAbout.length > 0) {
					const warningMessage = `Workbox is precaching URLs without revision ` + `info: ${urlsToWarnAbout.join(", ")}\nThis is generally NOT safe. ` + `Learn more at https://bit.ly/wb-precache`;
					{
						logger.warn(warningMessage);
					}
				}
			}
		}
		/**
		* Precaches new and updated assets. Call this method from the service worker
		* install event.
		*
		* Note: this method calls `event.waitUntil()` for you, so you do not need
		* to call it yourself in your event handlers.
		*
		* @param {ExtendableEvent} event
		* @return {Promise<workbox-precaching.InstallResult>}
		*/
		install(event) {
			// waitUntil returns Promise<any>
			// eslint-disable-next-line @typescript-eslint/no-unsafe-return
			return waitUntil(event, async () => {
				const installReportPlugin = new PrecacheInstallReportPlugin();
				this.strategy.plugins.push(installReportPlugin);
				// Cache entries one at a time.
				// See https://github.com/GoogleChrome/workbox/issues/2528
				for (const [url, cacheKey] of this._urlsToCacheKeys) {
					const integrity = this._cacheKeysToIntegrities.get(cacheKey);
					const cacheMode = this._urlsToCacheModes.get(url);
					const request = new Request(url, {
						integrity,
						cache: cacheMode,
						credentials: "same-origin"
					});
					await Promise.all(this.strategy.handleAll({
						params: { cacheKey },
						request,
						event
					}));
				}
				const { updatedURLs, notUpdatedURLs } = installReportPlugin;
				{
					printInstallDetails(updatedURLs, notUpdatedURLs);
				}
				return {
					updatedURLs,
					notUpdatedURLs
				};
			});
		}
		/**
		* Deletes assets that are no longer present in the current precache manifest.
		* Call this method from the service worker activate event.
		*
		* Note: this method calls `event.waitUntil()` for you, so you do not need
		* to call it yourself in your event handlers.
		*
		* @param {ExtendableEvent} event
		* @return {Promise<workbox-precaching.CleanupResult>}
		*/
		activate(event) {
			// waitUntil returns Promise<any>
			// eslint-disable-next-line @typescript-eslint/no-unsafe-return
			return waitUntil(event, async () => {
				const cache = await self.caches.open(this.strategy.cacheName);
				const currentlyCachedRequests = await cache.keys();
				const expectedCacheKeys = new Set(this._urlsToCacheKeys.values());
				const deletedURLs = [];
				for (const request of currentlyCachedRequests) {
					if (!expectedCacheKeys.has(request.url)) {
						await cache.delete(request);
						deletedURLs.push(request.url);
					}
				}
				{
					printCleanupDetails(deletedURLs);
				}
				return { deletedURLs };
			});
		}
		/**
		* Returns a mapping of a precached URL to the corresponding cache key, taking
		* into account the revision information for the URL.
		*
		* @return {Map<string, string>} A URL to cache key mapping.
		*/
		getURLsToCacheKeys() {
			return this._urlsToCacheKeys;
		}
		/**
		* Returns a list of all the URLs that have been precached by the current
		* service worker.
		*
		* @return {Array<string>} The precached URLs.
		*/
		getCachedURLs() {
			return [...this._urlsToCacheKeys.keys()];
		}
		/**
		* Returns the cache key used for storing a given URL. If that URL is
		* unversioned, like `/index.html', then the cache key will be the original
		* URL with a search parameter appended to it.
		*
		* @param {string} url A URL whose cache key you want to look up.
		* @return {string} The versioned URL that corresponds to a cache key
		* for the original URL, or undefined if that URL isn't precached.
		*/
		getCacheKeyForURL(url) {
			const urlObject = new URL(url, location.href);
			return this._urlsToCacheKeys.get(urlObject.href);
		}
		/**
		* @param {string} url A cache key whose SRI you want to look up.
		* @return {string} The subresource integrity associated with the cache key,
		* or undefined if it's not set.
		*/
		getIntegrityForCacheKey(cacheKey) {
			return this._cacheKeysToIntegrities.get(cacheKey);
		}
		/**
		* This acts as a drop-in replacement for
		* [`cache.match()`](https://developer.mozilla.org/en-US/docs/Web/API/Cache/match)
		* with the following differences:
		*
		* - It knows what the name of the precache is, and only checks in that cache.
		* - It allows you to pass in an "original" URL without versioning parameters,
		* and it will automatically look up the correct cache key for the currently
		* active revision of that URL.
		*
		* E.g., `matchPrecache('index.html')` will find the correct precached
		* response for the currently active service worker, even if the actual cache
		* key is `'/index.html?__WB_REVISION__=1234abcd'`.
		*
		* @param {string|Request} request The key (without revisioning parameters)
		* to look up in the precache.
		* @return {Promise<Response|undefined>}
		*/
		async matchPrecache(request) {
			const url = request instanceof Request ? request.url : request;
			const cacheKey = this.getCacheKeyForURL(url);
			if (cacheKey) {
				const cache = await self.caches.open(this.strategy.cacheName);
				return cache.match(cacheKey);
			}
			return undefined;
		}
		/**
		* Returns a function that looks up `url` in the precache (taking into
		* account revision information), and returns the corresponding `Response`.
		*
		* @param {string} url The precached URL which will be used to lookup the
		* `Response`.
		* @return {workbox-routing~handlerCallback}
		*/
		createHandlerBoundToURL(url) {
			const cacheKey = this.getCacheKeyForURL(url);
			if (!cacheKey) {
				throw new WorkboxError("non-precached-url", { url });
			}
			return (options) => {
				options.request = new Request(url);
				options.params = Object.assign({ cacheKey }, options.params);
				return this.strategy.handle(options);
			};
		}
	}
	/*
	Copyright 2019 Google LLC
	
	Use of this source code is governed by an MIT-style
	license that can be found in the LICENSE file or at
	https://opensource.org/licenses/MIT.
	*/
	let precacheController;
	/**
	* @return {PrecacheController}
	* @private
	*/
	const getOrCreatePrecacheController = () => {
		if (!precacheController) {
			precacheController = new PrecacheController();
		}
		return precacheController;
	};
	/*
	Copyright 2018 Google LLC
	
	Use of this source code is governed by an MIT-style
	license that can be found in the LICENSE file or at
	https://opensource.org/licenses/MIT.
	*/
	/**
	* Removes any URL search parameters that should be ignored.
	*
	* @param {URL} urlObject The original URL.
	* @param {Array<RegExp>} ignoreURLParametersMatching RegExps to test against
	* each search parameter name. Matches mean that the search parameter should be
	* ignored.
	* @return {URL} The URL with any ignored search parameters removed.
	*
	* @private
	* @memberof workbox-precaching
	*/
	function removeIgnoredSearchParams(urlObject, ignoreURLParametersMatching = []) {
		// Convert the iterable into an array at the start of the loop to make sure
		// deletion doesn't mess up iteration.
		for (const paramName of [...urlObject.searchParams.keys()]) {
			if (ignoreURLParametersMatching.some((regExp) => regExp.test(paramName))) {
				urlObject.searchParams.delete(paramName);
			}
		}
		return urlObject;
	}
	/*
	Copyright 2019 Google LLC
	
	Use of this source code is governed by an MIT-style
	license that can be found in the LICENSE file or at
	https://opensource.org/licenses/MIT.
	*/
	/**
	* Generator function that yields possible variations on the original URL to
	* check, one at a time.
	*
	* @param {string} url
	* @param {Object} options
	*
	* @private
	* @memberof workbox-precaching
	*/
	function* generateURLVariations(url, { ignoreURLParametersMatching = [/^utm_/, /^fbclid$/], directoryIndex = "index.html", cleanURLs = true, urlManipulation } = {}) {
		const urlObject = new URL(url, location.href);
		urlObject.hash = "";
		yield urlObject.href;
		const urlWithoutIgnoredParams = removeIgnoredSearchParams(urlObject, ignoreURLParametersMatching);
		yield urlWithoutIgnoredParams.href;
		if (directoryIndex && urlWithoutIgnoredParams.pathname.endsWith("/")) {
			const directoryURL = new URL(urlWithoutIgnoredParams.href);
			directoryURL.pathname += directoryIndex;
			yield directoryURL.href;
		}
		if (cleanURLs) {
			const cleanURL = new URL(urlWithoutIgnoredParams.href);
			cleanURL.pathname += ".html";
			yield cleanURL.href;
		}
		if (urlManipulation) {
			const additionalURLs = urlManipulation({ url: urlObject });
			for (const urlToAttempt of additionalURLs) {
				yield urlToAttempt.href;
			}
		}
	}
	/*
	Copyright 2020 Google LLC
	
	Use of this source code is governed by an MIT-style
	license that can be found in the LICENSE file or at
	https://opensource.org/licenses/MIT.
	*/
	/**
	* A subclass of {@link workbox-routing.Route} that takes a
	* {@link workbox-precaching.PrecacheController}
	* instance and uses it to match incoming requests and handle fetching
	* responses from the precache.
	*
	* @memberof workbox-precaching
	* @extends workbox-routing.Route
	*/
	class PrecacheRoute extends Route {
		/**
		* @param {PrecacheController} precacheController A `PrecacheController`
		* instance used to both match requests and respond to fetch events.
		* @param {Object} [options] Options to control how requests are matched
		* against the list of precached URLs.
		* @param {string} [options.directoryIndex=index.html] The `directoryIndex` will
		* check cache entries for a URLs ending with '/' to see if there is a hit when
		* appending the `directoryIndex` value.
		* @param {Array<RegExp>} [options.ignoreURLParametersMatching=[/^utm_/, /^fbclid$/]] An
		* array of regex's to remove search params when looking for a cache match.
		* @param {boolean} [options.cleanURLs=true] The `cleanURLs` option will
		* check the cache for the URL with a `.html` added to the end of the end.
		* @param {workbox-precaching~urlManipulation} [options.urlManipulation]
		* This is a function that should take a URL and return an array of
		* alternative URLs that should be checked for precache matches.
		*/
		constructor(precacheController, options) {
			const match = ({ request }) => {
				const urlsToCacheKeys = precacheController.getURLsToCacheKeys();
				for (const possibleURL of generateURLVariations(request.url, options)) {
					const cacheKey = urlsToCacheKeys.get(possibleURL);
					if (cacheKey) {
						const integrity = precacheController.getIntegrityForCacheKey(cacheKey);
						return {
							cacheKey,
							integrity
						};
					}
				}
				{
					logger.debug(`Precaching did not find a match for ` + getFriendlyURL(request.url));
				}
				return;
			};
			super(match, precacheController.strategy);
		}
	}
	/*
	Copyright 2019 Google LLC
	Use of this source code is governed by an MIT-style
	license that can be found in the LICENSE file or at
	https://opensource.org/licenses/MIT.
	*/
	/**
	* Add a `fetch` listener to the service worker that will
	* respond to
	* [network requests]{@link https://developer.mozilla.org/en-US/docs/Web/API/Service_Worker_API/Using_Service_Workers#Custom_responses_to_requests}
	* with precached assets.
	*
	* Requests for assets that aren't precached, the `FetchEvent` will not be
	* responded to, allowing the event to fall through to other `fetch` event
	* listeners.
	*
	* @param {Object} [options] See the {@link workbox-precaching.PrecacheRoute}
	* options.
	*
	* @memberof workbox-precaching
	*/
	function addRoute(options) {
		const precacheController = getOrCreatePrecacheController();
		const precacheRoute = new PrecacheRoute(precacheController, options);
		registerRoute(precacheRoute);
	}
	/*
	Copyright 2019 Google LLC
	
	Use of this source code is governed by an MIT-style
	license that can be found in the LICENSE file or at
	https://opensource.org/licenses/MIT.
	*/
	/**
	* Adds items to the precache list, removing any duplicates and
	* stores the files in the
	* {@link workbox-core.cacheNames|"precache cache"} when the service
	* worker installs.
	*
	* This method can be called multiple times.
	*
	* Please note: This method **will not** serve any of the cached files for you.
	* It only precaches files. To respond to a network request you call
	* {@link workbox-precaching.addRoute}.
	*
	* If you have a single array of files to precache, you can just call
	* {@link workbox-precaching.precacheAndRoute}.
	*
	* @param {Array<Object|string>} [entries=[]] Array of entries to precache.
	*
	* @memberof workbox-precaching
	*/
	function precache(entries) {
		const precacheController = getOrCreatePrecacheController();
		precacheController.precache(entries);
	}
	/*
	Copyright 2019 Google LLC
	
	Use of this source code is governed by an MIT-style
	license that can be found in the LICENSE file or at
	https://opensource.org/licenses/MIT.
	*/
	/**
	* This method will add entries to the precache list and add a route to
	* respond to fetch events.
	*
	* This is a convenience method that will call
	* {@link workbox-precaching.precache} and
	* {@link workbox-precaching.addRoute} in a single call.
	*
	* @param {Array<Object|string>} entries Array of entries to precache.
	* @param {Object} [options] See the
	* {@link workbox-precaching.PrecacheRoute} options.
	*
	* @memberof workbox-precaching
	*/
	function precacheAndRoute(entries, options) {
		precache(entries);
		addRoute(options);
	}
	/*
	Copyright 2018 Google LLC
	
	Use of this source code is governed by an MIT-style
	license that can be found in the LICENSE file or at
	https://opensource.org/licenses/MIT.
	*/
	const SUBSTRING_TO_FIND = "-precache-";
	/**
	* Cleans up incompatible precaches that were created by older versions of
	* Workbox, by a service worker registered under the current scope.
	*
	* This is meant to be called as part of the `activate` event.
	*
	* This should be safe to use as long as you don't include `substringToFind`
	* (defaulting to `-precache-`) in your non-precache cache names.
	*
	* @param {string} currentPrecacheName The cache name currently in use for
	* precaching. This cache won't be deleted.
	* @param {string} [substringToFind='-precache-'] Cache names which include this
	* substring will be deleted (excluding `currentPrecacheName`).
	* @return {Array<string>} A list of all the cache names that were deleted.
	*
	* @private
	* @memberof workbox-precaching
	*/
	const deleteOutdatedCaches = async (currentPrecacheName, substringToFind = SUBSTRING_TO_FIND) => {
		const cacheNames = await self.caches.keys();
		const cacheNamesToDelete = cacheNames.filter((cacheName) => {
			return cacheName.includes(substringToFind) && cacheName.includes(self.registration.scope) && cacheName !== currentPrecacheName;
		});
		await Promise.all(cacheNamesToDelete.map((cacheName) => self.caches.delete(cacheName)));
		return cacheNamesToDelete;
	};
	/*
	Copyright 2019 Google LLC
	
	Use of this source code is governed by an MIT-style
	license that can be found in the LICENSE file or at
	https://opensource.org/licenses/MIT.
	*/
	/**
	* Adds an `activate` event listener which will clean up incompatible
	* precaches that were created by older versions of Workbox.
	*
	* @memberof workbox-precaching
	*/
	function cleanupOutdatedCaches() {
		// See https://github.com/Microsoft/TypeScript/issues/28357#issuecomment-436484705
		self.addEventListener("activate", (event) => {
			const cacheName = cacheNames.getPrecacheName();
			event.waitUntil(deleteOutdatedCaches(cacheName).then((cachesDeleted) => {
				{
					if (cachesDeleted.length > 0) {
						logger.log(`The following out-of-date precaches were cleaned up ` + `automatically:`, cachesDeleted);
					}
				}
			}));
		});
	}
	/*
	Copyright 2018 Google LLC
	
	Use of this source code is governed by an MIT-style
	license that can be found in the LICENSE file or at
	https://opensource.org/licenses/MIT.
	*/
	/**
	* NavigationRoute makes it easy to create a
	* {@link workbox-routing.Route} that matches for browser
	* [navigation requests]{@link https://developers.google.com/web/fundamentals/primers/service-workers/high-performance-loading#first_what_are_navigation_requests}.
	*
	* It will only match incoming Requests whose
	* {@link https://fetch.spec.whatwg.org/#concept-request-mode|mode}
	* is set to `navigate`.
	*
	* You can optionally only apply this route to a subset of navigation requests
	* by using one or both of the `denylist` and `allowlist` parameters.
	*
	* @memberof workbox-routing
	* @extends workbox-routing.Route
	*/
	class NavigationRoute extends Route {
		/**
		* If both `denylist` and `allowlist` are provided, the `denylist` will
		* take precedence and the request will not match this route.
		*
		* The regular expressions in `allowlist` and `denylist`
		* are matched against the concatenated
		* [`pathname`]{@link https://developer.mozilla.org/en-US/docs/Web/API/HTMLHyperlinkElementUtils/pathname}
		* and [`search`]{@link https://developer.mozilla.org/en-US/docs/Web/API/HTMLHyperlinkElementUtils/search}
		* portions of the requested URL.
		*
		* *Note*: These RegExps may be evaluated against every destination URL during
		* a navigation. Avoid using
		* [complex RegExps](https://github.com/GoogleChrome/workbox/issues/3077),
		* or else your users may see delays when navigating your site.
		*
		* @param {workbox-routing~handlerCallback} handler A callback
		* function that returns a Promise resulting in a Response.
		* @param {Object} options
		* @param {Array<RegExp>} [options.denylist] If any of these patterns match,
		* the route will not handle the request (even if a allowlist RegExp matches).
		* @param {Array<RegExp>} [options.allowlist=[/./]] If any of these patterns
		* match the URL's pathname and search parameter, the route will handle the
		* request (assuming the denylist doesn't match).
		*/
		constructor(handler, { allowlist = [/./], denylist = [] } = {}) {
			{
				finalAssertExports.isArrayOfClass(allowlist, RegExp, {
					moduleName: "workbox-routing",
					className: "NavigationRoute",
					funcName: "constructor",
					paramName: "options.allowlist"
				});
				finalAssertExports.isArrayOfClass(denylist, RegExp, {
					moduleName: "workbox-routing",
					className: "NavigationRoute",
					funcName: "constructor",
					paramName: "options.denylist"
				});
			}
			super((options) => this._match(options), handler);
			this._allowlist = allowlist;
			this._denylist = denylist;
		}
		/**
		* Routes match handler.
		*
		* @param {Object} options
		* @param {URL} options.url
		* @param {Request} options.request
		* @return {boolean}
		*
		* @private
		*/
		_match({ url, request }) {
			if (request && request.mode !== "navigate") {
				return false;
			}
			const pathnameAndSearch = url.pathname + url.search;
			for (const regExp of this._denylist) {
				if (regExp.test(pathnameAndSearch)) {
					{
						logger.log(`The navigation route ${pathnameAndSearch} is not ` + `being used, since the URL matches this denylist pattern: ` + `${regExp.toString()}`);
					}
					return false;
				}
			}
			if (this._allowlist.some((regExp) => regExp.test(pathnameAndSearch))) {
				{
					logger.debug(`The navigation route ${pathnameAndSearch} ` + `is being used.`);
				}
				return true;
			}
			{
				logger.log(`The navigation route ${pathnameAndSearch} is not ` + `being used, since the URL being navigated to doesn't ` + `match the allowlist.`);
			}
			return false;
		}
	}
	/*
	Copyright 2019 Google LLC
	
	Use of this source code is governed by an MIT-style
	license that can be found in the LICENSE file or at
	https://opensource.org/licenses/MIT.
	*/
	/**
	* Helper function that calls
	* {@link PrecacheController#createHandlerBoundToURL} on the default
	* {@link PrecacheController} instance.
	*
	* If you are creating your own {@link PrecacheController}, then call the
	* {@link PrecacheController#createHandlerBoundToURL} on that instance,
	* instead of using this function.
	*
	* @param {string} url The precached URL which will be used to lookup the
	* `Response`.
	* @param {boolean} [fallbackToNetwork=true] Whether to attempt to get the
	* response from the network if there's a precache miss.
	* @return {workbox-routing~handlerCallback}
	*
	* @memberof workbox-precaching
	*/
	function createHandlerBoundToURL(url) {
		const precacheController = getOrCreatePrecacheController();
		return precacheController.createHandlerBoundToURL(url);
	}
	exports.CacheableResponsePlugin = CacheableResponsePlugin;
	exports.ExpirationPlugin = ExpirationPlugin;
	exports.NavigationRoute = NavigationRoute;
	exports.NetworkFirst = NetworkFirst;
	exports.cleanupOutdatedCaches = cleanupOutdatedCaches;
	exports.clientsClaim = clientsClaim;
	exports.createHandlerBoundToURL = createHandlerBoundToURL;
	exports.precacheAndRoute = precacheAndRoute;
	exports.registerRoute = registerRoute;
}));
//# sourceMappingURL=workbox-970124e6.js.map
//# sourceMappingURL=workbox-970124e6.js.map

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxDQUFDLFNBQVMsSUFBSSxTQUFVLFNBQVM7Q0FBRTs7Q0FHdEMsSUFBSTtFQUNGLEtBQUsseUJBQXlCLEVBQUU7Q0FDbEMsU0FBUyxHQUFHLENBQUM7Ozs7Ozs7Q0FRYixNQUFNLGdCQUFnQjs7O0VBR3BCLElBQUksRUFBRSwyQkFBMkIsYUFBYTtHQUM1QyxLQUFLLHdCQUF3QjtFQUMvQjtFQUNBLElBQUksVUFBVTtFQUNkLE1BQU0sbUJBQW1CO0dBQ3ZCLE9BQU87R0FDUCxLQUFLO0dBQ0wsTUFBTTtHQUNOLE9BQU87R0FDUCxnQkFBZ0I7R0FDaEIsVUFBVTtFQUNaO0VBQ0EsTUFBTSxRQUFRLFNBQVUsUUFBUSxNQUFNO0dBQ3BDLElBQUksS0FBSyx1QkFBdUI7SUFDOUI7R0FDRjtHQUNBLElBQUksV0FBVyxrQkFBa0I7OztJQUcvQixJQUFJLGlDQUFpQyxLQUFLLFVBQVUsU0FBUyxHQUFHO0tBQzlELFFBQVEsT0FBTyxDQUFDLEdBQUcsSUFBSTtLQUN2QjtJQUNGO0dBQ0Y7R0FDQSxNQUFNLFNBQVM7SUFBQyxlQUFlLGlCQUFpQjtJQUFXO0lBQXdCO0lBQWdCO0lBQXFCO0dBQW9COztHQUU1SSxNQUFNLFlBQVksVUFBVSxDQUFDLElBQUksQ0FBQyxhQUFhLE9BQU8sS0FBSyxHQUFHLENBQUM7R0FDL0QsUUFBUSxPQUFPLENBQUMsR0FBRyxXQUFXLEdBQUcsSUFBSTtHQUNyQyxJQUFJLFdBQVcsa0JBQWtCO0lBQy9CLFVBQVU7R0FDWjtHQUNBLElBQUksV0FBVyxZQUFZO0lBQ3pCLFVBQVU7R0FDWjtFQUNGOztFQUVBLE1BQU0sTUFBTSxDQUFDO0VBQ2IsTUFBTSxnQkFBZ0IsT0FBTyxLQUFLLGdCQUFnQjtFQUNsRCxLQUFLLE1BQU0sT0FBTyxlQUFlO0dBQy9CLE1BQU0sU0FBUztHQUNmLElBQUksV0FBVyxHQUFHLFNBQVM7SUFDekIsTUFBTSxRQUFRLElBQUk7R0FDcEI7RUFDRjtFQUNBLE9BQU87Q0FDVCxFQUFDLENBQUU7Ozs7Ozs7O0NBU0gsTUFBTSxhQUFhO0VBQ2pCLGtCQUFrQixFQUNoQixXQUNBLHVCQUNBLFlBQ0k7R0FDSixJQUFJLENBQUMsYUFBYSxDQUFDLHVCQUF1QjtJQUN4QyxNQUFNLElBQUksTUFBTSw0Q0FBNEM7R0FDOUQ7R0FDQSxPQUFPLFFBQVEsVUFBVSwwQ0FBMEMscUJBQXFCLHNCQUFzQix5QkFBeUIsR0FBRyxLQUFLLFVBQVUsS0FBSyxFQUFFO0VBQ2xLO0VBQ0EsaUJBQWlCLEVBQ2YsWUFDQSxXQUNBLFVBQ0EsZ0JBQ0k7R0FDSixJQUFJLENBQUMsY0FBYyxDQUFDLGFBQWEsQ0FBQyxZQUFZLENBQUMsV0FBVztJQUN4RCxNQUFNLElBQUksTUFBTSwyQ0FBMkM7R0FDN0Q7R0FDQSxPQUFPLGtCQUFrQixVQUFVLGtCQUFrQixJQUFJLFdBQVcsR0FBRyxVQUFVLEdBQUcsU0FBUztFQUMvRjtFQUNBLG1CQUFtQixFQUNqQixjQUNBLFdBQ0EsWUFDQSxXQUNBLGVBQ0k7R0FDSixJQUFJLENBQUMsZ0JBQWdCLENBQUMsYUFBYSxDQUFDLGNBQWMsQ0FBQyxVQUFVO0lBQzNELE1BQU0sSUFBSSxNQUFNLDZDQUE2QztHQUMvRDtHQUNBLE1BQU0sZUFBZSxZQUFZLEdBQUcsVUFBVSxLQUFLO0dBQ25ELE9BQU8sa0JBQWtCLFVBQVUsa0JBQWtCLElBQUksV0FBVyxHQUFHLGlCQUFpQixHQUFHLFNBQVMsc0JBQXNCLGFBQWE7RUFDekk7RUFDQSxvQkFBb0IsRUFDbEIsbUJBQ0EsV0FDQSxZQUNBLFdBQ0EsVUFDQSwyQkFDSTtHQUNKLElBQUksQ0FBQyxxQkFBcUIsQ0FBQyxjQUFjLENBQUMsVUFBVTtJQUNsRCxNQUFNLElBQUksTUFBTSw4Q0FBOEM7R0FDaEU7R0FDQSxNQUFNLGVBQWUsWUFBWSxHQUFHLFVBQVUsS0FBSztHQUNuRCxJQUFJLHNCQUFzQjtJQUN4QixPQUFPLDJCQUEyQixJQUFJLFdBQVcsR0FBRyxlQUFlLFNBQVMsUUFBUSxnQ0FBZ0Msa0JBQWtCO0dBQ3hJO0dBQ0EsT0FBTyxrQkFBa0IsVUFBVSxrQkFBa0IsSUFBSSxXQUFXLEdBQUcsZUFBZSxTQUFTLFFBQVEsZ0NBQWdDLGtCQUFrQjtFQUMzSjtFQUNBLHFCQUFxQixFQUNuQixnQkFDQSxXQUNBLFlBQ0EsV0FDQSxlQUNJO0dBQ0osSUFBSSxDQUFDLGtCQUFrQixDQUFDLGFBQWEsQ0FBQyxjQUFjLENBQUMsYUFBYSxDQUFDLFVBQVU7SUFDM0UsTUFBTSxJQUFJLE1BQU0sK0NBQStDO0dBQ2pFO0dBQ0EsT0FBTyxHQUFHLFdBQVcsR0FBRyxVQUFVLEdBQUcsU0FBUyxvQkFBb0IsSUFBSSxVQUFVLDJCQUEyQixlQUFlO0VBQzVIO0VBQ0Esc0NBQXNDLEVBQ3BDLFlBQ0k7R0FDSixPQUFPLHVDQUF1Qyx3RUFBd0UsSUFBSSxLQUFLLFVBQVUsS0FBSyxFQUFFLG1EQUFtRCx5RUFBeUU7RUFDOVE7RUFDQSwwQ0FBMEMsRUFDeEMsWUFDQSxrQkFDSTtHQUNKLElBQUksQ0FBQyxjQUFjLENBQUMsYUFBYTtJQUMvQixNQUFNLElBQUksTUFBTSx5QkFBeUIsOENBQThDO0dBQ3pGO0dBQ0EsT0FBTyxrQ0FBa0MsMEVBQTBFLEdBQUcsV0FBVyxnREFBZ0Qsd0VBQXdFO0VBQzNQO0VBQ0Esb0NBQW9DLEVBQ2xDLHlCQUNJO0dBQ0osSUFBSSxDQUFDLG9CQUFvQjtJQUN2QixNQUFNLElBQUksTUFBTSx5QkFBeUIsMkNBQTJDO0dBQ3RGO0dBQ0EsT0FBTyxtRUFBbUUsa0NBQWtDLG1CQUFtQjtFQUNqSTtFQUNBLHVCQUF1QixFQUNyQixhQUNBLFlBQ0k7R0FDSixJQUFJLENBQUMsYUFBYTtJQUNoQixNQUFNLElBQUksTUFBTSx5REFBeUQ7R0FDM0U7R0FDQSxPQUFPLG1FQUFtRSxvQkFBb0IsWUFBWSxtQ0FBbUMsSUFBSSxLQUFLLFVBQVUsS0FBSyxFQUFFO0VBQ3pLO0VBQ0EsK0NBQStDLEVBQzdDLGFBQ0k7R0FDSixJQUFJLENBQUMsUUFBUTtJQUNYLE1BQU0sSUFBSSxNQUFNLHlCQUF5QixxREFBcUQ7R0FDaEc7R0FDQSxPQUFPLCtEQUErRCxtQ0FBbUMsT0FBTztFQUNsSDtFQUNBLCtDQUErQztHQUM3QyxPQUFPLDhEQUE4RDtFQUN2RTtFQUNBLHdCQUF3QixFQUN0QixXQUNJO0dBQ0osT0FBTyx3Q0FBd0MsS0FBSztFQUN0RDtFQUNBLHlCQUF5QixFQUN2QixXQUNJO0dBQ0osT0FBTyxtQkFBbUIsS0FBSyw2QkFBNkI7RUFDOUQ7RUFDQSxpQ0FBaUMsRUFDL0IsWUFDQSxnQkFDSTtHQUNKLE9BQU8sUUFBUSxXQUFXLHlDQUF5QyxJQUFJLFVBQVU7RUFDbkY7RUFDQSwyQkFBMkIsRUFDekIsWUFDQSxXQUNBLFVBQ0EsZ0JBQ0k7R0FDSixPQUFPLGlCQUFpQixVQUFVLHlDQUF5Qyw2QkFBNkIsV0FBVyxHQUFHLFVBQVUsR0FBRyxTQUFTLFNBQVM7RUFDdko7RUFDQSx1QkFBdUIsRUFDckIsT0FDQSxlQUNBLFlBQ0EsV0FDQSxVQUNBLGdCQUNJO0dBQ0osT0FBTyxpQkFBaUIsVUFBVSxvQ0FBb0MsSUFBSSxjQUFjLHVCQUF1QixLQUFLLFVBQVUsS0FBSyxFQUFFLFFBQVEsNEJBQTRCLFdBQVcsR0FBRyxVQUFVLEdBQUcsU0FBUyxPQUFPO0VBQ3ROO0VBQ0EsZ0NBQWdDLEVBQzlCLFlBQ0EsV0FDQSxlQUNJO0dBQ0osT0FBTyxxRUFBcUUsTUFBTSxXQUFXLEdBQUcsVUFBVSxHQUFHO0VBQy9HO0VBQ0EsaUNBQWlDLEVBQy9CLFlBQ0EsV0FDQSxlQUNJO0dBQ0osT0FBTyw2REFBNkQsTUFBTSxXQUFXLEdBQUcsVUFBVSxHQUFHO0VBQ3ZHO0VBQ0EsbUJBQW1CLEVBQ2pCLFlBQ0EsVUFDQSxnQkFDSTtHQUNKLElBQUksQ0FBQyxhQUFhLENBQUMsY0FBYyxDQUFDLFVBQVU7SUFDMUMsTUFBTSxJQUFJLE1BQU0sNkNBQTZDO0dBQy9EO0dBQ0EsT0FBTyw0QkFBNEIsVUFBVSxnQ0FBZ0MseUVBQXlFLDJCQUEyQixXQUFXLEdBQUcsU0FBUyxXQUFXO0VBQ3JOO0VBQ0EsK0JBQStCO0dBQzdCLE9BQU8sbURBQW1EO0VBQzVEO0VBQ0EseUNBQXlDO0dBQ3ZDLE9BQU8sK0RBQStEO0VBQ3hFO0VBQ0EsbUNBQW1DO0dBQ2pDLE9BQU8sNERBQTREO0VBQ3JFO0VBQ0EsdUJBQXVCLEVBQ3JCLDRCQUNJO0dBQ0osSUFBSSxDQUFDLHVCQUF1QjtJQUMxQixNQUFNLElBQUksTUFBTSxpREFBaUQ7R0FDbkU7R0FDQSxPQUFPLG9FQUFvRSxrQ0FBa0Msc0JBQXNCO0VBQ3JJO0VBQ0Esc0JBQXNCLEVBQ3BCLDRCQUNJO0dBQ0osSUFBSSxDQUFDLHVCQUF1QjtJQUMxQixNQUFNLElBQUksTUFBTSxnREFBZ0Q7R0FDbEU7R0FDQSxPQUFPLG1FQUFtRSxrRUFBa0UsSUFBSSxzQkFBc0I7RUFDeEs7RUFDQSx5QkFBeUIsRUFDdkIsNEJBQ0k7R0FDSixJQUFJLENBQUMsdUJBQXVCO0lBQzFCLE1BQU0sSUFBSSxNQUFNLG1EQUFtRDtHQUNyRTtHQUNBLE9BQU8scUVBQXFFLGtFQUFrRSxJQUFJLHNCQUFzQjtFQUMxSztFQUNBLHlCQUF5QjtHQUN2QixPQUFPO0VBQ1Q7RUFDQSwwQkFBMEIsRUFDeEIsTUFDQSxPQUNBLFVBQ0k7R0FDSixPQUFPLGNBQWMsTUFBTSxhQUFhLElBQUksOEJBQThCLG9EQUFvRCxLQUFLO0VBQ3JJO0VBQ0EscUNBQXFDLEVBQ25DLEtBQ0EsYUFDSTtHQUNKLE9BQU8sb0JBQW9CLElBQUkscUJBQXFCLE9BQU8sa0JBQWtCO0VBQy9FO0VBQ0EsK0JBQStCLEVBQzdCLFVBQ0k7R0FDSixPQUFPLGtDQUFrQyxJQUFJLCtCQUErQjtFQUM5RTtFQUNBLGdCQUFnQixFQUNkLEtBQ0EsWUFDSTtHQUNKLElBQUksVUFBVSxtREFBbUQsSUFBSTtHQUNyRSxJQUFJLE9BQU87SUFDVCxXQUFXLDRCQUE0QixNQUFNO0dBQy9DO0dBQ0EsT0FBTztFQUNUO0VBQ0EsNEJBQTRCLEVBQzFCLEtBQ0EsYUFDSTtHQUNKLE9BQU8sK0JBQStCLElBQUksYUFBYSxTQUFTLDJCQUEyQixPQUFPLEtBQUs7RUFDekc7RUFDQSxzQkFBc0IsRUFDcEIsVUFDSTtHQUNKLE9BQU8sNEJBQTRCLElBQUksbUNBQW1DO0VBQzVFO0VBQ0EsOENBQThDLEVBQzVDLFVBQ0k7R0FDSixPQUFPLGtDQUFrQywwRUFBMEUsR0FBRyxJQUFJO0VBQzVIO0VBQ0EsMkJBQTJCLEVBQ3pCLFdBQ0EsVUFDSTtHQUNKLE9BQU8sMENBQTBDLFVBQVUsT0FBTyxJQUFJO0VBQ3hFO0VBQ0EsK0JBQStCLEVBQzdCLGFBQ0k7R0FDSixPQUFPLG1FQUFtRSxtREFBbUQsT0FBTztFQUN0STtFQUNBLDBCQUEwQixFQUN4QixXQUNJO0dBQ0osTUFBTSxVQUFVLHVEQUF1RCxJQUFJLEtBQUs7R0FDaEYsSUFBSSxTQUFTLGtCQUFrQjtJQUM3QixPQUFPLEdBQUcsUUFBUSx5REFBeUQ7R0FDN0U7R0FDQSxPQUFPLEdBQUcsUUFBUTtFQUNwQjtDQUNGOzs7Ozs7OztDQVNBLE1BQU0scUJBQXFCLE1BQU0sVUFBVSxDQUFDLE1BQU07RUFDaEQsTUFBTSxVQUFVLFdBQVc7RUFDM0IsSUFBSSxDQUFDLFNBQVM7R0FDWixNQUFNLElBQUksTUFBTSxvQ0FBb0MsS0FBSyxHQUFHO0VBQzlEO0VBQ0EsT0FBTyxRQUFRLE9BQU87Q0FDeEI7Q0FDQSxNQUFNLG1CQUFtQjs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0FrQnpCLE1BQU0scUJBQXFCLE1BQU07Ozs7Ozs7OztFQVMvQixZQUFZLFdBQVcsU0FBUztHQUM5QixNQUFNLFVBQVUsaUJBQWlCLFdBQVcsT0FBTztHQUNuRCxNQUFNLE9BQU87R0FDYixLQUFLLE9BQU87R0FDWixLQUFLLFVBQVU7RUFDakI7Q0FDRjs7Ozs7Ozs7Ozs7Ozs7Q0FlQSxNQUFNLFdBQVcsT0FBTyxZQUFZO0VBQ2xDLElBQUksQ0FBQyxNQUFNLFFBQVEsS0FBSyxHQUFHO0dBQ3pCLE1BQU0sSUFBSSxhQUFhLGdCQUFnQixPQUFPO0VBQ2hEO0NBQ0Y7Q0FDQSxNQUFNLGFBQWEsUUFBUSxnQkFBZ0IsWUFBWTtFQUNyRCxNQUFNLE9BQU8sT0FBTyxPQUFPO0VBQzNCLElBQUksU0FBUyxZQUFZO0dBQ3ZCLFFBQVEsb0JBQW9CO0dBQzVCLE1BQU0sSUFBSSxhQUFhLG9CQUFvQixPQUFPO0VBQ3BEO0NBQ0Y7Q0FDQSxNQUFNLFVBQVUsUUFBUSxjQUFjLFlBQVk7RUFDaEQsSUFBSSxPQUFPLFdBQVcsY0FBYztHQUNsQyxRQUFRLGtCQUFrQjtHQUMxQixNQUFNLElBQUksYUFBYSxrQkFBa0IsT0FBTztFQUNsRDtDQUNGO0NBQ0EsTUFBTSxjQUFjLFFBR3BCLGVBQWUsWUFBWTtFQUN6QixJQUFJLEVBQUUsa0JBQWtCLGdCQUFnQjtHQUN0QyxRQUFRLHVCQUF1QixjQUFjO0dBQzdDLE1BQU0sSUFBSSxhQUFhLG1CQUFtQixPQUFPO0VBQ25EO0NBQ0Y7Q0FDQSxNQUFNLFdBQVcsT0FBTyxhQUFhLFlBQVk7RUFDL0MsSUFBSSxDQUFDLFlBQVksU0FBUyxLQUFLLEdBQUc7R0FDaEMsUUFBUSwyQkFBMkIsb0JBQW9CLEtBQUssVUFBVSxXQUFXLEVBQUU7R0FDbkYsTUFBTSxJQUFJLGFBQWEsaUJBQWlCLE9BQU87RUFDakQ7Q0FDRjtDQUNBLE1BQU0sa0JBQWtCLE9BRXhCLGVBRUEsWUFBWTtFQUNWLE1BQU0sUUFBUSxJQUFJLGFBQWEsc0JBQXNCLE9BQU87RUFDNUQsSUFBSSxDQUFDLE1BQU0sUUFBUSxLQUFLLEdBQUc7R0FDekIsTUFBTTtFQUNSO0VBQ0EsS0FBSyxNQUFNLFFBQVEsT0FBTztHQUN4QixJQUFJLEVBQUUsZ0JBQWdCLGdCQUFnQjtJQUNwQyxNQUFNO0dBQ1I7RUFDRjtDQUNGO0NBQ0EsTUFBTSxxQkFBcUI7RUFDekI7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0NBQ0Y7O0NBR0EsSUFBSTtFQUNGLEtBQUssNEJBQTRCLEVBQUU7Q0FDckMsU0FBUyxHQUFHLENBQUM7Ozs7Ozs7Ozs7Ozs7Ozs7Q0FpQmIsTUFBTSxnQkFBZ0I7Ozs7Ozs7O0NBUXRCLE1BQU0sZUFBZTtFQUFDO0VBQVU7RUFBTztFQUFRO0VBQVM7RUFBUTtDQUFLOzs7Ozs7Ozs7Ozs7Ozs7Q0FnQnJFLE1BQU0sb0JBQW1CLFlBQVc7RUFDbEMsSUFBSSxXQUFXLE9BQU8sWUFBWSxVQUFVO0dBQzFDO0lBQ0UsbUJBQW1CLFVBQVUsU0FBUyxVQUFVO0tBQzlDLFlBQVk7S0FDWixXQUFXO0tBQ1gsVUFBVTtLQUNWLFdBQVc7SUFDYixDQUFDO0dBQ0g7R0FDQSxPQUFPO0VBQ1QsT0FBTztHQUNMO0lBQ0UsbUJBQW1CLE9BQU8sU0FBUyxZQUFZO0tBQzdDLFlBQVk7S0FDWixXQUFXO0tBQ1gsVUFBVTtLQUNWLFdBQVc7SUFDYixDQUFDO0dBQ0g7R0FDQSxPQUFPLEVBQ0wsUUFBUSxRQUNWO0VBQ0Y7Q0FDRjs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0FrQkEsTUFBTSxNQUFNOzs7Ozs7Ozs7Ozs7RUFZVixZQUFZLE9BQU8sU0FBUyxTQUFTLGVBQWU7R0FDbEQ7SUFDRSxtQkFBbUIsT0FBTyxPQUFPLFlBQVk7S0FDM0MsWUFBWTtLQUNaLFdBQVc7S0FDWCxVQUFVO0tBQ1YsV0FBVztJQUNiLENBQUM7SUFDRCxJQUFJLFFBQVE7S0FDVixtQkFBbUIsUUFBUSxRQUFRLGNBQWMsRUFDL0MsV0FBVyxTQUNiLENBQUM7SUFDSDtHQUNGOzs7R0FHQSxLQUFLLFVBQVUsaUJBQWlCLE9BQU87R0FDdkMsS0FBSyxRQUFRO0dBQ2IsS0FBSyxTQUFTO0VBQ2hCOzs7Ozs7RUFNQSxnQkFBZ0IsU0FBUztHQUN2QixLQUFLLGVBQWUsaUJBQWlCLE9BQU87RUFDOUM7Q0FDRjs7Ozs7Ozs7Ozs7Ozs7Ozs7OztDQW9CQSxNQUFNLG9CQUFvQixNQUFNOzs7Ozs7Ozs7Ozs7OztFQWM5QixZQUFZLFFBQVEsU0FBUyxRQUFRO0dBQ25DO0lBQ0UsbUJBQW1CLFdBQVcsUUFBUSxRQUFRO0tBQzVDLFlBQVk7S0FDWixXQUFXO0tBQ1gsVUFBVTtLQUNWLFdBQVc7SUFDYixDQUFDO0dBQ0g7R0FDQSxNQUFNLFNBQVMsRUFDYixVQUNJO0lBQ0osTUFBTSxTQUFTLE9BQU8sS0FBSyxJQUFJLElBQUk7O0lBRW5DLElBQUksQ0FBQyxRQUFRO0tBQ1g7SUFDRjs7Ozs7SUFLQSxJQUFJLElBQUksV0FBVyxTQUFTLFVBQVUsT0FBTyxVQUFVLEdBQUc7S0FDeEQ7TUFDRSxPQUFPLE1BQU0sMkJBQTJCLE9BQU8sU0FBUyxFQUFFLDZCQUE2QixpQ0FBaUMsSUFBSSxTQUFTLEVBQUUsK0JBQStCLDREQUE0RDtLQUNwTztLQUNBO0lBQ0Y7Ozs7O0lBS0EsT0FBTyxPQUFPLE1BQU0sQ0FBQztHQUN2QjtHQUNBLE1BQU0sT0FBTyxTQUFTLE1BQU07RUFDOUI7Q0FDRjs7Ozs7Ozs7Q0FTQSxNQUFNLGtCQUFpQixRQUFPO0VBQzVCLE1BQU0sU0FBUyxJQUFJLElBQUksT0FBTyxHQUFHLEdBQUcsU0FBUyxJQUFJOzs7RUFHakQsT0FBTyxPQUFPLEtBQUssUUFBUSxJQUFJLE9BQU8sSUFBSSxTQUFTLFFBQVEsR0FBRyxFQUFFO0NBQ2xFOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBMEJBLE1BQU0sT0FBTzs7OztFQUlYLGNBQWM7R0FDWixLQUFLLFVBQVUsSUFBSSxJQUFJO0dBQ3ZCLEtBQUsscUJBQXFCLElBQUksSUFBSTtFQUNwQzs7Ozs7O0VBTUEsSUFBSSxTQUFTO0dBQ1gsT0FBTyxLQUFLO0VBQ2Q7Ozs7O0VBS0EsbUJBQW1COztHQUVqQixLQUFLLGlCQUFpQixVQUFTLFVBQVM7SUFDdEMsTUFBTSxFQUNKLFlBQ0U7SUFDSixNQUFNLGtCQUFrQixLQUFLLGNBQWM7S0FDekM7S0FDQTtJQUNGLENBQUM7SUFDRCxJQUFJLGlCQUFpQjtLQUNuQixNQUFNLFlBQVksZUFBZTtJQUNuQztHQUNGLENBQUM7RUFDSDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7RUF1QkEsbUJBQW1COztHQUVqQixLQUFLLGlCQUFpQixZQUFXLFVBQVM7OztJQUd4QyxJQUFJLE1BQU0sUUFBUSxNQUFNLEtBQUssU0FBUyxjQUFjOztLQUVsRCxNQUFNLEVBQ0osWUFDRSxNQUFNO0tBQ1Y7TUFDRSxPQUFPLE1BQU0sZ0NBQWdDLFFBQVEsV0FBVztLQUNsRTtLQUNBLE1BQU0sa0JBQWtCLFFBQVEsSUFBSSxRQUFRLFlBQVksS0FBSSxVQUFTO01BQ25FLElBQUksT0FBTyxVQUFVLFVBQVU7T0FDN0IsUUFBUSxDQUFDLEtBQUs7TUFDaEI7TUFDQSxNQUFNLFVBQVUsSUFBSSxRQUFRLEdBQUcsS0FBSztNQUNwQyxPQUFPLEtBQUssY0FBYztPQUN4QjtPQUNBO01BQ0YsQ0FBQzs7OztLQUlILENBQUMsQ0FBQztLQUNGLE1BQU0sVUFBVSxlQUFlOztLQUUvQixJQUFJLE1BQU0sU0FBUyxNQUFNLE1BQU0sSUFBSTtNQUNqQyxLQUFLLGdCQUFnQixXQUFXLE1BQU0sTUFBTSxFQUFFLENBQUMsWUFBWSxJQUFJLENBQUM7S0FDbEU7SUFDRjtHQUNGLENBQUM7RUFDSDs7Ozs7Ozs7Ozs7OztFQWFBLGNBQWMsRUFDWixTQUNBLFNBQ0M7R0FDRDtJQUNFLG1CQUFtQixXQUFXLFNBQVMsU0FBUztLQUM5QyxZQUFZO0tBQ1osV0FBVztLQUNYLFVBQVU7S0FDVixXQUFXO0lBQ2IsQ0FBQztHQUNIO0dBQ0EsTUFBTSxNQUFNLElBQUksSUFBSSxRQUFRLEtBQUssU0FBUyxJQUFJO0dBQzlDLElBQUksQ0FBQyxJQUFJLFNBQVMsV0FBVyxNQUFNLEdBQUc7SUFDcEM7S0FDRSxPQUFPLE1BQU0sMkRBQTJEO0lBQzFFO0lBQ0E7R0FDRjtHQUNBLE1BQU0sYUFBYSxJQUFJLFdBQVcsU0FBUztHQUMzQyxNQUFNLEVBQ0osUUFDQSxVQUNFLEtBQUssa0JBQWtCO0lBQ3pCO0lBQ0E7SUFDQTtJQUNBO0dBQ0YsQ0FBQztHQUNELElBQUksVUFBVSxTQUFTLE1BQU07R0FDN0IsTUFBTSxnQkFBZ0IsQ0FBQztHQUN2QjtJQUNFLElBQUksU0FBUztLQUNYLGNBQWMsS0FBSyxDQUFDLHlDQUF5QyxLQUFLLENBQUM7S0FDbkUsSUFBSSxRQUFRO01BQ1YsY0FBYyxLQUFLLENBQUMsd0RBQXdELE1BQU0sQ0FBQztLQUNyRjtJQUNGO0dBQ0Y7OztHQUdBLE1BQU0sU0FBUyxRQUFRO0dBQ3ZCLElBQUksQ0FBQyxXQUFXLEtBQUssbUJBQW1CLElBQUksTUFBTSxHQUFHO0lBQ25EO0tBQ0UsY0FBYyxLQUFLLDhDQUE4QyxtQ0FBbUMsT0FBTyxFQUFFO0lBQy9HO0lBQ0EsVUFBVSxLQUFLLG1CQUFtQixJQUFJLE1BQU07R0FDOUM7R0FDQSxJQUFJLENBQUMsU0FBUztJQUNaOzs7S0FHRSxPQUFPLE1BQU0sdUJBQXVCLGVBQWUsR0FBRyxHQUFHO0lBQzNEO0lBQ0E7R0FDRjtHQUNBOzs7SUFHRSxPQUFPLGVBQWUsNEJBQTRCLGVBQWUsR0FBRyxHQUFHO0lBQ3ZFLGNBQWMsU0FBUSxRQUFPO0tBQzNCLElBQUksTUFBTSxRQUFRLEdBQUcsR0FBRztNQUN0QixPQUFPLElBQUksR0FBRyxHQUFHO0tBQ25CLE9BQU87TUFDTCxPQUFPLElBQUksR0FBRztLQUNoQjtJQUNGLENBQUM7SUFDRCxPQUFPLFNBQVM7R0FDbEI7OztHQUdBLElBQUk7R0FDSixJQUFJO0lBQ0Ysa0JBQWtCLFFBQVEsT0FBTztLQUMvQjtLQUNBO0tBQ0E7S0FDQTtJQUNGLENBQUM7R0FDSCxTQUFTLEtBQUs7SUFDWixrQkFBa0IsUUFBUSxPQUFPLEdBQUc7R0FDdEM7O0dBRUEsTUFBTSxlQUFlLFNBQVMsTUFBTTtHQUNwQyxJQUFJLDJCQUEyQixZQUFZLEtBQUssaUJBQWlCLGVBQWU7SUFDOUUsa0JBQWtCLGdCQUFnQixNQUFNLE9BQU0sUUFBTzs7S0FFbkQsSUFBSSxjQUFjO01BQ2hCOzs7T0FHRSxPQUFPLGVBQWUsc0NBQXNDLElBQUksZUFBZSxHQUFHLEVBQUUseUNBQXlDO09BQzdILE9BQU8sTUFBTSxvQkFBb0IsS0FBSztPQUN0QyxPQUFPLE1BQU0sR0FBRztPQUNoQixPQUFPLFNBQVM7TUFDbEI7TUFDQSxJQUFJO09BQ0YsT0FBTyxNQUFNLGFBQWEsT0FBTztRQUMvQjtRQUNBO1FBQ0E7UUFDQTtPQUNGLENBQUM7TUFDSCxTQUFTLFVBQVU7T0FDakIsSUFBSSxvQkFBb0IsT0FBTztRQUM3QixNQUFNO09BQ1I7TUFDRjtLQUNGO0tBQ0EsSUFBSSxLQUFLLGVBQWU7TUFDdEI7OztPQUdFLE9BQU8sZUFBZSxzQ0FBc0MsSUFBSSxlQUFlLEdBQUcsRUFBRSx3Q0FBd0M7T0FDNUgsT0FBTyxNQUFNLG9CQUFvQixLQUFLO09BQ3RDLE9BQU8sTUFBTSxHQUFHO09BQ2hCLE9BQU8sU0FBUztNQUNsQjtNQUNBLE9BQU8sS0FBSyxjQUFjLE9BQU87T0FDL0I7T0FDQTtPQUNBO01BQ0YsQ0FBQztLQUNIO0tBQ0EsTUFBTTtJQUNSLENBQUM7R0FDSDtHQUNBLE9BQU87RUFDVDs7Ozs7Ozs7Ozs7Ozs7OztFQWdCQSxrQkFBa0IsRUFDaEIsS0FDQSxZQUNBLFNBQ0EsU0FDQztHQUNELE1BQU0sU0FBUyxLQUFLLFFBQVEsSUFBSSxRQUFRLE1BQU0sS0FBSyxDQUFDO0dBQ3BELEtBQUssTUFBTSxTQUFTLFFBQVE7SUFDMUIsSUFBSTs7O0lBR0osTUFBTSxjQUFjLE1BQU0sTUFBTTtLQUM5QjtLQUNBO0tBQ0E7S0FDQTtJQUNGLENBQUM7SUFDRCxJQUFJLGFBQWE7S0FDZjs7O01BR0UsSUFBSSx1QkFBdUIsU0FBUztPQUNsQyxPQUFPLEtBQUssaUJBQWlCLGVBQWUsR0FBRyxFQUFFLGVBQWUseURBQXlELGdFQUFnRSxLQUFLO01BQ2hNO0tBQ0Y7OztLQUdBLFNBQVM7S0FDVCxJQUFJLE1BQU0sUUFBUSxNQUFNLEtBQUssT0FBTyxXQUFXLEdBQUc7O01BRWhELFNBQVM7S0FDWCxPQUFPLElBQUksWUFBWSxnQkFBZ0IsVUFFdkMsT0FBTyxLQUFLLFdBQVcsQ0FBQyxDQUFDLFdBQVcsR0FBRzs7TUFFckMsU0FBUztLQUNYLE9BQU8sSUFBSSxPQUFPLGdCQUFnQixXQUFXOzs7O01BSTNDLFNBQVM7S0FDWDs7S0FFQSxPQUFPO01BQ0w7TUFDQTtLQUNGO0lBQ0Y7R0FDRjs7R0FFQSxPQUFPLENBQUM7RUFDVjs7Ozs7Ozs7Ozs7Ozs7O0VBZUEsa0JBQWtCLFNBQVMsU0FBUyxlQUFlO0dBQ2pELEtBQUssbUJBQW1CLElBQUksUUFBUSxpQkFBaUIsT0FBTyxDQUFDO0VBQy9EOzs7Ozs7OztFQVFBLGdCQUFnQixTQUFTO0dBQ3ZCLEtBQUssZ0JBQWdCLGlCQUFpQixPQUFPO0VBQy9DOzs7Ozs7RUFNQSxjQUFjLE9BQU87R0FDbkI7SUFDRSxtQkFBbUIsT0FBTyxPQUFPLFVBQVU7S0FDekMsWUFBWTtLQUNaLFdBQVc7S0FDWCxVQUFVO0tBQ1YsV0FBVztJQUNiLENBQUM7SUFDRCxtQkFBbUIsVUFBVSxPQUFPLFNBQVM7S0FDM0MsWUFBWTtLQUNaLFdBQVc7S0FDWCxVQUFVO0tBQ1YsV0FBVztJQUNiLENBQUM7SUFDRCxtQkFBbUIsT0FBTyxNQUFNLFNBQVMsVUFBVTtLQUNqRCxZQUFZO0tBQ1osV0FBVztLQUNYLFVBQVU7S0FDVixXQUFXO0lBQ2IsQ0FBQztJQUNELG1CQUFtQixVQUFVLE1BQU0sU0FBUyxVQUFVO0tBQ3BELFlBQVk7S0FDWixXQUFXO0tBQ1gsVUFBVTtLQUNWLFdBQVc7SUFDYixDQUFDO0lBQ0QsbUJBQW1CLE9BQU8sTUFBTSxRQUFRLFVBQVU7S0FDaEQsWUFBWTtLQUNaLFdBQVc7S0FDWCxVQUFVO0tBQ1YsV0FBVztJQUNiLENBQUM7R0FDSDtHQUNBLElBQUksQ0FBQyxLQUFLLFFBQVEsSUFBSSxNQUFNLE1BQU0sR0FBRztJQUNuQyxLQUFLLFFBQVEsSUFBSSxNQUFNLFFBQVEsQ0FBQyxDQUFDO0dBQ25DOzs7R0FHQSxLQUFLLFFBQVEsSUFBSSxNQUFNLE1BQU0sQ0FBQyxDQUFDLEtBQUssS0FBSztFQUMzQzs7Ozs7O0VBTUEsZ0JBQWdCLE9BQU87R0FDckIsSUFBSSxDQUFDLEtBQUssUUFBUSxJQUFJLE1BQU0sTUFBTSxHQUFHO0lBQ25DLE1BQU0sSUFBSSxhQUFhLDhDQUE4QyxFQUNuRSxRQUFRLE1BQU0sT0FDaEIsQ0FBQztHQUNIO0dBQ0EsTUFBTSxhQUFhLEtBQUssUUFBUSxJQUFJLE1BQU0sTUFBTSxDQUFDLENBQUMsUUFBUSxLQUFLO0dBQy9ELElBQUksYUFBYSxDQUFDLEdBQUc7SUFDbkIsS0FBSyxRQUFRLElBQUksTUFBTSxNQUFNLENBQUMsQ0FBQyxPQUFPLFlBQVksQ0FBQztHQUNyRCxPQUFPO0lBQ0wsTUFBTSxJQUFJLGFBQWEsdUNBQXVDO0dBQ2hFO0VBQ0Y7Q0FDRjs7Ozs7Ozs7Q0FTQSxJQUFJOzs7Ozs7OztDQVFKLE1BQU0saUNBQWlDO0VBQ3JDLElBQUksQ0FBQyxlQUFlO0dBQ2xCLGdCQUFnQixJQUFJLE9BQU87O0dBRTNCLGNBQWMsaUJBQWlCO0dBQy9CLGNBQWMsaUJBQWlCO0VBQ2pDO0VBQ0EsT0FBTztDQUNUOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztDQTJCQSxTQUFTLGNBQWMsU0FBUyxTQUFTLFFBQVE7RUFDL0MsSUFBSTtFQUNKLElBQUksT0FBTyxZQUFZLFVBQVU7R0FDL0IsTUFBTSxhQUFhLElBQUksSUFBSSxTQUFTLFNBQVMsSUFBSTtHQUNqRDtJQUNFLElBQUksRUFBRSxRQUFRLFdBQVcsR0FBRyxLQUFLLFFBQVEsV0FBVyxNQUFNLElBQUk7S0FDNUQsTUFBTSxJQUFJLGFBQWEsa0JBQWtCO01BQ3ZDLFlBQVk7TUFDWixVQUFVO01BQ1YsV0FBVztLQUNiLENBQUM7SUFDSDs7O0lBR0EsTUFBTSxlQUFlLFFBQVEsV0FBVyxNQUFNLElBQUksV0FBVyxXQUFXOztJQUV4RSxNQUFNLFlBQVk7SUFDbEIsSUFBSSxJQUFJLE9BQU8sR0FBRyxXQUFXLENBQUMsQ0FBQyxLQUFLLFlBQVksR0FBRztLQUNqRCxPQUFPLE1BQU0saUVBQWlFLGNBQWMsVUFBVSw2Q0FBNkMsOERBQThEO0lBQ25OO0dBQ0Y7R0FDQSxNQUFNLGlCQUFpQixFQUNyQixVQUNJO0lBQ0o7S0FDRSxJQUFJLElBQUksYUFBYSxXQUFXLFlBQVksSUFBSSxXQUFXLFdBQVcsUUFBUTtNQUM1RSxPQUFPLE1BQU0sR0FBRyxRQUFRLGlEQUFpRCxHQUFHLElBQUksU0FBUyxFQUFFLHdEQUF3RCwrQkFBK0I7S0FDcEw7SUFDRjtJQUNBLE9BQU8sSUFBSSxTQUFTLFdBQVc7R0FDakM7O0dBRUEsUUFBUSxJQUFJLE1BQU0sZUFBZSxTQUFTLE1BQU07RUFDbEQsT0FBTyxJQUFJLG1CQUFtQixRQUFROztHQUVwQyxRQUFRLElBQUksWUFBWSxTQUFTLFNBQVMsTUFBTTtFQUNsRCxPQUFPLElBQUksT0FBTyxZQUFZLFlBQVk7O0dBRXhDLFFBQVEsSUFBSSxNQUFNLFNBQVMsU0FBUyxNQUFNO0VBQzVDLE9BQU8sSUFBSSxtQkFBbUIsT0FBTztHQUNuQyxRQUFRO0VBQ1YsT0FBTztHQUNMLE1BQU0sSUFBSSxhQUFhLDBCQUEwQjtJQUMvQyxZQUFZO0lBQ1osVUFBVTtJQUNWLFdBQVc7R0FDYixDQUFDO0VBQ0g7RUFDQSxNQUFNLGdCQUFnQix5QkFBeUI7RUFDL0MsY0FBYyxjQUFjLEtBQUs7RUFDakMsT0FBTztDQUNUOzs7Ozs7OztDQVNBLE1BQU0sb0JBQW9CO0VBQ3hCLGlCQUFpQjtFQUNqQixVQUFVO0VBQ1YsUUFBUTtFQUNSLFNBQVM7RUFDVCxRQUFRLE9BQU8saUJBQWlCLGNBQWMsYUFBYSxRQUFRO0NBQ3JFO0NBQ0EsTUFBTSxvQkFBbUIsY0FBYTtFQUNwQyxPQUFPO0dBQUMsa0JBQWtCO0dBQVE7R0FBVyxrQkFBa0I7RUFBTSxDQUFDLENBQUMsUUFBTyxVQUFTLFNBQVMsTUFBTSxTQUFTLENBQUMsQ0FBQyxDQUFDLEtBQUssR0FBRztDQUM1SDtDQUNBLE1BQU0sdUJBQXNCLE9BQU07RUFDaEMsS0FBSyxNQUFNLE9BQU8sT0FBTyxLQUFLLGlCQUFpQixHQUFHO0dBQ2hELEdBQUcsR0FBRztFQUNSO0NBQ0Y7Q0FDQSxNQUFNLGFBQWE7RUFDakIsZ0JBQWUsWUFBVztHQUN4QixxQkFBb0IsUUFBTztJQUN6QixJQUFJLE9BQU8sUUFBUSxTQUFTLFVBQVU7S0FDcEMsa0JBQWtCLE9BQU8sUUFBUTtJQUNuQztHQUNGLENBQUM7RUFDSDtFQUNBLHlCQUF3QixrQkFBaUI7R0FDdkMsT0FBTyxpQkFBaUIsaUJBQWlCLGtCQUFrQixlQUFlO0VBQzVFO0VBQ0Esa0JBQWlCLGtCQUFpQjtHQUNoQyxPQUFPLGlCQUFpQixpQkFBaUIsa0JBQWtCLFFBQVE7RUFDckU7RUFDQSxpQkFBaUI7R0FDZixPQUFPLGtCQUFrQjtFQUMzQjtFQUNBLGlCQUFnQixrQkFBaUI7R0FDL0IsT0FBTyxpQkFBaUIsaUJBQWlCLGtCQUFrQixPQUFPO0VBQ3BFO0VBQ0EsaUJBQWlCO0dBQ2YsT0FBTyxrQkFBa0I7RUFDM0I7Q0FDRjs7Ozs7Ozs7Ozs7O0NBYUEsU0FBUyxZQUFZLFNBQVM7O0VBRTVCLEtBQUssUUFBUSxXQUFXLENBQUMsQ0FBQztDQUM1Qjs7Ozs7Ozs7Ozs7Q0FZQSxNQUFNLHNCQUFzQixJQUFJLElBQUk7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBa0JwQyxTQUFTLDJCQUEyQixVQUFVO0VBQzVDO0dBQ0UsbUJBQW1CLE9BQU8sVUFBVSxZQUFZO0lBQzlDLFlBQVk7SUFDWixVQUFVO0lBQ1YsV0FBVztHQUNiLENBQUM7RUFDSDtFQUNBLG9CQUFvQixJQUFJLFFBQVE7RUFDaEM7R0FDRSxPQUFPLElBQUkscURBQXFELFFBQVE7RUFDMUU7Q0FDRjtDQUVBLFNBQVMsV0FBVztFQUNsQixPQUFPLFdBQVcsT0FBTyxTQUFTLE9BQU8sT0FBTyxLQUFLLElBQUksU0FBVSxHQUFHO0dBQ3BFLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxVQUFVLFFBQVEsS0FBSztJQUN6QyxJQUFJLElBQUksVUFBVTtJQUNsQixLQUFLLElBQUksS0FBSyxHQUFHLENBQUMsQ0FBQyxFQUFDLENBQUUsZUFBZSxLQUFLLEdBQUcsQ0FBQyxNQUFNLEVBQUUsS0FBSyxFQUFFO0dBQy9EO0dBQ0EsT0FBTztFQUNULEdBQUcsU0FBUyxNQUFNLE1BQU0sU0FBUztDQUNuQztDQUVBLE1BQU0saUJBQWlCLFFBQVEsaUJBQWlCLGFBQWEsTUFBSyxNQUFLLGtCQUFrQixDQUFDO0NBQzFGLElBQUk7Q0FDSixJQUFJOztDQUVKLFNBQVMsdUJBQXVCO0VBQzlCLE9BQU8sc0JBQXNCLG9CQUFvQjtHQUFDO0dBQWE7R0FBZ0I7R0FBVTtHQUFXO0VBQWM7Q0FDcEg7O0NBRUEsU0FBUywwQkFBMEI7RUFDakMsT0FBTyx5QkFBeUIsdUJBQXVCO0dBQUMsVUFBVSxVQUFVO0dBQVMsVUFBVSxVQUFVO0dBQVUsVUFBVSxVQUFVO0VBQWtCO0NBQzNKO0NBQ0EsTUFBTSxtQkFBbUIsSUFBSSxRQUFRO0NBQ3JDLE1BQU0scUJBQXFCLElBQUksUUFBUTtDQUN2QyxNQUFNLDJCQUEyQixJQUFJLFFBQVE7Q0FDN0MsTUFBTSxpQkFBaUIsSUFBSSxRQUFRO0NBQ25DLE1BQU0sd0JBQXdCLElBQUksUUFBUTtDQUMxQyxTQUFTLGlCQUFpQixTQUFTO0VBQ2pDLE1BQU0sVUFBVSxJQUFJLFNBQVMsU0FBUyxXQUFXO0dBQy9DLE1BQU0saUJBQWlCO0lBQ3JCLFFBQVEsb0JBQW9CLFdBQVcsT0FBTztJQUM5QyxRQUFRLG9CQUFvQixTQUFTLEtBQUs7R0FDNUM7R0FDQSxNQUFNLGdCQUFnQjtJQUNwQixRQUFRLEtBQUssUUFBUSxNQUFNLENBQUM7SUFDNUIsU0FBUztHQUNYO0dBQ0EsTUFBTSxjQUFjO0lBQ2xCLE9BQU8sUUFBUSxLQUFLO0lBQ3BCLFNBQVM7R0FDWDtHQUNBLFFBQVEsaUJBQWlCLFdBQVcsT0FBTztHQUMzQyxRQUFRLGlCQUFpQixTQUFTLEtBQUs7RUFDekMsQ0FBQztFQUNELFFBQVEsTUFBSyxVQUFTOzs7R0FHcEIsSUFBSSxpQkFBaUIsV0FBVztJQUM5QixpQkFBaUIsSUFBSSxPQUFPLE9BQU87R0FDckM7O0VBRUYsQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDLENBQUM7OztFQUdqQixzQkFBc0IsSUFBSSxTQUFTLE9BQU87RUFDMUMsT0FBTztDQUNUO0NBQ0EsU0FBUywrQkFBK0IsSUFBSTs7RUFFMUMsSUFBSSxtQkFBbUIsSUFBSSxFQUFFLEdBQUc7RUFDaEMsTUFBTSxPQUFPLElBQUksU0FBUyxTQUFTLFdBQVc7R0FDNUMsTUFBTSxpQkFBaUI7SUFDckIsR0FBRyxvQkFBb0IsWUFBWSxRQUFRO0lBQzNDLEdBQUcsb0JBQW9CLFNBQVMsS0FBSztJQUNyQyxHQUFHLG9CQUFvQixTQUFTLEtBQUs7R0FDdkM7R0FDQSxNQUFNLGlCQUFpQjtJQUNyQixRQUFRO0lBQ1IsU0FBUztHQUNYO0dBQ0EsTUFBTSxjQUFjO0lBQ2xCLE9BQU8sR0FBRyxTQUFTLElBQUksYUFBYSxjQUFjLFlBQVksQ0FBQztJQUMvRCxTQUFTO0dBQ1g7R0FDQSxHQUFHLGlCQUFpQixZQUFZLFFBQVE7R0FDeEMsR0FBRyxpQkFBaUIsU0FBUyxLQUFLO0dBQ2xDLEdBQUcsaUJBQWlCLFNBQVMsS0FBSztFQUNwQyxDQUFDOztFQUVELG1CQUFtQixJQUFJLElBQUksSUFBSTtDQUNqQztDQUNBLElBQUksZ0JBQWdCO0VBQ2xCLElBQUksUUFBUSxNQUFNLFVBQVU7R0FDMUIsSUFBSSxrQkFBa0IsZ0JBQWdCOztJQUVwQyxJQUFJLFNBQVMsUUFBUSxPQUFPLG1CQUFtQixJQUFJLE1BQU07O0lBRXpELElBQUksU0FBUyxvQkFBb0I7S0FDL0IsT0FBTyxPQUFPLG9CQUFvQix5QkFBeUIsSUFBSSxNQUFNO0lBQ3ZFOztJQUVBLElBQUksU0FBUyxTQUFTO0tBQ3BCLE9BQU8sU0FBUyxpQkFBaUIsS0FBSyxZQUFZLFNBQVMsWUFBWSxTQUFTLGlCQUFpQixFQUFFO0lBQ3JHO0dBQ0Y7O0dBRUEsT0FBTyxLQUFLLE9BQU8sS0FBSztFQUMxQjtFQUNBLElBQUksUUFBUSxNQUFNLE9BQU87R0FDdkIsT0FBTyxRQUFRO0dBQ2YsT0FBTztFQUNUO0VBQ0EsSUFBSSxRQUFRLE1BQU07R0FDaEIsSUFBSSxrQkFBa0IsbUJBQW1CLFNBQVMsVUFBVSxTQUFTLFVBQVU7SUFDN0UsT0FBTztHQUNUO0dBQ0EsT0FBTyxRQUFRO0VBQ2pCO0NBQ0Y7Q0FDQSxTQUFTLGFBQWEsVUFBVTtFQUM5QixnQkFBZ0IsU0FBUyxhQUFhO0NBQ3hDO0NBQ0EsU0FBUyxhQUFhLE1BQU07Ozs7RUFJMUIsSUFBSSxTQUFTLFlBQVksVUFBVSxlQUFlLEVBQUUsc0JBQXNCLGVBQWUsWUFBWTtHQUNuRyxPQUFPLFNBQVUsWUFBWSxHQUFHLE1BQU07SUFDcEMsTUFBTSxLQUFLLEtBQUssS0FBSyxPQUFPLElBQUksR0FBRyxZQUFZLEdBQUcsSUFBSTtJQUN0RCx5QkFBeUIsSUFBSSxJQUFJLFdBQVcsT0FBTyxXQUFXLEtBQUssSUFBSSxDQUFDLFVBQVUsQ0FBQztJQUNuRixPQUFPLEtBQUssRUFBRTtHQUNoQjtFQUNGOzs7Ozs7RUFNQSxJQUFJLHdCQUF3QixDQUFDLENBQUMsU0FBUyxJQUFJLEdBQUc7R0FDNUMsT0FBTyxTQUFVLEdBQUcsTUFBTTs7O0lBR3hCLEtBQUssTUFBTSxPQUFPLElBQUksR0FBRyxJQUFJO0lBQzdCLE9BQU8sS0FBSyxpQkFBaUIsSUFBSSxJQUFJLENBQUM7R0FDeEM7RUFDRjtFQUNBLE9BQU8sU0FBVSxHQUFHLE1BQU07OztHQUd4QixPQUFPLEtBQUssS0FBSyxNQUFNLE9BQU8sSUFBSSxHQUFHLElBQUksQ0FBQztFQUM1QztDQUNGO0NBQ0EsU0FBUyx1QkFBdUIsT0FBTztFQUNyQyxJQUFJLE9BQU8sVUFBVSxZQUFZLE9BQU8sYUFBYSxLQUFLOzs7RUFHMUQsSUFBSSxpQkFBaUIsZ0JBQWdCLCtCQUErQixLQUFLO0VBQ3pFLElBQUksY0FBYyxPQUFPLHFCQUFxQixDQUFDLEdBQUcsT0FBTyxJQUFJLE1BQU0sT0FBTyxhQUFhOztFQUV2RixPQUFPO0NBQ1Q7Q0FDQSxTQUFTLEtBQUssT0FBTzs7O0VBR25CLElBQUksaUJBQWlCLFlBQVksT0FBTyxpQkFBaUIsS0FBSzs7O0VBRzlELElBQUksZUFBZSxJQUFJLEtBQUssR0FBRyxPQUFPLGVBQWUsSUFBSSxLQUFLO0VBQzlELE1BQU0sV0FBVyx1QkFBdUIsS0FBSzs7O0VBRzdDLElBQUksYUFBYSxPQUFPO0dBQ3RCLGVBQWUsSUFBSSxPQUFPLFFBQVE7R0FDbEMsc0JBQXNCLElBQUksVUFBVSxLQUFLO0VBQzNDO0VBQ0EsT0FBTztDQUNUO0NBQ0EsTUFBTSxVQUFTLFVBQVMsc0JBQXNCLElBQUksS0FBSzs7Ozs7Ozs7Q0FTdkQsU0FBUyxPQUFPLE1BQU0sU0FBUyxFQUM3QixTQUNBLFNBQ0EsVUFDQSxlQUNFLENBQUMsR0FBRztFQUNOLE1BQU0sVUFBVSxVQUFVLEtBQUssTUFBTSxPQUFPO0VBQzVDLE1BQU0sY0FBYyxLQUFLLE9BQU87RUFDaEMsSUFBSSxTQUFTO0dBQ1gsUUFBUSxpQkFBaUIsa0JBQWlCLFVBQVM7SUFDakQsUUFBUSxLQUFLLFFBQVEsTUFBTSxHQUFHLE1BQU0sWUFBWSxNQUFNLFlBQVksS0FBSyxRQUFRLFdBQVcsR0FBRyxLQUFLO0dBQ3BHLENBQUM7RUFDSDtFQUNBLElBQUksU0FBUztHQUNYLFFBQVEsaUJBQWlCLFlBQVcsVUFBUzs7SUFFN0MsTUFBTTtJQUFZLE1BQU07SUFBWTtHQUFLLENBQUM7RUFDNUM7RUFDQSxZQUFZLE1BQUssT0FBTTtHQUNyQixJQUFJLFlBQVksR0FBRyxpQkFBaUIsZUFBZSxXQUFXLENBQUM7R0FDL0QsSUFBSSxVQUFVO0lBQ1osR0FBRyxpQkFBaUIsa0JBQWlCLFVBQVMsU0FBUyxNQUFNLFlBQVksTUFBTSxZQUFZLEtBQUssQ0FBQztHQUNuRztFQUNGLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDO0VBQ2pCLE9BQU87Q0FDVDs7Ozs7O0NBTUEsU0FBUyxTQUFTLE1BQU0sRUFDdEIsWUFDRSxDQUFDLEdBQUc7RUFDTixNQUFNLFVBQVUsVUFBVSxlQUFlLElBQUk7RUFDN0MsSUFBSSxTQUFTO0dBQ1gsUUFBUSxpQkFBaUIsWUFBVyxVQUFTOztJQUU3QyxNQUFNO0lBQVk7R0FBSyxDQUFDO0VBQzFCO0VBQ0EsT0FBTyxLQUFLLE9BQU8sQ0FBQyxDQUFDLFdBQVcsU0FBUztDQUMzQztDQUNBLE1BQU0sY0FBYztFQUFDO0VBQU87RUFBVTtFQUFVO0VBQWM7Q0FBTztDQUNyRSxNQUFNLGVBQWU7RUFBQztFQUFPO0VBQU87RUFBVTtDQUFPO0NBQ3JELE1BQU0sZ0JBQWdCLElBQUksSUFBSTtDQUM5QixTQUFTLFVBQVUsUUFBUSxNQUFNO0VBQy9CLElBQUksRUFBRSxrQkFBa0IsZUFBZSxFQUFFLFFBQVEsV0FBVyxPQUFPLFNBQVMsV0FBVztHQUNyRjtFQUNGO0VBQ0EsSUFBSSxjQUFjLElBQUksSUFBSSxHQUFHLE9BQU8sY0FBYyxJQUFJLElBQUk7RUFDMUQsTUFBTSxpQkFBaUIsS0FBSyxRQUFRLGNBQWMsRUFBRTtFQUNwRCxNQUFNLFdBQVcsU0FBUztFQUMxQixNQUFNLFVBQVUsYUFBYSxTQUFTLGNBQWM7RUFDcEQsSUFFQSxFQUFFLG1CQUFtQixXQUFXLFdBQVcsZUFBYyxDQUFFLGNBQWMsRUFBRSxXQUFXLFlBQVksU0FBUyxjQUFjLElBQUk7R0FDM0g7RUFDRjtFQUNBLE1BQU0sU0FBUyxlQUFnQixXQUFXLEdBQUcsTUFBTTs7R0FFakQsTUFBTSxLQUFLLEtBQUssWUFBWSxXQUFXLFVBQVUsY0FBYyxVQUFVO0dBQ3pFLElBQUksU0FBUyxHQUFHO0dBQ2hCLElBQUksVUFBVSxTQUFTLE9BQU8sTUFBTSxLQUFLLE1BQU0sQ0FBQzs7Ozs7O0dBTWhELFFBQVEsTUFBTSxRQUFRLElBQUksQ0FBQyxPQUFPLGVBQWUsQ0FBQyxHQUFHLElBQUksR0FBRyxXQUFXLEdBQUcsSUFBSSxDQUFDLEVBQUMsQ0FBRTtFQUNwRjtFQUNBLGNBQWMsSUFBSSxNQUFNLE1BQU07RUFDOUIsT0FBTztDQUNUO0NBQ0EsY0FBYSxhQUFZLFNBQVMsQ0FBQyxHQUFHLFVBQVU7RUFDOUMsTUFBTSxRQUFRLE1BQU0sYUFBYSxVQUFVLFFBQVEsSUFBSSxLQUFLLFNBQVMsSUFBSSxRQUFRLE1BQU0sUUFBUTtFQUMvRixNQUFNLFFBQVEsU0FBUyxDQUFDLENBQUMsVUFBVSxRQUFRLElBQUksS0FBSyxTQUFTLElBQUksUUFBUSxJQUFJO0NBQy9FLENBQUMsQ0FBQzs7Q0FHRixJQUFJO0VBQ0YsS0FBSywrQkFBK0IsRUFBRTtDQUN4QyxTQUFTLEdBQUcsQ0FBQzs7Ozs7Ozs7Q0FTYixNQUFNLFVBQVU7Q0FDaEIsTUFBTSxxQkFBcUI7Q0FDM0IsTUFBTSxnQkFBZSxvQkFBbUI7RUFDdEMsTUFBTSxNQUFNLElBQUksSUFBSSxpQkFBaUIsU0FBUyxJQUFJO0VBQ2xELElBQUksT0FBTztFQUNYLE9BQU8sSUFBSTtDQUNiOzs7Ozs7Q0FNQSxNQUFNLHFCQUFxQjs7Ozs7OztFQU96QixZQUFZLFdBQVc7R0FDckIsS0FBSyxNQUFNO0dBQ1gsS0FBSyxhQUFhO0VBQ3BCOzs7Ozs7OztFQVFBLFdBQVcsSUFBSTs7Ozs7R0FLYixNQUFNLFdBQVcsR0FBRyxrQkFBa0Isb0JBQW9CLEVBQ3hELFNBQVMsS0FDWCxDQUFDOzs7O0dBSUQsU0FBUyxZQUFZLGFBQWEsYUFBYSxFQUM3QyxRQUFRLE1BQ1YsQ0FBQztHQUNELFNBQVMsWUFBWSxhQUFhLGFBQWEsRUFDN0MsUUFBUSxNQUNWLENBQUM7RUFDSDs7Ozs7Ozs7RUFRQSwwQkFBMEIsSUFBSTtHQUM1QixLQUFLLFdBQVcsRUFBRTtHQUNsQixJQUFJLEtBQUssWUFBWTtJQUNuQixLQUFLLFNBQVMsS0FBSyxVQUFVO0dBQy9CO0VBQ0Y7Ozs7Ozs7RUFPQSxNQUFNLGFBQWEsS0FBSyxXQUFXO0dBQ2pDLE1BQU0sYUFBYSxHQUFHO0dBQ3RCLE1BQU0sUUFBUTtJQUNaO0lBQ0E7SUFDQSxXQUFXLEtBQUs7Ozs7SUFJaEIsSUFBSSxLQUFLLE9BQU8sR0FBRztHQUNyQjtHQUNBLE1BQU0sS0FBSyxNQUFNLEtBQUssTUFBTTtHQUM1QixNQUFNLEtBQUssR0FBRyxZQUFZLG9CQUFvQixhQUFhLEVBQ3pELFlBQVksVUFDZCxDQUFDO0dBQ0QsTUFBTSxHQUFHLE1BQU0sSUFBSSxLQUFLO0dBQ3hCLE1BQU0sR0FBRztFQUNYOzs7Ozs7Ozs7RUFTQSxNQUFNLGFBQWEsS0FBSztHQUN0QixNQUFNLEtBQUssTUFBTSxLQUFLLE1BQU07R0FDNUIsTUFBTSxRQUFRLE1BQU0sR0FBRyxJQUFJLG9CQUFvQixLQUFLLE9BQU8sR0FBRyxDQUFDO0dBQy9ELE9BQU8sVUFBVSxRQUFRLFVBQVUsS0FBSyxJQUFJLEtBQUssSUFBSSxNQUFNO0VBQzdEOzs7Ozs7Ozs7Ozs7RUFZQSxNQUFNLGNBQWMsY0FBYyxVQUFVO0dBQzFDLE1BQU0sS0FBSyxNQUFNLEtBQUssTUFBTTtHQUM1QixJQUFJLFNBQVMsTUFBTSxHQUFHLFlBQVksa0JBQWtCLENBQUMsQ0FBQyxNQUFNLE1BQU0sV0FBVyxDQUFDLENBQUMsV0FBVyxNQUFNLE1BQU07R0FDdEcsTUFBTSxrQkFBa0IsQ0FBQztHQUN6QixJQUFJLHlCQUF5QjtHQUM3QixPQUFPLFFBQVE7SUFDYixNQUFNLFNBQVMsT0FBTzs7O0lBR3RCLElBQUksT0FBTyxjQUFjLEtBQUssWUFBWTs7O0tBR3hDLElBQUksZ0JBQWdCLE9BQU8sWUFBWSxnQkFBZ0IsWUFBWSwwQkFBMEIsVUFBVTs7Ozs7Ozs7O01BU3JHLGdCQUFnQixLQUFLLE9BQU8sS0FBSztLQUNuQyxPQUFPO01BQ0w7S0FDRjtJQUNGO0lBQ0EsU0FBUyxNQUFNLE9BQU8sU0FBUztHQUNqQzs7Ozs7R0FLQSxNQUFNLGNBQWMsQ0FBQztHQUNyQixLQUFLLE1BQU0sU0FBUyxpQkFBaUI7SUFDbkMsTUFBTSxHQUFHLE9BQU8sb0JBQW9CLE1BQU0sRUFBRTtJQUM1QyxZQUFZLEtBQUssTUFBTSxHQUFHO0dBQzVCO0dBQ0EsT0FBTztFQUNUOzs7Ozs7Ozs7RUFTQSxPQUFPLEtBQUs7Ozs7R0FJVixPQUFPLEtBQUssYUFBYSxNQUFNLGFBQWEsR0FBRztFQUNqRDs7Ozs7O0VBTUEsTUFBTSxRQUFRO0dBQ1osSUFBSSxDQUFDLEtBQUssS0FBSztJQUNiLEtBQUssTUFBTSxNQUFNLE9BQU8sU0FBUyxHQUFHLEVBQ2xDLFNBQVMsS0FBSywwQkFBMEIsS0FBSyxJQUFJLEVBQ25ELENBQUM7R0FDSDtHQUNBLE9BQU8sS0FBSztFQUNkO0NBQ0Y7Ozs7Ozs7Ozs7Ozs7OztDQWdCQSxNQUFNLGdCQUFnQjs7Ozs7Ozs7Ozs7Ozs7RUFjcEIsWUFBWSxXQUFXLFNBQVMsQ0FBQyxHQUFHO0dBQ2xDLEtBQUssYUFBYTtHQUNsQixLQUFLLGtCQUFrQjtHQUN2QjtJQUNFLG1CQUFtQixPQUFPLFdBQVcsVUFBVTtLQUM3QyxZQUFZO0tBQ1osV0FBVztLQUNYLFVBQVU7S0FDVixXQUFXO0lBQ2IsQ0FBQztJQUNELElBQUksRUFBRSxPQUFPLGNBQWMsT0FBTyxnQkFBZ0I7S0FDaEQsTUFBTSxJQUFJLGFBQWEsK0JBQStCO01BQ3BELFlBQVk7TUFDWixXQUFXO01BQ1gsVUFBVTtLQUNaLENBQUM7SUFDSDtJQUNBLElBQUksT0FBTyxZQUFZO0tBQ3JCLG1CQUFtQixPQUFPLE9BQU8sWUFBWSxVQUFVO01BQ3JELFlBQVk7TUFDWixXQUFXO01BQ1gsVUFBVTtNQUNWLFdBQVc7S0FDYixDQUFDO0lBQ0g7SUFDQSxJQUFJLE9BQU8sZUFBZTtLQUN4QixtQkFBbUIsT0FBTyxPQUFPLGVBQWUsVUFBVTtNQUN4RCxZQUFZO01BQ1osV0FBVztNQUNYLFVBQVU7TUFDVixXQUFXO0tBQ2IsQ0FBQztJQUNIO0dBQ0Y7R0FDQSxLQUFLLGNBQWMsT0FBTztHQUMxQixLQUFLLGlCQUFpQixPQUFPO0dBQzdCLEtBQUssZ0JBQWdCLE9BQU87R0FDNUIsS0FBSyxhQUFhO0dBQ2xCLEtBQUssa0JBQWtCLElBQUkscUJBQXFCLFNBQVM7RUFDM0Q7Ozs7RUFJQSxNQUFNLGdCQUFnQjtHQUNwQixJQUFJLEtBQUssWUFBWTtJQUNuQixLQUFLLGtCQUFrQjtJQUN2QjtHQUNGO0dBQ0EsS0FBSyxhQUFhO0dBQ2xCLE1BQU0sZUFBZSxLQUFLLGlCQUFpQixLQUFLLElBQUksSUFBSSxLQUFLLGlCQUFpQixNQUFPO0dBQ3JGLE1BQU0sY0FBYyxNQUFNLEtBQUssZ0JBQWdCLGNBQWMsY0FBYyxLQUFLLFdBQVc7O0dBRTNGLE1BQU0sUUFBUSxNQUFNLEtBQUssT0FBTyxLQUFLLEtBQUssVUFBVTtHQUNwRCxLQUFLLE1BQU0sT0FBTyxhQUFhO0lBQzdCLE1BQU0sTUFBTSxPQUFPLEtBQUssS0FBSyxhQUFhO0dBQzVDO0dBQ0E7SUFDRSxJQUFJLFlBQVksU0FBUyxHQUFHO0tBQzFCLE9BQU8sZUFBZSxXQUFXLFlBQVksT0FBTyxLQUFLLEdBQUcsWUFBWSxXQUFXLElBQUksVUFBVSxVQUFVLGlCQUFpQixHQUFHLFlBQVksV0FBVyxJQUFJLE9BQU8sT0FBTyxjQUFjLElBQUksS0FBSyxXQUFXLFNBQVM7S0FDbk4sT0FBTyxJQUFJLHlCQUF5QixZQUFZLFdBQVcsSUFBSSxRQUFRLE9BQU8sRUFBRTtLQUNoRixZQUFZLFNBQVEsUUFBTyxPQUFPLElBQUksT0FBTyxLQUFLLENBQUM7S0FDbkQsT0FBTyxTQUFTO0lBQ2xCLE9BQU87S0FDTCxPQUFPLE1BQU0sc0RBQXNEO0lBQ3JFO0dBQ0Y7R0FDQSxLQUFLLGFBQWE7R0FDbEIsSUFBSSxLQUFLLGlCQUFpQjtJQUN4QixLQUFLLGtCQUFrQjtJQUN2QixZQUFZLEtBQUssY0FBYyxDQUFDO0dBQ2xDO0VBQ0Y7Ozs7Ozs7O0VBUUEsTUFBTSxnQkFBZ0IsS0FBSztHQUN6QjtJQUNFLG1CQUFtQixPQUFPLEtBQUssVUFBVTtLQUN2QyxZQUFZO0tBQ1osV0FBVztLQUNYLFVBQVU7S0FDVixXQUFXO0lBQ2IsQ0FBQztHQUNIO0dBQ0EsTUFBTSxLQUFLLGdCQUFnQixhQUFhLEtBQUssS0FBSyxJQUFJLENBQUM7RUFDekQ7Ozs7Ozs7Ozs7OztFQVlBLE1BQU0sYUFBYSxLQUFLO0dBQ3RCLElBQUksQ0FBQyxLQUFLLGdCQUFnQjtJQUN4QjtLQUNFLE1BQU0sSUFBSSxhQUFhLGdDQUFnQztNQUNyRCxZQUFZO01BQ1osV0FBVztLQUNiLENBQUM7SUFDSDtHQUNGLE9BQU87SUFDTCxNQUFNLFlBQVksTUFBTSxLQUFLLGdCQUFnQixhQUFhLEdBQUc7SUFDN0QsTUFBTSxrQkFBa0IsS0FBSyxJQUFJLElBQUksS0FBSyxpQkFBaUI7SUFDM0QsT0FBTyxjQUFjLFlBQVksWUFBWSxrQkFBa0I7R0FDakU7RUFDRjs7Ozs7RUFLQSxNQUFNLFNBQVM7OztHQUdiLEtBQUssa0JBQWtCO0dBQ3ZCLE1BQU0sS0FBSyxnQkFBZ0IsY0FBYyxRQUFRO0VBQ25EO0NBQ0Y7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0FnQ0EsTUFBTSxpQkFBaUI7Ozs7Ozs7Ozs7OztFQVlyQixZQUFZLFNBQVMsQ0FBQyxHQUFHOzs7Ozs7Ozs7Ozs7Ozs7Ozs7R0FrQnZCLEtBQUssMkJBQTJCLE9BQU8sRUFDckMsT0FDQSxTQUNBLFdBQ0EscUJBQ0k7SUFDSixJQUFJLENBQUMsZ0JBQWdCO0tBQ25CLE9BQU87SUFDVDtJQUNBLE1BQU0sVUFBVSxLQUFLLHFCQUFxQixjQUFjOzs7SUFHeEQsTUFBTSxrQkFBa0IsS0FBSyxvQkFBb0IsU0FBUztJQUMxRCxZQUFZLGdCQUFnQixjQUFjLENBQUM7OztJQUczQyxNQUFNLHNCQUFzQixnQkFBZ0IsZ0JBQWdCLFFBQVEsR0FBRztJQUN2RSxJQUFJLE9BQU87S0FDVCxJQUFJO01BQ0YsTUFBTSxVQUFVLG1CQUFtQjtLQUNyQyxTQUFTLE9BQU87TUFDZDs7T0FFRSxJQUFJLGFBQWEsT0FBTztRQUN0QixPQUFPLEtBQUssc0RBQXNELDhCQUE4QixJQUFJLGVBQWUsTUFBTSxRQUFRLEdBQUcsRUFBRSxHQUFHO09BQzNJO01BQ0Y7S0FDRjtJQUNGO0lBQ0EsT0FBTyxVQUFVLGlCQUFpQjtHQUNwQzs7Ozs7Ozs7Ozs7R0FXQSxLQUFLLGlCQUFpQixPQUFPLEVBQzNCLFdBQ0EsY0FDSTtJQUNKO0tBQ0UsbUJBQW1CLE9BQU8sV0FBVyxVQUFVO01BQzdDLFlBQVk7TUFDWixXQUFXO01BQ1gsVUFBVTtNQUNWLFdBQVc7S0FDYixDQUFDO0tBQ0QsbUJBQW1CLFdBQVcsU0FBUyxTQUFTO01BQzlDLFlBQVk7TUFDWixXQUFXO01BQ1gsVUFBVTtNQUNWLFdBQVc7S0FDYixDQUFDO0lBQ0g7SUFDQSxNQUFNLGtCQUFrQixLQUFLLG9CQUFvQixTQUFTO0lBQzFELE1BQU0sZ0JBQWdCLGdCQUFnQixRQUFRLEdBQUc7SUFDakQsTUFBTSxnQkFBZ0IsY0FBYztHQUN0QztHQUNBO0lBQ0UsSUFBSSxFQUFFLE9BQU8sY0FBYyxPQUFPLGdCQUFnQjtLQUNoRCxNQUFNLElBQUksYUFBYSwrQkFBK0I7TUFDcEQsWUFBWTtNQUNaLFdBQVc7TUFDWCxVQUFVO0tBQ1osQ0FBQztJQUNIO0lBQ0EsSUFBSSxPQUFPLFlBQVk7S0FDckIsbUJBQW1CLE9BQU8sT0FBTyxZQUFZLFVBQVU7TUFDckQsWUFBWTtNQUNaLFdBQVc7TUFDWCxVQUFVO01BQ1YsV0FBVztLQUNiLENBQUM7SUFDSDtJQUNBLElBQUksT0FBTyxlQUFlO0tBQ3hCLG1CQUFtQixPQUFPLE9BQU8sZUFBZSxVQUFVO01BQ3hELFlBQVk7TUFDWixXQUFXO01BQ1gsVUFBVTtNQUNWLFdBQVc7S0FDYixDQUFDO0lBQ0g7R0FDRjtHQUNBLEtBQUssVUFBVTtHQUNmLEtBQUssaUJBQWlCLE9BQU87R0FDN0IsS0FBSyxvQkFBb0IsSUFBSSxJQUFJO0dBQ2pDLElBQUksT0FBTyxtQkFBbUI7SUFDNUIsaUNBQWlDLEtBQUssdUJBQXVCLENBQUM7R0FDaEU7RUFDRjs7Ozs7Ozs7OztFQVVBLG9CQUFvQixXQUFXO0dBQzdCLElBQUksY0FBYyxXQUFXLGVBQWUsR0FBRztJQUM3QyxNQUFNLElBQUksYUFBYSwyQkFBMkI7R0FDcEQ7R0FDQSxJQUFJLGtCQUFrQixLQUFLLGtCQUFrQixJQUFJLFNBQVM7R0FDMUQsSUFBSSxDQUFDLGlCQUFpQjtJQUNwQixrQkFBa0IsSUFBSSxnQkFBZ0IsV0FBVyxLQUFLLE9BQU87SUFDN0QsS0FBSyxrQkFBa0IsSUFBSSxXQUFXLGVBQWU7R0FDdkQ7R0FDQSxPQUFPO0VBQ1Q7Ozs7Ozs7RUFPQSxxQkFBcUIsZ0JBQWdCO0dBQ25DLElBQUksQ0FBQyxLQUFLLGdCQUFnQjs7SUFFeEIsT0FBTztHQUNUOzs7O0dBSUEsTUFBTSxzQkFBc0IsS0FBSyx3QkFBd0IsY0FBYztHQUN2RSxJQUFJLHdCQUF3QixNQUFNOztJQUVoQyxPQUFPO0dBQ1Q7OztHQUdBLE1BQU0sTUFBTSxLQUFLLElBQUk7R0FDckIsT0FBTyx1QkFBdUIsTUFBTSxLQUFLLGlCQUFpQjtFQUM1RDs7Ozs7Ozs7OztFQVVBLHdCQUF3QixnQkFBZ0I7R0FDdEMsSUFBSSxDQUFDLGVBQWUsUUFBUSxJQUFJLE1BQU0sR0FBRztJQUN2QyxPQUFPO0dBQ1Q7R0FDQSxNQUFNLGFBQWEsZUFBZSxRQUFRLElBQUksTUFBTTtHQUNwRCxNQUFNLGFBQWEsSUFBSSxLQUFLLFVBQVU7R0FDdEMsTUFBTSxhQUFhLFdBQVcsUUFBUTs7O0dBR3RDLElBQUksTUFBTSxVQUFVLEdBQUc7SUFDckIsT0FBTztHQUNUO0dBQ0EsT0FBTztFQUNUOzs7Ozs7Ozs7Ozs7Ozs7OztFQWlCQSxNQUFNLHlCQUF5Qjs7O0dBRzdCLEtBQUssTUFBTSxDQUFDLFdBQVcsb0JBQW9CLEtBQUssbUJBQW1CO0lBQ2pFLE1BQU0sS0FBSyxPQUFPLE9BQU8sU0FBUztJQUNsQyxNQUFNLGdCQUFnQixPQUFPO0dBQy9COztHQUVBLEtBQUssb0JBQW9CLElBQUksSUFBSTtFQUNuQztDQUNGOztDQUdBLElBQUk7RUFDRixLQUFLLHVDQUF1QyxFQUFFO0NBQ2hELFNBQVMsR0FBRyxDQUFDOzs7Ozs7Ozs7Ozs7Ozs7O0NBaUJiLE1BQU0sa0JBQWtCOzs7Ozs7Ozs7Ozs7Ozs7RUFldEIsWUFBWSxTQUFTLENBQUMsR0FBRztHQUN2QjtJQUNFLElBQUksRUFBRSxPQUFPLFlBQVksT0FBTyxVQUFVO0tBQ3hDLE1BQU0sSUFBSSxhQUFhLGdDQUFnQztNQUNyRCxZQUFZO01BQ1osV0FBVztNQUNYLFVBQVU7S0FDWixDQUFDO0lBQ0g7SUFDQSxJQUFJLE9BQU8sVUFBVTtLQUNuQixtQkFBbUIsUUFBUSxPQUFPLFVBQVU7TUFDMUMsWUFBWTtNQUNaLFdBQVc7TUFDWCxVQUFVO01BQ1YsV0FBVztLQUNiLENBQUM7SUFDSDtJQUNBLElBQUksT0FBTyxTQUFTO0tBQ2xCLG1CQUFtQixPQUFPLE9BQU8sU0FBUyxVQUFVO01BQ2xELFlBQVk7TUFDWixXQUFXO01BQ1gsVUFBVTtNQUNWLFdBQVc7S0FDYixDQUFDO0lBQ0g7R0FDRjtHQUNBLEtBQUssWUFBWSxPQUFPO0dBQ3hCLEtBQUssV0FBVyxPQUFPO0VBQ3pCOzs7Ozs7Ozs7O0VBVUEsb0JBQW9CLFVBQVU7R0FDNUI7SUFDRSxtQkFBbUIsV0FBVyxVQUFVLFVBQVU7S0FDaEQsWUFBWTtLQUNaLFdBQVc7S0FDWCxVQUFVO0tBQ1YsV0FBVztJQUNiLENBQUM7R0FDSDtHQUNBLElBQUksWUFBWTtHQUNoQixJQUFJLEtBQUssV0FBVztJQUNsQixZQUFZLEtBQUssVUFBVSxTQUFTLFNBQVMsTUFBTTtHQUNyRDtHQUNBLElBQUksS0FBSyxZQUFZLFdBQVc7SUFDOUIsWUFBWSxPQUFPLEtBQUssS0FBSyxRQUFRLENBQUMsQ0FBQyxNQUFLLGVBQWM7S0FDeEQsT0FBTyxTQUFTLFFBQVEsSUFBSSxVQUFVLE1BQU0sS0FBSyxTQUFTO0lBQzVELENBQUM7R0FDSDtHQUNBO0lBQ0UsSUFBSSxDQUFDLFdBQVc7S0FDZCxPQUFPLGVBQWUscUJBQXFCLElBQUksZUFBZSxTQUFTLEdBQUcsRUFBRSxvQ0FBb0MseUNBQXlDO0tBQ3pKLE9BQU8sZUFBZSxrQ0FBa0M7S0FDeEQsT0FBTyxJQUFJLHlCQUF5QixLQUFLLFVBQVUsS0FBSyxTQUFTLENBQUM7S0FDbEUsT0FBTyxJQUFJLHdCQUF3QixLQUFLLFVBQVUsS0FBSyxVQUFVLE1BQU0sQ0FBQyxDQUFDO0tBQ3pFLE9BQU8sU0FBUztLQUNoQixNQUFNLHFCQUFxQixDQUFDO0tBQzVCLFNBQVMsUUFBUSxTQUFTLE9BQU8sUUFBUTtNQUN2QyxtQkFBbUIsT0FBTztLQUM1QixDQUFDO0tBQ0QsT0FBTyxlQUFlLHdDQUF3QztLQUM5RCxPQUFPLElBQUksb0JBQW9CLFNBQVMsUUFBUTtLQUNoRCxPQUFPLElBQUksdUJBQXVCLEtBQUssVUFBVSxvQkFBb0IsTUFBTSxDQUFDLENBQUM7S0FDN0UsT0FBTyxTQUFTO0tBQ2hCLE9BQU8sZUFBZSxrQ0FBa0M7S0FDeEQsT0FBTyxJQUFJLFNBQVMsT0FBTztLQUMzQixPQUFPLElBQUksUUFBUTtLQUNuQixPQUFPLFNBQVM7S0FDaEIsT0FBTyxTQUFTO0lBQ2xCO0dBQ0Y7R0FDQSxPQUFPO0VBQ1Q7Q0FDRjs7Ozs7Ozs7Ozs7Ozs7O0NBZ0JBLE1BQU0sd0JBQXdCOzs7Ozs7Ozs7Ozs7Ozs7RUFlNUIsWUFBWSxRQUFROzs7Ozs7O0dBT2xCLEtBQUssa0JBQWtCLE9BQU8sRUFDNUIsZUFDSTtJQUNKLElBQUksS0FBSyxtQkFBbUIsb0JBQW9CLFFBQVEsR0FBRztLQUN6RCxPQUFPO0lBQ1Q7SUFDQSxPQUFPO0dBQ1Q7R0FDQSxLQUFLLHFCQUFxQixJQUFJLGtCQUFrQixNQUFNO0VBQ3hEO0NBQ0Y7O0NBR0EsSUFBSTtFQUNGLEtBQUssK0JBQStCLEVBQUU7Q0FDeEMsU0FBUyxHQUFHLENBQUM7Ozs7Ozs7O0NBU2IsTUFBTSx5QkFBeUI7Ozs7Ozs7Ozs7O0FBVzdCLGlCQUFpQixPQUFPLEVBQ3RCLGVBQ0k7RUFDSixJQUFJLFNBQVMsV0FBVyxPQUFPLFNBQVMsV0FBVyxHQUFHO0dBQ3BELE9BQU87RUFDVDtFQUNBLE9BQU87Q0FDVCxFQUNGOzs7Ozs7O0NBUUEsU0FBUyxZQUFZLFNBQVMsY0FBYztFQUMxQyxNQUFNLGNBQWMsSUFBSSxJQUFJLE9BQU87RUFDbkMsS0FBSyxNQUFNLFNBQVMsY0FBYztHQUNoQyxZQUFZLGFBQWEsT0FBTyxLQUFLO0VBQ3ZDO0VBQ0EsT0FBTyxZQUFZO0NBQ3JCOzs7Ozs7Ozs7Ozs7O0NBYUEsZUFBZSx1QkFBdUIsT0FBTyxTQUFTLGNBQWMsY0FBYztFQUNoRixNQUFNLHFCQUFxQixZQUFZLFFBQVEsS0FBSyxZQUFZOztFQUVoRSxJQUFJLFFBQVEsUUFBUSxvQkFBb0I7R0FDdEMsT0FBTyxNQUFNLE1BQU0sU0FBUyxZQUFZO0VBQzFDOztFQUVBLE1BQU0sY0FBYyxPQUFPLE9BQU8sT0FBTyxPQUFPLENBQUMsR0FBRyxZQUFZLEdBQUcsRUFDakUsY0FBYyxLQUNoQixDQUFDO0VBQ0QsTUFBTSxZQUFZLE1BQU0sTUFBTSxLQUFLLFNBQVMsV0FBVztFQUN2RCxLQUFLLE1BQU0sWUFBWSxXQUFXO0dBQ2hDLE1BQU0sc0JBQXNCLFlBQVksU0FBUyxLQUFLLFlBQVk7R0FDbEUsSUFBSSx1QkFBdUIscUJBQXFCO0lBQzlDLE9BQU8sTUFBTSxNQUFNLFVBQVUsWUFBWTtHQUMzQztFQUNGO0VBQ0E7Q0FDRjs7Ozs7Ozs7Ozs7Ozs7OztDQWlCQSxNQUFNLFNBQVM7Ozs7RUFJYixjQUFjO0dBQ1osS0FBSyxVQUFVLElBQUksU0FBUyxTQUFTLFdBQVc7SUFDOUMsS0FBSyxVQUFVO0lBQ2YsS0FBSyxTQUFTO0dBQ2hCLENBQUM7RUFDSDtDQUNGOzs7Ozs7Ozs7Ozs7Ozs7Q0FnQkEsZUFBZSw2QkFBNkI7RUFDMUM7R0FDRSxPQUFPLElBQUksZ0JBQWdCLG9CQUFvQixLQUFLLEtBQUssK0JBQStCO0VBQzFGO0VBQ0EsS0FBSyxNQUFNLFlBQVkscUJBQXFCO0dBQzFDLE1BQU0sU0FBUztHQUNmO0lBQ0UsT0FBTyxJQUFJLFVBQVUsY0FBYztHQUNyQztFQUNGO0VBQ0E7R0FDRSxPQUFPLElBQUksNkJBQTZCO0VBQzFDO0NBQ0Y7Ozs7Ozs7Ozs7Ozs7OztDQWdCQSxTQUFTLFFBQVEsSUFBSTtFQUNuQixPQUFPLElBQUksU0FBUSxZQUFXLFdBQVcsU0FBUyxFQUFFLENBQUM7Q0FDdkQ7Ozs7Ozs7O0NBU0EsU0FBUyxVQUFVLE9BQU87RUFDeEIsT0FBTyxPQUFPLFVBQVUsV0FBVyxJQUFJLFFBQVEsS0FBSyxJQUFJO0NBQzFEOzs7Ozs7Ozs7O0NBVUEsTUFBTSxnQkFBZ0I7Ozs7Ozs7Ozs7Ozs7Ozs7O0VBaUJwQixZQUFZLFVBQVUsU0FBUztHQUM3QixLQUFLLGFBQWEsQ0FBQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7R0FzQ25CO0lBQ0UsbUJBQW1CLFdBQVcsUUFBUSxPQUFPLGlCQUFpQjtLQUM1RCxZQUFZO0tBQ1osV0FBVztLQUNYLFVBQVU7S0FDVixXQUFXO0lBQ2IsQ0FBQztHQUNIO0dBQ0EsT0FBTyxPQUFPLE1BQU0sT0FBTztHQUMzQixLQUFLLFFBQVEsUUFBUTtHQUNyQixLQUFLLFlBQVk7R0FDakIsS0FBSyxtQkFBbUIsSUFBSSxTQUFTO0dBQ3JDLEtBQUssMEJBQTBCLENBQUM7OztHQUdoQyxLQUFLLFdBQVcsQ0FBQyxHQUFHLFNBQVMsT0FBTztHQUNwQyxLQUFLLGtCQUFrQixJQUFJLElBQUk7R0FDL0IsS0FBSyxNQUFNLFVBQVUsS0FBSyxVQUFVO0lBQ2xDLEtBQUssZ0JBQWdCLElBQUksUUFBUSxDQUFDLENBQUM7R0FDckM7R0FDQSxLQUFLLE1BQU0sVUFBVSxLQUFLLGlCQUFpQixPQUFPO0VBQ3BEOzs7Ozs7Ozs7Ozs7OztFQWNBLE1BQU0sTUFBTSxPQUFPO0dBQ2pCLE1BQU0sRUFDSixVQUNFO0dBQ0osSUFBSSxVQUFVLFVBQVUsS0FBSztHQUM3QixJQUFJLFFBQVEsU0FBUyxjQUFjLGlCQUFpQixjQUFjLE1BQU0saUJBQWlCO0lBQ3ZGLE1BQU0sMEJBQTBCLE1BQU0sTUFBTTtJQUM1QyxJQUFJLHlCQUF5QjtLQUMzQjtNQUNFLE9BQU8sSUFBSSwrQ0FBK0MsSUFBSSxlQUFlLFFBQVEsR0FBRyxFQUFFLEVBQUU7S0FDOUY7S0FDQSxPQUFPO0lBQ1Q7R0FDRjs7OztHQUlBLE1BQU0sa0JBQWtCLEtBQUssWUFBWSxjQUFjLElBQUksUUFBUSxNQUFNLElBQUk7R0FDN0UsSUFBSTtJQUNGLEtBQUssTUFBTSxNQUFNLEtBQUssaUJBQWlCLGtCQUFrQixHQUFHO0tBQzFELFVBQVUsTUFBTSxHQUFHO01BQ2pCLFNBQVMsUUFBUSxNQUFNO01BQ3ZCO0tBQ0YsQ0FBQztJQUNIO0dBQ0YsU0FBUyxLQUFLO0lBQ1osSUFBSSxlQUFlLE9BQU87S0FDeEIsTUFBTSxJQUFJLGFBQWEsbUNBQW1DLEVBQ3hELG9CQUFvQixJQUFJLFFBQzFCLENBQUM7SUFDSDtHQUNGOzs7O0dBSUEsTUFBTSx3QkFBd0IsUUFBUSxNQUFNO0dBQzVDLElBQUk7SUFDRixJQUFJOztJQUVKLGdCQUFnQixNQUFNLE1BQU0sU0FBUyxRQUFRLFNBQVMsYUFBYSxZQUFZLEtBQUssVUFBVSxZQUFZO0lBQzFHLElBQUksa0JBQWtCLGNBQWM7S0FDbEMsT0FBTyxNQUFNLHlCQUF5QixJQUFJLGVBQWUsUUFBUSxHQUFHLEVBQUUsK0JBQStCLFdBQVcsY0FBYyxPQUFPLEdBQUc7SUFDMUk7SUFDQSxLQUFLLE1BQU0sWUFBWSxLQUFLLGlCQUFpQixpQkFBaUIsR0FBRztLQUMvRCxnQkFBZ0IsTUFBTSxTQUFTO01BQzdCO01BQ0EsU0FBUztNQUNULFVBQVU7S0FDWixDQUFDO0lBQ0g7SUFDQSxPQUFPO0dBQ1QsU0FBUyxPQUFPO0lBQ2Q7S0FDRSxPQUFPLElBQUkseUJBQXlCLElBQUksZUFBZSxRQUFRLEdBQUcsRUFBRSxvQkFBb0IsS0FBSztJQUMvRjs7O0lBR0EsSUFBSSxpQkFBaUI7S0FDbkIsTUFBTSxLQUFLLGFBQWEsZ0JBQWdCO01BQy9CO01BQ1A7TUFDQSxpQkFBaUIsZ0JBQWdCLE1BQU07TUFDdkMsU0FBUyxzQkFBc0IsTUFBTTtLQUN2QyxDQUFDO0lBQ0g7SUFDQSxNQUFNO0dBQ1I7RUFDRjs7Ozs7Ozs7Ozs7RUFXQSxNQUFNLGlCQUFpQixPQUFPO0dBQzVCLE1BQU0sV0FBVyxNQUFNLEtBQUssTUFBTSxLQUFLO0dBQ3ZDLE1BQU0sZ0JBQWdCLFNBQVMsTUFBTTtHQUNyQyxLQUFLLEtBQUssVUFBVSxLQUFLLFNBQVMsT0FBTyxhQUFhLENBQUM7R0FDdkQsT0FBTztFQUNUOzs7Ozs7Ozs7Ozs7O0VBYUEsTUFBTSxXQUFXLEtBQUs7R0FDcEIsTUFBTSxVQUFVLFVBQVUsR0FBRztHQUM3QixJQUFJO0dBQ0osTUFBTSxFQUNKLFdBQ0EsaUJBQ0UsS0FBSztHQUNULE1BQU0sbUJBQW1CLE1BQU0sS0FBSyxZQUFZLFNBQVMsTUFBTTtHQUMvRCxNQUFNLG9CQUFvQixPQUFPLE9BQU8sT0FBTyxPQUFPLENBQUMsR0FBRyxZQUFZLEdBQUcsRUFDdkUsVUFDRixDQUFDO0dBQ0QsaUJBQWlCLE1BQU0sT0FBTyxNQUFNLGtCQUFrQixpQkFBaUI7R0FDdkU7SUFDRSxJQUFJLGdCQUFnQjtLQUNsQixPQUFPLE1BQU0sK0JBQStCLFVBQVUsR0FBRztJQUMzRCxPQUFPO0tBQ0wsT0FBTyxNQUFNLGdDQUFnQyxVQUFVLEdBQUc7SUFDNUQ7R0FDRjtHQUNBLEtBQUssTUFBTSxZQUFZLEtBQUssaUJBQWlCLDBCQUEwQixHQUFHO0lBQ3hFLGlCQUFrQixNQUFNLFNBQVM7S0FDL0I7S0FDQTtLQUNBO0tBQ0EsU0FBUztLQUNULE9BQU8sS0FBSztJQUNkLENBQUMsS0FBTTtHQUNUO0dBQ0EsT0FBTztFQUNUOzs7Ozs7Ozs7Ozs7Ozs7O0VBZ0JBLE1BQU0sU0FBUyxLQUFLLFVBQVU7R0FDNUIsTUFBTSxVQUFVLFVBQVUsR0FBRzs7O0dBRzdCLE1BQU0sUUFBUSxDQUFDO0dBQ2YsTUFBTSxtQkFBbUIsTUFBTSxLQUFLLFlBQVksU0FBUyxPQUFPO0dBQ2hFO0lBQ0UsSUFBSSxpQkFBaUIsVUFBVSxpQkFBaUIsV0FBVyxPQUFPO0tBQ2hFLE1BQU0sSUFBSSxhQUFhLG9DQUFvQztNQUN6RCxLQUFLLGVBQWUsaUJBQWlCLEdBQUc7TUFDeEMsUUFBUSxpQkFBaUI7S0FDM0IsQ0FBQztJQUNIOztJQUVBLE1BQU0sT0FBTyxTQUFTLFFBQVEsSUFBSSxNQUFNO0lBQ3hDLElBQUksTUFBTTtLQUNSLE9BQU8sTUFBTSxvQkFBb0IsZUFBZSxpQkFBaUIsR0FBRyxFQUFFLEtBQUssZ0JBQWdCLEtBQUssY0FBYyxxRUFBcUUsMERBQTBEO0lBQy9PO0dBQ0Y7R0FDQSxJQUFJLENBQUMsVUFBVTtJQUNiO0tBQ0UsT0FBTyxNQUFNLDRDQUE0QyxJQUFJLGVBQWUsaUJBQWlCLEdBQUcsRUFBRSxHQUFHO0lBQ3ZHO0lBQ0EsTUFBTSxJQUFJLGFBQWEsOEJBQThCLEVBQ25ELEtBQUssZUFBZSxpQkFBaUIsR0FBRyxFQUMxQyxDQUFDO0dBQ0g7R0FDQSxNQUFNLGtCQUFrQixNQUFNLEtBQUssMkJBQTJCLFFBQVE7R0FDdEUsSUFBSSxDQUFDLGlCQUFpQjtJQUNwQjtLQUNFLE9BQU8sTUFBTSxhQUFhLGVBQWUsaUJBQWlCLEdBQUcsRUFBRSxNQUFNLHVCQUF1QixlQUFlO0lBQzdHO0lBQ0EsT0FBTztHQUNUO0dBQ0EsTUFBTSxFQUNKLFdBQ0EsaUJBQ0UsS0FBSztHQUNULE1BQU0sUUFBUSxNQUFNLEtBQUssT0FBTyxLQUFLLFNBQVM7R0FDOUMsTUFBTSx5QkFBeUIsS0FBSyxZQUFZLGdCQUFnQjtHQUNoRSxNQUFNLGNBQWMseUJBQXlCLE1BQU07Ozs7SUFJbkQ7SUFBTyxpQkFBaUIsTUFBTTtJQUFHLENBQUMsaUJBQWlCO0lBQUc7R0FBWSxJQUFJO0dBQ3RFO0lBQ0UsT0FBTyxNQUFNLGlCQUFpQixVQUFVLGdDQUFnQyxPQUFPLGVBQWUsaUJBQWlCLEdBQUcsRUFBRSxFQUFFO0dBQ3hIO0dBQ0EsSUFBSTtJQUNGLE1BQU0sTUFBTSxJQUFJLGtCQUFrQix5QkFBeUIsZ0JBQWdCLE1BQU0sSUFBSSxlQUFlO0dBQ3RHLFNBQVMsT0FBTztJQUNkLElBQUksaUJBQWlCLE9BQU87O0tBRTFCLElBQUksTUFBTSxTQUFTLHNCQUFzQjtNQUN2QyxNQUFNLDJCQUEyQjtLQUNuQztLQUNBLE1BQU07SUFDUjtHQUNGO0dBQ0EsS0FBSyxNQUFNLFlBQVksS0FBSyxpQkFBaUIsZ0JBQWdCLEdBQUc7SUFDOUQsTUFBTSxTQUFTO0tBQ2I7S0FDQTtLQUNBLGFBQWEsZ0JBQWdCLE1BQU07S0FDbkMsU0FBUztLQUNULE9BQU8sS0FBSztJQUNkLENBQUM7R0FDSDtHQUNBLE9BQU87RUFDVDs7Ozs7Ozs7Ozs7O0VBWUEsTUFBTSxZQUFZLFNBQVMsTUFBTTtHQUMvQixNQUFNLE1BQU0sR0FBRyxRQUFRLElBQUksS0FBSztHQUNoQyxJQUFJLENBQUMsS0FBSyxXQUFXLE1BQU07SUFDekIsSUFBSSxtQkFBbUI7SUFDdkIsS0FBSyxNQUFNLFlBQVksS0FBSyxpQkFBaUIsb0JBQW9CLEdBQUc7S0FDbEUsbUJBQW1CLFVBQVUsTUFBTSxTQUFTO01BQzFDO01BQ0EsU0FBUztNQUNULE9BQU8sS0FBSzs7TUFFWixRQUFRLEtBQUs7S0FDZixDQUFDLENBQUM7SUFDSjtJQUNBLEtBQUssV0FBVyxPQUFPO0dBQ3pCO0dBQ0EsT0FBTyxLQUFLLFdBQVc7RUFDekI7Ozs7Ozs7O0VBUUEsWUFBWSxNQUFNO0dBQ2hCLEtBQUssTUFBTSxVQUFVLEtBQUssVUFBVSxTQUFTO0lBQzNDLElBQUksUUFBUSxRQUFRO0tBQ2xCLE9BQU87SUFDVDtHQUNGO0dBQ0EsT0FBTztFQUNUOzs7Ozs7Ozs7Ozs7Ozs7OztFQWlCQSxNQUFNLGFBQWEsTUFBTSxPQUFPO0dBQzlCLEtBQUssTUFBTSxZQUFZLEtBQUssaUJBQWlCLElBQUksR0FBRzs7O0lBR2xELE1BQU0sU0FBUyxLQUFLO0dBQ3RCO0VBQ0Y7Ozs7Ozs7Ozs7RUFVQSxDQUFDLGlCQUFpQixNQUFNO0dBQ3RCLEtBQUssTUFBTSxVQUFVLEtBQUssVUFBVSxTQUFTO0lBQzNDLElBQUksT0FBTyxPQUFPLFVBQVUsWUFBWTtLQUN0QyxNQUFNLFFBQVEsS0FBSyxnQkFBZ0IsSUFBSSxNQUFNO0tBQzdDLE1BQU0sb0JBQW1CLFVBQVM7TUFDaEMsTUFBTSxnQkFBZ0IsT0FBTyxPQUFPLE9BQU8sT0FBTyxDQUFDLEdBQUcsS0FBSyxHQUFHLEVBQzVELE1BQ0YsQ0FBQzs7O01BR0QsT0FBTyxPQUFPLEtBQUssQ0FBQyxhQUFhO0tBQ25DO0tBQ0EsTUFBTTtJQUNSO0dBQ0Y7RUFDRjs7Ozs7Ozs7Ozs7Ozs7RUFjQSxVQUFVLFNBQVM7R0FDakIsS0FBSyx3QkFBd0IsS0FBSyxPQUFPO0dBQ3pDLE9BQU87RUFDVDs7Ozs7Ozs7Ozs7RUFXQSxNQUFNLGNBQWM7R0FDbEIsT0FBTyxLQUFLLHdCQUF3QixRQUFRO0lBQzFDLE1BQU0sV0FBVyxLQUFLLHdCQUF3QixPQUFPLENBQUM7SUFDdEQsTUFBTSxTQUFTLE1BQU0sUUFBUSxXQUFXLFFBQVE7SUFDaEQsTUFBTSxpQkFBaUIsT0FBTyxNQUFLLE1BQUssRUFBRSxXQUFXLFVBQVU7SUFDL0QsSUFBSSxnQkFBZ0I7S0FDbEIsTUFBTSxlQUFlO0lBQ3ZCO0dBQ0Y7RUFDRjs7Ozs7RUFLQSxVQUFVO0dBQ1IsS0FBSyxpQkFBaUIsUUFBUSxJQUFJO0VBQ3BDOzs7Ozs7Ozs7OztFQVdBLE1BQU0sMkJBQTJCLFVBQVU7R0FDekMsSUFBSSxrQkFBa0I7R0FDdEIsSUFBSSxjQUFjO0dBQ2xCLEtBQUssTUFBTSxZQUFZLEtBQUssaUJBQWlCLGlCQUFpQixHQUFHO0lBQy9ELGtCQUFtQixNQUFNLFNBQVM7S0FDaEMsU0FBUyxLQUFLO0tBQ2QsVUFBVTtLQUNWLE9BQU8sS0FBSztJQUNkLENBQUMsS0FBTTtJQUNQLGNBQWM7SUFDZCxJQUFJLENBQUMsaUJBQWlCO0tBQ3BCO0lBQ0Y7R0FDRjtHQUNBLElBQUksQ0FBQyxhQUFhO0lBQ2hCLElBQUksbUJBQW1CLGdCQUFnQixXQUFXLEtBQUs7S0FDckQsa0JBQWtCO0lBQ3BCO0lBQ0E7S0FDRSxJQUFJLGlCQUFpQjtNQUNuQixJQUFJLGdCQUFnQixXQUFXLEtBQUs7T0FDbEMsSUFBSSxnQkFBZ0IsV0FBVyxHQUFHO1FBQ2hDLE9BQU8sS0FBSyxxQkFBcUIsS0FBSyxRQUFRLElBQUksTUFBTSw2REFBNkQsbURBQW1EO09BQzFLLE9BQU87UUFDTCxPQUFPLE1BQU0scUJBQXFCLEtBQUssUUFBUSxJQUFJLE1BQU0sOEJBQThCLFNBQVMsT0FBTyxnQkFBZ0Isd0JBQXdCO09BQ2pKO01BQ0Y7S0FDRjtJQUNGO0dBQ0Y7R0FDQSxPQUFPO0VBQ1Q7Q0FDRjs7Ozs7Ozs7Ozs7OztDQWNBLE1BQU0sU0FBUzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7RUF1QmIsWUFBWSxVQUFVLENBQUMsR0FBRzs7Ozs7Ozs7R0FReEIsS0FBSyxZQUFZLFdBQVcsZUFBZSxRQUFRLFNBQVM7Ozs7Ozs7O0dBUTVELEtBQUssVUFBVSxRQUFRLFdBQVcsQ0FBQzs7Ozs7Ozs7R0FRbkMsS0FBSyxlQUFlLFFBQVE7Ozs7Ozs7O0dBUTVCLEtBQUssZUFBZSxRQUFRO0VBQzlCOzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztFQW9CQSxPQUFPLFNBQVM7R0FDZCxNQUFNLENBQUMsZ0JBQWdCLEtBQUssVUFBVSxPQUFPO0dBQzdDLE9BQU87RUFDVDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7RUF1QkEsVUFBVSxTQUFTOztHQUVqQixJQUFJLG1CQUFtQixZQUFZO0lBQ2pDLFVBQVU7S0FDUixPQUFPO0tBQ1AsU0FBUyxRQUFRO0lBQ25CO0dBQ0Y7R0FDQSxNQUFNLFFBQVEsUUFBUTtHQUN0QixNQUFNLFVBQVUsT0FBTyxRQUFRLFlBQVksV0FBVyxJQUFJLFFBQVEsUUFBUSxPQUFPLElBQUksUUFBUTtHQUM3RixNQUFNLFNBQVMsWUFBWSxVQUFVLFFBQVEsU0FBUztHQUN0RCxNQUFNLFVBQVUsSUFBSSxnQkFBZ0IsTUFBTTtJQUN4QztJQUNBO0lBQ0E7R0FDRixDQUFDO0dBQ0QsTUFBTSxlQUFlLEtBQUssYUFBYSxTQUFTLFNBQVMsS0FBSztHQUM5RCxNQUFNLGNBQWMsS0FBSyxlQUFlLGNBQWMsU0FBUyxTQUFTLEtBQUs7O0dBRTdFLE9BQU8sQ0FBQyxjQUFjLFdBQVc7RUFDbkM7RUFDQSxNQUFNLGFBQWEsU0FBUyxTQUFTLE9BQU87R0FDMUMsTUFBTSxRQUFRLGFBQWEsb0JBQW9CO0lBQzdDO0lBQ0E7R0FDRixDQUFDO0dBQ0QsSUFBSSxXQUFXO0dBQ2YsSUFBSTtJQUNGLFdBQVcsTUFBTSxLQUFLLFFBQVEsU0FBUyxPQUFPOzs7O0lBSTlDLElBQUksQ0FBQyxZQUFZLFNBQVMsU0FBUyxTQUFTO0tBQzFDLE1BQU0sSUFBSSxhQUFhLGVBQWUsRUFDcEMsS0FBSyxRQUFRLElBQ2YsQ0FBQztJQUNIO0dBQ0YsU0FBUyxPQUFPO0lBQ2QsSUFBSSxpQkFBaUIsT0FBTztLQUMxQixLQUFLLE1BQU0sWUFBWSxRQUFRLGlCQUFpQixpQkFBaUIsR0FBRztNQUNsRSxXQUFXLE1BQU0sU0FBUztPQUN4QjtPQUNBO09BQ0E7TUFDRixDQUFDO01BQ0QsSUFBSSxVQUFVO09BQ1o7TUFDRjtLQUNGO0lBQ0Y7SUFDQSxJQUFJLENBQUMsVUFBVTtLQUNiLE1BQU07SUFDUixPQUFPO0tBQ0wsT0FBTyxJQUFJLHdCQUF3QixlQUFlLFFBQVEsR0FBRyxFQUFFLE9BQU8sTUFBTSxpQkFBaUIsUUFBUSxNQUFNLFNBQVMsSUFBSSxHQUFHLDJEQUEyRCwyQkFBMkI7SUFDbk47R0FDRjtHQUNBLEtBQUssTUFBTSxZQUFZLFFBQVEsaUJBQWlCLG9CQUFvQixHQUFHO0lBQ3JFLFdBQVcsTUFBTSxTQUFTO0tBQ3hCO0tBQ0E7S0FDQTtJQUNGLENBQUM7R0FDSDtHQUNBLE9BQU87RUFDVDtFQUNBLE1BQU0sZUFBZSxjQUFjLFNBQVMsU0FBUyxPQUFPO0dBQzFELElBQUk7R0FDSixJQUFJO0dBQ0osSUFBSTtJQUNGLFdBQVcsTUFBTTtHQUNuQixTQUFTLE9BQU8sQ0FJaEI7R0FDQSxJQUFJO0lBQ0YsTUFBTSxRQUFRLGFBQWEscUJBQXFCO0tBQzlDO0tBQ0E7S0FDQTtJQUNGLENBQUM7SUFDRCxNQUFNLFFBQVEsWUFBWTtHQUM1QixTQUFTLGdCQUFnQjtJQUN2QixJQUFJLDBCQUEwQixPQUFPO0tBQ25DLFFBQVE7SUFDVjtHQUNGO0dBQ0EsTUFBTSxRQUFRLGFBQWEsc0JBQXNCO0lBQy9DO0lBQ0E7SUFDQTtJQUNPO0dBQ1QsQ0FBQztHQUNELFFBQVEsUUFBUTtHQUNoQixJQUFJLE9BQU87SUFDVCxNQUFNO0dBQ1I7RUFDRjtDQUNGOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBMEJBLE1BQU0sV0FBVztFQUNmLGdCQUFnQixjQUFjLFlBQVksU0FBUyxhQUFhLGtCQUFrQixlQUFlLFFBQVEsR0FBRyxFQUFFO0VBQzlHLHFCQUFvQixhQUFZO0dBQzlCLElBQUksVUFBVTtJQUNaLE9BQU8sZUFBZSwrQkFBK0I7SUFDckQsT0FBTyxJQUFJLFlBQVksd0JBQXdCO0lBQy9DLE9BQU8sU0FBUztHQUNsQjtFQUNGO0NBQ0Y7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztDQXlCQSxNQUFNLHFCQUFxQixTQUFTOzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztFQW9CbEMsWUFBWSxVQUFVLENBQUMsR0FBRztHQUN4QixNQUFNLE9BQU87OztHQUdiLElBQUksQ0FBQyxLQUFLLFFBQVEsTUFBSyxNQUFLLHFCQUFxQixDQUFDLEdBQUc7SUFDbkQsS0FBSyxRQUFRLFFBQVEsc0JBQXNCO0dBQzdDO0dBQ0EsS0FBSyx5QkFBeUIsUUFBUSx5QkFBeUI7R0FDL0Q7SUFDRSxJQUFJLEtBQUssd0JBQXdCO0tBQy9CLG1CQUFtQixPQUFPLEtBQUssd0JBQXdCLFVBQVU7TUFDL0QsWUFBWTtNQUNaLFdBQVcsS0FBSyxZQUFZO01BQzVCLFVBQVU7TUFDVixXQUFXO0tBQ2IsQ0FBQztJQUNIO0dBQ0Y7RUFDRjs7Ozs7Ozs7RUFRQSxNQUFNLFFBQVEsU0FBUyxTQUFTO0dBQzlCLE1BQU0sT0FBTyxDQUFDO0dBQ2Q7SUFDRSxtQkFBbUIsV0FBVyxTQUFTLFNBQVM7S0FDOUMsWUFBWTtLQUNaLFdBQVcsS0FBSyxZQUFZO0tBQzVCLFVBQVU7S0FDVixXQUFXO0lBQ2IsQ0FBQztHQUNIO0dBQ0EsTUFBTSxXQUFXLENBQUM7R0FDbEIsSUFBSTtHQUNKLElBQUksS0FBSyx3QkFBd0I7SUFDL0IsTUFBTSxFQUNKLElBQ0EsWUFDRSxLQUFLLG1CQUFtQjtLQUMxQjtLQUNBO0tBQ0E7SUFDRixDQUFDO0lBQ0QsWUFBWTtJQUNaLFNBQVMsS0FBSyxPQUFPO0dBQ3ZCO0dBQ0EsTUFBTSxpQkFBaUIsS0FBSyxtQkFBbUI7SUFDN0M7SUFDQTtJQUNBO0lBQ0E7R0FDRixDQUFDO0dBQ0QsU0FBUyxLQUFLLGNBQWM7R0FDNUIsTUFBTSxXQUFXLE1BQU0sUUFBUSxXQUFXLFlBQVk7O0lBRXBELE9BQVEsTUFBTSxRQUFRLFVBQVUsUUFBUSxLQUFLLFFBQVEsQ0FBQyxLQU10RCxNQUFNO0dBQ1IsRUFBQyxDQUFFLENBQUM7R0FDSjtJQUNFLE9BQU8sZUFBZSxTQUFTLGNBQWMsS0FBSyxZQUFZLE1BQU0sT0FBTyxDQUFDO0lBQzVFLEtBQUssTUFBTSxPQUFPLE1BQU07S0FDdEIsT0FBTyxJQUFJLEdBQUc7SUFDaEI7SUFDQSxTQUFTLG1CQUFtQixRQUFRO0lBQ3BDLE9BQU8sU0FBUztHQUNsQjtHQUNBLElBQUksQ0FBQyxVQUFVO0lBQ2IsTUFBTSxJQUFJLGFBQWEsZUFBZSxFQUNwQyxLQUFLLFFBQVEsSUFDZixDQUFDO0dBQ0g7R0FDQSxPQUFPO0VBQ1Q7Ozs7Ozs7Ozs7RUFVQSxtQkFBbUIsRUFDakIsU0FDQSxNQUNBLFdBQ0M7R0FDRCxJQUFJO0dBQ0osTUFBTSxpQkFBaUIsSUFBSSxTQUFRLFlBQVc7SUFDNUMsTUFBTSxtQkFBbUIsWUFBWTtLQUNuQztNQUNFLEtBQUssS0FBSyx3Q0FBd0MsR0FBRyxLQUFLLHVCQUF1QixVQUFVO0tBQzdGO0tBQ0EsUUFBUSxNQUFNLFFBQVEsV0FBVyxPQUFPLENBQUM7SUFDM0M7SUFDQSxZQUFZLFdBQVcsa0JBQWtCLEtBQUsseUJBQXlCLEdBQUk7R0FDN0UsQ0FBQztHQUNELE9BQU87SUFDTCxTQUFTO0lBQ1QsSUFBSTtHQUNOO0VBQ0Y7Ozs7Ozs7Ozs7O0VBV0EsTUFBTSxtQkFBbUIsRUFDdkIsV0FDQSxTQUNBLE1BQ0EsV0FDQztHQUNELElBQUk7R0FDSixJQUFJO0dBQ0osSUFBSTtJQUNGLFdBQVcsTUFBTSxRQUFRLGlCQUFpQixPQUFPO0dBQ25ELFNBQVMsWUFBWTtJQUNuQixJQUFJLHNCQUFzQixPQUFPO0tBQy9CLFFBQVE7SUFDVjtHQUNGO0dBQ0EsSUFBSSxXQUFXO0lBQ2IsYUFBYSxTQUFTO0dBQ3hCO0dBQ0E7SUFDRSxJQUFJLFVBQVU7S0FDWixLQUFLLEtBQUssNEJBQTRCO0lBQ3hDLE9BQU87S0FDTCxLQUFLLEtBQUssNkRBQTZELHlCQUF5QjtJQUNsRztHQUNGO0dBQ0EsSUFBSSxTQUFTLENBQUMsVUFBVTtJQUN0QixXQUFXLE1BQU0sUUFBUSxXQUFXLE9BQU87SUFDM0M7S0FDRSxJQUFJLFVBQVU7TUFDWixLQUFLLEtBQUssbUNBQW1DLEtBQUssVUFBVSxLQUFLLFNBQVM7S0FDNUUsT0FBTztNQUNMLEtBQUssS0FBSyw2QkFBNkIsS0FBSyxVQUFVLFNBQVM7S0FDakU7SUFDRjtHQUNGO0dBQ0EsT0FBTztFQUNUO0NBQ0Y7Ozs7Ozs7Ozs7Ozs7O0NBZUEsU0FBUyxlQUFlO0VBQ3RCLEtBQUssaUJBQWlCLGtCQUFrQixLQUFLLFFBQVEsTUFBTSxDQUFDO0NBQzlEOzs7Ozs7Ozs7Ozs7Ozs7O0NBaUJBLFNBQVMsVUFBVSxPQUFPLFNBQVM7RUFDakMsTUFBTSxnQkFBZ0IsUUFBUTtFQUM5QixNQUFNLFVBQVUsYUFBYTtFQUM3QixPQUFPO0NBQ1Q7O0NBR0EsSUFBSTtFQUNGLEtBQUssK0JBQStCLEVBQUU7Q0FDeEMsU0FBUyxHQUFHLENBQUM7Ozs7Ozs7OztDQVViLE1BQU0sd0JBQXdCOzs7Ozs7Ozs7O0NBVTlCLFNBQVMsZUFBZSxPQUFPO0VBQzdCLElBQUksQ0FBQyxPQUFPO0dBQ1YsTUFBTSxJQUFJLGFBQWEscUNBQXFDLEVBQzFELE1BQ0YsQ0FBQztFQUNIOzs7RUFHQSxJQUFJLE9BQU8sVUFBVSxVQUFVO0dBQzdCLE1BQU0sWUFBWSxJQUFJLElBQUksT0FBTyxTQUFTLElBQUk7R0FDOUMsT0FBTztJQUNMLFVBQVUsVUFBVTtJQUNwQixLQUFLLFVBQVU7R0FDakI7RUFDRjtFQUNBLE1BQU0sRUFDSixVQUNBLFFBQ0U7RUFDSixJQUFJLENBQUMsS0FBSztHQUNSLE1BQU0sSUFBSSxhQUFhLHFDQUFxQyxFQUMxRCxNQUNGLENBQUM7RUFDSDs7O0VBR0EsSUFBSSxDQUFDLFVBQVU7R0FDYixNQUFNLFlBQVksSUFBSSxJQUFJLEtBQUssU0FBUyxJQUFJO0dBQzVDLE9BQU87SUFDTCxVQUFVLFVBQVU7SUFDcEIsS0FBSyxVQUFVO0dBQ2pCO0VBQ0Y7OztFQUdBLE1BQU0sY0FBYyxJQUFJLElBQUksS0FBSyxTQUFTLElBQUk7RUFDOUMsTUFBTSxjQUFjLElBQUksSUFBSSxLQUFLLFNBQVMsSUFBSTtFQUM5QyxZQUFZLGFBQWEsSUFBSSx1QkFBdUIsUUFBUTtFQUM1RCxPQUFPO0dBQ0wsVUFBVSxZQUFZO0dBQ3RCLEtBQUssWUFBWTtFQUNuQjtDQUNGOzs7Ozs7Ozs7Ozs7OztDQWVBLE1BQU0sNEJBQTRCO0VBQ2hDLGNBQWM7R0FDWixLQUFLLGNBQWMsQ0FBQztHQUNwQixLQUFLLGlCQUFpQixDQUFDO0dBQ3ZCLEtBQUssbUJBQW1CLE9BQU8sRUFDN0IsU0FDQSxZQUNJOztJQUVKLElBQUksT0FBTztLQUNULE1BQU0sa0JBQWtCO0lBQzFCO0dBQ0Y7R0FDQSxLQUFLLDJCQUEyQixPQUFPLEVBQ3JDLE9BQ0EsT0FDQSxxQkFDSTtJQUNKLElBQUksTUFBTSxTQUFTLFdBQVc7S0FDNUIsSUFBSSxTQUFTLE1BQU0sbUJBQW1CLE1BQU0sMkJBQTJCLFNBQVM7O01BRTlFLE1BQU0sTUFBTSxNQUFNLGdCQUFnQjtNQUNsQyxJQUFJLGdCQUFnQjtPQUNsQixLQUFLLGVBQWUsS0FBSyxHQUFHO01BQzlCLE9BQU87T0FDTCxLQUFLLFlBQVksS0FBSyxHQUFHO01BQzNCO0tBQ0Y7SUFDRjtJQUNBLE9BQU87R0FDVDtFQUNGO0NBQ0Y7Ozs7Ozs7Ozs7Ozs7O0NBZUEsTUFBTSx1QkFBdUI7RUFDM0IsWUFBWSxFQUNWLHNCQUNDO0dBQ0QsS0FBSyxxQkFBcUIsT0FBTyxFQUMvQixTQUNBLGFBQ0k7OztJQUdKLE1BQU0sWUFBWSxXQUFXLFFBQVEsV0FBVyxLQUFLLElBQUksS0FBSyxJQUFJLE9BQU8sYUFBYSxLQUFLLG9CQUFvQixrQkFBa0IsUUFBUSxHQUFHOztJQUU1SSxPQUFPLFdBQVcsSUFBSSxRQUFRLFVBQVUsRUFDdEMsU0FBUyxRQUFRLFFBQ25CLENBQUMsSUFBSTtHQUNQO0dBQ0EsS0FBSyxzQkFBc0I7RUFDN0I7Q0FDRjs7Ozs7Ozs7Ozs7Ozs7Q0FlQSxNQUFNLFlBQVksWUFBWSxnQkFBZ0I7RUFDNUMsT0FBTyxlQUFlLFVBQVU7RUFDaEMsS0FBSyxNQUFNLE9BQU8sYUFBYTtHQUM3QixPQUFPLElBQUksR0FBRztFQUNoQjtFQUNBLE9BQU8sU0FBUztDQUNsQjs7Ozs7OztDQU9BLFNBQVMsb0JBQW9CLGFBQWE7RUFDeEMsTUFBTSxnQkFBZ0IsWUFBWTtFQUNsQyxJQUFJLGdCQUFnQixHQUFHO0dBQ3JCLE9BQU8sZUFBZSxnQ0FBZ0MsR0FBRyxjQUFjLFlBQVksVUFBVSxrQkFBa0IsSUFBSSxTQUFTLFNBQVMsVUFBVTtHQUMvSSxTQUFTLDBCQUEwQixXQUFXO0dBQzlDLE9BQU8sU0FBUztFQUNsQjtDQUNGOzs7Ozs7Ozs7Ozs7OztDQWVBLFNBQVMsYUFBYSxZQUFZLE1BQU07RUFDdEMsSUFBSSxLQUFLLFdBQVcsR0FBRztHQUNyQjtFQUNGO0VBQ0EsT0FBTyxlQUFlLFVBQVU7RUFDaEMsS0FBSyxNQUFNLE9BQU8sTUFBTTtHQUN0QixPQUFPLElBQUksR0FBRztFQUNoQjtFQUNBLE9BQU8sU0FBUztDQUNsQjs7Ozs7Ozs7Q0FRQSxTQUFTLG9CQUFvQixnQkFBZ0Isc0JBQXNCO0VBQ2pFLE1BQU0saUJBQWlCLGVBQWU7RUFDdEMsTUFBTSx3QkFBd0IscUJBQXFCO0VBQ25ELElBQUksa0JBQWtCLHVCQUF1QjtHQUMzQyxJQUFJLFVBQVUsY0FBYyxlQUFlLE9BQU8sbUJBQW1CLElBQUksS0FBSyxJQUFJO0dBQ2xGLElBQUksd0JBQXdCLEdBQUc7SUFDN0IsV0FBVyxJQUFJLHNCQUFzQixLQUFLLE9BQU8sMEJBQTBCLElBQUksUUFBUSxRQUFRO0dBQ2pHO0dBQ0EsT0FBTyxlQUFlLE9BQU87R0FDN0IsYUFBYSw4QkFBOEIsY0FBYztHQUN6RCxhQUFhLG1DQUFtQyxvQkFBb0I7R0FDcEUsT0FBTyxTQUFTO0VBQ2xCO0NBQ0Y7Ozs7Ozs7O0NBU0EsSUFBSTs7Ozs7Ozs7OztDQVVKLFNBQVMscUNBQXFDO0VBQzVDLElBQUksa0JBQWtCLFdBQVc7R0FDL0IsTUFBTSxlQUFlLElBQUksU0FBUyxFQUFFO0dBQ3BDLElBQUksVUFBVSxjQUFjO0lBQzFCLElBQUk7S0FDRixJQUFJLFNBQVMsYUFBYSxJQUFJO0tBQzlCLGdCQUFnQjtJQUNsQixTQUFTLE9BQU87S0FDZCxnQkFBZ0I7SUFDbEI7R0FDRjtHQUNBLGdCQUFnQjtFQUNsQjtFQUNBLE9BQU87Q0FDVDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBNEJBLGVBQWUsYUFBYSxVQUFVLFVBQVU7RUFDOUMsSUFBSSxTQUFTOztFQUViLElBQUksU0FBUyxLQUFLO0dBQ2hCLE1BQU0sY0FBYyxJQUFJLElBQUksU0FBUyxHQUFHO0dBQ3hDLFNBQVMsWUFBWTtFQUN2QjtFQUNBLElBQUksV0FBVyxLQUFLLFNBQVMsUUFBUTtHQUNuQyxNQUFNLElBQUksYUFBYSw4QkFBOEIsRUFDbkQsT0FDRixDQUFDO0VBQ0g7RUFDQSxNQUFNLGlCQUFpQixTQUFTLE1BQU07O0VBRXRDLE1BQU0sZUFBZTtHQUNuQixTQUFTLElBQUksUUFBUSxlQUFlLE9BQU87R0FDM0MsUUFBUSxlQUFlO0dBQ3ZCLFlBQVksZUFBZTtFQUM3Qjs7RUFFQSxNQUFNLHVCQUF1Qjs7OztFQUk3QixNQUFNLE9BQU8sbUNBQW1DLElBQUksZUFBZSxPQUFPLE1BQU0sZUFBZSxLQUFLO0VBQ3BHLE9BQU8sSUFBSSxTQUFTLE1BQU0sb0JBQW9CO0NBQ2hEOzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztDQXFCQSxNQUFNLHlCQUF5QixTQUFTOzs7Ozs7Ozs7Ozs7Ozs7Ozs7RUFrQnRDLFlBQVksVUFBVSxDQUFDLEdBQUc7R0FDeEIsUUFBUSxZQUFZLFdBQVcsZ0JBQWdCLFFBQVEsU0FBUztHQUNoRSxNQUFNLE9BQU87R0FDYixLQUFLLHFCQUFxQixRQUFRLHNCQUFzQixRQUFRLFFBQVE7Ozs7O0dBS3hFLEtBQUssUUFBUSxLQUFLLGlCQUFpQixzQ0FBc0M7RUFDM0U7Ozs7Ozs7O0VBUUEsTUFBTSxRQUFRLFNBQVMsU0FBUztHQUM5QixNQUFNLFdBQVcsTUFBTSxRQUFRLFdBQVcsT0FBTztHQUNqRCxJQUFJLFVBQVU7SUFDWixPQUFPO0dBQ1Q7OztHQUdBLElBQUksUUFBUSxTQUFTLFFBQVEsTUFBTSxTQUFTLFdBQVc7SUFDckQsT0FBTyxNQUFNLEtBQUssZUFBZSxTQUFTLE9BQU87R0FDbkQ7OztHQUdBLE9BQU8sTUFBTSxLQUFLLGFBQWEsU0FBUyxPQUFPO0VBQ2pEO0VBQ0EsTUFBTSxhQUFhLFNBQVMsU0FBUztHQUNuQyxJQUFJO0dBQ0osTUFBTSxTQUFTLFFBQVEsVUFBVSxDQUFDOztHQUVsQyxJQUFJLEtBQUssb0JBQW9CO0lBQzNCO0tBQ0UsT0FBTyxLQUFLLGdDQUFnQyxHQUFHLGVBQWUsUUFBUSxHQUFHLEVBQUUsTUFBTSxLQUFLLFVBQVUsYUFBYSxxQ0FBcUM7SUFDcEo7SUFDQSxNQUFNLHNCQUFzQixPQUFPO0lBQ25DLE1BQU0scUJBQXFCLFFBQVE7SUFDbkMsTUFBTSxzQkFBc0IsQ0FBQyxzQkFBc0IsdUJBQXVCOzs7SUFHMUUsV0FBVyxNQUFNLFFBQVEsTUFBTSxJQUFJLFFBQVEsU0FBUyxFQUNsRCxXQUFXLFFBQVEsU0FBUyxZQUFZLHNCQUFzQixzQkFBc0IsVUFDdEYsQ0FBQyxDQUFDOzs7Ozs7OztJQVFGLElBQUksdUJBQXVCLHVCQUF1QixRQUFRLFNBQVMsV0FBVztLQUM1RSxLQUFLLHNDQUFzQztLQUMzQyxNQUFNLFlBQVksTUFBTSxRQUFRLFNBQVMsU0FBUyxTQUFTLE1BQU0sQ0FBQztLQUNsRTtNQUNFLElBQUksV0FBVztPQUNiLE9BQU8sSUFBSSxrQkFBa0IsZUFBZSxRQUFRLEdBQUcsRUFBRSxLQUFLLG9DQUFvQztNQUNwRztLQUNGO0lBQ0Y7R0FDRixPQUFPOzs7SUFHTCxNQUFNLElBQUksYUFBYSwwQkFBMEI7S0FDL0MsV0FBVyxLQUFLO0tBQ2hCLEtBQUssUUFBUTtJQUNmLENBQUM7R0FDSDtHQUNBO0lBQ0UsTUFBTSxXQUFXLE9BQU8sWUFBYSxNQUFNLFFBQVEsWUFBWSxTQUFTLE1BQU07OztJQUc5RSxPQUFPLGVBQWUsa0NBQWtDLGVBQWUsUUFBUSxHQUFHLENBQUM7SUFDbkYsT0FBTyxJQUFJLDhCQUE4QixlQUFlLG9CQUFvQixVQUFVLFNBQVMsTUFBTSxRQUFRLEdBQUc7SUFDaEgsT0FBTyxlQUFlLDRCQUE0QjtJQUNsRCxPQUFPLElBQUksT0FBTztJQUNsQixPQUFPLFNBQVM7SUFDaEIsT0FBTyxlQUFlLDZCQUE2QjtJQUNuRCxPQUFPLElBQUksUUFBUTtJQUNuQixPQUFPLFNBQVM7SUFDaEIsT0FBTyxTQUFTO0dBQ2xCO0dBQ0EsT0FBTztFQUNUO0VBQ0EsTUFBTSxlQUFlLFNBQVMsU0FBUztHQUNyQyxLQUFLLHNDQUFzQztHQUMzQyxNQUFNLFdBQVcsTUFBTSxRQUFRLE1BQU0sT0FBTzs7O0dBRzVDLE1BQU0sWUFBWSxNQUFNLFFBQVEsU0FBUyxTQUFTLFNBQVMsTUFBTSxDQUFDO0dBQ2xFLElBQUksQ0FBQyxXQUFXOzs7SUFHZCxNQUFNLElBQUksYUFBYSwyQkFBMkI7S0FDaEQsS0FBSyxRQUFRO0tBQ2IsUUFBUSxTQUFTO0lBQ25CLENBQUM7R0FDSDtHQUNBLE9BQU87RUFDVDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztFQTRCQSx3Q0FBd0M7R0FDdEMsSUFBSSxxQkFBcUI7R0FDekIsSUFBSSw2QkFBNkI7R0FDakMsS0FBSyxNQUFNLENBQUMsT0FBTyxXQUFXLEtBQUssUUFBUSxRQUFRLEdBQUc7O0lBRXBELElBQUksV0FBVyxpQkFBaUIsd0NBQXdDO0tBQ3RFO0lBQ0Y7O0lBRUEsSUFBSSxXQUFXLGlCQUFpQixtQ0FBbUM7S0FDakUscUJBQXFCO0lBQ3ZCO0lBQ0EsSUFBSSxPQUFPLGlCQUFpQjtLQUMxQjtJQUNGO0dBQ0Y7R0FDQSxJQUFJLCtCQUErQixHQUFHO0lBQ3BDLEtBQUssUUFBUSxLQUFLLGlCQUFpQixpQ0FBaUM7R0FDdEUsT0FBTyxJQUFJLDZCQUE2QixLQUFLLHVCQUF1QixNQUFNOztJQUV4RSxLQUFLLFFBQVEsT0FBTyxvQkFBb0IsQ0FBQztHQUMzQzs7RUFFRjtDQUNGO0NBQ0EsaUJBQWlCLG9DQUFvQyxFQUNuRCxNQUFNLGdCQUFnQixFQUNwQixZQUNDO0VBQ0QsSUFBSSxDQUFDLFlBQVksU0FBUyxVQUFVLEtBQUs7R0FDdkMsT0FBTztFQUNUO0VBQ0EsT0FBTztDQUNULEVBQ0Y7Q0FDQSxpQkFBaUIseUNBQXlDLEVBQ3hELE1BQU0sZ0JBQWdCLEVBQ3BCLFlBQ0M7RUFDRCxPQUFPLFNBQVMsYUFBYSxNQUFNLGFBQWEsUUFBUSxJQUFJO0NBQzlELEVBQ0Y7Ozs7Ozs7Ozs7Ozs7Q0FjQSxNQUFNLG1CQUFtQjs7Ozs7Ozs7Ozs7RUFXdkIsWUFBWSxFQUNWLFdBQ0EsVUFBVSxDQUFDLEdBQ1gsb0JBQW9CLFNBQ2xCLENBQUMsR0FBRztHQUNOLEtBQUssbUJBQW1CLElBQUksSUFBSTtHQUNoQyxLQUFLLG9CQUFvQixJQUFJLElBQUk7R0FDakMsS0FBSywwQkFBMEIsSUFBSSxJQUFJO0dBQ3ZDLEtBQUssWUFBWSxJQUFJLGlCQUFpQjtJQUNwQyxXQUFXLFdBQVcsZ0JBQWdCLFNBQVM7SUFDL0MsU0FBUyxDQUFDLEdBQUcsU0FBUyxJQUFJLHVCQUF1QixFQUMvQyxvQkFBb0IsS0FDdEIsQ0FBQyxDQUFDO0lBQ0Y7R0FDRixDQUFDOztHQUVELEtBQUssVUFBVSxLQUFLLFFBQVEsS0FBSyxJQUFJO0dBQ3JDLEtBQUssV0FBVyxLQUFLLFNBQVMsS0FBSyxJQUFJO0VBQ3pDOzs7OztFQUtBLElBQUksV0FBVztHQUNiLE9BQU8sS0FBSztFQUNkOzs7Ozs7Ozs7OztFQVdBLFNBQVMsU0FBUztHQUNoQixLQUFLLGVBQWUsT0FBTztHQUMzQixJQUFJLENBQUMsS0FBSyxpQ0FBaUM7SUFDekMsS0FBSyxpQkFBaUIsV0FBVyxLQUFLLE9BQU87SUFDN0MsS0FBSyxpQkFBaUIsWUFBWSxLQUFLLFFBQVE7SUFDL0MsS0FBSyxrQ0FBa0M7R0FDekM7RUFDRjs7Ozs7Ozs7RUFRQSxlQUFlLFNBQVM7R0FDdEI7SUFDRSxtQkFBbUIsUUFBUSxTQUFTO0tBQ2xDLFlBQVk7S0FDWixXQUFXO0tBQ1gsVUFBVTtLQUNWLFdBQVc7SUFDYixDQUFDO0dBQ0g7R0FDQSxNQUFNLGtCQUFrQixDQUFDO0dBQ3pCLEtBQUssTUFBTSxTQUFTLFNBQVM7O0lBRTNCLElBQUksT0FBTyxVQUFVLFVBQVU7S0FDN0IsZ0JBQWdCLEtBQUssS0FBSztJQUM1QixPQUFPLElBQUksU0FBUyxNQUFNLGFBQWEsV0FBVztLQUNoRCxnQkFBZ0IsS0FBSyxNQUFNLEdBQUc7SUFDaEM7SUFDQSxNQUFNLEVBQ0osVUFDQSxRQUNFLGVBQWUsS0FBSztJQUN4QixNQUFNLFlBQVksT0FBTyxVQUFVLFlBQVksTUFBTSxXQUFXLFdBQVc7SUFDM0UsSUFBSSxLQUFLLGlCQUFpQixJQUFJLEdBQUcsS0FBSyxLQUFLLGlCQUFpQixJQUFJLEdBQUcsTUFBTSxVQUFVO0tBQ2pGLE1BQU0sSUFBSSxhQUFhLHlDQUF5QztNQUM5RCxZQUFZLEtBQUssaUJBQWlCLElBQUksR0FBRztNQUN6QyxhQUFhO0tBQ2YsQ0FBQztJQUNIO0lBQ0EsSUFBSSxPQUFPLFVBQVUsWUFBWSxNQUFNLFdBQVc7S0FDaEQsSUFBSSxLQUFLLHdCQUF3QixJQUFJLFFBQVEsS0FBSyxLQUFLLHdCQUF3QixJQUFJLFFBQVEsTUFBTSxNQUFNLFdBQVc7TUFDaEgsTUFBTSxJQUFJLGFBQWEsNkNBQTZDLEVBQ2xFLElBQ0YsQ0FBQztLQUNIO0tBQ0EsS0FBSyx3QkFBd0IsSUFBSSxVQUFVLE1BQU0sU0FBUztJQUM1RDtJQUNBLEtBQUssaUJBQWlCLElBQUksS0FBSyxRQUFRO0lBQ3ZDLEtBQUssa0JBQWtCLElBQUksS0FBSyxTQUFTO0lBQ3pDLElBQUksZ0JBQWdCLFNBQVMsR0FBRztLQUM5QixNQUFNLGlCQUFpQixpREFBaUQsU0FBUyxnQkFBZ0IsS0FBSyxJQUFJLEVBQUUsa0NBQWtDO0tBQzlJO01BQ0UsT0FBTyxLQUFLLGNBQWM7S0FDNUI7SUFDRjtHQUNGO0VBQ0Y7Ozs7Ozs7Ozs7O0VBV0EsUUFBUSxPQUFPOzs7R0FHYixPQUFPLFVBQVUsT0FBTyxZQUFZO0lBQ2xDLE1BQU0sc0JBQXNCLElBQUksNEJBQTRCO0lBQzVELEtBQUssU0FBUyxRQUFRLEtBQUssbUJBQW1COzs7SUFHOUMsS0FBSyxNQUFNLENBQUMsS0FBSyxhQUFhLEtBQUssa0JBQWtCO0tBQ25ELE1BQU0sWUFBWSxLQUFLLHdCQUF3QixJQUFJLFFBQVE7S0FDM0QsTUFBTSxZQUFZLEtBQUssa0JBQWtCLElBQUksR0FBRztLQUNoRCxNQUFNLFVBQVUsSUFBSSxRQUFRLEtBQUs7TUFDL0I7TUFDQSxPQUFPO01BQ1AsYUFBYTtLQUNmLENBQUM7S0FDRCxNQUFNLFFBQVEsSUFBSSxLQUFLLFNBQVMsVUFBVTtNQUN4QyxRQUFRLEVBQ04sU0FDRjtNQUNBO01BQ0E7S0FDRixDQUFDLENBQUM7SUFDSjtJQUNBLE1BQU0sRUFDSixhQUNBLG1CQUNFO0lBQ0o7S0FDRSxvQkFBb0IsYUFBYSxjQUFjO0lBQ2pEO0lBQ0EsT0FBTztLQUNMO0tBQ0E7SUFDRjtHQUNGLENBQUM7RUFDSDs7Ozs7Ozs7Ozs7RUFXQSxTQUFTLE9BQU87OztHQUdkLE9BQU8sVUFBVSxPQUFPLFlBQVk7SUFDbEMsTUFBTSxRQUFRLE1BQU0sS0FBSyxPQUFPLEtBQUssS0FBSyxTQUFTLFNBQVM7SUFDNUQsTUFBTSwwQkFBMEIsTUFBTSxNQUFNLEtBQUs7SUFDakQsTUFBTSxvQkFBb0IsSUFBSSxJQUFJLEtBQUssaUJBQWlCLE9BQU8sQ0FBQztJQUNoRSxNQUFNLGNBQWMsQ0FBQztJQUNyQixLQUFLLE1BQU0sV0FBVyx5QkFBeUI7S0FDN0MsSUFBSSxDQUFDLGtCQUFrQixJQUFJLFFBQVEsR0FBRyxHQUFHO01BQ3ZDLE1BQU0sTUFBTSxPQUFPLE9BQU87TUFDMUIsWUFBWSxLQUFLLFFBQVEsR0FBRztLQUM5QjtJQUNGO0lBQ0E7S0FDRSxvQkFBb0IsV0FBVztJQUNqQztJQUNBLE9BQU8sRUFDTCxZQUNGO0dBQ0YsQ0FBQztFQUNIOzs7Ozs7O0VBT0EscUJBQXFCO0dBQ25CLE9BQU8sS0FBSztFQUNkOzs7Ozs7O0VBT0EsZ0JBQWdCO0dBQ2QsT0FBTyxDQUFDLEdBQUcsS0FBSyxpQkFBaUIsS0FBSyxDQUFDO0VBQ3pDOzs7Ozs7Ozs7O0VBVUEsa0JBQWtCLEtBQUs7R0FDckIsTUFBTSxZQUFZLElBQUksSUFBSSxLQUFLLFNBQVMsSUFBSTtHQUM1QyxPQUFPLEtBQUssaUJBQWlCLElBQUksVUFBVSxJQUFJO0VBQ2pEOzs7Ozs7RUFNQSx3QkFBd0IsVUFBVTtHQUNoQyxPQUFPLEtBQUssd0JBQXdCLElBQUksUUFBUTtFQUNsRDs7Ozs7Ozs7Ozs7Ozs7Ozs7OztFQW1CQSxNQUFNLGNBQWMsU0FBUztHQUMzQixNQUFNLE1BQU0sbUJBQW1CLFVBQVUsUUFBUSxNQUFNO0dBQ3ZELE1BQU0sV0FBVyxLQUFLLGtCQUFrQixHQUFHO0dBQzNDLElBQUksVUFBVTtJQUNaLE1BQU0sUUFBUSxNQUFNLEtBQUssT0FBTyxLQUFLLEtBQUssU0FBUyxTQUFTO0lBQzVELE9BQU8sTUFBTSxNQUFNLFFBQVE7R0FDN0I7R0FDQSxPQUFPO0VBQ1Q7Ozs7Ozs7OztFQVNBLHdCQUF3QixLQUFLO0dBQzNCLE1BQU0sV0FBVyxLQUFLLGtCQUFrQixHQUFHO0dBQzNDLElBQUksQ0FBQyxVQUFVO0lBQ2IsTUFBTSxJQUFJLGFBQWEscUJBQXFCLEVBQzFDLElBQ0YsQ0FBQztHQUNIO0dBQ0EsUUFBTyxZQUFXO0lBQ2hCLFFBQVEsVUFBVSxJQUFJLFFBQVEsR0FBRztJQUNqQyxRQUFRLFNBQVMsT0FBTyxPQUFPLEVBQzdCLFNBQ0YsR0FBRyxRQUFRLE1BQU07SUFDakIsT0FBTyxLQUFLLFNBQVMsT0FBTyxPQUFPO0dBQ3JDO0VBQ0Y7Q0FDRjs7Ozs7Ozs7Q0FTQSxJQUFJOzs7OztDQUtKLE1BQU0sc0NBQXNDO0VBQzFDLElBQUksQ0FBQyxvQkFBb0I7R0FDdkIscUJBQXFCLElBQUksbUJBQW1CO0VBQzlDO0VBQ0EsT0FBTztDQUNUOzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztDQXFCQSxTQUFTLDBCQUEwQixXQUFXLDhCQUE4QixDQUFDLEdBQUc7OztFQUc5RSxLQUFLLE1BQU0sYUFBYSxDQUFDLEdBQUcsVUFBVSxhQUFhLEtBQUssQ0FBQyxHQUFHO0dBQzFELElBQUksNEJBQTRCLE1BQUssV0FBVSxPQUFPLEtBQUssU0FBUyxDQUFDLEdBQUc7SUFDdEUsVUFBVSxhQUFhLE9BQU8sU0FBUztHQUN6QztFQUNGO0VBQ0EsT0FBTztDQUNUOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0FtQkEsVUFBVSxzQkFBc0IsS0FBSyxFQUNuQyw4QkFBOEIsQ0FBQyxTQUFTLFVBQVUsR0FDbEQsaUJBQWlCLGNBQ2pCLFlBQVksTUFDWixvQkFDRSxDQUFDLEdBQUc7RUFDTixNQUFNLFlBQVksSUFBSSxJQUFJLEtBQUssU0FBUyxJQUFJO0VBQzVDLFVBQVUsT0FBTztFQUNqQixNQUFNLFVBQVU7RUFDaEIsTUFBTSwwQkFBMEIsMEJBQTBCLFdBQVcsMkJBQTJCO0VBQ2hHLE1BQU0sd0JBQXdCO0VBQzlCLElBQUksa0JBQWtCLHdCQUF3QixTQUFTLFNBQVMsR0FBRyxHQUFHO0dBQ3BFLE1BQU0sZUFBZSxJQUFJLElBQUksd0JBQXdCLElBQUk7R0FDekQsYUFBYSxZQUFZO0dBQ3pCLE1BQU0sYUFBYTtFQUNyQjtFQUNBLElBQUksV0FBVztHQUNiLE1BQU0sV0FBVyxJQUFJLElBQUksd0JBQXdCLElBQUk7R0FDckQsU0FBUyxZQUFZO0dBQ3JCLE1BQU0sU0FBUztFQUNqQjtFQUNBLElBQUksaUJBQWlCO0dBQ25CLE1BQU0saUJBQWlCLGdCQUFnQixFQUNyQyxLQUFLLFVBQ1AsQ0FBQztHQUNELEtBQUssTUFBTSxnQkFBZ0IsZ0JBQWdCO0lBQ3pDLE1BQU0sYUFBYTtHQUNyQjtFQUNGO0NBQ0Y7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBa0JBLE1BQU0sc0JBQXNCLE1BQU07Ozs7Ozs7Ozs7Ozs7Ozs7O0VBaUJoQyxZQUFZLG9CQUFvQixTQUFTO0dBQ3ZDLE1BQU0sU0FBUyxFQUNiLGNBQ0k7SUFDSixNQUFNLGtCQUFrQixtQkFBbUIsbUJBQW1CO0lBQzlELEtBQUssTUFBTSxlQUFlLHNCQUFzQixRQUFRLEtBQUssT0FBTyxHQUFHO0tBQ3JFLE1BQU0sV0FBVyxnQkFBZ0IsSUFBSSxXQUFXO0tBQ2hELElBQUksVUFBVTtNQUNaLE1BQU0sWUFBWSxtQkFBbUIsd0JBQXdCLFFBQVE7TUFDckUsT0FBTztPQUNMO09BQ0E7TUFDRjtLQUNGO0lBQ0Y7SUFDQTtLQUNFLE9BQU8sTUFBTSx5Q0FBeUMsZUFBZSxRQUFRLEdBQUcsQ0FBQztJQUNuRjtJQUNBO0dBQ0Y7R0FDQSxNQUFNLE9BQU8sbUJBQW1CLFFBQVE7RUFDMUM7Q0FDRjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztDQXVCQSxTQUFTLFNBQVMsU0FBUztFQUN6QixNQUFNLHFCQUFxQiw4QkFBOEI7RUFDekQsTUFBTSxnQkFBZ0IsSUFBSSxjQUFjLG9CQUFvQixPQUFPO0VBQ25FLGNBQWMsYUFBYTtDQUM3Qjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBNEJBLFNBQVMsU0FBUyxTQUFTO0VBQ3pCLE1BQU0scUJBQXFCLDhCQUE4QjtFQUN6RCxtQkFBbUIsU0FBUyxPQUFPO0NBQ3JDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBdUJBLFNBQVMsaUJBQWlCLFNBQVMsU0FBUztFQUMxQyxTQUFTLE9BQU87RUFDaEIsU0FBUyxPQUFPO0NBQ2xCOzs7Ozs7OztDQVNBLE1BQU0sb0JBQW9COzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBbUIxQixNQUFNLHVCQUF1QixPQUFPLHFCQUFxQixrQkFBa0Isc0JBQXNCO0VBQy9GLE1BQU0sYUFBYSxNQUFNLEtBQUssT0FBTyxLQUFLO0VBQzFDLE1BQU0scUJBQXFCLFdBQVcsUUFBTyxjQUFhO0dBQ3hELE9BQU8sVUFBVSxTQUFTLGVBQWUsS0FBSyxVQUFVLFNBQVMsS0FBSyxhQUFhLEtBQUssS0FBSyxjQUFjO0VBQzdHLENBQUM7RUFDRCxNQUFNLFFBQVEsSUFBSSxtQkFBbUIsS0FBSSxjQUFhLEtBQUssT0FBTyxPQUFPLFNBQVMsQ0FBQyxDQUFDO0VBQ3BGLE9BQU87Q0FDVDs7Ozs7Ozs7Ozs7Ozs7Q0FlQSxTQUFTLHdCQUF3Qjs7RUFFL0IsS0FBSyxpQkFBaUIsYUFBWSxVQUFTO0dBQ3pDLE1BQU0sWUFBWSxXQUFXLGdCQUFnQjtHQUM3QyxNQUFNLFVBQVUscUJBQXFCLFNBQVMsQ0FBQyxDQUFDLE1BQUssa0JBQWlCO0lBQ3BFO0tBQ0UsSUFBSSxjQUFjLFNBQVMsR0FBRztNQUM1QixPQUFPLElBQUkseURBQXlELGtCQUFrQixhQUFhO0tBQ3JHO0lBQ0Y7R0FDRixDQUFDLENBQUM7RUFDSixDQUFDO0NBQ0g7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBd0JBLE1BQU0sd0JBQXdCLE1BQU07Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7RUF5QmxDLFlBQVksU0FBUyxFQUNuQixZQUFZLENBQUMsR0FBRyxHQUNoQixXQUFXLENBQUMsTUFDVixDQUFDLEdBQUc7R0FDTjtJQUNFLG1CQUFtQixlQUFlLFdBQVcsUUFBUTtLQUNuRCxZQUFZO0tBQ1osV0FBVztLQUNYLFVBQVU7S0FDVixXQUFXO0lBQ2IsQ0FBQztJQUNELG1CQUFtQixlQUFlLFVBQVUsUUFBUTtLQUNsRCxZQUFZO0tBQ1osV0FBVztLQUNYLFVBQVU7S0FDVixXQUFXO0lBQ2IsQ0FBQztHQUNIO0dBQ0EsT0FBTSxZQUFXLEtBQUssT0FBTyxPQUFPLEdBQUcsT0FBTztHQUM5QyxLQUFLLGFBQWE7R0FDbEIsS0FBSyxZQUFZO0VBQ25COzs7Ozs7Ozs7OztFQVdBLE9BQU8sRUFDTCxLQUNBLFdBQ0M7R0FDRCxJQUFJLFdBQVcsUUFBUSxTQUFTLFlBQVk7SUFDMUMsT0FBTztHQUNUO0dBQ0EsTUFBTSxvQkFBb0IsSUFBSSxXQUFXLElBQUk7R0FDN0MsS0FBSyxNQUFNLFVBQVUsS0FBSyxXQUFXO0lBQ25DLElBQUksT0FBTyxLQUFLLGlCQUFpQixHQUFHO0tBQ2xDO01BQ0UsT0FBTyxJQUFJLHdCQUF3QixrQkFBa0IsWUFBWSw4REFBOEQsR0FBRyxPQUFPLFNBQVMsR0FBRztLQUN2SjtLQUNBLE9BQU87SUFDVDtHQUNGO0dBQ0EsSUFBSSxLQUFLLFdBQVcsTUFBSyxXQUFVLE9BQU8sS0FBSyxpQkFBaUIsQ0FBQyxHQUFHO0lBQ2xFO0tBQ0UsT0FBTyxNQUFNLHdCQUF3QixrQkFBa0IsS0FBSyxnQkFBZ0I7SUFDOUU7SUFDQSxPQUFPO0dBQ1Q7R0FDQTtJQUNFLE9BQU8sSUFBSSx3QkFBd0Isa0JBQWtCLFlBQVksMERBQTBELHNCQUFzQjtHQUNuSjtHQUNBLE9BQU87RUFDVDtDQUNGOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBMEJBLFNBQVMsd0JBQXdCLEtBQUs7RUFDcEMsTUFBTSxxQkFBcUIsOEJBQThCO0VBQ3pELE9BQU8sbUJBQW1CLHdCQUF3QixHQUFHO0NBQ3ZEO0NBRUEsUUFBUSwwQkFBMEI7Q0FDbEMsUUFBUSxtQkFBbUI7Q0FDM0IsUUFBUSxrQkFBa0I7Q0FDMUIsUUFBUSxlQUFlO0NBQ3ZCLFFBQVEsd0JBQXdCO0NBQ2hDLFFBQVEsZUFBZTtDQUN2QixRQUFRLDBCQUEwQjtDQUNsQyxRQUFRLG1CQUFtQjtDQUMzQixRQUFRLGdCQUFnQjtBQUU1QixFQUFFIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIndvcmtib3gtOTcwMTI0ZTYuanMiXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiZGVmaW5lKFsnZXhwb3J0cyddLCAoZnVuY3Rpb24gKGV4cG9ydHMpIHsgJ3VzZSBzdHJpY3QnO1xuXG4gICAgLy8gQHRzLWlnbm9yZVxuICAgIHRyeSB7XG4gICAgICBzZWxmWyd3b3JrYm94OmNvcmU6Ny40LjAnXSAmJiBfKCk7XG4gICAgfSBjYXRjaCAoZSkge31cblxuICAgIC8qXG4gICAgICBDb3B5cmlnaHQgMjAxOSBHb29nbGUgTExDXG4gICAgICBVc2Ugb2YgdGhpcyBzb3VyY2UgY29kZSBpcyBnb3Zlcm5lZCBieSBhbiBNSVQtc3R5bGVcbiAgICAgIGxpY2Vuc2UgdGhhdCBjYW4gYmUgZm91bmQgaW4gdGhlIExJQ0VOU0UgZmlsZSBvciBhdFxuICAgICAgaHR0cHM6Ly9vcGVuc291cmNlLm9yZy9saWNlbnNlcy9NSVQuXG4gICAgKi9cbiAgICBjb25zdCBsb2dnZXIgPSAoKCkgPT4ge1xuICAgICAgLy8gRG9uJ3Qgb3ZlcndyaXRlIHRoaXMgdmFsdWUgaWYgaXQncyBhbHJlYWR5IHNldC5cbiAgICAgIC8vIFNlZSBodHRwczovL2dpdGh1Yi5jb20vR29vZ2xlQ2hyb21lL3dvcmtib3gvcHVsbC8yMjg0I2lzc3VlY29tbWVudC01NjA0NzA5MjNcbiAgICAgIGlmICghKCdfX1dCX0RJU0FCTEVfREVWX0xPR1MnIGluIGdsb2JhbFRoaXMpKSB7XG4gICAgICAgIHNlbGYuX19XQl9ESVNBQkxFX0RFVl9MT0dTID0gZmFsc2U7XG4gICAgICB9XG4gICAgICBsZXQgaW5Hcm91cCA9IGZhbHNlO1xuICAgICAgY29uc3QgbWV0aG9kVG9Db2xvck1hcCA9IHtcbiAgICAgICAgZGVidWc6IGAjN2Y4YzhkYCxcbiAgICAgICAgbG9nOiBgIzJlY2M3MWAsXG4gICAgICAgIHdhcm46IGAjZjM5YzEyYCxcbiAgICAgICAgZXJyb3I6IGAjYzAzOTJiYCxcbiAgICAgICAgZ3JvdXBDb2xsYXBzZWQ6IGAjMzQ5OGRiYCxcbiAgICAgICAgZ3JvdXBFbmQ6IG51bGwgLy8gTm8gY29sb3JlZCBwcmVmaXggb24gZ3JvdXBFbmRcbiAgICAgIH07XG4gICAgICBjb25zdCBwcmludCA9IGZ1bmN0aW9uIChtZXRob2QsIGFyZ3MpIHtcbiAgICAgICAgaWYgKHNlbGYuX19XQl9ESVNBQkxFX0RFVl9MT0dTKSB7XG4gICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIGlmIChtZXRob2QgPT09ICdncm91cENvbGxhcHNlZCcpIHtcbiAgICAgICAgICAvLyBTYWZhcmkgZG9lc24ndCBwcmludCBhbGwgY29uc29sZS5ncm91cENvbGxhcHNlZCgpIGFyZ3VtZW50czpcbiAgICAgICAgICAvLyBodHRwczovL2J1Z3Mud2Via2l0Lm9yZy9zaG93X2J1Zy5jZ2k/aWQ9MTgyNzU0XG4gICAgICAgICAgaWYgKC9eKCg/IWNocm9tZXxhbmRyb2lkKS4pKnNhZmFyaS9pLnRlc3QobmF2aWdhdG9yLnVzZXJBZ2VudCkpIHtcbiAgICAgICAgICAgIGNvbnNvbGVbbWV0aG9kXSguLi5hcmdzKTtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgY29uc3Qgc3R5bGVzID0gW2BiYWNrZ3JvdW5kOiAke21ldGhvZFRvQ29sb3JNYXBbbWV0aG9kXX1gLCBgYm9yZGVyLXJhZGl1czogMC41ZW1gLCBgY29sb3I6IHdoaXRlYCwgYGZvbnQtd2VpZ2h0OiBib2xkYCwgYHBhZGRpbmc6IDJweCAwLjVlbWBdO1xuICAgICAgICAvLyBXaGVuIGluIGEgZ3JvdXAsIHRoZSB3b3JrYm94IHByZWZpeCBpcyBub3QgZGlzcGxheWVkLlxuICAgICAgICBjb25zdCBsb2dQcmVmaXggPSBpbkdyb3VwID8gW10gOiBbJyVjd29ya2JveCcsIHN0eWxlcy5qb2luKCc7JyldO1xuICAgICAgICBjb25zb2xlW21ldGhvZF0oLi4ubG9nUHJlZml4LCAuLi5hcmdzKTtcbiAgICAgICAgaWYgKG1ldGhvZCA9PT0gJ2dyb3VwQ29sbGFwc2VkJykge1xuICAgICAgICAgIGluR3JvdXAgPSB0cnVlO1xuICAgICAgICB9XG4gICAgICAgIGlmIChtZXRob2QgPT09ICdncm91cEVuZCcpIHtcbiAgICAgICAgICBpbkdyb3VwID0gZmFsc2U7XG4gICAgICAgIH1cbiAgICAgIH07XG4gICAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgQHR5cGVzY3JpcHQtZXNsaW50L2Jhbi10eXBlc1xuICAgICAgY29uc3QgYXBpID0ge307XG4gICAgICBjb25zdCBsb2dnZXJNZXRob2RzID0gT2JqZWN0LmtleXMobWV0aG9kVG9Db2xvck1hcCk7XG4gICAgICBmb3IgKGNvbnN0IGtleSBvZiBsb2dnZXJNZXRob2RzKSB7XG4gICAgICAgIGNvbnN0IG1ldGhvZCA9IGtleTtcbiAgICAgICAgYXBpW21ldGhvZF0gPSAoLi4uYXJncykgPT4ge1xuICAgICAgICAgIHByaW50KG1ldGhvZCwgYXJncyk7XG4gICAgICAgIH07XG4gICAgICB9XG4gICAgICByZXR1cm4gYXBpO1xuICAgIH0pKCk7XG5cbiAgICAvKlxuICAgICAgQ29weXJpZ2h0IDIwMTggR29vZ2xlIExMQ1xuXG4gICAgICBVc2Ugb2YgdGhpcyBzb3VyY2UgY29kZSBpcyBnb3Zlcm5lZCBieSBhbiBNSVQtc3R5bGVcbiAgICAgIGxpY2Vuc2UgdGhhdCBjYW4gYmUgZm91bmQgaW4gdGhlIExJQ0VOU0UgZmlsZSBvciBhdFxuICAgICAgaHR0cHM6Ly9vcGVuc291cmNlLm9yZy9saWNlbnNlcy9NSVQuXG4gICAgKi9cbiAgICBjb25zdCBtZXNzYWdlcyQxID0ge1xuICAgICAgJ2ludmFsaWQtdmFsdWUnOiAoe1xuICAgICAgICBwYXJhbU5hbWUsXG4gICAgICAgIHZhbGlkVmFsdWVEZXNjcmlwdGlvbixcbiAgICAgICAgdmFsdWVcbiAgICAgIH0pID0+IHtcbiAgICAgICAgaWYgKCFwYXJhbU5hbWUgfHwgIXZhbGlkVmFsdWVEZXNjcmlwdGlvbikge1xuICAgICAgICAgIHRocm93IG5ldyBFcnJvcihgVW5leHBlY3RlZCBpbnB1dCB0byAnaW52YWxpZC12YWx1ZScgZXJyb3IuYCk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIGBUaGUgJyR7cGFyYW1OYW1lfScgcGFyYW1ldGVyIHdhcyBnaXZlbiBhIHZhbHVlIHdpdGggYW4gYCArIGB1bmV4cGVjdGVkIHZhbHVlLiAke3ZhbGlkVmFsdWVEZXNjcmlwdGlvbn0gUmVjZWl2ZWQgYSB2YWx1ZSBvZiBgICsgYCR7SlNPTi5zdHJpbmdpZnkodmFsdWUpfS5gO1xuICAgICAgfSxcbiAgICAgICdub3QtYW4tYXJyYXknOiAoe1xuICAgICAgICBtb2R1bGVOYW1lLFxuICAgICAgICBjbGFzc05hbWUsXG4gICAgICAgIGZ1bmNOYW1lLFxuICAgICAgICBwYXJhbU5hbWVcbiAgICAgIH0pID0+IHtcbiAgICAgICAgaWYgKCFtb2R1bGVOYW1lIHx8ICFjbGFzc05hbWUgfHwgIWZ1bmNOYW1lIHx8ICFwYXJhbU5hbWUpIHtcbiAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoYFVuZXhwZWN0ZWQgaW5wdXQgdG8gJ25vdC1hbi1hcnJheScgZXJyb3IuYCk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIGBUaGUgcGFyYW1ldGVyICcke3BhcmFtTmFtZX0nIHBhc3NlZCBpbnRvIGAgKyBgJyR7bW9kdWxlTmFtZX0uJHtjbGFzc05hbWV9LiR7ZnVuY05hbWV9KCknIG11c3QgYmUgYW4gYXJyYXkuYDtcbiAgICAgIH0sXG4gICAgICAnaW5jb3JyZWN0LXR5cGUnOiAoe1xuICAgICAgICBleHBlY3RlZFR5cGUsXG4gICAgICAgIHBhcmFtTmFtZSxcbiAgICAgICAgbW9kdWxlTmFtZSxcbiAgICAgICAgY2xhc3NOYW1lLFxuICAgICAgICBmdW5jTmFtZVxuICAgICAgfSkgPT4ge1xuICAgICAgICBpZiAoIWV4cGVjdGVkVHlwZSB8fCAhcGFyYW1OYW1lIHx8ICFtb2R1bGVOYW1lIHx8ICFmdW5jTmFtZSkge1xuICAgICAgICAgIHRocm93IG5ldyBFcnJvcihgVW5leHBlY3RlZCBpbnB1dCB0byAnaW5jb3JyZWN0LXR5cGUnIGVycm9yLmApO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IGNsYXNzTmFtZVN0ciA9IGNsYXNzTmFtZSA/IGAke2NsYXNzTmFtZX0uYCA6ICcnO1xuICAgICAgICByZXR1cm4gYFRoZSBwYXJhbWV0ZXIgJyR7cGFyYW1OYW1lfScgcGFzc2VkIGludG8gYCArIGAnJHttb2R1bGVOYW1lfS4ke2NsYXNzTmFtZVN0cn1gICsgYCR7ZnVuY05hbWV9KCknIG11c3QgYmUgb2YgdHlwZSAke2V4cGVjdGVkVHlwZX0uYDtcbiAgICAgIH0sXG4gICAgICAnaW5jb3JyZWN0LWNsYXNzJzogKHtcbiAgICAgICAgZXhwZWN0ZWRDbGFzc05hbWUsXG4gICAgICAgIHBhcmFtTmFtZSxcbiAgICAgICAgbW9kdWxlTmFtZSxcbiAgICAgICAgY2xhc3NOYW1lLFxuICAgICAgICBmdW5jTmFtZSxcbiAgICAgICAgaXNSZXR1cm5WYWx1ZVByb2JsZW1cbiAgICAgIH0pID0+IHtcbiAgICAgICAgaWYgKCFleHBlY3RlZENsYXNzTmFtZSB8fCAhbW9kdWxlTmFtZSB8fCAhZnVuY05hbWUpIHtcbiAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoYFVuZXhwZWN0ZWQgaW5wdXQgdG8gJ2luY29ycmVjdC1jbGFzcycgZXJyb3IuYCk7XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgY2xhc3NOYW1lU3RyID0gY2xhc3NOYW1lID8gYCR7Y2xhc3NOYW1lfS5gIDogJyc7XG4gICAgICAgIGlmIChpc1JldHVyblZhbHVlUHJvYmxlbSkge1xuICAgICAgICAgIHJldHVybiBgVGhlIHJldHVybiB2YWx1ZSBmcm9tIGAgKyBgJyR7bW9kdWxlTmFtZX0uJHtjbGFzc05hbWVTdHJ9JHtmdW5jTmFtZX0oKScgYCArIGBtdXN0IGJlIGFuIGluc3RhbmNlIG9mIGNsYXNzICR7ZXhwZWN0ZWRDbGFzc05hbWV9LmA7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIGBUaGUgcGFyYW1ldGVyICcke3BhcmFtTmFtZX0nIHBhc3NlZCBpbnRvIGAgKyBgJyR7bW9kdWxlTmFtZX0uJHtjbGFzc05hbWVTdHJ9JHtmdW5jTmFtZX0oKScgYCArIGBtdXN0IGJlIGFuIGluc3RhbmNlIG9mIGNsYXNzICR7ZXhwZWN0ZWRDbGFzc05hbWV9LmA7XG4gICAgICB9LFxuICAgICAgJ21pc3NpbmctYS1tZXRob2QnOiAoe1xuICAgICAgICBleHBlY3RlZE1ldGhvZCxcbiAgICAgICAgcGFyYW1OYW1lLFxuICAgICAgICBtb2R1bGVOYW1lLFxuICAgICAgICBjbGFzc05hbWUsXG4gICAgICAgIGZ1bmNOYW1lXG4gICAgICB9KSA9PiB7XG4gICAgICAgIGlmICghZXhwZWN0ZWRNZXRob2QgfHwgIXBhcmFtTmFtZSB8fCAhbW9kdWxlTmFtZSB8fCAhY2xhc3NOYW1lIHx8ICFmdW5jTmFtZSkge1xuICAgICAgICAgIHRocm93IG5ldyBFcnJvcihgVW5leHBlY3RlZCBpbnB1dCB0byAnbWlzc2luZy1hLW1ldGhvZCcgZXJyb3IuYCk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIGAke21vZHVsZU5hbWV9LiR7Y2xhc3NOYW1lfS4ke2Z1bmNOYW1lfSgpIGV4cGVjdGVkIHRoZSBgICsgYCcke3BhcmFtTmFtZX0nIHBhcmFtZXRlciB0byBleHBvc2UgYSAnJHtleHBlY3RlZE1ldGhvZH0nIG1ldGhvZC5gO1xuICAgICAgfSxcbiAgICAgICdhZGQtdG8tY2FjaGUtbGlzdC11bmV4cGVjdGVkLXR5cGUnOiAoe1xuICAgICAgICBlbnRyeVxuICAgICAgfSkgPT4ge1xuICAgICAgICByZXR1cm4gYEFuIHVuZXhwZWN0ZWQgZW50cnkgd2FzIHBhc3NlZCB0byBgICsgYCd3b3JrYm94LXByZWNhY2hpbmcuUHJlY2FjaGVDb250cm9sbGVyLmFkZFRvQ2FjaGVMaXN0KCknIFRoZSBlbnRyeSBgICsgYCcke0pTT04uc3RyaW5naWZ5KGVudHJ5KX0nIGlzbid0IHN1cHBvcnRlZC4gWW91IG11c3Qgc3VwcGx5IGFuIGFycmF5IG9mIGAgKyBgc3RyaW5ncyB3aXRoIG9uZSBvciBtb3JlIGNoYXJhY3RlcnMsIG9iamVjdHMgd2l0aCBhIHVybCBwcm9wZXJ0eSBvciBgICsgYFJlcXVlc3Qgb2JqZWN0cy5gO1xuICAgICAgfSxcbiAgICAgICdhZGQtdG8tY2FjaGUtbGlzdC1jb25mbGljdGluZy1lbnRyaWVzJzogKHtcbiAgICAgICAgZmlyc3RFbnRyeSxcbiAgICAgICAgc2Vjb25kRW50cnlcbiAgICAgIH0pID0+IHtcbiAgICAgICAgaWYgKCFmaXJzdEVudHJ5IHx8ICFzZWNvbmRFbnRyeSkge1xuICAgICAgICAgIHRocm93IG5ldyBFcnJvcihgVW5leHBlY3RlZCBpbnB1dCB0byBgICsgYCdhZGQtdG8tY2FjaGUtbGlzdC1kdXBsaWNhdGUtZW50cmllcycgZXJyb3IuYCk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIGBUd28gb2YgdGhlIGVudHJpZXMgcGFzc2VkIHRvIGAgKyBgJ3dvcmtib3gtcHJlY2FjaGluZy5QcmVjYWNoZUNvbnRyb2xsZXIuYWRkVG9DYWNoZUxpc3QoKScgaGFkIHRoZSBVUkwgYCArIGAke2ZpcnN0RW50cnl9IGJ1dCBkaWZmZXJlbnQgcmV2aXNpb24gZGV0YWlscy4gV29ya2JveCBpcyBgICsgYHVuYWJsZSB0byBjYWNoZSBhbmQgdmVyc2lvbiB0aGUgYXNzZXQgY29ycmVjdGx5LiBQbGVhc2UgcmVtb3ZlIG9uZSBgICsgYG9mIHRoZSBlbnRyaWVzLmA7XG4gICAgICB9LFxuICAgICAgJ3BsdWdpbi1lcnJvci1yZXF1ZXN0LXdpbGwtZmV0Y2gnOiAoe1xuICAgICAgICB0aHJvd25FcnJvck1lc3NhZ2VcbiAgICAgIH0pID0+IHtcbiAgICAgICAgaWYgKCF0aHJvd25FcnJvck1lc3NhZ2UpIHtcbiAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoYFVuZXhwZWN0ZWQgaW5wdXQgdG8gYCArIGAncGx1Z2luLWVycm9yLXJlcXVlc3Qtd2lsbC1mZXRjaCcsIGVycm9yLmApO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBgQW4gZXJyb3Igd2FzIHRocm93biBieSBhIHBsdWdpbnMgJ3JlcXVlc3RXaWxsRmV0Y2goKScgbWV0aG9kLiBgICsgYFRoZSB0aHJvd24gZXJyb3IgbWVzc2FnZSB3YXM6ICcke3Rocm93bkVycm9yTWVzc2FnZX0nLmA7XG4gICAgICB9LFxuICAgICAgJ2ludmFsaWQtY2FjaGUtbmFtZSc6ICh7XG4gICAgICAgIGNhY2hlTmFtZUlkLFxuICAgICAgICB2YWx1ZVxuICAgICAgfSkgPT4ge1xuICAgICAgICBpZiAoIWNhY2hlTmFtZUlkKSB7XG4gICAgICAgICAgdGhyb3cgbmV3IEVycm9yKGBFeHBlY3RlZCBhICdjYWNoZU5hbWVJZCcgZm9yIGVycm9yICdpbnZhbGlkLWNhY2hlLW5hbWUnYCk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIGBZb3UgbXVzdCBwcm92aWRlIGEgbmFtZSBjb250YWluaW5nIGF0IGxlYXN0IG9uZSBjaGFyYWN0ZXIgZm9yIGAgKyBgc2V0Q2FjaGVEZXRhaWxzKHske2NhY2hlTmFtZUlkfTogJy4uLid9KS4gUmVjZWl2ZWQgYSB2YWx1ZSBvZiBgICsgYCcke0pTT04uc3RyaW5naWZ5KHZhbHVlKX0nYDtcbiAgICAgIH0sXG4gICAgICAndW5yZWdpc3Rlci1yb3V0ZS1idXQtbm90LWZvdW5kLXdpdGgtbWV0aG9kJzogKHtcbiAgICAgICAgbWV0aG9kXG4gICAgICB9KSA9PiB7XG4gICAgICAgIGlmICghbWV0aG9kKSB7XG4gICAgICAgICAgdGhyb3cgbmV3IEVycm9yKGBVbmV4cGVjdGVkIGlucHV0IHRvIGAgKyBgJ3VucmVnaXN0ZXItcm91dGUtYnV0LW5vdC1mb3VuZC13aXRoLW1ldGhvZCcgZXJyb3IuYCk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIGBUaGUgcm91dGUgeW91J3JlIHRyeWluZyB0byB1bnJlZ2lzdGVyIHdhcyBub3QgIHByZXZpb3VzbHkgYCArIGByZWdpc3RlcmVkIGZvciB0aGUgbWV0aG9kIHR5cGUgJyR7bWV0aG9kfScuYDtcbiAgICAgIH0sXG4gICAgICAndW5yZWdpc3Rlci1yb3V0ZS1yb3V0ZS1ub3QtcmVnaXN0ZXJlZCc6ICgpID0+IHtcbiAgICAgICAgcmV0dXJuIGBUaGUgcm91dGUgeW91J3JlIHRyeWluZyB0byB1bnJlZ2lzdGVyIHdhcyBub3QgcHJldmlvdXNseSBgICsgYHJlZ2lzdGVyZWQuYDtcbiAgICAgIH0sXG4gICAgICAncXVldWUtcmVwbGF5LWZhaWxlZCc6ICh7XG4gICAgICAgIG5hbWVcbiAgICAgIH0pID0+IHtcbiAgICAgICAgcmV0dXJuIGBSZXBsYXlpbmcgdGhlIGJhY2tncm91bmQgc3luYyBxdWV1ZSAnJHtuYW1lfScgZmFpbGVkLmA7XG4gICAgICB9LFxuICAgICAgJ2R1cGxpY2F0ZS1xdWV1ZS1uYW1lJzogKHtcbiAgICAgICAgbmFtZVxuICAgICAgfSkgPT4ge1xuICAgICAgICByZXR1cm4gYFRoZSBRdWV1ZSBuYW1lICcke25hbWV9JyBpcyBhbHJlYWR5IGJlaW5nIHVzZWQuIGAgKyBgQWxsIGluc3RhbmNlcyBvZiBiYWNrZ3JvdW5kU3luYy5RdWV1ZSBtdXN0IGJlIGdpdmVuIHVuaXF1ZSBuYW1lcy5gO1xuICAgICAgfSxcbiAgICAgICdleHBpcmVkLXRlc3Qtd2l0aG91dC1tYXgtYWdlJzogKHtcbiAgICAgICAgbWV0aG9kTmFtZSxcbiAgICAgICAgcGFyYW1OYW1lXG4gICAgICB9KSA9PiB7XG4gICAgICAgIHJldHVybiBgVGhlICcke21ldGhvZE5hbWV9KCknIG1ldGhvZCBjYW4gb25seSBiZSB1c2VkIHdoZW4gdGhlIGAgKyBgJyR7cGFyYW1OYW1lfScgaXMgdXNlZCBpbiB0aGUgY29uc3RydWN0b3IuYDtcbiAgICAgIH0sXG4gICAgICAndW5zdXBwb3J0ZWQtcm91dGUtdHlwZSc6ICh7XG4gICAgICAgIG1vZHVsZU5hbWUsXG4gICAgICAgIGNsYXNzTmFtZSxcbiAgICAgICAgZnVuY05hbWUsXG4gICAgICAgIHBhcmFtTmFtZVxuICAgICAgfSkgPT4ge1xuICAgICAgICByZXR1cm4gYFRoZSBzdXBwbGllZCAnJHtwYXJhbU5hbWV9JyBwYXJhbWV0ZXIgd2FzIGFuIHVuc3VwcG9ydGVkIHR5cGUuIGAgKyBgUGxlYXNlIGNoZWNrIHRoZSBkb2NzIGZvciAke21vZHVsZU5hbWV9LiR7Y2xhc3NOYW1lfS4ke2Z1bmNOYW1lfSBmb3IgYCArIGB2YWxpZCBpbnB1dCB0eXBlcy5gO1xuICAgICAgfSxcbiAgICAgICdub3QtYXJyYXktb2YtY2xhc3MnOiAoe1xuICAgICAgICB2YWx1ZSxcbiAgICAgICAgZXhwZWN0ZWRDbGFzcyxcbiAgICAgICAgbW9kdWxlTmFtZSxcbiAgICAgICAgY2xhc3NOYW1lLFxuICAgICAgICBmdW5jTmFtZSxcbiAgICAgICAgcGFyYW1OYW1lXG4gICAgICB9KSA9PiB7XG4gICAgICAgIHJldHVybiBgVGhlIHN1cHBsaWVkICcke3BhcmFtTmFtZX0nIHBhcmFtZXRlciBtdXN0IGJlIGFuIGFycmF5IG9mIGAgKyBgJyR7ZXhwZWN0ZWRDbGFzc30nIG9iamVjdHMuIFJlY2VpdmVkICcke0pTT04uc3RyaW5naWZ5KHZhbHVlKX0sJy4gYCArIGBQbGVhc2UgY2hlY2sgdGhlIGNhbGwgdG8gJHttb2R1bGVOYW1lfS4ke2NsYXNzTmFtZX0uJHtmdW5jTmFtZX0oKSBgICsgYHRvIGZpeCB0aGUgaXNzdWUuYDtcbiAgICAgIH0sXG4gICAgICAnbWF4LWVudHJpZXMtb3ItYWdlLXJlcXVpcmVkJzogKHtcbiAgICAgICAgbW9kdWxlTmFtZSxcbiAgICAgICAgY2xhc3NOYW1lLFxuICAgICAgICBmdW5jTmFtZVxuICAgICAgfSkgPT4ge1xuICAgICAgICByZXR1cm4gYFlvdSBtdXN0IGRlZmluZSBlaXRoZXIgY29uZmlnLm1heEVudHJpZXMgb3IgY29uZmlnLm1heEFnZVNlY29uZHNgICsgYGluICR7bW9kdWxlTmFtZX0uJHtjbGFzc05hbWV9LiR7ZnVuY05hbWV9YDtcbiAgICAgIH0sXG4gICAgICAnc3RhdHVzZXMtb3ItaGVhZGVycy1yZXF1aXJlZCc6ICh7XG4gICAgICAgIG1vZHVsZU5hbWUsXG4gICAgICAgIGNsYXNzTmFtZSxcbiAgICAgICAgZnVuY05hbWVcbiAgICAgIH0pID0+IHtcbiAgICAgICAgcmV0dXJuIGBZb3UgbXVzdCBkZWZpbmUgZWl0aGVyIGNvbmZpZy5zdGF0dXNlcyBvciBjb25maWcuaGVhZGVyc2AgKyBgaW4gJHttb2R1bGVOYW1lfS4ke2NsYXNzTmFtZX0uJHtmdW5jTmFtZX1gO1xuICAgICAgfSxcbiAgICAgICdpbnZhbGlkLXN0cmluZyc6ICh7XG4gICAgICAgIG1vZHVsZU5hbWUsXG4gICAgICAgIGZ1bmNOYW1lLFxuICAgICAgICBwYXJhbU5hbWVcbiAgICAgIH0pID0+IHtcbiAgICAgICAgaWYgKCFwYXJhbU5hbWUgfHwgIW1vZHVsZU5hbWUgfHwgIWZ1bmNOYW1lKSB7XG4gICAgICAgICAgdGhyb3cgbmV3IEVycm9yKGBVbmV4cGVjdGVkIGlucHV0IHRvICdpbnZhbGlkLXN0cmluZycgZXJyb3IuYCk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIGBXaGVuIHVzaW5nIHN0cmluZ3MsIHRoZSAnJHtwYXJhbU5hbWV9JyBwYXJhbWV0ZXIgbXVzdCBzdGFydCB3aXRoIGAgKyBgJ2h0dHAnIChmb3IgY3Jvc3Mtb3JpZ2luIG1hdGNoZXMpIG9yICcvJyAoZm9yIHNhbWUtb3JpZ2luIG1hdGNoZXMpLiBgICsgYFBsZWFzZSBzZWUgdGhlIGRvY3MgZm9yICR7bW9kdWxlTmFtZX0uJHtmdW5jTmFtZX0oKSBmb3IgYCArIGBtb3JlIGluZm8uYDtcbiAgICAgIH0sXG4gICAgICAnY2hhbm5lbC1uYW1lLXJlcXVpcmVkJzogKCkgPT4ge1xuICAgICAgICByZXR1cm4gYFlvdSBtdXN0IHByb3ZpZGUgYSBjaGFubmVsTmFtZSB0byBjb25zdHJ1Y3QgYSBgICsgYEJyb2FkY2FzdENhY2hlVXBkYXRlIGluc3RhbmNlLmA7XG4gICAgICB9LFxuICAgICAgJ2ludmFsaWQtcmVzcG9uc2VzLWFyZS1zYW1lLWFyZ3MnOiAoKSA9PiB7XG4gICAgICAgIHJldHVybiBgVGhlIGFyZ3VtZW50cyBwYXNzZWQgaW50byByZXNwb25zZXNBcmVTYW1lKCkgYXBwZWFyIHRvIGJlIGAgKyBgaW52YWxpZC4gUGxlYXNlIGVuc3VyZSB2YWxpZCBSZXNwb25zZXMgYXJlIHVzZWQuYDtcbiAgICAgIH0sXG4gICAgICAnZXhwaXJlLWN1c3RvbS1jYWNoZXMtb25seSc6ICgpID0+IHtcbiAgICAgICAgcmV0dXJuIGBZb3UgbXVzdCBwcm92aWRlIGEgJ2NhY2hlTmFtZScgcHJvcGVydHkgd2hlbiB1c2luZyB0aGUgYCArIGBleHBpcmF0aW9uIHBsdWdpbiB3aXRoIGEgcnVudGltZSBjYWNoaW5nIHN0cmF0ZWd5LmA7XG4gICAgICB9LFxuICAgICAgJ3VuaXQtbXVzdC1iZS1ieXRlcyc6ICh7XG4gICAgICAgIG5vcm1hbGl6ZWRSYW5nZUhlYWRlclxuICAgICAgfSkgPT4ge1xuICAgICAgICBpZiAoIW5vcm1hbGl6ZWRSYW5nZUhlYWRlcikge1xuICAgICAgICAgIHRocm93IG5ldyBFcnJvcihgVW5leHBlY3RlZCBpbnB1dCB0byAndW5pdC1tdXN0LWJlLWJ5dGVzJyBlcnJvci5gKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gYFRoZSAndW5pdCcgcG9ydGlvbiBvZiB0aGUgUmFuZ2UgaGVhZGVyIG11c3QgYmUgc2V0IHRvICdieXRlcycuIGAgKyBgVGhlIFJhbmdlIGhlYWRlciBwcm92aWRlZCB3YXMgXCIke25vcm1hbGl6ZWRSYW5nZUhlYWRlcn1cImA7XG4gICAgICB9LFxuICAgICAgJ3NpbmdsZS1yYW5nZS1vbmx5JzogKHtcbiAgICAgICAgbm9ybWFsaXplZFJhbmdlSGVhZGVyXG4gICAgICB9KSA9PiB7XG4gICAgICAgIGlmICghbm9ybWFsaXplZFJhbmdlSGVhZGVyKSB7XG4gICAgICAgICAgdGhyb3cgbmV3IEVycm9yKGBVbmV4cGVjdGVkIGlucHV0IHRvICdzaW5nbGUtcmFuZ2Utb25seScgZXJyb3IuYCk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIGBNdWx0aXBsZSByYW5nZXMgYXJlIG5vdCBzdXBwb3J0ZWQuIFBsZWFzZSB1c2UgYSAgc2luZ2xlIHN0YXJ0IGAgKyBgdmFsdWUsIGFuZCBvcHRpb25hbCBlbmQgdmFsdWUuIFRoZSBSYW5nZSBoZWFkZXIgcHJvdmlkZWQgd2FzIGAgKyBgXCIke25vcm1hbGl6ZWRSYW5nZUhlYWRlcn1cImA7XG4gICAgICB9LFxuICAgICAgJ2ludmFsaWQtcmFuZ2UtdmFsdWVzJzogKHtcbiAgICAgICAgbm9ybWFsaXplZFJhbmdlSGVhZGVyXG4gICAgICB9KSA9PiB7XG4gICAgICAgIGlmICghbm9ybWFsaXplZFJhbmdlSGVhZGVyKSB7XG4gICAgICAgICAgdGhyb3cgbmV3IEVycm9yKGBVbmV4cGVjdGVkIGlucHV0IHRvICdpbnZhbGlkLXJhbmdlLXZhbHVlcycgZXJyb3IuYCk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIGBUaGUgUmFuZ2UgaGVhZGVyIGlzIG1pc3NpbmcgYm90aCBzdGFydCBhbmQgZW5kIHZhbHVlcy4gQXQgbGVhc3QgYCArIGBvbmUgb2YgdGhvc2UgdmFsdWVzIGlzIG5lZWRlZC4gVGhlIFJhbmdlIGhlYWRlciBwcm92aWRlZCB3YXMgYCArIGBcIiR7bm9ybWFsaXplZFJhbmdlSGVhZGVyfVwiYDtcbiAgICAgIH0sXG4gICAgICAnbm8tcmFuZ2UtaGVhZGVyJzogKCkgPT4ge1xuICAgICAgICByZXR1cm4gYE5vIFJhbmdlIGhlYWRlciB3YXMgZm91bmQgaW4gdGhlIFJlcXVlc3QgcHJvdmlkZWQuYDtcbiAgICAgIH0sXG4gICAgICAncmFuZ2Utbm90LXNhdGlzZmlhYmxlJzogKHtcbiAgICAgICAgc2l6ZSxcbiAgICAgICAgc3RhcnQsXG4gICAgICAgIGVuZFxuICAgICAgfSkgPT4ge1xuICAgICAgICByZXR1cm4gYFRoZSBzdGFydCAoJHtzdGFydH0pIGFuZCBlbmQgKCR7ZW5kfSkgdmFsdWVzIGluIHRoZSBSYW5nZSBhcmUgYCArIGBub3Qgc2F0aXNmaWFibGUgYnkgdGhlIGNhY2hlZCByZXNwb25zZSwgd2hpY2ggaXMgJHtzaXplfSBieXRlcy5gO1xuICAgICAgfSxcbiAgICAgICdhdHRlbXB0LXRvLWNhY2hlLW5vbi1nZXQtcmVxdWVzdCc6ICh7XG4gICAgICAgIHVybCxcbiAgICAgICAgbWV0aG9kXG4gICAgICB9KSA9PiB7XG4gICAgICAgIHJldHVybiBgVW5hYmxlIHRvIGNhY2hlICcke3VybH0nIGJlY2F1c2UgaXQgaXMgYSAnJHttZXRob2R9JyByZXF1ZXN0IGFuZCBgICsgYG9ubHkgJ0dFVCcgcmVxdWVzdHMgY2FuIGJlIGNhY2hlZC5gO1xuICAgICAgfSxcbiAgICAgICdjYWNoZS1wdXQtd2l0aC1uby1yZXNwb25zZSc6ICh7XG4gICAgICAgIHVybFxuICAgICAgfSkgPT4ge1xuICAgICAgICByZXR1cm4gYFRoZXJlIHdhcyBhbiBhdHRlbXB0IHRvIGNhY2hlICcke3VybH0nIGJ1dCB0aGUgcmVzcG9uc2Ugd2FzIG5vdCBgICsgYGRlZmluZWQuYDtcbiAgICAgIH0sXG4gICAgICAnbm8tcmVzcG9uc2UnOiAoe1xuICAgICAgICB1cmwsXG4gICAgICAgIGVycm9yXG4gICAgICB9KSA9PiB7XG4gICAgICAgIGxldCBtZXNzYWdlID0gYFRoZSBzdHJhdGVneSBjb3VsZCBub3QgZ2VuZXJhdGUgYSByZXNwb25zZSBmb3IgJyR7dXJsfScuYDtcbiAgICAgICAgaWYgKGVycm9yKSB7XG4gICAgICAgICAgbWVzc2FnZSArPSBgIFRoZSB1bmRlcmx5aW5nIGVycm9yIGlzICR7ZXJyb3J9LmA7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIG1lc3NhZ2U7XG4gICAgICB9LFxuICAgICAgJ2JhZC1wcmVjYWNoaW5nLXJlc3BvbnNlJzogKHtcbiAgICAgICAgdXJsLFxuICAgICAgICBzdGF0dXNcbiAgICAgIH0pID0+IHtcbiAgICAgICAgcmV0dXJuIGBUaGUgcHJlY2FjaGluZyByZXF1ZXN0IGZvciAnJHt1cmx9JyBmYWlsZWRgICsgKHN0YXR1cyA/IGAgd2l0aCBhbiBIVFRQIHN0YXR1cyBvZiAke3N0YXR1c30uYCA6IGAuYCk7XG4gICAgICB9LFxuICAgICAgJ25vbi1wcmVjYWNoZWQtdXJsJzogKHtcbiAgICAgICAgdXJsXG4gICAgICB9KSA9PiB7XG4gICAgICAgIHJldHVybiBgY3JlYXRlSGFuZGxlckJvdW5kVG9VUkwoJyR7dXJsfScpIHdhcyBjYWxsZWQsIGJ1dCB0aGF0IFVSTCBpcyBgICsgYG5vdCBwcmVjYWNoZWQuIFBsZWFzZSBwYXNzIGluIGEgVVJMIHRoYXQgaXMgcHJlY2FjaGVkIGluc3RlYWQuYDtcbiAgICAgIH0sXG4gICAgICAnYWRkLXRvLWNhY2hlLWxpc3QtY29uZmxpY3RpbmctaW50ZWdyaXRpZXMnOiAoe1xuICAgICAgICB1cmxcbiAgICAgIH0pID0+IHtcbiAgICAgICAgcmV0dXJuIGBUd28gb2YgdGhlIGVudHJpZXMgcGFzc2VkIHRvIGAgKyBgJ3dvcmtib3gtcHJlY2FjaGluZy5QcmVjYWNoZUNvbnRyb2xsZXIuYWRkVG9DYWNoZUxpc3QoKScgaGFkIHRoZSBVUkwgYCArIGAke3VybH0gd2l0aCBkaWZmZXJlbnQgaW50ZWdyaXR5IHZhbHVlcy4gUGxlYXNlIHJlbW92ZSBvbmUgb2YgdGhlbS5gO1xuICAgICAgfSxcbiAgICAgICdtaXNzaW5nLXByZWNhY2hlLWVudHJ5JzogKHtcbiAgICAgICAgY2FjaGVOYW1lLFxuICAgICAgICB1cmxcbiAgICAgIH0pID0+IHtcbiAgICAgICAgcmV0dXJuIGBVbmFibGUgdG8gZmluZCBhIHByZWNhY2hlZCByZXNwb25zZSBpbiAke2NhY2hlTmFtZX0gZm9yICR7dXJsfS5gO1xuICAgICAgfSxcbiAgICAgICdjcm9zcy1vcmlnaW4tY29weS1yZXNwb25zZSc6ICh7XG4gICAgICAgIG9yaWdpblxuICAgICAgfSkgPT4ge1xuICAgICAgICByZXR1cm4gYHdvcmtib3gtY29yZS5jb3B5UmVzcG9uc2UoKSBjYW4gb25seSBiZSB1c2VkIHdpdGggc2FtZS1vcmlnaW4gYCArIGByZXNwb25zZXMuIEl0IHdhcyBwYXNzZWQgYSByZXNwb25zZSB3aXRoIG9yaWdpbiAke29yaWdpbn0uYDtcbiAgICAgIH0sXG4gICAgICAnb3BhcXVlLXN0cmVhbXMtc291cmNlJzogKHtcbiAgICAgICAgdHlwZVxuICAgICAgfSkgPT4ge1xuICAgICAgICBjb25zdCBtZXNzYWdlID0gYE9uZSBvZiB0aGUgd29ya2JveC1zdHJlYW1zIHNvdXJjZXMgcmVzdWx0ZWQgaW4gYW4gYCArIGAnJHt0eXBlfScgcmVzcG9uc2UuYDtcbiAgICAgICAgaWYgKHR5cGUgPT09ICdvcGFxdWVyZWRpcmVjdCcpIHtcbiAgICAgICAgICByZXR1cm4gYCR7bWVzc2FnZX0gUGxlYXNlIGRvIG5vdCB1c2UgYSBuYXZpZ2F0aW9uIHJlcXVlc3QgdGhhdCByZXN1bHRzIGAgKyBgaW4gYSByZWRpcmVjdCBhcyBhIHNvdXJjZS5gO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBgJHttZXNzYWdlfSBQbGVhc2UgZW5zdXJlIHlvdXIgc291cmNlcyBhcmUgQ09SUy1lbmFibGVkLmA7XG4gICAgICB9XG4gICAgfTtcblxuICAgIC8qXG4gICAgICBDb3B5cmlnaHQgMjAxOCBHb29nbGUgTExDXG5cbiAgICAgIFVzZSBvZiB0aGlzIHNvdXJjZSBjb2RlIGlzIGdvdmVybmVkIGJ5IGFuIE1JVC1zdHlsZVxuICAgICAgbGljZW5zZSB0aGF0IGNhbiBiZSBmb3VuZCBpbiB0aGUgTElDRU5TRSBmaWxlIG9yIGF0XG4gICAgICBodHRwczovL29wZW5zb3VyY2Uub3JnL2xpY2Vuc2VzL01JVC5cbiAgICAqL1xuICAgIGNvbnN0IGdlbmVyYXRvckZ1bmN0aW9uID0gKGNvZGUsIGRldGFpbHMgPSB7fSkgPT4ge1xuICAgICAgY29uc3QgbWVzc2FnZSA9IG1lc3NhZ2VzJDFbY29kZV07XG4gICAgICBpZiAoIW1lc3NhZ2UpIHtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKGBVbmFibGUgdG8gZmluZCBtZXNzYWdlIGZvciBjb2RlICcke2NvZGV9Jy5gKTtcbiAgICAgIH1cbiAgICAgIHJldHVybiBtZXNzYWdlKGRldGFpbHMpO1xuICAgIH07XG4gICAgY29uc3QgbWVzc2FnZUdlbmVyYXRvciA9IGdlbmVyYXRvckZ1bmN0aW9uO1xuXG4gICAgLypcbiAgICAgIENvcHlyaWdodCAyMDE4IEdvb2dsZSBMTENcblxuICAgICAgVXNlIG9mIHRoaXMgc291cmNlIGNvZGUgaXMgZ292ZXJuZWQgYnkgYW4gTUlULXN0eWxlXG4gICAgICBsaWNlbnNlIHRoYXQgY2FuIGJlIGZvdW5kIGluIHRoZSBMSUNFTlNFIGZpbGUgb3IgYXRcbiAgICAgIGh0dHBzOi8vb3BlbnNvdXJjZS5vcmcvbGljZW5zZXMvTUlULlxuICAgICovXG4gICAgLyoqXG4gICAgICogV29ya2JveCBlcnJvcnMgc2hvdWxkIGJlIHRocm93biB3aXRoIHRoaXMgY2xhc3MuXG4gICAgICogVGhpcyBhbGxvd3MgdXNlIHRvIGVuc3VyZSB0aGUgdHlwZSBlYXNpbHkgaW4gdGVzdHMsXG4gICAgICogaGVscHMgZGV2ZWxvcGVycyBpZGVudGlmeSBlcnJvcnMgZnJvbSB3b3JrYm94XG4gICAgICogZWFzaWx5IGFuZCBhbGxvd3MgdXNlIHRvIG9wdGltaXNlIGVycm9yXG4gICAgICogbWVzc2FnZXMgY29ycmVjdGx5LlxuICAgICAqXG4gICAgICogQHByaXZhdGVcbiAgICAgKi9cbiAgICBjbGFzcyBXb3JrYm94RXJyb3IgZXh0ZW5kcyBFcnJvciB7XG4gICAgICAvKipcbiAgICAgICAqXG4gICAgICAgKiBAcGFyYW0ge3N0cmluZ30gZXJyb3JDb2RlIFRoZSBlcnJvciBjb2RlIHRoYXRcbiAgICAgICAqIGlkZW50aWZpZXMgdGhpcyBwYXJ0aWN1bGFyIGVycm9yLlxuICAgICAgICogQHBhcmFtIHtPYmplY3Q9fSBkZXRhaWxzIEFueSByZWxldmFudCBhcmd1bWVudHNcbiAgICAgICAqIHRoYXQgd2lsbCBoZWxwIGRldmVsb3BlcnMgaWRlbnRpZnkgaXNzdWVzIHNob3VsZFxuICAgICAgICogYmUgYWRkZWQgYXMgYSBrZXkgb24gdGhlIGNvbnRleHQgb2JqZWN0LlxuICAgICAgICovXG4gICAgICBjb25zdHJ1Y3RvcihlcnJvckNvZGUsIGRldGFpbHMpIHtcbiAgICAgICAgY29uc3QgbWVzc2FnZSA9IG1lc3NhZ2VHZW5lcmF0b3IoZXJyb3JDb2RlLCBkZXRhaWxzKTtcbiAgICAgICAgc3VwZXIobWVzc2FnZSk7XG4gICAgICAgIHRoaXMubmFtZSA9IGVycm9yQ29kZTtcbiAgICAgICAgdGhpcy5kZXRhaWxzID0gZGV0YWlscztcbiAgICAgIH1cbiAgICB9XG5cbiAgICAvKlxuICAgICAgQ29weXJpZ2h0IDIwMTggR29vZ2xlIExMQ1xuXG4gICAgICBVc2Ugb2YgdGhpcyBzb3VyY2UgY29kZSBpcyBnb3Zlcm5lZCBieSBhbiBNSVQtc3R5bGVcbiAgICAgIGxpY2Vuc2UgdGhhdCBjYW4gYmUgZm91bmQgaW4gdGhlIExJQ0VOU0UgZmlsZSBvciBhdFxuICAgICAgaHR0cHM6Ly9vcGVuc291cmNlLm9yZy9saWNlbnNlcy9NSVQuXG4gICAgKi9cbiAgICAvKlxuICAgICAqIFRoaXMgbWV0aG9kIHRocm93cyBpZiB0aGUgc3VwcGxpZWQgdmFsdWUgaXMgbm90IGFuIGFycmF5LlxuICAgICAqIFRoZSBkZXN0cnVjdGVkIHZhbHVlcyBhcmUgcmVxdWlyZWQgdG8gcHJvZHVjZSBhIG1lYW5pbmdmdWwgZXJyb3IgZm9yIHVzZXJzLlxuICAgICAqIFRoZSBkZXN0cnVjdGVkIGFuZCByZXN0cnVjdHVyZWQgb2JqZWN0IGlzIHNvIGl0J3MgY2xlYXIgd2hhdCBpc1xuICAgICAqIG5lZWRlZC5cbiAgICAgKi9cbiAgICBjb25zdCBpc0FycmF5ID0gKHZhbHVlLCBkZXRhaWxzKSA9PiB7XG4gICAgICBpZiAoIUFycmF5LmlzQXJyYXkodmFsdWUpKSB7XG4gICAgICAgIHRocm93IG5ldyBXb3JrYm94RXJyb3IoJ25vdC1hbi1hcnJheScsIGRldGFpbHMpO1xuICAgICAgfVxuICAgIH07XG4gICAgY29uc3QgaGFzTWV0aG9kID0gKG9iamVjdCwgZXhwZWN0ZWRNZXRob2QsIGRldGFpbHMpID0+IHtcbiAgICAgIGNvbnN0IHR5cGUgPSB0eXBlb2Ygb2JqZWN0W2V4cGVjdGVkTWV0aG9kXTtcbiAgICAgIGlmICh0eXBlICE9PSAnZnVuY3Rpb24nKSB7XG4gICAgICAgIGRldGFpbHNbJ2V4cGVjdGVkTWV0aG9kJ10gPSBleHBlY3RlZE1ldGhvZDtcbiAgICAgICAgdGhyb3cgbmV3IFdvcmtib3hFcnJvcignbWlzc2luZy1hLW1ldGhvZCcsIGRldGFpbHMpO1xuICAgICAgfVxuICAgIH07XG4gICAgY29uc3QgaXNUeXBlID0gKG9iamVjdCwgZXhwZWN0ZWRUeXBlLCBkZXRhaWxzKSA9PiB7XG4gICAgICBpZiAodHlwZW9mIG9iamVjdCAhPT0gZXhwZWN0ZWRUeXBlKSB7XG4gICAgICAgIGRldGFpbHNbJ2V4cGVjdGVkVHlwZSddID0gZXhwZWN0ZWRUeXBlO1xuICAgICAgICB0aHJvdyBuZXcgV29ya2JveEVycm9yKCdpbmNvcnJlY3QtdHlwZScsIGRldGFpbHMpO1xuICAgICAgfVxuICAgIH07XG4gICAgY29uc3QgaXNJbnN0YW5jZSA9IChvYmplY3QsXG4gICAgLy8gTmVlZCB0aGUgZ2VuZXJhbCB0eXBlIHRvIGRvIHRoZSBjaGVjayBsYXRlci5cbiAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgQHR5cGVzY3JpcHQtZXNsaW50L2Jhbi10eXBlc1xuICAgIGV4cGVjdGVkQ2xhc3MsIGRldGFpbHMpID0+IHtcbiAgICAgIGlmICghKG9iamVjdCBpbnN0YW5jZW9mIGV4cGVjdGVkQ2xhc3MpKSB7XG4gICAgICAgIGRldGFpbHNbJ2V4cGVjdGVkQ2xhc3NOYW1lJ10gPSBleHBlY3RlZENsYXNzLm5hbWU7XG4gICAgICAgIHRocm93IG5ldyBXb3JrYm94RXJyb3IoJ2luY29ycmVjdC1jbGFzcycsIGRldGFpbHMpO1xuICAgICAgfVxuICAgIH07XG4gICAgY29uc3QgaXNPbmVPZiA9ICh2YWx1ZSwgdmFsaWRWYWx1ZXMsIGRldGFpbHMpID0+IHtcbiAgICAgIGlmICghdmFsaWRWYWx1ZXMuaW5jbHVkZXModmFsdWUpKSB7XG4gICAgICAgIGRldGFpbHNbJ3ZhbGlkVmFsdWVEZXNjcmlwdGlvbiddID0gYFZhbGlkIHZhbHVlcyBhcmUgJHtKU09OLnN0cmluZ2lmeSh2YWxpZFZhbHVlcyl9LmA7XG4gICAgICAgIHRocm93IG5ldyBXb3JrYm94RXJyb3IoJ2ludmFsaWQtdmFsdWUnLCBkZXRhaWxzKTtcbiAgICAgIH1cbiAgICB9O1xuICAgIGNvbnN0IGlzQXJyYXlPZkNsYXNzID0gKHZhbHVlLFxuICAgIC8vIE5lZWQgZ2VuZXJhbCB0eXBlIHRvIGRvIGNoZWNrIGxhdGVyLlxuICAgIGV4cGVjdGVkQ2xhc3MsXG4gICAgLy8gZXNsaW50LWRpc2FibGUtbGluZVxuICAgIGRldGFpbHMpID0+IHtcbiAgICAgIGNvbnN0IGVycm9yID0gbmV3IFdvcmtib3hFcnJvcignbm90LWFycmF5LW9mLWNsYXNzJywgZGV0YWlscyk7XG4gICAgICBpZiAoIUFycmF5LmlzQXJyYXkodmFsdWUpKSB7XG4gICAgICAgIHRocm93IGVycm9yO1xuICAgICAgfVxuICAgICAgZm9yIChjb25zdCBpdGVtIG9mIHZhbHVlKSB7XG4gICAgICAgIGlmICghKGl0ZW0gaW5zdGFuY2VvZiBleHBlY3RlZENsYXNzKSkge1xuICAgICAgICAgIHRocm93IGVycm9yO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfTtcbiAgICBjb25zdCBmaW5hbEFzc2VydEV4cG9ydHMgPSB7XG4gICAgICBoYXNNZXRob2QsXG4gICAgICBpc0FycmF5LFxuICAgICAgaXNJbnN0YW5jZSxcbiAgICAgIGlzT25lT2YsXG4gICAgICBpc1R5cGUsXG4gICAgICBpc0FycmF5T2ZDbGFzc1xuICAgIH07XG5cbiAgICAvLyBAdHMtaWdub3JlXG4gICAgdHJ5IHtcbiAgICAgIHNlbGZbJ3dvcmtib3g6cm91dGluZzo3LjQuMCddICYmIF8oKTtcbiAgICB9IGNhdGNoIChlKSB7fVxuXG4gICAgLypcbiAgICAgIENvcHlyaWdodCAyMDE4IEdvb2dsZSBMTENcblxuICAgICAgVXNlIG9mIHRoaXMgc291cmNlIGNvZGUgaXMgZ292ZXJuZWQgYnkgYW4gTUlULXN0eWxlXG4gICAgICBsaWNlbnNlIHRoYXQgY2FuIGJlIGZvdW5kIGluIHRoZSBMSUNFTlNFIGZpbGUgb3IgYXRcbiAgICAgIGh0dHBzOi8vb3BlbnNvdXJjZS5vcmcvbGljZW5zZXMvTUlULlxuICAgICovXG4gICAgLyoqXG4gICAgICogVGhlIGRlZmF1bHQgSFRUUCBtZXRob2QsICdHRVQnLCB1c2VkIHdoZW4gdGhlcmUncyBubyBzcGVjaWZpYyBtZXRob2RcbiAgICAgKiBjb25maWd1cmVkIGZvciBhIHJvdXRlLlxuICAgICAqXG4gICAgICogQHR5cGUge3N0cmluZ31cbiAgICAgKlxuICAgICAqIEBwcml2YXRlXG4gICAgICovXG4gICAgY29uc3QgZGVmYXVsdE1ldGhvZCA9ICdHRVQnO1xuICAgIC8qKlxuICAgICAqIFRoZSBsaXN0IG9mIHZhbGlkIEhUVFAgbWV0aG9kcyBhc3NvY2lhdGVkIHdpdGggcmVxdWVzdHMgdGhhdCBjb3VsZCBiZSByb3V0ZWQuXG4gICAgICpcbiAgICAgKiBAdHlwZSB7QXJyYXk8c3RyaW5nPn1cbiAgICAgKlxuICAgICAqIEBwcml2YXRlXG4gICAgICovXG4gICAgY29uc3QgdmFsaWRNZXRob2RzID0gWydERUxFVEUnLCAnR0VUJywgJ0hFQUQnLCAnUEFUQ0gnLCAnUE9TVCcsICdQVVQnXTtcblxuICAgIC8qXG4gICAgICBDb3B5cmlnaHQgMjAxOCBHb29nbGUgTExDXG5cbiAgICAgIFVzZSBvZiB0aGlzIHNvdXJjZSBjb2RlIGlzIGdvdmVybmVkIGJ5IGFuIE1JVC1zdHlsZVxuICAgICAgbGljZW5zZSB0aGF0IGNhbiBiZSBmb3VuZCBpbiB0aGUgTElDRU5TRSBmaWxlIG9yIGF0XG4gICAgICBodHRwczovL29wZW5zb3VyY2Uub3JnL2xpY2Vuc2VzL01JVC5cbiAgICAqL1xuICAgIC8qKlxuICAgICAqIEBwYXJhbSB7ZnVuY3Rpb24oKXxPYmplY3R9IGhhbmRsZXIgRWl0aGVyIGEgZnVuY3Rpb24sIG9yIGFuIG9iamVjdCB3aXRoIGFcbiAgICAgKiAnaGFuZGxlJyBtZXRob2QuXG4gICAgICogQHJldHVybiB7T2JqZWN0fSBBbiBvYmplY3Qgd2l0aCBhIGhhbmRsZSBtZXRob2QuXG4gICAgICpcbiAgICAgKiBAcHJpdmF0ZVxuICAgICAqL1xuICAgIGNvbnN0IG5vcm1hbGl6ZUhhbmRsZXIgPSBoYW5kbGVyID0+IHtcbiAgICAgIGlmIChoYW5kbGVyICYmIHR5cGVvZiBoYW5kbGVyID09PSAnb2JqZWN0Jykge1xuICAgICAgICB7XG4gICAgICAgICAgZmluYWxBc3NlcnRFeHBvcnRzLmhhc01ldGhvZChoYW5kbGVyLCAnaGFuZGxlJywge1xuICAgICAgICAgICAgbW9kdWxlTmFtZTogJ3dvcmtib3gtcm91dGluZycsXG4gICAgICAgICAgICBjbGFzc05hbWU6ICdSb3V0ZScsXG4gICAgICAgICAgICBmdW5jTmFtZTogJ2NvbnN0cnVjdG9yJyxcbiAgICAgICAgICAgIHBhcmFtTmFtZTogJ2hhbmRsZXInXG4gICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIGhhbmRsZXI7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICB7XG4gICAgICAgICAgZmluYWxBc3NlcnRFeHBvcnRzLmlzVHlwZShoYW5kbGVyLCAnZnVuY3Rpb24nLCB7XG4gICAgICAgICAgICBtb2R1bGVOYW1lOiAnd29ya2JveC1yb3V0aW5nJyxcbiAgICAgICAgICAgIGNsYXNzTmFtZTogJ1JvdXRlJyxcbiAgICAgICAgICAgIGZ1bmNOYW1lOiAnY29uc3RydWN0b3InLFxuICAgICAgICAgICAgcGFyYW1OYW1lOiAnaGFuZGxlcidcbiAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgIGhhbmRsZTogaGFuZGxlclxuICAgICAgICB9O1xuICAgICAgfVxuICAgIH07XG5cbiAgICAvKlxuICAgICAgQ29weXJpZ2h0IDIwMTggR29vZ2xlIExMQ1xuXG4gICAgICBVc2Ugb2YgdGhpcyBzb3VyY2UgY29kZSBpcyBnb3Zlcm5lZCBieSBhbiBNSVQtc3R5bGVcbiAgICAgIGxpY2Vuc2UgdGhhdCBjYW4gYmUgZm91bmQgaW4gdGhlIExJQ0VOU0UgZmlsZSBvciBhdFxuICAgICAgaHR0cHM6Ly9vcGVuc291cmNlLm9yZy9saWNlbnNlcy9NSVQuXG4gICAgKi9cbiAgICAvKipcbiAgICAgKiBBIGBSb3V0ZWAgY29uc2lzdHMgb2YgYSBwYWlyIG9mIGNhbGxiYWNrIGZ1bmN0aW9ucywgXCJtYXRjaFwiIGFuZCBcImhhbmRsZXJcIi5cbiAgICAgKiBUaGUgXCJtYXRjaFwiIGNhbGxiYWNrIGRldGVybWluZSBpZiBhIHJvdXRlIHNob3VsZCBiZSB1c2VkIHRvIFwiaGFuZGxlXCIgYVxuICAgICAqIHJlcXVlc3QgYnkgcmV0dXJuaW5nIGEgbm9uLWZhbHN5IHZhbHVlIGlmIGl0IGNhbi4gVGhlIFwiaGFuZGxlclwiIGNhbGxiYWNrXG4gICAgICogaXMgY2FsbGVkIHdoZW4gdGhlcmUgaXMgYSBtYXRjaCBhbmQgc2hvdWxkIHJldHVybiBhIFByb21pc2UgdGhhdCByZXNvbHZlc1xuICAgICAqIHRvIGEgYFJlc3BvbnNlYC5cbiAgICAgKlxuICAgICAqIEBtZW1iZXJvZiB3b3JrYm94LXJvdXRpbmdcbiAgICAgKi9cbiAgICBjbGFzcyBSb3V0ZSB7XG4gICAgICAvKipcbiAgICAgICAqIENvbnN0cnVjdG9yIGZvciBSb3V0ZSBjbGFzcy5cbiAgICAgICAqXG4gICAgICAgKiBAcGFyYW0ge3dvcmtib3gtcm91dGluZ35tYXRjaENhbGxiYWNrfSBtYXRjaFxuICAgICAgICogQSBjYWxsYmFjayBmdW5jdGlvbiB0aGF0IGRldGVybWluZXMgd2hldGhlciB0aGUgcm91dGUgbWF0Y2hlcyBhIGdpdmVuXG4gICAgICAgKiBgZmV0Y2hgIGV2ZW50IGJ5IHJldHVybmluZyBhIG5vbi1mYWxzeSB2YWx1ZS5cbiAgICAgICAqIEBwYXJhbSB7d29ya2JveC1yb3V0aW5nfmhhbmRsZXJDYWxsYmFja30gaGFuZGxlciBBIGNhbGxiYWNrXG4gICAgICAgKiBmdW5jdGlvbiB0aGF0IHJldHVybnMgYSBQcm9taXNlIHJlc29sdmluZyB0byBhIFJlc3BvbnNlLlxuICAgICAgICogQHBhcmFtIHtzdHJpbmd9IFttZXRob2Q9J0dFVCddIFRoZSBIVFRQIG1ldGhvZCB0byBtYXRjaCB0aGUgUm91dGVcbiAgICAgICAqIGFnYWluc3QuXG4gICAgICAgKi9cbiAgICAgIGNvbnN0cnVjdG9yKG1hdGNoLCBoYW5kbGVyLCBtZXRob2QgPSBkZWZhdWx0TWV0aG9kKSB7XG4gICAgICAgIHtcbiAgICAgICAgICBmaW5hbEFzc2VydEV4cG9ydHMuaXNUeXBlKG1hdGNoLCAnZnVuY3Rpb24nLCB7XG4gICAgICAgICAgICBtb2R1bGVOYW1lOiAnd29ya2JveC1yb3V0aW5nJyxcbiAgICAgICAgICAgIGNsYXNzTmFtZTogJ1JvdXRlJyxcbiAgICAgICAgICAgIGZ1bmNOYW1lOiAnY29uc3RydWN0b3InLFxuICAgICAgICAgICAgcGFyYW1OYW1lOiAnbWF0Y2gnXG4gICAgICAgICAgfSk7XG4gICAgICAgICAgaWYgKG1ldGhvZCkge1xuICAgICAgICAgICAgZmluYWxBc3NlcnRFeHBvcnRzLmlzT25lT2YobWV0aG9kLCB2YWxpZE1ldGhvZHMsIHtcbiAgICAgICAgICAgICAgcGFyYW1OYW1lOiAnbWV0aG9kJ1xuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIC8vIFRoZXNlIHZhbHVlcyBhcmUgcmVmZXJlbmNlZCBkaXJlY3RseSBieSBSb3V0ZXIgc28gY2Fubm90IGJlXG4gICAgICAgIC8vIGFsdGVyZWQgYnkgbWluaWZpY2F0b24uXG4gICAgICAgIHRoaXMuaGFuZGxlciA9IG5vcm1hbGl6ZUhhbmRsZXIoaGFuZGxlcik7XG4gICAgICAgIHRoaXMubWF0Y2ggPSBtYXRjaDtcbiAgICAgICAgdGhpcy5tZXRob2QgPSBtZXRob2Q7XG4gICAgICB9XG4gICAgICAvKipcbiAgICAgICAqXG4gICAgICAgKiBAcGFyYW0ge3dvcmtib3gtcm91dGluZy1oYW5kbGVyQ2FsbGJhY2t9IGhhbmRsZXIgQSBjYWxsYmFja1xuICAgICAgICogZnVuY3Rpb24gdGhhdCByZXR1cm5zIGEgUHJvbWlzZSByZXNvbHZpbmcgdG8gYSBSZXNwb25zZVxuICAgICAgICovXG4gICAgICBzZXRDYXRjaEhhbmRsZXIoaGFuZGxlcikge1xuICAgICAgICB0aGlzLmNhdGNoSGFuZGxlciA9IG5vcm1hbGl6ZUhhbmRsZXIoaGFuZGxlcik7XG4gICAgICB9XG4gICAgfVxuXG4gICAgLypcbiAgICAgIENvcHlyaWdodCAyMDE4IEdvb2dsZSBMTENcblxuICAgICAgVXNlIG9mIHRoaXMgc291cmNlIGNvZGUgaXMgZ292ZXJuZWQgYnkgYW4gTUlULXN0eWxlXG4gICAgICBsaWNlbnNlIHRoYXQgY2FuIGJlIGZvdW5kIGluIHRoZSBMSUNFTlNFIGZpbGUgb3IgYXRcbiAgICAgIGh0dHBzOi8vb3BlbnNvdXJjZS5vcmcvbGljZW5zZXMvTUlULlxuICAgICovXG4gICAgLyoqXG4gICAgICogUmVnRXhwUm91dGUgbWFrZXMgaXQgZWFzeSB0byBjcmVhdGUgYSByZWd1bGFyIGV4cHJlc3Npb24gYmFzZWRcbiAgICAgKiB7QGxpbmsgd29ya2JveC1yb3V0aW5nLlJvdXRlfS5cbiAgICAgKlxuICAgICAqIEZvciBzYW1lLW9yaWdpbiByZXF1ZXN0cyB0aGUgUmVnRXhwIG9ubHkgbmVlZHMgdG8gbWF0Y2ggcGFydCBvZiB0aGUgVVJMLiBGb3JcbiAgICAgKiByZXF1ZXN0cyBhZ2FpbnN0IHRoaXJkLXBhcnR5IHNlcnZlcnMsIHlvdSBtdXN0IGRlZmluZSBhIFJlZ0V4cCB0aGF0IG1hdGNoZXNcbiAgICAgKiB0aGUgc3RhcnQgb2YgdGhlIFVSTC5cbiAgICAgKlxuICAgICAqIEBtZW1iZXJvZiB3b3JrYm94LXJvdXRpbmdcbiAgICAgKiBAZXh0ZW5kcyB3b3JrYm94LXJvdXRpbmcuUm91dGVcbiAgICAgKi9cbiAgICBjbGFzcyBSZWdFeHBSb3V0ZSBleHRlbmRzIFJvdXRlIHtcbiAgICAgIC8qKlxuICAgICAgICogSWYgdGhlIHJlZ3VsYXIgZXhwcmVzc2lvbiBjb250YWluc1xuICAgICAgICogW2NhcHR1cmUgZ3JvdXBzXXtAbGluayBodHRwczovL2RldmVsb3Blci5tb3ppbGxhLm9yZy9lbi1VUy9kb2NzL1dlYi9KYXZhU2NyaXB0L1JlZmVyZW5jZS9HbG9iYWxfT2JqZWN0cy9SZWdFeHAjZ3JvdXBpbmctYmFjay1yZWZlcmVuY2VzfSxcbiAgICAgICAqIHRoZSBjYXB0dXJlZCB2YWx1ZXMgd2lsbCBiZSBwYXNzZWQgdG8gdGhlXG4gICAgICAgKiB7QGxpbmsgd29ya2JveC1yb3V0aW5nfmhhbmRsZXJDYWxsYmFja30gYHBhcmFtc2BcbiAgICAgICAqIGFyZ3VtZW50LlxuICAgICAgICpcbiAgICAgICAqIEBwYXJhbSB7UmVnRXhwfSByZWdFeHAgVGhlIHJlZ3VsYXIgZXhwcmVzc2lvbiB0byBtYXRjaCBhZ2FpbnN0IFVSTHMuXG4gICAgICAgKiBAcGFyYW0ge3dvcmtib3gtcm91dGluZ35oYW5kbGVyQ2FsbGJhY2t9IGhhbmRsZXIgQSBjYWxsYmFja1xuICAgICAgICogZnVuY3Rpb24gdGhhdCByZXR1cm5zIGEgUHJvbWlzZSByZXN1bHRpbmcgaW4gYSBSZXNwb25zZS5cbiAgICAgICAqIEBwYXJhbSB7c3RyaW5nfSBbbWV0aG9kPSdHRVQnXSBUaGUgSFRUUCBtZXRob2QgdG8gbWF0Y2ggdGhlIFJvdXRlXG4gICAgICAgKiBhZ2FpbnN0LlxuICAgICAgICovXG4gICAgICBjb25zdHJ1Y3RvcihyZWdFeHAsIGhhbmRsZXIsIG1ldGhvZCkge1xuICAgICAgICB7XG4gICAgICAgICAgZmluYWxBc3NlcnRFeHBvcnRzLmlzSW5zdGFuY2UocmVnRXhwLCBSZWdFeHAsIHtcbiAgICAgICAgICAgIG1vZHVsZU5hbWU6ICd3b3JrYm94LXJvdXRpbmcnLFxuICAgICAgICAgICAgY2xhc3NOYW1lOiAnUmVnRXhwUm91dGUnLFxuICAgICAgICAgICAgZnVuY05hbWU6ICdjb25zdHJ1Y3RvcicsXG4gICAgICAgICAgICBwYXJhbU5hbWU6ICdwYXR0ZXJuJ1xuICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IG1hdGNoID0gKHtcbiAgICAgICAgICB1cmxcbiAgICAgICAgfSkgPT4ge1xuICAgICAgICAgIGNvbnN0IHJlc3VsdCA9IHJlZ0V4cC5leGVjKHVybC5ocmVmKTtcbiAgICAgICAgICAvLyBSZXR1cm4gaW1tZWRpYXRlbHkgaWYgdGhlcmUncyBubyBtYXRjaC5cbiAgICAgICAgICBpZiAoIXJlc3VsdCkge1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgIH1cbiAgICAgICAgICAvLyBSZXF1aXJlIHRoYXQgdGhlIG1hdGNoIHN0YXJ0IGF0IHRoZSBmaXJzdCBjaGFyYWN0ZXIgaW4gdGhlIFVSTCBzdHJpbmdcbiAgICAgICAgICAvLyBpZiBpdCdzIGEgY3Jvc3Mtb3JpZ2luIHJlcXVlc3QuXG4gICAgICAgICAgLy8gU2VlIGh0dHBzOi8vZ2l0aHViLmNvbS9Hb29nbGVDaHJvbWUvd29ya2JveC9pc3N1ZXMvMjgxIGZvciB0aGUgY29udGV4dFxuICAgICAgICAgIC8vIGJlaGluZCB0aGlzIGJlaGF2aW9yLlxuICAgICAgICAgIGlmICh1cmwub3JpZ2luICE9PSBsb2NhdGlvbi5vcmlnaW4gJiYgcmVzdWx0LmluZGV4ICE9PSAwKSB7XG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgIGxvZ2dlci5kZWJ1ZyhgVGhlIHJlZ3VsYXIgZXhwcmVzc2lvbiAnJHtyZWdFeHAudG9TdHJpbmcoKX0nIG9ubHkgcGFydGlhbGx5IG1hdGNoZWQgYCArIGBhZ2FpbnN0IHRoZSBjcm9zcy1vcmlnaW4gVVJMICcke3VybC50b1N0cmluZygpfScuIFJlZ0V4cFJvdXRlJ3Mgd2lsbCBvbmx5IGAgKyBgaGFuZGxlIGNyb3NzLW9yaWdpbiByZXF1ZXN0cyBpZiB0aGV5IG1hdGNoIHRoZSBlbnRpcmUgVVJMLmApO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgIH1cbiAgICAgICAgICAvLyBJZiB0aGUgcm91dGUgbWF0Y2hlcywgYnV0IHRoZXJlIGFyZW4ndCBhbnkgY2FwdHVyZSBncm91cHMgZGVmaW5lZCwgdGhlblxuICAgICAgICAgIC8vIHRoaXMgd2lsbCByZXR1cm4gW10sIHdoaWNoIGlzIHRydXRoeSBhbmQgdGhlcmVmb3JlIHN1ZmZpY2llbnQgdG9cbiAgICAgICAgICAvLyBpbmRpY2F0ZSBhIG1hdGNoLlxuICAgICAgICAgIC8vIElmIHRoZXJlIGFyZSBjYXB0dXJlIGdyb3VwcywgdGhlbiBpdCB3aWxsIHJldHVybiB0aGVpciB2YWx1ZXMuXG4gICAgICAgICAgcmV0dXJuIHJlc3VsdC5zbGljZSgxKTtcbiAgICAgICAgfTtcbiAgICAgICAgc3VwZXIobWF0Y2gsIGhhbmRsZXIsIG1ldGhvZCk7XG4gICAgICB9XG4gICAgfVxuXG4gICAgLypcbiAgICAgIENvcHlyaWdodCAyMDE4IEdvb2dsZSBMTENcblxuICAgICAgVXNlIG9mIHRoaXMgc291cmNlIGNvZGUgaXMgZ292ZXJuZWQgYnkgYW4gTUlULXN0eWxlXG4gICAgICBsaWNlbnNlIHRoYXQgY2FuIGJlIGZvdW5kIGluIHRoZSBMSUNFTlNFIGZpbGUgb3IgYXRcbiAgICAgIGh0dHBzOi8vb3BlbnNvdXJjZS5vcmcvbGljZW5zZXMvTUlULlxuICAgICovXG4gICAgY29uc3QgZ2V0RnJpZW5kbHlVUkwgPSB1cmwgPT4ge1xuICAgICAgY29uc3QgdXJsT2JqID0gbmV3IFVSTChTdHJpbmcodXJsKSwgbG9jYXRpb24uaHJlZik7XG4gICAgICAvLyBTZWUgaHR0cHM6Ly9naXRodWIuY29tL0dvb2dsZUNocm9tZS93b3JrYm94L2lzc3Vlcy8yMzIzXG4gICAgICAvLyBXZSB3YW50IHRvIGluY2x1ZGUgZXZlcnl0aGluZywgZXhjZXB0IGZvciB0aGUgb3JpZ2luIGlmIGl0J3Mgc2FtZS1vcmlnaW4uXG4gICAgICByZXR1cm4gdXJsT2JqLmhyZWYucmVwbGFjZShuZXcgUmVnRXhwKGBeJHtsb2NhdGlvbi5vcmlnaW59YCksICcnKTtcbiAgICB9O1xuXG4gICAgLypcbiAgICAgIENvcHlyaWdodCAyMDE4IEdvb2dsZSBMTENcblxuICAgICAgVXNlIG9mIHRoaXMgc291cmNlIGNvZGUgaXMgZ292ZXJuZWQgYnkgYW4gTUlULXN0eWxlXG4gICAgICBsaWNlbnNlIHRoYXQgY2FuIGJlIGZvdW5kIGluIHRoZSBMSUNFTlNFIGZpbGUgb3IgYXRcbiAgICAgIGh0dHBzOi8vb3BlbnNvdXJjZS5vcmcvbGljZW5zZXMvTUlULlxuICAgICovXG4gICAgLyoqXG4gICAgICogVGhlIFJvdXRlciBjYW4gYmUgdXNlZCB0byBwcm9jZXNzIGEgYEZldGNoRXZlbnRgIHVzaW5nIG9uZSBvciBtb3JlXG4gICAgICoge0BsaW5rIHdvcmtib3gtcm91dGluZy5Sb3V0ZX0sIHJlc3BvbmRpbmcgd2l0aCBhIGBSZXNwb25zZWAgaWZcbiAgICAgKiBhIG1hdGNoaW5nIHJvdXRlIGV4aXN0cy5cbiAgICAgKlxuICAgICAqIElmIG5vIHJvdXRlIG1hdGNoZXMgYSBnaXZlbiBhIHJlcXVlc3QsIHRoZSBSb3V0ZXIgd2lsbCB1c2UgYSBcImRlZmF1bHRcIlxuICAgICAqIGhhbmRsZXIgaWYgb25lIGlzIGRlZmluZWQuXG4gICAgICpcbiAgICAgKiBTaG91bGQgdGhlIG1hdGNoaW5nIFJvdXRlIHRocm93IGFuIGVycm9yLCB0aGUgUm91dGVyIHdpbGwgdXNlIGEgXCJjYXRjaFwiXG4gICAgICogaGFuZGxlciBpZiBvbmUgaXMgZGVmaW5lZCB0byBncmFjZWZ1bGx5IGRlYWwgd2l0aCBpc3N1ZXMgYW5kIHJlc3BvbmQgd2l0aCBhXG4gICAgICogUmVxdWVzdC5cbiAgICAgKlxuICAgICAqIElmIGEgcmVxdWVzdCBtYXRjaGVzIG11bHRpcGxlIHJvdXRlcywgdGhlICoqZWFybGllc3QqKiByZWdpc3RlcmVkIHJvdXRlIHdpbGxcbiAgICAgKiBiZSB1c2VkIHRvIHJlc3BvbmQgdG8gdGhlIHJlcXVlc3QuXG4gICAgICpcbiAgICAgKiBAbWVtYmVyb2Ygd29ya2JveC1yb3V0aW5nXG4gICAgICovXG4gICAgY2xhc3MgUm91dGVyIHtcbiAgICAgIC8qKlxuICAgICAgICogSW5pdGlhbGl6ZXMgYSBuZXcgUm91dGVyLlxuICAgICAgICovXG4gICAgICBjb25zdHJ1Y3RvcigpIHtcbiAgICAgICAgdGhpcy5fcm91dGVzID0gbmV3IE1hcCgpO1xuICAgICAgICB0aGlzLl9kZWZhdWx0SGFuZGxlck1hcCA9IG5ldyBNYXAoKTtcbiAgICAgIH1cbiAgICAgIC8qKlxuICAgICAgICogQHJldHVybiB7TWFwPHN0cmluZywgQXJyYXk8d29ya2JveC1yb3V0aW5nLlJvdXRlPj59IHJvdXRlcyBBIGBNYXBgIG9mIEhUVFBcbiAgICAgICAqIG1ldGhvZCBuYW1lICgnR0VUJywgZXRjLikgdG8gYW4gYXJyYXkgb2YgYWxsIHRoZSBjb3JyZXNwb25kaW5nIGBSb3V0ZWBcbiAgICAgICAqIGluc3RhbmNlcyB0aGF0IGFyZSByZWdpc3RlcmVkLlxuICAgICAgICovXG4gICAgICBnZXQgcm91dGVzKCkge1xuICAgICAgICByZXR1cm4gdGhpcy5fcm91dGVzO1xuICAgICAgfVxuICAgICAgLyoqXG4gICAgICAgKiBBZGRzIGEgZmV0Y2ggZXZlbnQgbGlzdGVuZXIgdG8gcmVzcG9uZCB0byBldmVudHMgd2hlbiBhIHJvdXRlIG1hdGNoZXNcbiAgICAgICAqIHRoZSBldmVudCdzIHJlcXVlc3QuXG4gICAgICAgKi9cbiAgICAgIGFkZEZldGNoTGlzdGVuZXIoKSB7XG4gICAgICAgIC8vIFNlZSBodHRwczovL2dpdGh1Yi5jb20vTWljcm9zb2Z0L1R5cGVTY3JpcHQvaXNzdWVzLzI4MzU3I2lzc3VlY29tbWVudC00MzY0ODQ3MDVcbiAgICAgICAgc2VsZi5hZGRFdmVudExpc3RlbmVyKCdmZXRjaCcsIGV2ZW50ID0+IHtcbiAgICAgICAgICBjb25zdCB7XG4gICAgICAgICAgICByZXF1ZXN0XG4gICAgICAgICAgfSA9IGV2ZW50O1xuICAgICAgICAgIGNvbnN0IHJlc3BvbnNlUHJvbWlzZSA9IHRoaXMuaGFuZGxlUmVxdWVzdCh7XG4gICAgICAgICAgICByZXF1ZXN0LFxuICAgICAgICAgICAgZXZlbnRcbiAgICAgICAgICB9KTtcbiAgICAgICAgICBpZiAocmVzcG9uc2VQcm9taXNlKSB7XG4gICAgICAgICAgICBldmVudC5yZXNwb25kV2l0aChyZXNwb25zZVByb21pc2UpO1xuICAgICAgICAgIH1cbiAgICAgICAgfSk7XG4gICAgICB9XG4gICAgICAvKipcbiAgICAgICAqIEFkZHMgYSBtZXNzYWdlIGV2ZW50IGxpc3RlbmVyIGZvciBVUkxzIHRvIGNhY2hlIGZyb20gdGhlIHdpbmRvdy5cbiAgICAgICAqIFRoaXMgaXMgdXNlZnVsIHRvIGNhY2hlIHJlc291cmNlcyBsb2FkZWQgb24gdGhlIHBhZ2UgcHJpb3IgdG8gd2hlbiB0aGVcbiAgICAgICAqIHNlcnZpY2Ugd29ya2VyIHN0YXJ0ZWQgY29udHJvbGxpbmcgaXQuXG4gICAgICAgKlxuICAgICAgICogVGhlIGZvcm1hdCBvZiB0aGUgbWVzc2FnZSBkYXRhIHNlbnQgZnJvbSB0aGUgd2luZG93IHNob3VsZCBiZSBhcyBmb2xsb3dzLlxuICAgICAgICogV2hlcmUgdGhlIGB1cmxzVG9DYWNoZWAgYXJyYXkgbWF5IGNvbnNpc3Qgb2YgVVJMIHN0cmluZ3Mgb3IgYW4gYXJyYXkgb2ZcbiAgICAgICAqIFVSTCBzdHJpbmcgKyBgcmVxdWVzdEluaXRgIG9iamVjdCAodGhlIHNhbWUgYXMgeW91J2QgcGFzcyB0byBgZmV0Y2goKWApLlxuICAgICAgICpcbiAgICAgICAqIGBgYFxuICAgICAgICoge1xuICAgICAgICogICB0eXBlOiAnQ0FDSEVfVVJMUycsXG4gICAgICAgKiAgIHBheWxvYWQ6IHtcbiAgICAgICAqICAgICB1cmxzVG9DYWNoZTogW1xuICAgICAgICogICAgICAgJy4vc2NyaXB0MS5qcycsXG4gICAgICAgKiAgICAgICAnLi9zY3JpcHQyLmpzJyxcbiAgICAgICAqICAgICAgIFsnLi9zY3JpcHQzLmpzJywge21vZGU6ICduby1jb3JzJ31dLFxuICAgICAgICogICAgIF0sXG4gICAgICAgKiAgIH0sXG4gICAgICAgKiB9XG4gICAgICAgKiBgYGBcbiAgICAgICAqL1xuICAgICAgYWRkQ2FjaGVMaXN0ZW5lcigpIHtcbiAgICAgICAgLy8gU2VlIGh0dHBzOi8vZ2l0aHViLmNvbS9NaWNyb3NvZnQvVHlwZVNjcmlwdC9pc3N1ZXMvMjgzNTcjaXNzdWVjb21tZW50LTQzNjQ4NDcwNVxuICAgICAgICBzZWxmLmFkZEV2ZW50TGlzdGVuZXIoJ21lc3NhZ2UnLCBldmVudCA9PiB7XG4gICAgICAgICAgLy8gZXZlbnQuZGF0YSBpcyB0eXBlICdhbnknXG4gICAgICAgICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIEB0eXBlc2NyaXB0LWVzbGludC9uby11bnNhZmUtbWVtYmVyLWFjY2Vzc1xuICAgICAgICAgIGlmIChldmVudC5kYXRhICYmIGV2ZW50LmRhdGEudHlwZSA9PT0gJ0NBQ0hFX1VSTFMnKSB7XG4gICAgICAgICAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgQHR5cGVzY3JpcHQtZXNsaW50L25vLXVuc2FmZS1hc3NpZ25tZW50XG4gICAgICAgICAgICBjb25zdCB7XG4gICAgICAgICAgICAgIHBheWxvYWRcbiAgICAgICAgICAgIH0gPSBldmVudC5kYXRhO1xuICAgICAgICAgICAge1xuICAgICAgICAgICAgICBsb2dnZXIuZGVidWcoYENhY2hpbmcgVVJMcyBmcm9tIHRoZSB3aW5kb3dgLCBwYXlsb2FkLnVybHNUb0NhY2hlKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGNvbnN0IHJlcXVlc3RQcm9taXNlcyA9IFByb21pc2UuYWxsKHBheWxvYWQudXJsc1RvQ2FjaGUubWFwKGVudHJ5ID0+IHtcbiAgICAgICAgICAgICAgaWYgKHR5cGVvZiBlbnRyeSA9PT0gJ3N0cmluZycpIHtcbiAgICAgICAgICAgICAgICBlbnRyeSA9IFtlbnRyeV07XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgY29uc3QgcmVxdWVzdCA9IG5ldyBSZXF1ZXN0KC4uLmVudHJ5KTtcbiAgICAgICAgICAgICAgcmV0dXJuIHRoaXMuaGFuZGxlUmVxdWVzdCh7XG4gICAgICAgICAgICAgICAgcmVxdWVzdCxcbiAgICAgICAgICAgICAgICBldmVudFxuICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgLy8gVE9ETyhwaGlsaXB3YWx0b24pOiBUeXBlU2NyaXB0IGVycm9ycyB3aXRob3V0IHRoaXMgdHlwZWNhc3QgZm9yXG4gICAgICAgICAgICAgIC8vIHNvbWUgcmVhc29uIChwcm9iYWJseSBhIGJ1ZykuIFRoZSByZWFsIHR5cGUgaGVyZSBzaG91bGQgd29yayBidXRcbiAgICAgICAgICAgICAgLy8gZG9lc24ndDogYEFycmF5PFByb21pc2U8UmVzcG9uc2U+IHwgdW5kZWZpbmVkPmAuXG4gICAgICAgICAgICB9KSk7IC8vIFR5cGVTY3JpcHRcbiAgICAgICAgICAgIGV2ZW50LndhaXRVbnRpbChyZXF1ZXN0UHJvbWlzZXMpO1xuICAgICAgICAgICAgLy8gSWYgYSBNZXNzYWdlQ2hhbm5lbCB3YXMgdXNlZCwgcmVwbHkgdG8gdGhlIG1lc3NhZ2Ugb24gc3VjY2Vzcy5cbiAgICAgICAgICAgIGlmIChldmVudC5wb3J0cyAmJiBldmVudC5wb3J0c1swXSkge1xuICAgICAgICAgICAgICB2b2lkIHJlcXVlc3RQcm9taXNlcy50aGVuKCgpID0+IGV2ZW50LnBvcnRzWzBdLnBvc3RNZXNzYWdlKHRydWUpKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICAgIH0pO1xuICAgICAgfVxuICAgICAgLyoqXG4gICAgICAgKiBBcHBseSB0aGUgcm91dGluZyBydWxlcyB0byBhIEZldGNoRXZlbnQgb2JqZWN0IHRvIGdldCBhIFJlc3BvbnNlIGZyb20gYW5cbiAgICAgICAqIGFwcHJvcHJpYXRlIFJvdXRlJ3MgaGFuZGxlci5cbiAgICAgICAqXG4gICAgICAgKiBAcGFyYW0ge09iamVjdH0gb3B0aW9uc1xuICAgICAgICogQHBhcmFtIHtSZXF1ZXN0fSBvcHRpb25zLnJlcXVlc3QgVGhlIHJlcXVlc3QgdG8gaGFuZGxlLlxuICAgICAgICogQHBhcmFtIHtFeHRlbmRhYmxlRXZlbnR9IG9wdGlvbnMuZXZlbnQgVGhlIGV2ZW50IHRoYXQgdHJpZ2dlcmVkIHRoZVxuICAgICAgICogICAgIHJlcXVlc3QuXG4gICAgICAgKiBAcmV0dXJuIHtQcm9taXNlPFJlc3BvbnNlPnx1bmRlZmluZWR9IEEgcHJvbWlzZSBpcyByZXR1cm5lZCBpZiBhXG4gICAgICAgKiAgICAgcmVnaXN0ZXJlZCByb3V0ZSBjYW4gaGFuZGxlIHRoZSByZXF1ZXN0LiBJZiB0aGVyZSBpcyBubyBtYXRjaGluZ1xuICAgICAgICogICAgIHJvdXRlIGFuZCB0aGVyZSdzIG5vIGBkZWZhdWx0SGFuZGxlcmAsIGB1bmRlZmluZWRgIGlzIHJldHVybmVkLlxuICAgICAgICovXG4gICAgICBoYW5kbGVSZXF1ZXN0KHtcbiAgICAgICAgcmVxdWVzdCxcbiAgICAgICAgZXZlbnRcbiAgICAgIH0pIHtcbiAgICAgICAge1xuICAgICAgICAgIGZpbmFsQXNzZXJ0RXhwb3J0cy5pc0luc3RhbmNlKHJlcXVlc3QsIFJlcXVlc3QsIHtcbiAgICAgICAgICAgIG1vZHVsZU5hbWU6ICd3b3JrYm94LXJvdXRpbmcnLFxuICAgICAgICAgICAgY2xhc3NOYW1lOiAnUm91dGVyJyxcbiAgICAgICAgICAgIGZ1bmNOYW1lOiAnaGFuZGxlUmVxdWVzdCcsXG4gICAgICAgICAgICBwYXJhbU5hbWU6ICdvcHRpb25zLnJlcXVlc3QnXG4gICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgdXJsID0gbmV3IFVSTChyZXF1ZXN0LnVybCwgbG9jYXRpb24uaHJlZik7XG4gICAgICAgIGlmICghdXJsLnByb3RvY29sLnN0YXJ0c1dpdGgoJ2h0dHAnKSkge1xuICAgICAgICAgIHtcbiAgICAgICAgICAgIGxvZ2dlci5kZWJ1ZyhgV29ya2JveCBSb3V0ZXIgb25seSBzdXBwb3J0cyBVUkxzIHRoYXQgc3RhcnQgd2l0aCAnaHR0cCcuYCk7XG4gICAgICAgICAgfVxuICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCBzYW1lT3JpZ2luID0gdXJsLm9yaWdpbiA9PT0gbG9jYXRpb24ub3JpZ2luO1xuICAgICAgICBjb25zdCB7XG4gICAgICAgICAgcGFyYW1zLFxuICAgICAgICAgIHJvdXRlXG4gICAgICAgIH0gPSB0aGlzLmZpbmRNYXRjaGluZ1JvdXRlKHtcbiAgICAgICAgICBldmVudCxcbiAgICAgICAgICByZXF1ZXN0LFxuICAgICAgICAgIHNhbWVPcmlnaW4sXG4gICAgICAgICAgdXJsXG4gICAgICAgIH0pO1xuICAgICAgICBsZXQgaGFuZGxlciA9IHJvdXRlICYmIHJvdXRlLmhhbmRsZXI7XG4gICAgICAgIGNvbnN0IGRlYnVnTWVzc2FnZXMgPSBbXTtcbiAgICAgICAge1xuICAgICAgICAgIGlmIChoYW5kbGVyKSB7XG4gICAgICAgICAgICBkZWJ1Z01lc3NhZ2VzLnB1c2goW2BGb3VuZCBhIHJvdXRlIHRvIGhhbmRsZSB0aGlzIHJlcXVlc3Q6YCwgcm91dGVdKTtcbiAgICAgICAgICAgIGlmIChwYXJhbXMpIHtcbiAgICAgICAgICAgICAgZGVidWdNZXNzYWdlcy5wdXNoKFtgUGFzc2luZyB0aGUgZm9sbG93aW5nIHBhcmFtcyB0byB0aGUgcm91dGUncyBoYW5kbGVyOmAsIHBhcmFtc10pO1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICAvLyBJZiB3ZSBkb24ndCBoYXZlIGEgaGFuZGxlciBiZWNhdXNlIHRoZXJlIHdhcyBubyBtYXRjaGluZyByb3V0ZSwgdGhlblxuICAgICAgICAvLyBmYWxsIGJhY2sgdG8gZGVmYXVsdEhhbmRsZXIgaWYgdGhhdCdzIGRlZmluZWQuXG4gICAgICAgIGNvbnN0IG1ldGhvZCA9IHJlcXVlc3QubWV0aG9kO1xuICAgICAgICBpZiAoIWhhbmRsZXIgJiYgdGhpcy5fZGVmYXVsdEhhbmRsZXJNYXAuaGFzKG1ldGhvZCkpIHtcbiAgICAgICAgICB7XG4gICAgICAgICAgICBkZWJ1Z01lc3NhZ2VzLnB1c2goYEZhaWxlZCB0byBmaW5kIGEgbWF0Y2hpbmcgcm91dGUuIEZhbGxpbmcgYCArIGBiYWNrIHRvIHRoZSBkZWZhdWx0IGhhbmRsZXIgZm9yICR7bWV0aG9kfS5gKTtcbiAgICAgICAgICB9XG4gICAgICAgICAgaGFuZGxlciA9IHRoaXMuX2RlZmF1bHRIYW5kbGVyTWFwLmdldChtZXRob2QpO1xuICAgICAgICB9XG4gICAgICAgIGlmICghaGFuZGxlcikge1xuICAgICAgICAgIHtcbiAgICAgICAgICAgIC8vIE5vIGhhbmRsZXIgc28gV29ya2JveCB3aWxsIGRvIG5vdGhpbmcuIElmIGxvZ3MgaXMgc2V0IG9mIGRlYnVnXG4gICAgICAgICAgICAvLyBpLmUuIHZlcmJvc2UsIHdlIHNob3VsZCBwcmludCBvdXQgdGhpcyBpbmZvcm1hdGlvbi5cbiAgICAgICAgICAgIGxvZ2dlci5kZWJ1ZyhgTm8gcm91dGUgZm91bmQgZm9yOiAke2dldEZyaWVuZGx5VVJMKHVybCl9YCk7XG4gICAgICAgICAgfVxuICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICB7XG4gICAgICAgICAgLy8gV2UgaGF2ZSBhIGhhbmRsZXIsIG1lYW5pbmcgV29ya2JveCBpcyBnb2luZyB0byBoYW5kbGUgdGhlIHJvdXRlLlxuICAgICAgICAgIC8vIHByaW50IHRoZSByb3V0aW5nIGRldGFpbHMgdG8gdGhlIGNvbnNvbGUuXG4gICAgICAgICAgbG9nZ2VyLmdyb3VwQ29sbGFwc2VkKGBSb3V0ZXIgaXMgcmVzcG9uZGluZyB0bzogJHtnZXRGcmllbmRseVVSTCh1cmwpfWApO1xuICAgICAgICAgIGRlYnVnTWVzc2FnZXMuZm9yRWFjaChtc2cgPT4ge1xuICAgICAgICAgICAgaWYgKEFycmF5LmlzQXJyYXkobXNnKSkge1xuICAgICAgICAgICAgICBsb2dnZXIubG9nKC4uLm1zZyk7XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICBsb2dnZXIubG9nKG1zZyk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfSk7XG4gICAgICAgICAgbG9nZ2VyLmdyb3VwRW5kKCk7XG4gICAgICAgIH1cbiAgICAgICAgLy8gV3JhcCBpbiB0cnkgYW5kIGNhdGNoIGluIGNhc2UgdGhlIGhhbmRsZSBtZXRob2QgdGhyb3dzIGEgc3luY2hyb25vdXNcbiAgICAgICAgLy8gZXJyb3IuIEl0IHNob3VsZCBzdGlsbCBjYWxsYmFjayB0byB0aGUgY2F0Y2ggaGFuZGxlci5cbiAgICAgICAgbGV0IHJlc3BvbnNlUHJvbWlzZTtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICByZXNwb25zZVByb21pc2UgPSBoYW5kbGVyLmhhbmRsZSh7XG4gICAgICAgICAgICB1cmwsXG4gICAgICAgICAgICByZXF1ZXN0LFxuICAgICAgICAgICAgZXZlbnQsXG4gICAgICAgICAgICBwYXJhbXNcbiAgICAgICAgICB9KTtcbiAgICAgICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICAgICAgcmVzcG9uc2VQcm9taXNlID0gUHJvbWlzZS5yZWplY3QoZXJyKTtcbiAgICAgICAgfVxuICAgICAgICAvLyBHZXQgcm91dGUncyBjYXRjaCBoYW5kbGVyLCBpZiBpdCBleGlzdHNcbiAgICAgICAgY29uc3QgY2F0Y2hIYW5kbGVyID0gcm91dGUgJiYgcm91dGUuY2F0Y2hIYW5kbGVyO1xuICAgICAgICBpZiAocmVzcG9uc2VQcm9taXNlIGluc3RhbmNlb2YgUHJvbWlzZSAmJiAodGhpcy5fY2F0Y2hIYW5kbGVyIHx8IGNhdGNoSGFuZGxlcikpIHtcbiAgICAgICAgICByZXNwb25zZVByb21pc2UgPSByZXNwb25zZVByb21pc2UuY2F0Y2goYXN5bmMgZXJyID0+IHtcbiAgICAgICAgICAgIC8vIElmIHRoZXJlJ3MgYSByb3V0ZSBjYXRjaCBoYW5kbGVyLCBwcm9jZXNzIHRoYXQgZmlyc3RcbiAgICAgICAgICAgIGlmIChjYXRjaEhhbmRsZXIpIHtcbiAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIC8vIFN0aWxsIGluY2x1ZGUgVVJMIGhlcmUgYXMgaXQgd2lsbCBiZSBhc3luYyBmcm9tIHRoZSBjb25zb2xlIGdyb3VwXG4gICAgICAgICAgICAgICAgLy8gYW5kIG1heSBub3QgbWFrZSBzZW5zZSB3aXRob3V0IHRoZSBVUkxcbiAgICAgICAgICAgICAgICBsb2dnZXIuZ3JvdXBDb2xsYXBzZWQoYEVycm9yIHRocm93biB3aGVuIHJlc3BvbmRpbmcgdG86IGAgKyBgICR7Z2V0RnJpZW5kbHlVUkwodXJsKX0uIEZhbGxpbmcgYmFjayB0byByb3V0ZSdzIENhdGNoIEhhbmRsZXIuYCk7XG4gICAgICAgICAgICAgICAgbG9nZ2VyLmVycm9yKGBFcnJvciB0aHJvd24gYnk6YCwgcm91dGUpO1xuICAgICAgICAgICAgICAgIGxvZ2dlci5lcnJvcihlcnIpO1xuICAgICAgICAgICAgICAgIGxvZ2dlci5ncm91cEVuZCgpO1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIGF3YWl0IGNhdGNoSGFuZGxlci5oYW5kbGUoe1xuICAgICAgICAgICAgICAgICAgdXJsLFxuICAgICAgICAgICAgICAgICAgcmVxdWVzdCxcbiAgICAgICAgICAgICAgICAgIGV2ZW50LFxuICAgICAgICAgICAgICAgICAgcGFyYW1zXG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgIH0gY2F0Y2ggKGNhdGNoRXJyKSB7XG4gICAgICAgICAgICAgICAgaWYgKGNhdGNoRXJyIGluc3RhbmNlb2YgRXJyb3IpIHtcbiAgICAgICAgICAgICAgICAgIGVyciA9IGNhdGNoRXJyO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKHRoaXMuX2NhdGNoSGFuZGxlcikge1xuICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgLy8gU3RpbGwgaW5jbHVkZSBVUkwgaGVyZSBhcyBpdCB3aWxsIGJlIGFzeW5jIGZyb20gdGhlIGNvbnNvbGUgZ3JvdXBcbiAgICAgICAgICAgICAgICAvLyBhbmQgbWF5IG5vdCBtYWtlIHNlbnNlIHdpdGhvdXQgdGhlIFVSTFxuICAgICAgICAgICAgICAgIGxvZ2dlci5ncm91cENvbGxhcHNlZChgRXJyb3IgdGhyb3duIHdoZW4gcmVzcG9uZGluZyB0bzogYCArIGAgJHtnZXRGcmllbmRseVVSTCh1cmwpfS4gRmFsbGluZyBiYWNrIHRvIGdsb2JhbCBDYXRjaCBIYW5kbGVyLmApO1xuICAgICAgICAgICAgICAgIGxvZ2dlci5lcnJvcihgRXJyb3IgdGhyb3duIGJ5OmAsIHJvdXRlKTtcbiAgICAgICAgICAgICAgICBsb2dnZXIuZXJyb3IoZXJyKTtcbiAgICAgICAgICAgICAgICBsb2dnZXIuZ3JvdXBFbmQoKTtcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICByZXR1cm4gdGhpcy5fY2F0Y2hIYW5kbGVyLmhhbmRsZSh7XG4gICAgICAgICAgICAgICAgdXJsLFxuICAgICAgICAgICAgICAgIHJlcXVlc3QsXG4gICAgICAgICAgICAgICAgZXZlbnRcbiAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICB0aHJvdyBlcnI7XG4gICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlUHJvbWlzZTtcbiAgICAgIH1cbiAgICAgIC8qKlxuICAgICAgICogQ2hlY2tzIGEgcmVxdWVzdCBhbmQgVVJMIChhbmQgb3B0aW9uYWxseSBhbiBldmVudCkgYWdhaW5zdCB0aGUgbGlzdCBvZlxuICAgICAgICogcmVnaXN0ZXJlZCByb3V0ZXMsIGFuZCBpZiB0aGVyZSdzIGEgbWF0Y2gsIHJldHVybnMgdGhlIGNvcnJlc3BvbmRpbmdcbiAgICAgICAqIHJvdXRlIGFsb25nIHdpdGggYW55IHBhcmFtcyBnZW5lcmF0ZWQgYnkgdGhlIG1hdGNoLlxuICAgICAgICpcbiAgICAgICAqIEBwYXJhbSB7T2JqZWN0fSBvcHRpb25zXG4gICAgICAgKiBAcGFyYW0ge1VSTH0gb3B0aW9ucy51cmxcbiAgICAgICAqIEBwYXJhbSB7Ym9vbGVhbn0gb3B0aW9ucy5zYW1lT3JpZ2luIFRoZSByZXN1bHQgb2YgY29tcGFyaW5nIGB1cmwub3JpZ2luYFxuICAgICAgICogICAgIGFnYWluc3QgdGhlIGN1cnJlbnQgb3JpZ2luLlxuICAgICAgICogQHBhcmFtIHtSZXF1ZXN0fSBvcHRpb25zLnJlcXVlc3QgVGhlIHJlcXVlc3QgdG8gbWF0Y2guXG4gICAgICAgKiBAcGFyYW0ge0V2ZW50fSBvcHRpb25zLmV2ZW50IFRoZSBjb3JyZXNwb25kaW5nIGV2ZW50LlxuICAgICAgICogQHJldHVybiB7T2JqZWN0fSBBbiBvYmplY3Qgd2l0aCBgcm91dGVgIGFuZCBgcGFyYW1zYCBwcm9wZXJ0aWVzLlxuICAgICAgICogICAgIFRoZXkgYXJlIHBvcHVsYXRlZCBpZiBhIG1hdGNoaW5nIHJvdXRlIHdhcyBmb3VuZCBvciBgdW5kZWZpbmVkYFxuICAgICAgICogICAgIG90aGVyd2lzZS5cbiAgICAgICAqL1xuICAgICAgZmluZE1hdGNoaW5nUm91dGUoe1xuICAgICAgICB1cmwsXG4gICAgICAgIHNhbWVPcmlnaW4sXG4gICAgICAgIHJlcXVlc3QsXG4gICAgICAgIGV2ZW50XG4gICAgICB9KSB7XG4gICAgICAgIGNvbnN0IHJvdXRlcyA9IHRoaXMuX3JvdXRlcy5nZXQocmVxdWVzdC5tZXRob2QpIHx8IFtdO1xuICAgICAgICBmb3IgKGNvbnN0IHJvdXRlIG9mIHJvdXRlcykge1xuICAgICAgICAgIGxldCBwYXJhbXM7XG4gICAgICAgICAgLy8gcm91dGUubWF0Y2ggcmV0dXJucyB0eXBlIGFueSwgbm90IHBvc3NpYmxlIHRvIGNoYW5nZSByaWdodCBub3cuXG4gICAgICAgICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIEB0eXBlc2NyaXB0LWVzbGludC9uby11bnNhZmUtYXNzaWdubWVudFxuICAgICAgICAgIGNvbnN0IG1hdGNoUmVzdWx0ID0gcm91dGUubWF0Y2goe1xuICAgICAgICAgICAgdXJsLFxuICAgICAgICAgICAgc2FtZU9yaWdpbixcbiAgICAgICAgICAgIHJlcXVlc3QsXG4gICAgICAgICAgICBldmVudFxuICAgICAgICAgIH0pO1xuICAgICAgICAgIGlmIChtYXRjaFJlc3VsdCkge1xuICAgICAgICAgICAge1xuICAgICAgICAgICAgICAvLyBXYXJuIGRldmVsb3BlcnMgdGhhdCB1c2luZyBhbiBhc3luYyBtYXRjaENhbGxiYWNrIGlzIGFsbW9zdCBhbHdheXNcbiAgICAgICAgICAgICAgLy8gbm90IHRoZSByaWdodCB0aGluZyB0byBkby5cbiAgICAgICAgICAgICAgaWYgKG1hdGNoUmVzdWx0IGluc3RhbmNlb2YgUHJvbWlzZSkge1xuICAgICAgICAgICAgICAgIGxvZ2dlci53YXJuKGBXaGlsZSByb3V0aW5nICR7Z2V0RnJpZW5kbHlVUkwodXJsKX0sIGFuIGFzeW5jIGAgKyBgbWF0Y2hDYWxsYmFjayBmdW5jdGlvbiB3YXMgdXNlZC4gUGxlYXNlIGNvbnZlcnQgdGhlIGAgKyBgZm9sbG93aW5nIHJvdXRlIHRvIHVzZSBhIHN5bmNocm9ub3VzIG1hdGNoQ2FsbGJhY2sgZnVuY3Rpb246YCwgcm91dGUpO1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICAvLyBTZWUgaHR0cHM6Ly9naXRodWIuY29tL0dvb2dsZUNocm9tZS93b3JrYm94L2lzc3Vlcy8yMDc5XG4gICAgICAgICAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgQHR5cGVzY3JpcHQtZXNsaW50L25vLXVuc2FmZS1hc3NpZ25tZW50XG4gICAgICAgICAgICBwYXJhbXMgPSBtYXRjaFJlc3VsdDtcbiAgICAgICAgICAgIGlmIChBcnJheS5pc0FycmF5KHBhcmFtcykgJiYgcGFyYW1zLmxlbmd0aCA9PT0gMCkge1xuICAgICAgICAgICAgICAvLyBJbnN0ZWFkIG9mIHBhc3NpbmcgYW4gZW1wdHkgYXJyYXkgaW4gYXMgcGFyYW1zLCB1c2UgdW5kZWZpbmVkLlxuICAgICAgICAgICAgICBwYXJhbXMgPSB1bmRlZmluZWQ7XG4gICAgICAgICAgICB9IGVsc2UgaWYgKG1hdGNoUmVzdWx0LmNvbnN0cnVjdG9yID09PSBPYmplY3QgJiZcbiAgICAgICAgICAgIC8vIGVzbGludC1kaXNhYmxlLWxpbmVcbiAgICAgICAgICAgIE9iamVjdC5rZXlzKG1hdGNoUmVzdWx0KS5sZW5ndGggPT09IDApIHtcbiAgICAgICAgICAgICAgLy8gSW5zdGVhZCBvZiBwYXNzaW5nIGFuIGVtcHR5IG9iamVjdCBpbiBhcyBwYXJhbXMsIHVzZSB1bmRlZmluZWQuXG4gICAgICAgICAgICAgIHBhcmFtcyA9IHVuZGVmaW5lZDtcbiAgICAgICAgICAgIH0gZWxzZSBpZiAodHlwZW9mIG1hdGNoUmVzdWx0ID09PSAnYm9vbGVhbicpIHtcbiAgICAgICAgICAgICAgLy8gRm9yIHRoZSBib29sZWFuIHZhbHVlIHRydWUgKHJhdGhlciB0aGFuIGp1c3Qgc29tZXRoaW5nIHRydXRoLXkpLFxuICAgICAgICAgICAgICAvLyBkb24ndCBzZXQgcGFyYW1zLlxuICAgICAgICAgICAgICAvLyBTZWUgaHR0cHM6Ly9naXRodWIuY29tL0dvb2dsZUNocm9tZS93b3JrYm94L3B1bGwvMjEzNCNpc3N1ZWNvbW1lbnQtNTEzOTI0MzUzXG4gICAgICAgICAgICAgIHBhcmFtcyA9IHVuZGVmaW5lZDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIC8vIFJldHVybiBlYXJseSBpZiBoYXZlIGEgbWF0Y2guXG4gICAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgICByb3V0ZSxcbiAgICAgICAgICAgICAgcGFyYW1zXG4gICAgICAgICAgICB9O1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICAvLyBJZiBubyBtYXRjaCB3YXMgZm91bmQgYWJvdmUsIHJldHVybiBhbmQgZW1wdHkgb2JqZWN0LlxuICAgICAgICByZXR1cm4ge307XG4gICAgICB9XG4gICAgICAvKipcbiAgICAgICAqIERlZmluZSBhIGRlZmF1bHQgYGhhbmRsZXJgIHRoYXQncyBjYWxsZWQgd2hlbiBubyByb3V0ZXMgZXhwbGljaXRseVxuICAgICAgICogbWF0Y2ggdGhlIGluY29taW5nIHJlcXVlc3QuXG4gICAgICAgKlxuICAgICAgICogRWFjaCBIVFRQIG1ldGhvZCAoJ0dFVCcsICdQT1NUJywgZXRjLikgZ2V0cyBpdHMgb3duIGRlZmF1bHQgaGFuZGxlci5cbiAgICAgICAqXG4gICAgICAgKiBXaXRob3V0IGEgZGVmYXVsdCBoYW5kbGVyLCB1bm1hdGNoZWQgcmVxdWVzdHMgd2lsbCBnbyBhZ2FpbnN0IHRoZVxuICAgICAgICogbmV0d29yayBhcyBpZiB0aGVyZSB3ZXJlIG5vIHNlcnZpY2Ugd29ya2VyIHByZXNlbnQuXG4gICAgICAgKlxuICAgICAgICogQHBhcmFtIHt3b3JrYm94LXJvdXRpbmd+aGFuZGxlckNhbGxiYWNrfSBoYW5kbGVyIEEgY2FsbGJhY2tcbiAgICAgICAqIGZ1bmN0aW9uIHRoYXQgcmV0dXJucyBhIFByb21pc2UgcmVzdWx0aW5nIGluIGEgUmVzcG9uc2UuXG4gICAgICAgKiBAcGFyYW0ge3N0cmluZ30gW21ldGhvZD0nR0VUJ10gVGhlIEhUVFAgbWV0aG9kIHRvIGFzc29jaWF0ZSB3aXRoIHRoaXNcbiAgICAgICAqIGRlZmF1bHQgaGFuZGxlci4gRWFjaCBtZXRob2QgaGFzIGl0cyBvd24gZGVmYXVsdC5cbiAgICAgICAqL1xuICAgICAgc2V0RGVmYXVsdEhhbmRsZXIoaGFuZGxlciwgbWV0aG9kID0gZGVmYXVsdE1ldGhvZCkge1xuICAgICAgICB0aGlzLl9kZWZhdWx0SGFuZGxlck1hcC5zZXQobWV0aG9kLCBub3JtYWxpemVIYW5kbGVyKGhhbmRsZXIpKTtcbiAgICAgIH1cbiAgICAgIC8qKlxuICAgICAgICogSWYgYSBSb3V0ZSB0aHJvd3MgYW4gZXJyb3Igd2hpbGUgaGFuZGxpbmcgYSByZXF1ZXN0LCB0aGlzIGBoYW5kbGVyYFxuICAgICAgICogd2lsbCBiZSBjYWxsZWQgYW5kIGdpdmVuIGEgY2hhbmNlIHRvIHByb3ZpZGUgYSByZXNwb25zZS5cbiAgICAgICAqXG4gICAgICAgKiBAcGFyYW0ge3dvcmtib3gtcm91dGluZ35oYW5kbGVyQ2FsbGJhY2t9IGhhbmRsZXIgQSBjYWxsYmFja1xuICAgICAgICogZnVuY3Rpb24gdGhhdCByZXR1cm5zIGEgUHJvbWlzZSByZXN1bHRpbmcgaW4gYSBSZXNwb25zZS5cbiAgICAgICAqL1xuICAgICAgc2V0Q2F0Y2hIYW5kbGVyKGhhbmRsZXIpIHtcbiAgICAgICAgdGhpcy5fY2F0Y2hIYW5kbGVyID0gbm9ybWFsaXplSGFuZGxlcihoYW5kbGVyKTtcbiAgICAgIH1cbiAgICAgIC8qKlxuICAgICAgICogUmVnaXN0ZXJzIGEgcm91dGUgd2l0aCB0aGUgcm91dGVyLlxuICAgICAgICpcbiAgICAgICAqIEBwYXJhbSB7d29ya2JveC1yb3V0aW5nLlJvdXRlfSByb3V0ZSBUaGUgcm91dGUgdG8gcmVnaXN0ZXIuXG4gICAgICAgKi9cbiAgICAgIHJlZ2lzdGVyUm91dGUocm91dGUpIHtcbiAgICAgICAge1xuICAgICAgICAgIGZpbmFsQXNzZXJ0RXhwb3J0cy5pc1R5cGUocm91dGUsICdvYmplY3QnLCB7XG4gICAgICAgICAgICBtb2R1bGVOYW1lOiAnd29ya2JveC1yb3V0aW5nJyxcbiAgICAgICAgICAgIGNsYXNzTmFtZTogJ1JvdXRlcicsXG4gICAgICAgICAgICBmdW5jTmFtZTogJ3JlZ2lzdGVyUm91dGUnLFxuICAgICAgICAgICAgcGFyYW1OYW1lOiAncm91dGUnXG4gICAgICAgICAgfSk7XG4gICAgICAgICAgZmluYWxBc3NlcnRFeHBvcnRzLmhhc01ldGhvZChyb3V0ZSwgJ21hdGNoJywge1xuICAgICAgICAgICAgbW9kdWxlTmFtZTogJ3dvcmtib3gtcm91dGluZycsXG4gICAgICAgICAgICBjbGFzc05hbWU6ICdSb3V0ZXInLFxuICAgICAgICAgICAgZnVuY05hbWU6ICdyZWdpc3RlclJvdXRlJyxcbiAgICAgICAgICAgIHBhcmFtTmFtZTogJ3JvdXRlJ1xuICAgICAgICAgIH0pO1xuICAgICAgICAgIGZpbmFsQXNzZXJ0RXhwb3J0cy5pc1R5cGUocm91dGUuaGFuZGxlciwgJ29iamVjdCcsIHtcbiAgICAgICAgICAgIG1vZHVsZU5hbWU6ICd3b3JrYm94LXJvdXRpbmcnLFxuICAgICAgICAgICAgY2xhc3NOYW1lOiAnUm91dGVyJyxcbiAgICAgICAgICAgIGZ1bmNOYW1lOiAncmVnaXN0ZXJSb3V0ZScsXG4gICAgICAgICAgICBwYXJhbU5hbWU6ICdyb3V0ZSdcbiAgICAgICAgICB9KTtcbiAgICAgICAgICBmaW5hbEFzc2VydEV4cG9ydHMuaGFzTWV0aG9kKHJvdXRlLmhhbmRsZXIsICdoYW5kbGUnLCB7XG4gICAgICAgICAgICBtb2R1bGVOYW1lOiAnd29ya2JveC1yb3V0aW5nJyxcbiAgICAgICAgICAgIGNsYXNzTmFtZTogJ1JvdXRlcicsXG4gICAgICAgICAgICBmdW5jTmFtZTogJ3JlZ2lzdGVyUm91dGUnLFxuICAgICAgICAgICAgcGFyYW1OYW1lOiAncm91dGUuaGFuZGxlcidcbiAgICAgICAgICB9KTtcbiAgICAgICAgICBmaW5hbEFzc2VydEV4cG9ydHMuaXNUeXBlKHJvdXRlLm1ldGhvZCwgJ3N0cmluZycsIHtcbiAgICAgICAgICAgIG1vZHVsZU5hbWU6ICd3b3JrYm94LXJvdXRpbmcnLFxuICAgICAgICAgICAgY2xhc3NOYW1lOiAnUm91dGVyJyxcbiAgICAgICAgICAgIGZ1bmNOYW1lOiAncmVnaXN0ZXJSb3V0ZScsXG4gICAgICAgICAgICBwYXJhbU5hbWU6ICdyb3V0ZS5tZXRob2QnXG4gICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKCF0aGlzLl9yb3V0ZXMuaGFzKHJvdXRlLm1ldGhvZCkpIHtcbiAgICAgICAgICB0aGlzLl9yb3V0ZXMuc2V0KHJvdXRlLm1ldGhvZCwgW10pO1xuICAgICAgICB9XG4gICAgICAgIC8vIEdpdmUgcHJlY2VkZW5jZSB0byBhbGwgb2YgdGhlIGVhcmxpZXIgcm91dGVzIGJ5IGFkZGluZyB0aGlzIGFkZGl0aW9uYWxcbiAgICAgICAgLy8gcm91dGUgdG8gdGhlIGVuZCBvZiB0aGUgYXJyYXkuXG4gICAgICAgIHRoaXMuX3JvdXRlcy5nZXQocm91dGUubWV0aG9kKS5wdXNoKHJvdXRlKTtcbiAgICAgIH1cbiAgICAgIC8qKlxuICAgICAgICogVW5yZWdpc3RlcnMgYSByb3V0ZSB3aXRoIHRoZSByb3V0ZXIuXG4gICAgICAgKlxuICAgICAgICogQHBhcmFtIHt3b3JrYm94LXJvdXRpbmcuUm91dGV9IHJvdXRlIFRoZSByb3V0ZSB0byB1bnJlZ2lzdGVyLlxuICAgICAgICovXG4gICAgICB1bnJlZ2lzdGVyUm91dGUocm91dGUpIHtcbiAgICAgICAgaWYgKCF0aGlzLl9yb3V0ZXMuaGFzKHJvdXRlLm1ldGhvZCkpIHtcbiAgICAgICAgICB0aHJvdyBuZXcgV29ya2JveEVycm9yKCd1bnJlZ2lzdGVyLXJvdXRlLWJ1dC1ub3QtZm91bmQtd2l0aC1tZXRob2QnLCB7XG4gICAgICAgICAgICBtZXRob2Q6IHJvdXRlLm1ldGhvZFxuICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IHJvdXRlSW5kZXggPSB0aGlzLl9yb3V0ZXMuZ2V0KHJvdXRlLm1ldGhvZCkuaW5kZXhPZihyb3V0ZSk7XG4gICAgICAgIGlmIChyb3V0ZUluZGV4ID4gLTEpIHtcbiAgICAgICAgICB0aGlzLl9yb3V0ZXMuZ2V0KHJvdXRlLm1ldGhvZCkuc3BsaWNlKHJvdXRlSW5kZXgsIDEpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIHRocm93IG5ldyBXb3JrYm94RXJyb3IoJ3VucmVnaXN0ZXItcm91dGUtcm91dGUtbm90LXJlZ2lzdGVyZWQnKTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH1cblxuICAgIC8qXG4gICAgICBDb3B5cmlnaHQgMjAxOSBHb29nbGUgTExDXG5cbiAgICAgIFVzZSBvZiB0aGlzIHNvdXJjZSBjb2RlIGlzIGdvdmVybmVkIGJ5IGFuIE1JVC1zdHlsZVxuICAgICAgbGljZW5zZSB0aGF0IGNhbiBiZSBmb3VuZCBpbiB0aGUgTElDRU5TRSBmaWxlIG9yIGF0XG4gICAgICBodHRwczovL29wZW5zb3VyY2Uub3JnL2xpY2Vuc2VzL01JVC5cbiAgICAqL1xuICAgIGxldCBkZWZhdWx0Um91dGVyO1xuICAgIC8qKlxuICAgICAqIENyZWF0ZXMgYSBuZXcsIHNpbmdsZXRvbiBSb3V0ZXIgaW5zdGFuY2UgaWYgb25lIGRvZXMgbm90IGV4aXN0LiBJZiBvbmVcbiAgICAgKiBkb2VzIGFscmVhZHkgZXhpc3QsIHRoYXQgaW5zdGFuY2UgaXMgcmV0dXJuZWQuXG4gICAgICpcbiAgICAgKiBAcHJpdmF0ZVxuICAgICAqIEByZXR1cm4ge1JvdXRlcn1cbiAgICAgKi9cbiAgICBjb25zdCBnZXRPckNyZWF0ZURlZmF1bHRSb3V0ZXIgPSAoKSA9PiB7XG4gICAgICBpZiAoIWRlZmF1bHRSb3V0ZXIpIHtcbiAgICAgICAgZGVmYXVsdFJvdXRlciA9IG5ldyBSb3V0ZXIoKTtcbiAgICAgICAgLy8gVGhlIGhlbHBlcnMgdGhhdCB1c2UgdGhlIGRlZmF1bHQgUm91dGVyIGFzc3VtZSB0aGVzZSBsaXN0ZW5lcnMgZXhpc3QuXG4gICAgICAgIGRlZmF1bHRSb3V0ZXIuYWRkRmV0Y2hMaXN0ZW5lcigpO1xuICAgICAgICBkZWZhdWx0Um91dGVyLmFkZENhY2hlTGlzdGVuZXIoKTtcbiAgICAgIH1cbiAgICAgIHJldHVybiBkZWZhdWx0Um91dGVyO1xuICAgIH07XG5cbiAgICAvKlxuICAgICAgQ29weXJpZ2h0IDIwMTkgR29vZ2xlIExMQ1xuXG4gICAgICBVc2Ugb2YgdGhpcyBzb3VyY2UgY29kZSBpcyBnb3Zlcm5lZCBieSBhbiBNSVQtc3R5bGVcbiAgICAgIGxpY2Vuc2UgdGhhdCBjYW4gYmUgZm91bmQgaW4gdGhlIExJQ0VOU0UgZmlsZSBvciBhdFxuICAgICAgaHR0cHM6Ly9vcGVuc291cmNlLm9yZy9saWNlbnNlcy9NSVQuXG4gICAgKi9cbiAgICAvKipcbiAgICAgKiBFYXNpbHkgcmVnaXN0ZXIgYSBSZWdFeHAsIHN0cmluZywgb3IgZnVuY3Rpb24gd2l0aCBhIGNhY2hpbmdcbiAgICAgKiBzdHJhdGVneSB0byBhIHNpbmdsZXRvbiBSb3V0ZXIgaW5zdGFuY2UuXG4gICAgICpcbiAgICAgKiBUaGlzIG1ldGhvZCB3aWxsIGdlbmVyYXRlIGEgUm91dGUgZm9yIHlvdSBpZiBuZWVkZWQgYW5kXG4gICAgICogY2FsbCB7QGxpbmsgd29ya2JveC1yb3V0aW5nLlJvdXRlciNyZWdpc3RlclJvdXRlfS5cbiAgICAgKlxuICAgICAqIEBwYXJhbSB7UmVnRXhwfHN0cmluZ3x3b3JrYm94LXJvdXRpbmcuUm91dGV+bWF0Y2hDYWxsYmFja3x3b3JrYm94LXJvdXRpbmcuUm91dGV9IGNhcHR1cmVcbiAgICAgKiBJZiB0aGUgY2FwdHVyZSBwYXJhbSBpcyBhIGBSb3V0ZWAsIGFsbCBvdGhlciBhcmd1bWVudHMgd2lsbCBiZSBpZ25vcmVkLlxuICAgICAqIEBwYXJhbSB7d29ya2JveC1yb3V0aW5nfmhhbmRsZXJDYWxsYmFja30gW2hhbmRsZXJdIEEgY2FsbGJhY2tcbiAgICAgKiBmdW5jdGlvbiB0aGF0IHJldHVybnMgYSBQcm9taXNlIHJlc3VsdGluZyBpbiBhIFJlc3BvbnNlLiBUaGlzIHBhcmFtZXRlclxuICAgICAqIGlzIHJlcXVpcmVkIGlmIGBjYXB0dXJlYCBpcyBub3QgYSBgUm91dGVgIG9iamVjdC5cbiAgICAgKiBAcGFyYW0ge3N0cmluZ30gW21ldGhvZD0nR0VUJ10gVGhlIEhUVFAgbWV0aG9kIHRvIG1hdGNoIHRoZSBSb3V0ZVxuICAgICAqIGFnYWluc3QuXG4gICAgICogQHJldHVybiB7d29ya2JveC1yb3V0aW5nLlJvdXRlfSBUaGUgZ2VuZXJhdGVkIGBSb3V0ZWAuXG4gICAgICpcbiAgICAgKiBAbWVtYmVyb2Ygd29ya2JveC1yb3V0aW5nXG4gICAgICovXG4gICAgZnVuY3Rpb24gcmVnaXN0ZXJSb3V0ZShjYXB0dXJlLCBoYW5kbGVyLCBtZXRob2QpIHtcbiAgICAgIGxldCByb3V0ZTtcbiAgICAgIGlmICh0eXBlb2YgY2FwdHVyZSA9PT0gJ3N0cmluZycpIHtcbiAgICAgICAgY29uc3QgY2FwdHVyZVVybCA9IG5ldyBVUkwoY2FwdHVyZSwgbG9jYXRpb24uaHJlZik7XG4gICAgICAgIHtcbiAgICAgICAgICBpZiAoIShjYXB0dXJlLnN0YXJ0c1dpdGgoJy8nKSB8fCBjYXB0dXJlLnN0YXJ0c1dpdGgoJ2h0dHAnKSkpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBXb3JrYm94RXJyb3IoJ2ludmFsaWQtc3RyaW5nJywge1xuICAgICAgICAgICAgICBtb2R1bGVOYW1lOiAnd29ya2JveC1yb3V0aW5nJyxcbiAgICAgICAgICAgICAgZnVuY05hbWU6ICdyZWdpc3RlclJvdXRlJyxcbiAgICAgICAgICAgICAgcGFyYW1OYW1lOiAnY2FwdHVyZSdcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgIH1cbiAgICAgICAgICAvLyBXZSB3YW50IHRvIGNoZWNrIGlmIEV4cHJlc3Mtc3R5bGUgd2lsZGNhcmRzIGFyZSBpbiB0aGUgcGF0aG5hbWUgb25seS5cbiAgICAgICAgICAvLyBUT0RPOiBSZW1vdmUgdGhpcyBsb2cgbWVzc2FnZSBpbiB2NC5cbiAgICAgICAgICBjb25zdCB2YWx1ZVRvQ2hlY2sgPSBjYXB0dXJlLnN0YXJ0c1dpdGgoJ2h0dHAnKSA/IGNhcHR1cmVVcmwucGF0aG5hbWUgOiBjYXB0dXJlO1xuICAgICAgICAgIC8vIFNlZSBodHRwczovL2dpdGh1Yi5jb20vcGlsbGFyanMvcGF0aC10by1yZWdleHAjcGFyYW1ldGVyc1xuICAgICAgICAgIGNvbnN0IHdpbGRjYXJkcyA9ICdbKjo/K10nO1xuICAgICAgICAgIGlmIChuZXcgUmVnRXhwKGAke3dpbGRjYXJkc31gKS5leGVjKHZhbHVlVG9DaGVjaykpIHtcbiAgICAgICAgICAgIGxvZ2dlci5kZWJ1ZyhgVGhlICckY2FwdHVyZScgcGFyYW1ldGVyIGNvbnRhaW5zIGFuIEV4cHJlc3Mtc3R5bGUgd2lsZGNhcmQgYCArIGBjaGFyYWN0ZXIgKCR7d2lsZGNhcmRzfSkuIFN0cmluZ3MgYXJlIG5vdyBhbHdheXMgaW50ZXJwcmV0ZWQgYXMgYCArIGBleGFjdCBtYXRjaGVzOyB1c2UgYSBSZWdFeHAgZm9yIHBhcnRpYWwgb3Igd2lsZGNhcmQgbWF0Y2hlcy5gKTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgbWF0Y2hDYWxsYmFjayA9ICh7XG4gICAgICAgICAgdXJsXG4gICAgICAgIH0pID0+IHtcbiAgICAgICAgICB7XG4gICAgICAgICAgICBpZiAodXJsLnBhdGhuYW1lID09PSBjYXB0dXJlVXJsLnBhdGhuYW1lICYmIHVybC5vcmlnaW4gIT09IGNhcHR1cmVVcmwub3JpZ2luKSB7XG4gICAgICAgICAgICAgIGxvZ2dlci5kZWJ1ZyhgJHtjYXB0dXJlfSBvbmx5IHBhcnRpYWxseSBtYXRjaGVzIHRoZSBjcm9zcy1vcmlnaW4gVVJMIGAgKyBgJHt1cmwudG9TdHJpbmcoKX0uIFRoaXMgcm91dGUgd2lsbCBvbmx5IGhhbmRsZSBjcm9zcy1vcmlnaW4gcmVxdWVzdHMgYCArIGBpZiB0aGV5IG1hdGNoIHRoZSBlbnRpcmUgVVJMLmApO1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH1cbiAgICAgICAgICByZXR1cm4gdXJsLmhyZWYgPT09IGNhcHR1cmVVcmwuaHJlZjtcbiAgICAgICAgfTtcbiAgICAgICAgLy8gSWYgYGNhcHR1cmVgIGlzIGEgc3RyaW5nIHRoZW4gYGhhbmRsZXJgIGFuZCBgbWV0aG9kYCBtdXN0IGJlIHByZXNlbnQuXG4gICAgICAgIHJvdXRlID0gbmV3IFJvdXRlKG1hdGNoQ2FsbGJhY2ssIGhhbmRsZXIsIG1ldGhvZCk7XG4gICAgICB9IGVsc2UgaWYgKGNhcHR1cmUgaW5zdGFuY2VvZiBSZWdFeHApIHtcbiAgICAgICAgLy8gSWYgYGNhcHR1cmVgIGlzIGEgYFJlZ0V4cGAgdGhlbiBgaGFuZGxlcmAgYW5kIGBtZXRob2RgIG11c3QgYmUgcHJlc2VudC5cbiAgICAgICAgcm91dGUgPSBuZXcgUmVnRXhwUm91dGUoY2FwdHVyZSwgaGFuZGxlciwgbWV0aG9kKTtcbiAgICAgIH0gZWxzZSBpZiAodHlwZW9mIGNhcHR1cmUgPT09ICdmdW5jdGlvbicpIHtcbiAgICAgICAgLy8gSWYgYGNhcHR1cmVgIGlzIGEgZnVuY3Rpb24gdGhlbiBgaGFuZGxlcmAgYW5kIGBtZXRob2RgIG11c3QgYmUgcHJlc2VudC5cbiAgICAgICAgcm91dGUgPSBuZXcgUm91dGUoY2FwdHVyZSwgaGFuZGxlciwgbWV0aG9kKTtcbiAgICAgIH0gZWxzZSBpZiAoY2FwdHVyZSBpbnN0YW5jZW9mIFJvdXRlKSB7XG4gICAgICAgIHJvdXRlID0gY2FwdHVyZTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHRocm93IG5ldyBXb3JrYm94RXJyb3IoJ3Vuc3VwcG9ydGVkLXJvdXRlLXR5cGUnLCB7XG4gICAgICAgICAgbW9kdWxlTmFtZTogJ3dvcmtib3gtcm91dGluZycsXG4gICAgICAgICAgZnVuY05hbWU6ICdyZWdpc3RlclJvdXRlJyxcbiAgICAgICAgICBwYXJhbU5hbWU6ICdjYXB0dXJlJ1xuICAgICAgICB9KTtcbiAgICAgIH1cbiAgICAgIGNvbnN0IGRlZmF1bHRSb3V0ZXIgPSBnZXRPckNyZWF0ZURlZmF1bHRSb3V0ZXIoKTtcbiAgICAgIGRlZmF1bHRSb3V0ZXIucmVnaXN0ZXJSb3V0ZShyb3V0ZSk7XG4gICAgICByZXR1cm4gcm91dGU7XG4gICAgfVxuXG4gICAgLypcbiAgICAgIENvcHlyaWdodCAyMDE4IEdvb2dsZSBMTENcblxuICAgICAgVXNlIG9mIHRoaXMgc291cmNlIGNvZGUgaXMgZ292ZXJuZWQgYnkgYW4gTUlULXN0eWxlXG4gICAgICBsaWNlbnNlIHRoYXQgY2FuIGJlIGZvdW5kIGluIHRoZSBMSUNFTlNFIGZpbGUgb3IgYXRcbiAgICAgIGh0dHBzOi8vb3BlbnNvdXJjZS5vcmcvbGljZW5zZXMvTUlULlxuICAgICovXG4gICAgY29uc3QgX2NhY2hlTmFtZURldGFpbHMgPSB7XG4gICAgICBnb29nbGVBbmFseXRpY3M6ICdnb29nbGVBbmFseXRpY3MnLFxuICAgICAgcHJlY2FjaGU6ICdwcmVjYWNoZS12MicsXG4gICAgICBwcmVmaXg6ICd3b3JrYm94JyxcbiAgICAgIHJ1bnRpbWU6ICdydW50aW1lJyxcbiAgICAgIHN1ZmZpeDogdHlwZW9mIHJlZ2lzdHJhdGlvbiAhPT0gJ3VuZGVmaW5lZCcgPyByZWdpc3RyYXRpb24uc2NvcGUgOiAnJ1xuICAgIH07XG4gICAgY29uc3QgX2NyZWF0ZUNhY2hlTmFtZSA9IGNhY2hlTmFtZSA9PiB7XG4gICAgICByZXR1cm4gW19jYWNoZU5hbWVEZXRhaWxzLnByZWZpeCwgY2FjaGVOYW1lLCBfY2FjaGVOYW1lRGV0YWlscy5zdWZmaXhdLmZpbHRlcih2YWx1ZSA9PiB2YWx1ZSAmJiB2YWx1ZS5sZW5ndGggPiAwKS5qb2luKCctJyk7XG4gICAgfTtcbiAgICBjb25zdCBlYWNoQ2FjaGVOYW1lRGV0YWlsID0gZm4gPT4ge1xuICAgICAgZm9yIChjb25zdCBrZXkgb2YgT2JqZWN0LmtleXMoX2NhY2hlTmFtZURldGFpbHMpKSB7XG4gICAgICAgIGZuKGtleSk7XG4gICAgICB9XG4gICAgfTtcbiAgICBjb25zdCBjYWNoZU5hbWVzID0ge1xuICAgICAgdXBkYXRlRGV0YWlsczogZGV0YWlscyA9PiB7XG4gICAgICAgIGVhY2hDYWNoZU5hbWVEZXRhaWwoa2V5ID0+IHtcbiAgICAgICAgICBpZiAodHlwZW9mIGRldGFpbHNba2V5XSA9PT0gJ3N0cmluZycpIHtcbiAgICAgICAgICAgIF9jYWNoZU5hbWVEZXRhaWxzW2tleV0gPSBkZXRhaWxzW2tleV07XG4gICAgICAgICAgfVxuICAgICAgICB9KTtcbiAgICAgIH0sXG4gICAgICBnZXRHb29nbGVBbmFseXRpY3NOYW1lOiB1c2VyQ2FjaGVOYW1lID0+IHtcbiAgICAgICAgcmV0dXJuIHVzZXJDYWNoZU5hbWUgfHwgX2NyZWF0ZUNhY2hlTmFtZShfY2FjaGVOYW1lRGV0YWlscy5nb29nbGVBbmFseXRpY3MpO1xuICAgICAgfSxcbiAgICAgIGdldFByZWNhY2hlTmFtZTogdXNlckNhY2hlTmFtZSA9PiB7XG4gICAgICAgIHJldHVybiB1c2VyQ2FjaGVOYW1lIHx8IF9jcmVhdGVDYWNoZU5hbWUoX2NhY2hlTmFtZURldGFpbHMucHJlY2FjaGUpO1xuICAgICAgfSxcbiAgICAgIGdldFByZWZpeDogKCkgPT4ge1xuICAgICAgICByZXR1cm4gX2NhY2hlTmFtZURldGFpbHMucHJlZml4O1xuICAgICAgfSxcbiAgICAgIGdldFJ1bnRpbWVOYW1lOiB1c2VyQ2FjaGVOYW1lID0+IHtcbiAgICAgICAgcmV0dXJuIHVzZXJDYWNoZU5hbWUgfHwgX2NyZWF0ZUNhY2hlTmFtZShfY2FjaGVOYW1lRGV0YWlscy5ydW50aW1lKTtcbiAgICAgIH0sXG4gICAgICBnZXRTdWZmaXg6ICgpID0+IHtcbiAgICAgICAgcmV0dXJuIF9jYWNoZU5hbWVEZXRhaWxzLnN1ZmZpeDtcbiAgICAgIH1cbiAgICB9O1xuXG4gICAgLypcbiAgICAgIENvcHlyaWdodCAyMDE5IEdvb2dsZSBMTENcbiAgICAgIFVzZSBvZiB0aGlzIHNvdXJjZSBjb2RlIGlzIGdvdmVybmVkIGJ5IGFuIE1JVC1zdHlsZVxuICAgICAgbGljZW5zZSB0aGF0IGNhbiBiZSBmb3VuZCBpbiB0aGUgTElDRU5TRSBmaWxlIG9yIGF0XG4gICAgICBodHRwczovL29wZW5zb3VyY2Uub3JnL2xpY2Vuc2VzL01JVC5cbiAgICAqL1xuICAgIC8qKlxuICAgICAqIEEgaGVscGVyIGZ1bmN0aW9uIHRoYXQgcHJldmVudHMgYSBwcm9taXNlIGZyb20gYmVpbmcgZmxhZ2dlZCBhcyB1bnVzZWQuXG4gICAgICpcbiAgICAgKiBAcHJpdmF0ZVxuICAgICAqKi9cbiAgICBmdW5jdGlvbiBkb250V2FpdEZvcihwcm9taXNlKSB7XG4gICAgICAvLyBFZmZlY3RpdmUgbm8tb3AuXG4gICAgICB2b2lkIHByb21pc2UudGhlbigoKSA9PiB7fSk7XG4gICAgfVxuXG4gICAgLypcbiAgICAgIENvcHlyaWdodCAyMDE4IEdvb2dsZSBMTENcblxuICAgICAgVXNlIG9mIHRoaXMgc291cmNlIGNvZGUgaXMgZ292ZXJuZWQgYnkgYW4gTUlULXN0eWxlXG4gICAgICBsaWNlbnNlIHRoYXQgY2FuIGJlIGZvdW5kIGluIHRoZSBMSUNFTlNFIGZpbGUgb3IgYXRcbiAgICAgIGh0dHBzOi8vb3BlbnNvdXJjZS5vcmcvbGljZW5zZXMvTUlULlxuICAgICovXG4gICAgLy8gQ2FsbGJhY2tzIHRvIGJlIGV4ZWN1dGVkIHdoZW5ldmVyIHRoZXJlJ3MgYSBxdW90YSBlcnJvci5cbiAgICAvLyBDYW4ndCBjaGFuZ2UgRnVuY3Rpb24gdHlwZSByaWdodCBub3cuXG4gICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIEB0eXBlc2NyaXB0LWVzbGludC9iYW4tdHlwZXNcbiAgICBjb25zdCBxdW90YUVycm9yQ2FsbGJhY2tzID0gbmV3IFNldCgpO1xuXG4gICAgLypcbiAgICAgIENvcHlyaWdodCAyMDE5IEdvb2dsZSBMTENcblxuICAgICAgVXNlIG9mIHRoaXMgc291cmNlIGNvZGUgaXMgZ292ZXJuZWQgYnkgYW4gTUlULXN0eWxlXG4gICAgICBsaWNlbnNlIHRoYXQgY2FuIGJlIGZvdW5kIGluIHRoZSBMSUNFTlNFIGZpbGUgb3IgYXRcbiAgICAgIGh0dHBzOi8vb3BlbnNvdXJjZS5vcmcvbGljZW5zZXMvTUlULlxuICAgICovXG4gICAgLyoqXG4gICAgICogQWRkcyBhIGZ1bmN0aW9uIHRvIHRoZSBzZXQgb2YgcXVvdGFFcnJvckNhbGxiYWNrcyB0aGF0IHdpbGwgYmUgZXhlY3V0ZWQgaWZcbiAgICAgKiB0aGVyZSdzIGEgcXVvdGEgZXJyb3IuXG4gICAgICpcbiAgICAgKiBAcGFyYW0ge0Z1bmN0aW9ufSBjYWxsYmFja1xuICAgICAqIEBtZW1iZXJvZiB3b3JrYm94LWNvcmVcbiAgICAgKi9cbiAgICAvLyBDYW4ndCBjaGFuZ2UgRnVuY3Rpb24gdHlwZVxuICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBAdHlwZXNjcmlwdC1lc2xpbnQvYmFuLXR5cGVzXG4gICAgZnVuY3Rpb24gcmVnaXN0ZXJRdW90YUVycm9yQ2FsbGJhY2soY2FsbGJhY2spIHtcbiAgICAgIHtcbiAgICAgICAgZmluYWxBc3NlcnRFeHBvcnRzLmlzVHlwZShjYWxsYmFjaywgJ2Z1bmN0aW9uJywge1xuICAgICAgICAgIG1vZHVsZU5hbWU6ICd3b3JrYm94LWNvcmUnLFxuICAgICAgICAgIGZ1bmNOYW1lOiAncmVnaXN0ZXInLFxuICAgICAgICAgIHBhcmFtTmFtZTogJ2NhbGxiYWNrJ1xuICAgICAgICB9KTtcbiAgICAgIH1cbiAgICAgIHF1b3RhRXJyb3JDYWxsYmFja3MuYWRkKGNhbGxiYWNrKTtcbiAgICAgIHtcbiAgICAgICAgbG9nZ2VyLmxvZygnUmVnaXN0ZXJlZCBhIGNhbGxiYWNrIHRvIHJlc3BvbmQgdG8gcXVvdGEgZXJyb3JzLicsIGNhbGxiYWNrKTtcbiAgICAgIH1cbiAgICB9XG5cbiAgICBmdW5jdGlvbiBfZXh0ZW5kcygpIHtcbiAgICAgIHJldHVybiBfZXh0ZW5kcyA9IE9iamVjdC5hc3NpZ24gPyBPYmplY3QuYXNzaWduLmJpbmQoKSA6IGZ1bmN0aW9uIChuKSB7XG4gICAgICAgIGZvciAodmFyIGUgPSAxOyBlIDwgYXJndW1lbnRzLmxlbmd0aDsgZSsrKSB7XG4gICAgICAgICAgdmFyIHQgPSBhcmd1bWVudHNbZV07XG4gICAgICAgICAgZm9yICh2YXIgciBpbiB0KSAoe30pLmhhc093blByb3BlcnR5LmNhbGwodCwgcikgJiYgKG5bcl0gPSB0W3JdKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gbjtcbiAgICAgIH0sIF9leHRlbmRzLmFwcGx5KG51bGwsIGFyZ3VtZW50cyk7XG4gICAgfVxuXG4gICAgY29uc3QgaW5zdGFuY2VPZkFueSA9IChvYmplY3QsIGNvbnN0cnVjdG9ycykgPT4gY29uc3RydWN0b3JzLnNvbWUoYyA9PiBvYmplY3QgaW5zdGFuY2VvZiBjKTtcbiAgICBsZXQgaWRiUHJveHlhYmxlVHlwZXM7XG4gICAgbGV0IGN1cnNvckFkdmFuY2VNZXRob2RzO1xuICAgIC8vIFRoaXMgaXMgYSBmdW5jdGlvbiB0byBwcmV2ZW50IGl0IHRocm93aW5nIHVwIGluIG5vZGUgZW52aXJvbm1lbnRzLlxuICAgIGZ1bmN0aW9uIGdldElkYlByb3h5YWJsZVR5cGVzKCkge1xuICAgICAgcmV0dXJuIGlkYlByb3h5YWJsZVR5cGVzIHx8IChpZGJQcm94eWFibGVUeXBlcyA9IFtJREJEYXRhYmFzZSwgSURCT2JqZWN0U3RvcmUsIElEQkluZGV4LCBJREJDdXJzb3IsIElEQlRyYW5zYWN0aW9uXSk7XG4gICAgfVxuICAgIC8vIFRoaXMgaXMgYSBmdW5jdGlvbiB0byBwcmV2ZW50IGl0IHRocm93aW5nIHVwIGluIG5vZGUgZW52aXJvbm1lbnRzLlxuICAgIGZ1bmN0aW9uIGdldEN1cnNvckFkdmFuY2VNZXRob2RzKCkge1xuICAgICAgcmV0dXJuIGN1cnNvckFkdmFuY2VNZXRob2RzIHx8IChjdXJzb3JBZHZhbmNlTWV0aG9kcyA9IFtJREJDdXJzb3IucHJvdG90eXBlLmFkdmFuY2UsIElEQkN1cnNvci5wcm90b3R5cGUuY29udGludWUsIElEQkN1cnNvci5wcm90b3R5cGUuY29udGludWVQcmltYXJ5S2V5XSk7XG4gICAgfVxuICAgIGNvbnN0IGN1cnNvclJlcXVlc3RNYXAgPSBuZXcgV2Vha01hcCgpO1xuICAgIGNvbnN0IHRyYW5zYWN0aW9uRG9uZU1hcCA9IG5ldyBXZWFrTWFwKCk7XG4gICAgY29uc3QgdHJhbnNhY3Rpb25TdG9yZU5hbWVzTWFwID0gbmV3IFdlYWtNYXAoKTtcbiAgICBjb25zdCB0cmFuc2Zvcm1DYWNoZSA9IG5ldyBXZWFrTWFwKCk7XG4gICAgY29uc3QgcmV2ZXJzZVRyYW5zZm9ybUNhY2hlID0gbmV3IFdlYWtNYXAoKTtcbiAgICBmdW5jdGlvbiBwcm9taXNpZnlSZXF1ZXN0KHJlcXVlc3QpIHtcbiAgICAgIGNvbnN0IHByb21pc2UgPSBuZXcgUHJvbWlzZSgocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XG4gICAgICAgIGNvbnN0IHVubGlzdGVuID0gKCkgPT4ge1xuICAgICAgICAgIHJlcXVlc3QucmVtb3ZlRXZlbnRMaXN0ZW5lcignc3VjY2VzcycsIHN1Y2Nlc3MpO1xuICAgICAgICAgIHJlcXVlc3QucmVtb3ZlRXZlbnRMaXN0ZW5lcignZXJyb3InLCBlcnJvcik7XG4gICAgICAgIH07XG4gICAgICAgIGNvbnN0IHN1Y2Nlc3MgPSAoKSA9PiB7XG4gICAgICAgICAgcmVzb2x2ZSh3cmFwKHJlcXVlc3QucmVzdWx0KSk7XG4gICAgICAgICAgdW5saXN0ZW4oKTtcbiAgICAgICAgfTtcbiAgICAgICAgY29uc3QgZXJyb3IgPSAoKSA9PiB7XG4gICAgICAgICAgcmVqZWN0KHJlcXVlc3QuZXJyb3IpO1xuICAgICAgICAgIHVubGlzdGVuKCk7XG4gICAgICAgIH07XG4gICAgICAgIHJlcXVlc3QuYWRkRXZlbnRMaXN0ZW5lcignc3VjY2VzcycsIHN1Y2Nlc3MpO1xuICAgICAgICByZXF1ZXN0LmFkZEV2ZW50TGlzdGVuZXIoJ2Vycm9yJywgZXJyb3IpO1xuICAgICAgfSk7XG4gICAgICBwcm9taXNlLnRoZW4odmFsdWUgPT4ge1xuICAgICAgICAvLyBTaW5jZSBjdXJzb3JpbmcgcmV1c2VzIHRoZSBJREJSZXF1ZXN0ICgqc2lnaCopLCB3ZSBjYWNoZSBpdCBmb3IgbGF0ZXIgcmV0cmlldmFsXG4gICAgICAgIC8vIChzZWUgd3JhcEZ1bmN0aW9uKS5cbiAgICAgICAgaWYgKHZhbHVlIGluc3RhbmNlb2YgSURCQ3Vyc29yKSB7XG4gICAgICAgICAgY3Vyc29yUmVxdWVzdE1hcC5zZXQodmFsdWUsIHJlcXVlc3QpO1xuICAgICAgICB9XG4gICAgICAgIC8vIENhdGNoaW5nIHRvIGF2b2lkIFwiVW5jYXVnaHQgUHJvbWlzZSBleGNlcHRpb25zXCJcbiAgICAgIH0pLmNhdGNoKCgpID0+IHt9KTtcbiAgICAgIC8vIFRoaXMgbWFwcGluZyBleGlzdHMgaW4gcmV2ZXJzZVRyYW5zZm9ybUNhY2hlIGJ1dCBkb2Vzbid0IGRvZXNuJ3QgZXhpc3QgaW4gdHJhbnNmb3JtQ2FjaGUuIFRoaXNcbiAgICAgIC8vIGlzIGJlY2F1c2Ugd2UgY3JlYXRlIG1hbnkgcHJvbWlzZXMgZnJvbSBhIHNpbmdsZSBJREJSZXF1ZXN0LlxuICAgICAgcmV2ZXJzZVRyYW5zZm9ybUNhY2hlLnNldChwcm9taXNlLCByZXF1ZXN0KTtcbiAgICAgIHJldHVybiBwcm9taXNlO1xuICAgIH1cbiAgICBmdW5jdGlvbiBjYWNoZURvbmVQcm9taXNlRm9yVHJhbnNhY3Rpb24odHgpIHtcbiAgICAgIC8vIEVhcmx5IGJhaWwgaWYgd2UndmUgYWxyZWFkeSBjcmVhdGVkIGEgZG9uZSBwcm9taXNlIGZvciB0aGlzIHRyYW5zYWN0aW9uLlxuICAgICAgaWYgKHRyYW5zYWN0aW9uRG9uZU1hcC5oYXModHgpKSByZXR1cm47XG4gICAgICBjb25zdCBkb25lID0gbmV3IFByb21pc2UoKHJlc29sdmUsIHJlamVjdCkgPT4ge1xuICAgICAgICBjb25zdCB1bmxpc3RlbiA9ICgpID0+IHtcbiAgICAgICAgICB0eC5yZW1vdmVFdmVudExpc3RlbmVyKCdjb21wbGV0ZScsIGNvbXBsZXRlKTtcbiAgICAgICAgICB0eC5yZW1vdmVFdmVudExpc3RlbmVyKCdlcnJvcicsIGVycm9yKTtcbiAgICAgICAgICB0eC5yZW1vdmVFdmVudExpc3RlbmVyKCdhYm9ydCcsIGVycm9yKTtcbiAgICAgICAgfTtcbiAgICAgICAgY29uc3QgY29tcGxldGUgPSAoKSA9PiB7XG4gICAgICAgICAgcmVzb2x2ZSgpO1xuICAgICAgICAgIHVubGlzdGVuKCk7XG4gICAgICAgIH07XG4gICAgICAgIGNvbnN0IGVycm9yID0gKCkgPT4ge1xuICAgICAgICAgIHJlamVjdCh0eC5lcnJvciB8fCBuZXcgRE9NRXhjZXB0aW9uKCdBYm9ydEVycm9yJywgJ0Fib3J0RXJyb3InKSk7XG4gICAgICAgICAgdW5saXN0ZW4oKTtcbiAgICAgICAgfTtcbiAgICAgICAgdHguYWRkRXZlbnRMaXN0ZW5lcignY29tcGxldGUnLCBjb21wbGV0ZSk7XG4gICAgICAgIHR4LmFkZEV2ZW50TGlzdGVuZXIoJ2Vycm9yJywgZXJyb3IpO1xuICAgICAgICB0eC5hZGRFdmVudExpc3RlbmVyKCdhYm9ydCcsIGVycm9yKTtcbiAgICAgIH0pO1xuICAgICAgLy8gQ2FjaGUgaXQgZm9yIGxhdGVyIHJldHJpZXZhbC5cbiAgICAgIHRyYW5zYWN0aW9uRG9uZU1hcC5zZXQodHgsIGRvbmUpO1xuICAgIH1cbiAgICBsZXQgaWRiUHJveHlUcmFwcyA9IHtcbiAgICAgIGdldCh0YXJnZXQsIHByb3AsIHJlY2VpdmVyKSB7XG4gICAgICAgIGlmICh0YXJnZXQgaW5zdGFuY2VvZiBJREJUcmFuc2FjdGlvbikge1xuICAgICAgICAgIC8vIFNwZWNpYWwgaGFuZGxpbmcgZm9yIHRyYW5zYWN0aW9uLmRvbmUuXG4gICAgICAgICAgaWYgKHByb3AgPT09ICdkb25lJykgcmV0dXJuIHRyYW5zYWN0aW9uRG9uZU1hcC5nZXQodGFyZ2V0KTtcbiAgICAgICAgICAvLyBQb2x5ZmlsbCBmb3Igb2JqZWN0U3RvcmVOYW1lcyBiZWNhdXNlIG9mIEVkZ2UuXG4gICAgICAgICAgaWYgKHByb3AgPT09ICdvYmplY3RTdG9yZU5hbWVzJykge1xuICAgICAgICAgICAgcmV0dXJuIHRhcmdldC5vYmplY3RTdG9yZU5hbWVzIHx8IHRyYW5zYWN0aW9uU3RvcmVOYW1lc01hcC5nZXQodGFyZ2V0KTtcbiAgICAgICAgICB9XG4gICAgICAgICAgLy8gTWFrZSB0eC5zdG9yZSByZXR1cm4gdGhlIG9ubHkgc3RvcmUgaW4gdGhlIHRyYW5zYWN0aW9uLCBvciB1bmRlZmluZWQgaWYgdGhlcmUgYXJlIG1hbnkuXG4gICAgICAgICAgaWYgKHByb3AgPT09ICdzdG9yZScpIHtcbiAgICAgICAgICAgIHJldHVybiByZWNlaXZlci5vYmplY3RTdG9yZU5hbWVzWzFdID8gdW5kZWZpbmVkIDogcmVjZWl2ZXIub2JqZWN0U3RvcmUocmVjZWl2ZXIub2JqZWN0U3RvcmVOYW1lc1swXSk7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIC8vIEVsc2UgdHJhbnNmb3JtIHdoYXRldmVyIHdlIGdldCBiYWNrLlxuICAgICAgICByZXR1cm4gd3JhcCh0YXJnZXRbcHJvcF0pO1xuICAgICAgfSxcbiAgICAgIHNldCh0YXJnZXQsIHByb3AsIHZhbHVlKSB7XG4gICAgICAgIHRhcmdldFtwcm9wXSA9IHZhbHVlO1xuICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgIH0sXG4gICAgICBoYXModGFyZ2V0LCBwcm9wKSB7XG4gICAgICAgIGlmICh0YXJnZXQgaW5zdGFuY2VvZiBJREJUcmFuc2FjdGlvbiAmJiAocHJvcCA9PT0gJ2RvbmUnIHx8IHByb3AgPT09ICdzdG9yZScpKSB7XG4gICAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHByb3AgaW4gdGFyZ2V0O1xuICAgICAgfVxuICAgIH07XG4gICAgZnVuY3Rpb24gcmVwbGFjZVRyYXBzKGNhbGxiYWNrKSB7XG4gICAgICBpZGJQcm94eVRyYXBzID0gY2FsbGJhY2soaWRiUHJveHlUcmFwcyk7XG4gICAgfVxuICAgIGZ1bmN0aW9uIHdyYXBGdW5jdGlvbihmdW5jKSB7XG4gICAgICAvLyBEdWUgdG8gZXhwZWN0ZWQgb2JqZWN0IGVxdWFsaXR5ICh3aGljaCBpcyBlbmZvcmNlZCBieSB0aGUgY2FjaGluZyBpbiBgd3JhcGApLCB3ZVxuICAgICAgLy8gb25seSBjcmVhdGUgb25lIG5ldyBmdW5jIHBlciBmdW5jLlxuICAgICAgLy8gRWRnZSBkb2Vzbid0IHN1cHBvcnQgb2JqZWN0U3RvcmVOYW1lcyAoYm9vbyksIHNvIHdlIHBvbHlmaWxsIGl0IGhlcmUuXG4gICAgICBpZiAoZnVuYyA9PT0gSURCRGF0YWJhc2UucHJvdG90eXBlLnRyYW5zYWN0aW9uICYmICEoJ29iamVjdFN0b3JlTmFtZXMnIGluIElEQlRyYW5zYWN0aW9uLnByb3RvdHlwZSkpIHtcbiAgICAgICAgcmV0dXJuIGZ1bmN0aW9uIChzdG9yZU5hbWVzLCAuLi5hcmdzKSB7XG4gICAgICAgICAgY29uc3QgdHggPSBmdW5jLmNhbGwodW53cmFwKHRoaXMpLCBzdG9yZU5hbWVzLCAuLi5hcmdzKTtcbiAgICAgICAgICB0cmFuc2FjdGlvblN0b3JlTmFtZXNNYXAuc2V0KHR4LCBzdG9yZU5hbWVzLnNvcnQgPyBzdG9yZU5hbWVzLnNvcnQoKSA6IFtzdG9yZU5hbWVzXSk7XG4gICAgICAgICAgcmV0dXJuIHdyYXAodHgpO1xuICAgICAgICB9O1xuICAgICAgfVxuICAgICAgLy8gQ3Vyc29yIG1ldGhvZHMgYXJlIHNwZWNpYWwsIGFzIHRoZSBiZWhhdmlvdXIgaXMgYSBsaXR0bGUgbW9yZSBkaWZmZXJlbnQgdG8gc3RhbmRhcmQgSURCLiBJblxuICAgICAgLy8gSURCLCB5b3UgYWR2YW5jZSB0aGUgY3Vyc29yIGFuZCB3YWl0IGZvciBhIG5ldyAnc3VjY2Vzcycgb24gdGhlIElEQlJlcXVlc3QgdGhhdCBnYXZlIHlvdSB0aGVcbiAgICAgIC8vIGN1cnNvci4gSXQncyBraW5kYSBsaWtlIGEgcHJvbWlzZSB0aGF0IGNhbiByZXNvbHZlIHdpdGggbWFueSB2YWx1ZXMuIFRoYXQgZG9lc24ndCBtYWtlIHNlbnNlXG4gICAgICAvLyB3aXRoIHJlYWwgcHJvbWlzZXMsIHNvIGVhY2ggYWR2YW5jZSBtZXRob2RzIHJldHVybnMgYSBuZXcgcHJvbWlzZSBmb3IgdGhlIGN1cnNvciBvYmplY3QsIG9yXG4gICAgICAvLyB1bmRlZmluZWQgaWYgdGhlIGVuZCBvZiB0aGUgY3Vyc29yIGhhcyBiZWVuIHJlYWNoZWQuXG4gICAgICBpZiAoZ2V0Q3Vyc29yQWR2YW5jZU1ldGhvZHMoKS5pbmNsdWRlcyhmdW5jKSkge1xuICAgICAgICByZXR1cm4gZnVuY3Rpb24gKC4uLmFyZ3MpIHtcbiAgICAgICAgICAvLyBDYWxsaW5nIHRoZSBvcmlnaW5hbCBmdW5jdGlvbiB3aXRoIHRoZSBwcm94eSBhcyAndGhpcycgY2F1c2VzIElMTEVHQUwgSU5WT0NBVElPTiwgc28gd2UgdXNlXG4gICAgICAgICAgLy8gdGhlIG9yaWdpbmFsIG9iamVjdC5cbiAgICAgICAgICBmdW5jLmFwcGx5KHVud3JhcCh0aGlzKSwgYXJncyk7XG4gICAgICAgICAgcmV0dXJuIHdyYXAoY3Vyc29yUmVxdWVzdE1hcC5nZXQodGhpcykpO1xuICAgICAgICB9O1xuICAgICAgfVxuICAgICAgcmV0dXJuIGZ1bmN0aW9uICguLi5hcmdzKSB7XG4gICAgICAgIC8vIENhbGxpbmcgdGhlIG9yaWdpbmFsIGZ1bmN0aW9uIHdpdGggdGhlIHByb3h5IGFzICd0aGlzJyBjYXVzZXMgSUxMRUdBTCBJTlZPQ0FUSU9OLCBzbyB3ZSB1c2VcbiAgICAgICAgLy8gdGhlIG9yaWdpbmFsIG9iamVjdC5cbiAgICAgICAgcmV0dXJuIHdyYXAoZnVuYy5hcHBseSh1bndyYXAodGhpcyksIGFyZ3MpKTtcbiAgICAgIH07XG4gICAgfVxuICAgIGZ1bmN0aW9uIHRyYW5zZm9ybUNhY2hhYmxlVmFsdWUodmFsdWUpIHtcbiAgICAgIGlmICh0eXBlb2YgdmFsdWUgPT09ICdmdW5jdGlvbicpIHJldHVybiB3cmFwRnVuY3Rpb24odmFsdWUpO1xuICAgICAgLy8gVGhpcyBkb2Vzbid0IHJldHVybiwgaXQganVzdCBjcmVhdGVzIGEgJ2RvbmUnIHByb21pc2UgZm9yIHRoZSB0cmFuc2FjdGlvbixcbiAgICAgIC8vIHdoaWNoIGlzIGxhdGVyIHJldHVybmVkIGZvciB0cmFuc2FjdGlvbi5kb25lIChzZWUgaWRiT2JqZWN0SGFuZGxlcikuXG4gICAgICBpZiAodmFsdWUgaW5zdGFuY2VvZiBJREJUcmFuc2FjdGlvbikgY2FjaGVEb25lUHJvbWlzZUZvclRyYW5zYWN0aW9uKHZhbHVlKTtcbiAgICAgIGlmIChpbnN0YW5jZU9mQW55KHZhbHVlLCBnZXRJZGJQcm94eWFibGVUeXBlcygpKSkgcmV0dXJuIG5ldyBQcm94eSh2YWx1ZSwgaWRiUHJveHlUcmFwcyk7XG4gICAgICAvLyBSZXR1cm4gdGhlIHNhbWUgdmFsdWUgYmFjayBpZiB3ZSdyZSBub3QgZ29pbmcgdG8gdHJhbnNmb3JtIGl0LlxuICAgICAgcmV0dXJuIHZhbHVlO1xuICAgIH1cbiAgICBmdW5jdGlvbiB3cmFwKHZhbHVlKSB7XG4gICAgICAvLyBXZSBzb21ldGltZXMgZ2VuZXJhdGUgbXVsdGlwbGUgcHJvbWlzZXMgZnJvbSBhIHNpbmdsZSBJREJSZXF1ZXN0IChlZyB3aGVuIGN1cnNvcmluZyksIGJlY2F1c2VcbiAgICAgIC8vIElEQiBpcyB3ZWlyZCBhbmQgYSBzaW5nbGUgSURCUmVxdWVzdCBjYW4geWllbGQgbWFueSByZXNwb25zZXMsIHNvIHRoZXNlIGNhbid0IGJlIGNhY2hlZC5cbiAgICAgIGlmICh2YWx1ZSBpbnN0YW5jZW9mIElEQlJlcXVlc3QpIHJldHVybiBwcm9taXNpZnlSZXF1ZXN0KHZhbHVlKTtcbiAgICAgIC8vIElmIHdlJ3ZlIGFscmVhZHkgdHJhbnNmb3JtZWQgdGhpcyB2YWx1ZSBiZWZvcmUsIHJldXNlIHRoZSB0cmFuc2Zvcm1lZCB2YWx1ZS5cbiAgICAgIC8vIFRoaXMgaXMgZmFzdGVyLCBidXQgaXQgYWxzbyBwcm92aWRlcyBvYmplY3QgZXF1YWxpdHkuXG4gICAgICBpZiAodHJhbnNmb3JtQ2FjaGUuaGFzKHZhbHVlKSkgcmV0dXJuIHRyYW5zZm9ybUNhY2hlLmdldCh2YWx1ZSk7XG4gICAgICBjb25zdCBuZXdWYWx1ZSA9IHRyYW5zZm9ybUNhY2hhYmxlVmFsdWUodmFsdWUpO1xuICAgICAgLy8gTm90IGFsbCB0eXBlcyBhcmUgdHJhbnNmb3JtZWQuXG4gICAgICAvLyBUaGVzZSBtYXkgYmUgcHJpbWl0aXZlIHR5cGVzLCBzbyB0aGV5IGNhbid0IGJlIFdlYWtNYXAga2V5cy5cbiAgICAgIGlmIChuZXdWYWx1ZSAhPT0gdmFsdWUpIHtcbiAgICAgICAgdHJhbnNmb3JtQ2FjaGUuc2V0KHZhbHVlLCBuZXdWYWx1ZSk7XG4gICAgICAgIHJldmVyc2VUcmFuc2Zvcm1DYWNoZS5zZXQobmV3VmFsdWUsIHZhbHVlKTtcbiAgICAgIH1cbiAgICAgIHJldHVybiBuZXdWYWx1ZTtcbiAgICB9XG4gICAgY29uc3QgdW53cmFwID0gdmFsdWUgPT4gcmV2ZXJzZVRyYW5zZm9ybUNhY2hlLmdldCh2YWx1ZSk7XG5cbiAgICAvKipcbiAgICAgKiBPcGVuIGEgZGF0YWJhc2UuXG4gICAgICpcbiAgICAgKiBAcGFyYW0gbmFtZSBOYW1lIG9mIHRoZSBkYXRhYmFzZS5cbiAgICAgKiBAcGFyYW0gdmVyc2lvbiBTY2hlbWEgdmVyc2lvbi5cbiAgICAgKiBAcGFyYW0gY2FsbGJhY2tzIEFkZGl0aW9uYWwgY2FsbGJhY2tzLlxuICAgICAqL1xuICAgIGZ1bmN0aW9uIG9wZW5EQihuYW1lLCB2ZXJzaW9uLCB7XG4gICAgICBibG9ja2VkLFxuICAgICAgdXBncmFkZSxcbiAgICAgIGJsb2NraW5nLFxuICAgICAgdGVybWluYXRlZFxuICAgIH0gPSB7fSkge1xuICAgICAgY29uc3QgcmVxdWVzdCA9IGluZGV4ZWREQi5vcGVuKG5hbWUsIHZlcnNpb24pO1xuICAgICAgY29uc3Qgb3BlblByb21pc2UgPSB3cmFwKHJlcXVlc3QpO1xuICAgICAgaWYgKHVwZ3JhZGUpIHtcbiAgICAgICAgcmVxdWVzdC5hZGRFdmVudExpc3RlbmVyKCd1cGdyYWRlbmVlZGVkJywgZXZlbnQgPT4ge1xuICAgICAgICAgIHVwZ3JhZGUod3JhcChyZXF1ZXN0LnJlc3VsdCksIGV2ZW50Lm9sZFZlcnNpb24sIGV2ZW50Lm5ld1ZlcnNpb24sIHdyYXAocmVxdWVzdC50cmFuc2FjdGlvbiksIGV2ZW50KTtcbiAgICAgICAgfSk7XG4gICAgICB9XG4gICAgICBpZiAoYmxvY2tlZCkge1xuICAgICAgICByZXF1ZXN0LmFkZEV2ZW50TGlzdGVuZXIoJ2Jsb2NrZWQnLCBldmVudCA9PiBibG9ja2VkKFxuICAgICAgICAvLyBDYXN0aW5nIGR1ZSB0byBodHRwczovL2dpdGh1Yi5jb20vbWljcm9zb2Z0L1R5cGVTY3JpcHQtRE9NLWxpYi1nZW5lcmF0b3IvcHVsbC8xNDA1XG4gICAgICAgIGV2ZW50Lm9sZFZlcnNpb24sIGV2ZW50Lm5ld1ZlcnNpb24sIGV2ZW50KSk7XG4gICAgICB9XG4gICAgICBvcGVuUHJvbWlzZS50aGVuKGRiID0+IHtcbiAgICAgICAgaWYgKHRlcm1pbmF0ZWQpIGRiLmFkZEV2ZW50TGlzdGVuZXIoJ2Nsb3NlJywgKCkgPT4gdGVybWluYXRlZCgpKTtcbiAgICAgICAgaWYgKGJsb2NraW5nKSB7XG4gICAgICAgICAgZGIuYWRkRXZlbnRMaXN0ZW5lcigndmVyc2lvbmNoYW5nZScsIGV2ZW50ID0+IGJsb2NraW5nKGV2ZW50Lm9sZFZlcnNpb24sIGV2ZW50Lm5ld1ZlcnNpb24sIGV2ZW50KSk7XG4gICAgICAgIH1cbiAgICAgIH0pLmNhdGNoKCgpID0+IHt9KTtcbiAgICAgIHJldHVybiBvcGVuUHJvbWlzZTtcbiAgICB9XG4gICAgLyoqXG4gICAgICogRGVsZXRlIGEgZGF0YWJhc2UuXG4gICAgICpcbiAgICAgKiBAcGFyYW0gbmFtZSBOYW1lIG9mIHRoZSBkYXRhYmFzZS5cbiAgICAgKi9cbiAgICBmdW5jdGlvbiBkZWxldGVEQihuYW1lLCB7XG4gICAgICBibG9ja2VkXG4gICAgfSA9IHt9KSB7XG4gICAgICBjb25zdCByZXF1ZXN0ID0gaW5kZXhlZERCLmRlbGV0ZURhdGFiYXNlKG5hbWUpO1xuICAgICAgaWYgKGJsb2NrZWQpIHtcbiAgICAgICAgcmVxdWVzdC5hZGRFdmVudExpc3RlbmVyKCdibG9ja2VkJywgZXZlbnQgPT4gYmxvY2tlZChcbiAgICAgICAgLy8gQ2FzdGluZyBkdWUgdG8gaHR0cHM6Ly9naXRodWIuY29tL21pY3Jvc29mdC9UeXBlU2NyaXB0LURPTS1saWItZ2VuZXJhdG9yL3B1bGwvMTQwNVxuICAgICAgICBldmVudC5vbGRWZXJzaW9uLCBldmVudCkpO1xuICAgICAgfVxuICAgICAgcmV0dXJuIHdyYXAocmVxdWVzdCkudGhlbigoKSA9PiB1bmRlZmluZWQpO1xuICAgIH1cbiAgICBjb25zdCByZWFkTWV0aG9kcyA9IFsnZ2V0JywgJ2dldEtleScsICdnZXRBbGwnLCAnZ2V0QWxsS2V5cycsICdjb3VudCddO1xuICAgIGNvbnN0IHdyaXRlTWV0aG9kcyA9IFsncHV0JywgJ2FkZCcsICdkZWxldGUnLCAnY2xlYXInXTtcbiAgICBjb25zdCBjYWNoZWRNZXRob2RzID0gbmV3IE1hcCgpO1xuICAgIGZ1bmN0aW9uIGdldE1ldGhvZCh0YXJnZXQsIHByb3ApIHtcbiAgICAgIGlmICghKHRhcmdldCBpbnN0YW5jZW9mIElEQkRhdGFiYXNlICYmICEocHJvcCBpbiB0YXJnZXQpICYmIHR5cGVvZiBwcm9wID09PSAnc3RyaW5nJykpIHtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgICAgaWYgKGNhY2hlZE1ldGhvZHMuZ2V0KHByb3ApKSByZXR1cm4gY2FjaGVkTWV0aG9kcy5nZXQocHJvcCk7XG4gICAgICBjb25zdCB0YXJnZXRGdW5jTmFtZSA9IHByb3AucmVwbGFjZSgvRnJvbUluZGV4JC8sICcnKTtcbiAgICAgIGNvbnN0IHVzZUluZGV4ID0gcHJvcCAhPT0gdGFyZ2V0RnVuY05hbWU7XG4gICAgICBjb25zdCBpc1dyaXRlID0gd3JpdGVNZXRob2RzLmluY2x1ZGVzKHRhcmdldEZ1bmNOYW1lKTtcbiAgICAgIGlmIChcbiAgICAgIC8vIEJhaWwgaWYgdGhlIHRhcmdldCBkb2Vzbid0IGV4aXN0IG9uIHRoZSB0YXJnZXQuIEVnLCBnZXRBbGwgaXNuJ3QgaW4gRWRnZS5cbiAgICAgICEodGFyZ2V0RnVuY05hbWUgaW4gKHVzZUluZGV4ID8gSURCSW5kZXggOiBJREJPYmplY3RTdG9yZSkucHJvdG90eXBlKSB8fCAhKGlzV3JpdGUgfHwgcmVhZE1ldGhvZHMuaW5jbHVkZXModGFyZ2V0RnVuY05hbWUpKSkge1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgICBjb25zdCBtZXRob2QgPSBhc3luYyBmdW5jdGlvbiAoc3RvcmVOYW1lLCAuLi5hcmdzKSB7XG4gICAgICAgIC8vIGlzV3JpdGUgPyAncmVhZHdyaXRlJyA6IHVuZGVmaW5lZCBnemlwcHMgYmV0dGVyLCBidXQgZmFpbHMgaW4gRWRnZSA6KFxuICAgICAgICBjb25zdCB0eCA9IHRoaXMudHJhbnNhY3Rpb24oc3RvcmVOYW1lLCBpc1dyaXRlID8gJ3JlYWR3cml0ZScgOiAncmVhZG9ubHknKTtcbiAgICAgICAgbGV0IHRhcmdldCA9IHR4LnN0b3JlO1xuICAgICAgICBpZiAodXNlSW5kZXgpIHRhcmdldCA9IHRhcmdldC5pbmRleChhcmdzLnNoaWZ0KCkpO1xuICAgICAgICAvLyBNdXN0IHJlamVjdCBpZiBvcCByZWplY3RzLlxuICAgICAgICAvLyBJZiBpdCdzIGEgd3JpdGUgb3BlcmF0aW9uLCBtdXN0IHJlamVjdCBpZiB0eC5kb25lIHJlamVjdHMuXG4gICAgICAgIC8vIE11c3QgcmVqZWN0IHdpdGggb3AgcmVqZWN0aW9uIGZpcnN0LlxuICAgICAgICAvLyBNdXN0IHJlc29sdmUgd2l0aCBvcCB2YWx1ZS5cbiAgICAgICAgLy8gTXVzdCBoYW5kbGUgYm90aCBwcm9taXNlcyAobm8gdW5oYW5kbGVkIHJlamVjdGlvbnMpXG4gICAgICAgIHJldHVybiAoYXdhaXQgUHJvbWlzZS5hbGwoW3RhcmdldFt0YXJnZXRGdW5jTmFtZV0oLi4uYXJncyksIGlzV3JpdGUgJiYgdHguZG9uZV0pKVswXTtcbiAgICAgIH07XG4gICAgICBjYWNoZWRNZXRob2RzLnNldChwcm9wLCBtZXRob2QpO1xuICAgICAgcmV0dXJuIG1ldGhvZDtcbiAgICB9XG4gICAgcmVwbGFjZVRyYXBzKG9sZFRyYXBzID0+IF9leHRlbmRzKHt9LCBvbGRUcmFwcywge1xuICAgICAgZ2V0OiAodGFyZ2V0LCBwcm9wLCByZWNlaXZlcikgPT4gZ2V0TWV0aG9kKHRhcmdldCwgcHJvcCkgfHwgb2xkVHJhcHMuZ2V0KHRhcmdldCwgcHJvcCwgcmVjZWl2ZXIpLFxuICAgICAgaGFzOiAodGFyZ2V0LCBwcm9wKSA9PiAhIWdldE1ldGhvZCh0YXJnZXQsIHByb3ApIHx8IG9sZFRyYXBzLmhhcyh0YXJnZXQsIHByb3ApXG4gICAgfSkpO1xuXG4gICAgLy8gQHRzLWlnbm9yZVxuICAgIHRyeSB7XG4gICAgICBzZWxmWyd3b3JrYm94OmV4cGlyYXRpb246Ny40LjAnXSAmJiBfKCk7XG4gICAgfSBjYXRjaCAoZSkge31cblxuICAgIC8qXG4gICAgICBDb3B5cmlnaHQgMjAxOCBHb29nbGUgTExDXG5cbiAgICAgIFVzZSBvZiB0aGlzIHNvdXJjZSBjb2RlIGlzIGdvdmVybmVkIGJ5IGFuIE1JVC1zdHlsZVxuICAgICAgbGljZW5zZSB0aGF0IGNhbiBiZSBmb3VuZCBpbiB0aGUgTElDRU5TRSBmaWxlIG9yIGF0XG4gICAgICBodHRwczovL29wZW5zb3VyY2Uub3JnL2xpY2Vuc2VzL01JVC5cbiAgICAqL1xuICAgIGNvbnN0IERCX05BTUUgPSAnd29ya2JveC1leHBpcmF0aW9uJztcbiAgICBjb25zdCBDQUNIRV9PQkpFQ1RfU1RPUkUgPSAnY2FjaGUtZW50cmllcyc7XG4gICAgY29uc3Qgbm9ybWFsaXplVVJMID0gdW5Ob3JtYWxpemVkVXJsID0+IHtcbiAgICAgIGNvbnN0IHVybCA9IG5ldyBVUkwodW5Ob3JtYWxpemVkVXJsLCBsb2NhdGlvbi5ocmVmKTtcbiAgICAgIHVybC5oYXNoID0gJyc7XG4gICAgICByZXR1cm4gdXJsLmhyZWY7XG4gICAgfTtcbiAgICAvKipcbiAgICAgKiBSZXR1cm5zIHRoZSB0aW1lc3RhbXAgbW9kZWwuXG4gICAgICpcbiAgICAgKiBAcHJpdmF0ZVxuICAgICAqL1xuICAgIGNsYXNzIENhY2hlVGltZXN0YW1wc01vZGVsIHtcbiAgICAgIC8qKlxuICAgICAgICpcbiAgICAgICAqIEBwYXJhbSB7c3RyaW5nfSBjYWNoZU5hbWVcbiAgICAgICAqXG4gICAgICAgKiBAcHJpdmF0ZVxuICAgICAgICovXG4gICAgICBjb25zdHJ1Y3RvcihjYWNoZU5hbWUpIHtcbiAgICAgICAgdGhpcy5fZGIgPSBudWxsO1xuICAgICAgICB0aGlzLl9jYWNoZU5hbWUgPSBjYWNoZU5hbWU7XG4gICAgICB9XG4gICAgICAvKipcbiAgICAgICAqIFBlcmZvcm1zIGFuIHVwZ3JhZGUgb2YgaW5kZXhlZERCLlxuICAgICAgICpcbiAgICAgICAqIEBwYXJhbSB7SURCUERhdGFiYXNlPENhY2hlRGJTY2hlbWE+fSBkYlxuICAgICAgICpcbiAgICAgICAqIEBwcml2YXRlXG4gICAgICAgKi9cbiAgICAgIF91cGdyYWRlRGIoZGIpIHtcbiAgICAgICAgLy8gVE9ETyhwaGlsaXB3YWx0b24pOiBFZGdlSFRNTCBkb2Vzbid0IHN1cHBvcnQgYXJyYXlzIGFzIGEga2V5UGF0aCwgc28gd2VcbiAgICAgICAgLy8gaGF2ZSB0byB1c2UgdGhlIGBpZGAga2V5UGF0aCBoZXJlIGFuZCBjcmVhdGUgb3VyIG93biB2YWx1ZXMgKGFcbiAgICAgICAgLy8gY29uY2F0ZW5hdGlvbiBvZiBgdXJsICsgY2FjaGVOYW1lYCkgaW5zdGVhZCBvZiBzaW1wbHkgdXNpbmdcbiAgICAgICAgLy8gYGtleVBhdGg6IFsndXJsJywgJ2NhY2hlTmFtZSddYCwgd2hpY2ggaXMgc3VwcG9ydGVkIGluIG90aGVyIGJyb3dzZXJzLlxuICAgICAgICBjb25zdCBvYmpTdG9yZSA9IGRiLmNyZWF0ZU9iamVjdFN0b3JlKENBQ0hFX09CSkVDVF9TVE9SRSwge1xuICAgICAgICAgIGtleVBhdGg6ICdpZCdcbiAgICAgICAgfSk7XG4gICAgICAgIC8vIFRPRE8ocGhpbGlwd2FsdG9uKTogb25jZSB3ZSBkb24ndCBoYXZlIHRvIHN1cHBvcnQgRWRnZUhUTUwsIHdlIGNhblxuICAgICAgICAvLyBjcmVhdGUgYSBzaW5nbGUgaW5kZXggd2l0aCB0aGUga2V5UGF0aCBgWydjYWNoZU5hbWUnLCAndGltZXN0YW1wJ11gXG4gICAgICAgIC8vIGluc3RlYWQgb2YgZG9pbmcgYm90aCB0aGVzZSBpbmRleGVzLlxuICAgICAgICBvYmpTdG9yZS5jcmVhdGVJbmRleCgnY2FjaGVOYW1lJywgJ2NhY2hlTmFtZScsIHtcbiAgICAgICAgICB1bmlxdWU6IGZhbHNlXG4gICAgICAgIH0pO1xuICAgICAgICBvYmpTdG9yZS5jcmVhdGVJbmRleCgndGltZXN0YW1wJywgJ3RpbWVzdGFtcCcsIHtcbiAgICAgICAgICB1bmlxdWU6IGZhbHNlXG4gICAgICAgIH0pO1xuICAgICAgfVxuICAgICAgLyoqXG4gICAgICAgKiBQZXJmb3JtcyBhbiB1cGdyYWRlIG9mIGluZGV4ZWREQiBhbmQgZGVsZXRlcyBkZXByZWNhdGVkIERCcy5cbiAgICAgICAqXG4gICAgICAgKiBAcGFyYW0ge0lEQlBEYXRhYmFzZTxDYWNoZURiU2NoZW1hPn0gZGJcbiAgICAgICAqXG4gICAgICAgKiBAcHJpdmF0ZVxuICAgICAgICovXG4gICAgICBfdXBncmFkZURiQW5kRGVsZXRlT2xkRGJzKGRiKSB7XG4gICAgICAgIHRoaXMuX3VwZ3JhZGVEYihkYik7XG4gICAgICAgIGlmICh0aGlzLl9jYWNoZU5hbWUpIHtcbiAgICAgICAgICB2b2lkIGRlbGV0ZURCKHRoaXMuX2NhY2hlTmFtZSk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIC8qKlxuICAgICAgICogQHBhcmFtIHtzdHJpbmd9IHVybFxuICAgICAgICogQHBhcmFtIHtudW1iZXJ9IHRpbWVzdGFtcFxuICAgICAgICpcbiAgICAgICAqIEBwcml2YXRlXG4gICAgICAgKi9cbiAgICAgIGFzeW5jIHNldFRpbWVzdGFtcCh1cmwsIHRpbWVzdGFtcCkge1xuICAgICAgICB1cmwgPSBub3JtYWxpemVVUkwodXJsKTtcbiAgICAgICAgY29uc3QgZW50cnkgPSB7XG4gICAgICAgICAgdXJsLFxuICAgICAgICAgIHRpbWVzdGFtcCxcbiAgICAgICAgICBjYWNoZU5hbWU6IHRoaXMuX2NhY2hlTmFtZSxcbiAgICAgICAgICAvLyBDcmVhdGluZyBhbiBJRCBmcm9tIHRoZSBVUkwgYW5kIGNhY2hlIG5hbWUgd29uJ3QgYmUgbmVjZXNzYXJ5IG9uY2VcbiAgICAgICAgICAvLyBFZGdlIHN3aXRjaGVzIHRvIENocm9taXVtIGFuZCBhbGwgYnJvd3NlcnMgd2Ugc3VwcG9ydCB3b3JrIHdpdGhcbiAgICAgICAgICAvLyBhcnJheSBrZXlQYXRocy5cbiAgICAgICAgICBpZDogdGhpcy5fZ2V0SWQodXJsKVxuICAgICAgICB9O1xuICAgICAgICBjb25zdCBkYiA9IGF3YWl0IHRoaXMuZ2V0RGIoKTtcbiAgICAgICAgY29uc3QgdHggPSBkYi50cmFuc2FjdGlvbihDQUNIRV9PQkpFQ1RfU1RPUkUsICdyZWFkd3JpdGUnLCB7XG4gICAgICAgICAgZHVyYWJpbGl0eTogJ3JlbGF4ZWQnXG4gICAgICAgIH0pO1xuICAgICAgICBhd2FpdCB0eC5zdG9yZS5wdXQoZW50cnkpO1xuICAgICAgICBhd2FpdCB0eC5kb25lO1xuICAgICAgfVxuICAgICAgLyoqXG4gICAgICAgKiBSZXR1cm5zIHRoZSB0aW1lc3RhbXAgc3RvcmVkIGZvciBhIGdpdmVuIFVSTC5cbiAgICAgICAqXG4gICAgICAgKiBAcGFyYW0ge3N0cmluZ30gdXJsXG4gICAgICAgKiBAcmV0dXJuIHtudW1iZXIgfCB1bmRlZmluZWR9XG4gICAgICAgKlxuICAgICAgICogQHByaXZhdGVcbiAgICAgICAqL1xuICAgICAgYXN5bmMgZ2V0VGltZXN0YW1wKHVybCkge1xuICAgICAgICBjb25zdCBkYiA9IGF3YWl0IHRoaXMuZ2V0RGIoKTtcbiAgICAgICAgY29uc3QgZW50cnkgPSBhd2FpdCBkYi5nZXQoQ0FDSEVfT0JKRUNUX1NUT1JFLCB0aGlzLl9nZXRJZCh1cmwpKTtcbiAgICAgICAgcmV0dXJuIGVudHJ5ID09PSBudWxsIHx8IGVudHJ5ID09PSB2b2lkIDAgPyB2b2lkIDAgOiBlbnRyeS50aW1lc3RhbXA7XG4gICAgICB9XG4gICAgICAvKipcbiAgICAgICAqIEl0ZXJhdGVzIHRocm91Z2ggYWxsIHRoZSBlbnRyaWVzIGluIHRoZSBvYmplY3Qgc3RvcmUgKGZyb20gbmV3ZXN0IHRvXG4gICAgICAgKiBvbGRlc3QpIGFuZCByZW1vdmVzIGVudHJpZXMgb25jZSBlaXRoZXIgYG1heENvdW50YCBpcyByZWFjaGVkIG9yIHRoZVxuICAgICAgICogZW50cnkncyB0aW1lc3RhbXAgaXMgbGVzcyB0aGFuIGBtaW5UaW1lc3RhbXBgLlxuICAgICAgICpcbiAgICAgICAqIEBwYXJhbSB7bnVtYmVyfSBtaW5UaW1lc3RhbXBcbiAgICAgICAqIEBwYXJhbSB7bnVtYmVyfSBtYXhDb3VudFxuICAgICAgICogQHJldHVybiB7QXJyYXk8c3RyaW5nPn1cbiAgICAgICAqXG4gICAgICAgKiBAcHJpdmF0ZVxuICAgICAgICovXG4gICAgICBhc3luYyBleHBpcmVFbnRyaWVzKG1pblRpbWVzdGFtcCwgbWF4Q291bnQpIHtcbiAgICAgICAgY29uc3QgZGIgPSBhd2FpdCB0aGlzLmdldERiKCk7XG4gICAgICAgIGxldCBjdXJzb3IgPSBhd2FpdCBkYi50cmFuc2FjdGlvbihDQUNIRV9PQkpFQ1RfU1RPUkUpLnN0b3JlLmluZGV4KCd0aW1lc3RhbXAnKS5vcGVuQ3Vyc29yKG51bGwsICdwcmV2Jyk7XG4gICAgICAgIGNvbnN0IGVudHJpZXNUb0RlbGV0ZSA9IFtdO1xuICAgICAgICBsZXQgZW50cmllc05vdERlbGV0ZWRDb3VudCA9IDA7XG4gICAgICAgIHdoaWxlIChjdXJzb3IpIHtcbiAgICAgICAgICBjb25zdCByZXN1bHQgPSBjdXJzb3IudmFsdWU7XG4gICAgICAgICAgLy8gVE9ETyhwaGlsaXB3YWx0b24pOiBvbmNlIHdlIGNhbiB1c2UgYSBtdWx0aS1rZXkgaW5kZXgsIHdlXG4gICAgICAgICAgLy8gd29uJ3QgaGF2ZSB0byBjaGVjayBgY2FjaGVOYW1lYCBoZXJlLlxuICAgICAgICAgIGlmIChyZXN1bHQuY2FjaGVOYW1lID09PSB0aGlzLl9jYWNoZU5hbWUpIHtcbiAgICAgICAgICAgIC8vIERlbGV0ZSBhbiBlbnRyeSBpZiBpdCdzIG9sZGVyIHRoYW4gdGhlIG1heCBhZ2Ugb3JcbiAgICAgICAgICAgIC8vIGlmIHdlIGFscmVhZHkgaGF2ZSB0aGUgbWF4IG51bWJlciBhbGxvd2VkLlxuICAgICAgICAgICAgaWYgKG1pblRpbWVzdGFtcCAmJiByZXN1bHQudGltZXN0YW1wIDwgbWluVGltZXN0YW1wIHx8IG1heENvdW50ICYmIGVudHJpZXNOb3REZWxldGVkQ291bnQgPj0gbWF4Q291bnQpIHtcbiAgICAgICAgICAgICAgLy8gVE9ETyhwaGlsaXB3YWx0b24pOiB3ZSBzaG91bGQgYmUgYWJsZSB0byBkZWxldGUgdGhlXG4gICAgICAgICAgICAgIC8vIGVudHJ5IHJpZ2h0IGhlcmUsIGJ1dCBkb2luZyBzbyBjYXVzZXMgYW4gaXRlcmF0aW9uXG4gICAgICAgICAgICAgIC8vIGJ1ZyBpbiBTYWZhcmkgc3RhYmxlIChmaXhlZCBpbiBUUCkuIEluc3RlYWQgd2UgY2FuXG4gICAgICAgICAgICAgIC8vIHN0b3JlIHRoZSBrZXlzIG9mIHRoZSBlbnRyaWVzIHRvIGRlbGV0ZSwgYW5kIHRoZW5cbiAgICAgICAgICAgICAgLy8gZGVsZXRlIHRoZSBzZXBhcmF0ZSB0cmFuc2FjdGlvbnMuXG4gICAgICAgICAgICAgIC8vIGh0dHBzOi8vZ2l0aHViLmNvbS9Hb29nbGVDaHJvbWUvd29ya2JveC9pc3N1ZXMvMTk3OFxuICAgICAgICAgICAgICAvLyBjdXJzb3IuZGVsZXRlKCk7XG4gICAgICAgICAgICAgIC8vIFdlIG9ubHkgbmVlZCB0byByZXR1cm4gdGhlIFVSTCwgbm90IHRoZSB3aG9sZSBlbnRyeS5cbiAgICAgICAgICAgICAgZW50cmllc1RvRGVsZXRlLnB1c2goY3Vyc29yLnZhbHVlKTtcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgIGVudHJpZXNOb3REZWxldGVkQ291bnQrKztcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICAgICAgY3Vyc29yID0gYXdhaXQgY3Vyc29yLmNvbnRpbnVlKCk7XG4gICAgICAgIH1cbiAgICAgICAgLy8gVE9ETyhwaGlsaXB3YWx0b24pOiBvbmNlIHRoZSBTYWZhcmkgYnVnIGluIHRoZSBmb2xsb3dpbmcgaXNzdWUgaXMgZml4ZWQsXG4gICAgICAgIC8vIHdlIHNob3VsZCBiZSBhYmxlIHRvIHJlbW92ZSB0aGlzIGxvb3AgYW5kIGRvIHRoZSBlbnRyeSBkZWxldGlvbiBpbiB0aGVcbiAgICAgICAgLy8gY3Vyc29yIGxvb3AgYWJvdmU6XG4gICAgICAgIC8vIGh0dHBzOi8vZ2l0aHViLmNvbS9Hb29nbGVDaHJvbWUvd29ya2JveC9pc3N1ZXMvMTk3OFxuICAgICAgICBjb25zdCB1cmxzRGVsZXRlZCA9IFtdO1xuICAgICAgICBmb3IgKGNvbnN0IGVudHJ5IG9mIGVudHJpZXNUb0RlbGV0ZSkge1xuICAgICAgICAgIGF3YWl0IGRiLmRlbGV0ZShDQUNIRV9PQkpFQ1RfU1RPUkUsIGVudHJ5LmlkKTtcbiAgICAgICAgICB1cmxzRGVsZXRlZC5wdXNoKGVudHJ5LnVybCk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHVybHNEZWxldGVkO1xuICAgICAgfVxuICAgICAgLyoqXG4gICAgICAgKiBUYWtlcyBhIFVSTCBhbmQgcmV0dXJucyBhbiBJRCB0aGF0IHdpbGwgYmUgdW5pcXVlIGluIHRoZSBvYmplY3Qgc3RvcmUuXG4gICAgICAgKlxuICAgICAgICogQHBhcmFtIHtzdHJpbmd9IHVybFxuICAgICAgICogQHJldHVybiB7c3RyaW5nfVxuICAgICAgICpcbiAgICAgICAqIEBwcml2YXRlXG4gICAgICAgKi9cbiAgICAgIF9nZXRJZCh1cmwpIHtcbiAgICAgICAgLy8gQ3JlYXRpbmcgYW4gSUQgZnJvbSB0aGUgVVJMIGFuZCBjYWNoZSBuYW1lIHdvbid0IGJlIG5lY2Vzc2FyeSBvbmNlXG4gICAgICAgIC8vIEVkZ2Ugc3dpdGNoZXMgdG8gQ2hyb21pdW0gYW5kIGFsbCBicm93c2VycyB3ZSBzdXBwb3J0IHdvcmsgd2l0aFxuICAgICAgICAvLyBhcnJheSBrZXlQYXRocy5cbiAgICAgICAgcmV0dXJuIHRoaXMuX2NhY2hlTmFtZSArICd8JyArIG5vcm1hbGl6ZVVSTCh1cmwpO1xuICAgICAgfVxuICAgICAgLyoqXG4gICAgICAgKiBSZXR1cm5zIGFuIG9wZW4gY29ubmVjdGlvbiB0byB0aGUgZGF0YWJhc2UuXG4gICAgICAgKlxuICAgICAgICogQHByaXZhdGVcbiAgICAgICAqL1xuICAgICAgYXN5bmMgZ2V0RGIoKSB7XG4gICAgICAgIGlmICghdGhpcy5fZGIpIHtcbiAgICAgICAgICB0aGlzLl9kYiA9IGF3YWl0IG9wZW5EQihEQl9OQU1FLCAxLCB7XG4gICAgICAgICAgICB1cGdyYWRlOiB0aGlzLl91cGdyYWRlRGJBbmREZWxldGVPbGREYnMuYmluZCh0aGlzKVxuICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiB0aGlzLl9kYjtcbiAgICAgIH1cbiAgICB9XG5cbiAgICAvKlxuICAgICAgQ29weXJpZ2h0IDIwMTggR29vZ2xlIExMQ1xuXG4gICAgICBVc2Ugb2YgdGhpcyBzb3VyY2UgY29kZSBpcyBnb3Zlcm5lZCBieSBhbiBNSVQtc3R5bGVcbiAgICAgIGxpY2Vuc2UgdGhhdCBjYW4gYmUgZm91bmQgaW4gdGhlIExJQ0VOU0UgZmlsZSBvciBhdFxuICAgICAgaHR0cHM6Ly9vcGVuc291cmNlLm9yZy9saWNlbnNlcy9NSVQuXG4gICAgKi9cbiAgICAvKipcbiAgICAgKiBUaGUgYENhY2hlRXhwaXJhdGlvbmAgY2xhc3MgYWxsb3dzIHlvdSBkZWZpbmUgYW4gZXhwaXJhdGlvbiBhbmQgLyBvclxuICAgICAqIGxpbWl0IG9uIHRoZSBudW1iZXIgb2YgcmVzcG9uc2VzIHN0b3JlZCBpbiBhXG4gICAgICogW2BDYWNoZWBdKGh0dHBzOi8vZGV2ZWxvcGVyLm1vemlsbGEub3JnL2VuLVVTL2RvY3MvV2ViL0FQSS9DYWNoZSkuXG4gICAgICpcbiAgICAgKiBAbWVtYmVyb2Ygd29ya2JveC1leHBpcmF0aW9uXG4gICAgICovXG4gICAgY2xhc3MgQ2FjaGVFeHBpcmF0aW9uIHtcbiAgICAgIC8qKlxuICAgICAgICogVG8gY29uc3RydWN0IGEgbmV3IENhY2hlRXhwaXJhdGlvbiBpbnN0YW5jZSB5b3UgbXVzdCBwcm92aWRlIGF0IGxlYXN0XG4gICAgICAgKiBvbmUgb2YgdGhlIGBjb25maWdgIHByb3BlcnRpZXMuXG4gICAgICAgKlxuICAgICAgICogQHBhcmFtIHtzdHJpbmd9IGNhY2hlTmFtZSBOYW1lIG9mIHRoZSBjYWNoZSB0byBhcHBseSByZXN0cmljdGlvbnMgdG8uXG4gICAgICAgKiBAcGFyYW0ge09iamVjdH0gY29uZmlnXG4gICAgICAgKiBAcGFyYW0ge251bWJlcn0gW2NvbmZpZy5tYXhFbnRyaWVzXSBUaGUgbWF4aW11bSBudW1iZXIgb2YgZW50cmllcyB0byBjYWNoZS5cbiAgICAgICAqIEVudHJpZXMgdXNlZCB0aGUgbGVhc3Qgd2lsbCBiZSByZW1vdmVkIGFzIHRoZSBtYXhpbXVtIGlzIHJlYWNoZWQuXG4gICAgICAgKiBAcGFyYW0ge251bWJlcn0gW2NvbmZpZy5tYXhBZ2VTZWNvbmRzXSBUaGUgbWF4aW11bSBhZ2Ugb2YgYW4gZW50cnkgYmVmb3JlXG4gICAgICAgKiBpdCdzIHRyZWF0ZWQgYXMgc3RhbGUgYW5kIHJlbW92ZWQuXG4gICAgICAgKiBAcGFyYW0ge09iamVjdH0gW2NvbmZpZy5tYXRjaE9wdGlvbnNdIFRoZSBbYENhY2hlUXVlcnlPcHRpb25zYF0oaHR0cHM6Ly9kZXZlbG9wZXIubW96aWxsYS5vcmcvZW4tVVMvZG9jcy9XZWIvQVBJL0NhY2hlL2RlbGV0ZSNQYXJhbWV0ZXJzKVxuICAgICAgICogdGhhdCB3aWxsIGJlIHVzZWQgd2hlbiBjYWxsaW5nIGBkZWxldGUoKWAgb24gdGhlIGNhY2hlLlxuICAgICAgICovXG4gICAgICBjb25zdHJ1Y3RvcihjYWNoZU5hbWUsIGNvbmZpZyA9IHt9KSB7XG4gICAgICAgIHRoaXMuX2lzUnVubmluZyA9IGZhbHNlO1xuICAgICAgICB0aGlzLl9yZXJ1blJlcXVlc3RlZCA9IGZhbHNlO1xuICAgICAgICB7XG4gICAgICAgICAgZmluYWxBc3NlcnRFeHBvcnRzLmlzVHlwZShjYWNoZU5hbWUsICdzdHJpbmcnLCB7XG4gICAgICAgICAgICBtb2R1bGVOYW1lOiAnd29ya2JveC1leHBpcmF0aW9uJyxcbiAgICAgICAgICAgIGNsYXNzTmFtZTogJ0NhY2hlRXhwaXJhdGlvbicsXG4gICAgICAgICAgICBmdW5jTmFtZTogJ2NvbnN0cnVjdG9yJyxcbiAgICAgICAgICAgIHBhcmFtTmFtZTogJ2NhY2hlTmFtZSdcbiAgICAgICAgICB9KTtcbiAgICAgICAgICBpZiAoIShjb25maWcubWF4RW50cmllcyB8fCBjb25maWcubWF4QWdlU2Vjb25kcykpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBXb3JrYm94RXJyb3IoJ21heC1lbnRyaWVzLW9yLWFnZS1yZXF1aXJlZCcsIHtcbiAgICAgICAgICAgICAgbW9kdWxlTmFtZTogJ3dvcmtib3gtZXhwaXJhdGlvbicsXG4gICAgICAgICAgICAgIGNsYXNzTmFtZTogJ0NhY2hlRXhwaXJhdGlvbicsXG4gICAgICAgICAgICAgIGZ1bmNOYW1lOiAnY29uc3RydWN0b3InXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICB9XG4gICAgICAgICAgaWYgKGNvbmZpZy5tYXhFbnRyaWVzKSB7XG4gICAgICAgICAgICBmaW5hbEFzc2VydEV4cG9ydHMuaXNUeXBlKGNvbmZpZy5tYXhFbnRyaWVzLCAnbnVtYmVyJywge1xuICAgICAgICAgICAgICBtb2R1bGVOYW1lOiAnd29ya2JveC1leHBpcmF0aW9uJyxcbiAgICAgICAgICAgICAgY2xhc3NOYW1lOiAnQ2FjaGVFeHBpcmF0aW9uJyxcbiAgICAgICAgICAgICAgZnVuY05hbWU6ICdjb25zdHJ1Y3RvcicsXG4gICAgICAgICAgICAgIHBhcmFtTmFtZTogJ2NvbmZpZy5tYXhFbnRyaWVzJ1xuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgfVxuICAgICAgICAgIGlmIChjb25maWcubWF4QWdlU2Vjb25kcykge1xuICAgICAgICAgICAgZmluYWxBc3NlcnRFeHBvcnRzLmlzVHlwZShjb25maWcubWF4QWdlU2Vjb25kcywgJ251bWJlcicsIHtcbiAgICAgICAgICAgICAgbW9kdWxlTmFtZTogJ3dvcmtib3gtZXhwaXJhdGlvbicsXG4gICAgICAgICAgICAgIGNsYXNzTmFtZTogJ0NhY2hlRXhwaXJhdGlvbicsXG4gICAgICAgICAgICAgIGZ1bmNOYW1lOiAnY29uc3RydWN0b3InLFxuICAgICAgICAgICAgICBwYXJhbU5hbWU6ICdjb25maWcubWF4QWdlU2Vjb25kcydcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICB0aGlzLl9tYXhFbnRyaWVzID0gY29uZmlnLm1heEVudHJpZXM7XG4gICAgICAgIHRoaXMuX21heEFnZVNlY29uZHMgPSBjb25maWcubWF4QWdlU2Vjb25kcztcbiAgICAgICAgdGhpcy5fbWF0Y2hPcHRpb25zID0gY29uZmlnLm1hdGNoT3B0aW9ucztcbiAgICAgICAgdGhpcy5fY2FjaGVOYW1lID0gY2FjaGVOYW1lO1xuICAgICAgICB0aGlzLl90aW1lc3RhbXBNb2RlbCA9IG5ldyBDYWNoZVRpbWVzdGFtcHNNb2RlbChjYWNoZU5hbWUpO1xuICAgICAgfVxuICAgICAgLyoqXG4gICAgICAgKiBFeHBpcmVzIGVudHJpZXMgZm9yIHRoZSBnaXZlbiBjYWNoZSBhbmQgZ2l2ZW4gY3JpdGVyaWEuXG4gICAgICAgKi9cbiAgICAgIGFzeW5jIGV4cGlyZUVudHJpZXMoKSB7XG4gICAgICAgIGlmICh0aGlzLl9pc1J1bm5pbmcpIHtcbiAgICAgICAgICB0aGlzLl9yZXJ1blJlcXVlc3RlZCA9IHRydWU7XG4gICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIHRoaXMuX2lzUnVubmluZyA9IHRydWU7XG4gICAgICAgIGNvbnN0IG1pblRpbWVzdGFtcCA9IHRoaXMuX21heEFnZVNlY29uZHMgPyBEYXRlLm5vdygpIC0gdGhpcy5fbWF4QWdlU2Vjb25kcyAqIDEwMDAgOiAwO1xuICAgICAgICBjb25zdCB1cmxzRXhwaXJlZCA9IGF3YWl0IHRoaXMuX3RpbWVzdGFtcE1vZGVsLmV4cGlyZUVudHJpZXMobWluVGltZXN0YW1wLCB0aGlzLl9tYXhFbnRyaWVzKTtcbiAgICAgICAgLy8gRGVsZXRlIFVSTHMgZnJvbSB0aGUgY2FjaGVcbiAgICAgICAgY29uc3QgY2FjaGUgPSBhd2FpdCBzZWxmLmNhY2hlcy5vcGVuKHRoaXMuX2NhY2hlTmFtZSk7XG4gICAgICAgIGZvciAoY29uc3QgdXJsIG9mIHVybHNFeHBpcmVkKSB7XG4gICAgICAgICAgYXdhaXQgY2FjaGUuZGVsZXRlKHVybCwgdGhpcy5fbWF0Y2hPcHRpb25zKTtcbiAgICAgICAgfVxuICAgICAgICB7XG4gICAgICAgICAgaWYgKHVybHNFeHBpcmVkLmxlbmd0aCA+IDApIHtcbiAgICAgICAgICAgIGxvZ2dlci5ncm91cENvbGxhcHNlZChgRXhwaXJlZCAke3VybHNFeHBpcmVkLmxlbmd0aH0gYCArIGAke3VybHNFeHBpcmVkLmxlbmd0aCA9PT0gMSA/ICdlbnRyeScgOiAnZW50cmllcyd9IGFuZCByZW1vdmVkIGAgKyBgJHt1cmxzRXhwaXJlZC5sZW5ndGggPT09IDEgPyAnaXQnIDogJ3RoZW0nfSBmcm9tIHRoZSBgICsgYCcke3RoaXMuX2NhY2hlTmFtZX0nIGNhY2hlLmApO1xuICAgICAgICAgICAgbG9nZ2VyLmxvZyhgRXhwaXJlZCB0aGUgZm9sbG93aW5nICR7dXJsc0V4cGlyZWQubGVuZ3RoID09PSAxID8gJ1VSTCcgOiAnVVJMcyd9OmApO1xuICAgICAgICAgICAgdXJsc0V4cGlyZWQuZm9yRWFjaCh1cmwgPT4gbG9nZ2VyLmxvZyhgICAgICR7dXJsfWApKTtcbiAgICAgICAgICAgIGxvZ2dlci5ncm91cEVuZCgpO1xuICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBsb2dnZXIuZGVidWcoYENhY2hlIGV4cGlyYXRpb24gcmFuIGFuZCBmb3VuZCBubyBlbnRyaWVzIHRvIHJlbW92ZS5gKTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgdGhpcy5faXNSdW5uaW5nID0gZmFsc2U7XG4gICAgICAgIGlmICh0aGlzLl9yZXJ1blJlcXVlc3RlZCkge1xuICAgICAgICAgIHRoaXMuX3JlcnVuUmVxdWVzdGVkID0gZmFsc2U7XG4gICAgICAgICAgZG9udFdhaXRGb3IodGhpcy5leHBpcmVFbnRyaWVzKCkpO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICAvKipcbiAgICAgICAqIFVwZGF0ZSB0aGUgdGltZXN0YW1wIGZvciB0aGUgZ2l2ZW4gVVJMLiBUaGlzIGVuc3VyZXMgdGhlIHdoZW5cbiAgICAgICAqIHJlbW92aW5nIGVudHJpZXMgYmFzZWQgb24gbWF4aW11bSBlbnRyaWVzLCBtb3N0IHJlY2VudGx5IHVzZWRcbiAgICAgICAqIGlzIGFjY3VyYXRlIG9yIHdoZW4gZXhwaXJpbmcsIHRoZSB0aW1lc3RhbXAgaXMgdXAtdG8tZGF0ZS5cbiAgICAgICAqXG4gICAgICAgKiBAcGFyYW0ge3N0cmluZ30gdXJsXG4gICAgICAgKi9cbiAgICAgIGFzeW5jIHVwZGF0ZVRpbWVzdGFtcCh1cmwpIHtcbiAgICAgICAge1xuICAgICAgICAgIGZpbmFsQXNzZXJ0RXhwb3J0cy5pc1R5cGUodXJsLCAnc3RyaW5nJywge1xuICAgICAgICAgICAgbW9kdWxlTmFtZTogJ3dvcmtib3gtZXhwaXJhdGlvbicsXG4gICAgICAgICAgICBjbGFzc05hbWU6ICdDYWNoZUV4cGlyYXRpb24nLFxuICAgICAgICAgICAgZnVuY05hbWU6ICd1cGRhdGVUaW1lc3RhbXAnLFxuICAgICAgICAgICAgcGFyYW1OYW1lOiAndXJsJ1xuICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgICAgIGF3YWl0IHRoaXMuX3RpbWVzdGFtcE1vZGVsLnNldFRpbWVzdGFtcCh1cmwsIERhdGUubm93KCkpO1xuICAgICAgfVxuICAgICAgLyoqXG4gICAgICAgKiBDYW4gYmUgdXNlZCB0byBjaGVjayBpZiBhIFVSTCBoYXMgZXhwaXJlZCBvciBub3QgYmVmb3JlIGl0J3MgdXNlZC5cbiAgICAgICAqXG4gICAgICAgKiBUaGlzIHJlcXVpcmVzIGEgbG9vayB1cCBmcm9tIEluZGV4ZWREQiwgc28gY2FuIGJlIHNsb3cuXG4gICAgICAgKlxuICAgICAgICogTm90ZTogVGhpcyBtZXRob2Qgd2lsbCBub3QgcmVtb3ZlIHRoZSBjYWNoZWQgZW50cnksIGNhbGxcbiAgICAgICAqIGBleHBpcmVFbnRyaWVzKClgIHRvIHJlbW92ZSBpbmRleGVkREIgYW5kIENhY2hlIGVudHJpZXMuXG4gICAgICAgKlxuICAgICAgICogQHBhcmFtIHtzdHJpbmd9IHVybFxuICAgICAgICogQHJldHVybiB7Ym9vbGVhbn1cbiAgICAgICAqL1xuICAgICAgYXN5bmMgaXNVUkxFeHBpcmVkKHVybCkge1xuICAgICAgICBpZiAoIXRoaXMuX21heEFnZVNlY29uZHMpIHtcbiAgICAgICAgICB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgV29ya2JveEVycm9yKGBleHBpcmVkLXRlc3Qtd2l0aG91dC1tYXgtYWdlYCwge1xuICAgICAgICAgICAgICBtZXRob2ROYW1lOiAnaXNVUkxFeHBpcmVkJyxcbiAgICAgICAgICAgICAgcGFyYW1OYW1lOiAnbWF4QWdlU2Vjb25kcydcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgIH1cbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBjb25zdCB0aW1lc3RhbXAgPSBhd2FpdCB0aGlzLl90aW1lc3RhbXBNb2RlbC5nZXRUaW1lc3RhbXAodXJsKTtcbiAgICAgICAgICBjb25zdCBleHBpcmVPbGRlclRoYW4gPSBEYXRlLm5vdygpIC0gdGhpcy5fbWF4QWdlU2Vjb25kcyAqIDEwMDA7XG4gICAgICAgICAgcmV0dXJuIHRpbWVzdGFtcCAhPT0gdW5kZWZpbmVkID8gdGltZXN0YW1wIDwgZXhwaXJlT2xkZXJUaGFuIDogdHJ1ZTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgLyoqXG4gICAgICAgKiBSZW1vdmVzIHRoZSBJbmRleGVkREIgb2JqZWN0IHN0b3JlIHVzZWQgdG8ga2VlcCB0cmFjayBvZiBjYWNoZSBleHBpcmF0aW9uXG4gICAgICAgKiBtZXRhZGF0YS5cbiAgICAgICAqL1xuICAgICAgYXN5bmMgZGVsZXRlKCkge1xuICAgICAgICAvLyBNYWtlIHN1cmUgd2UgZG9uJ3QgYXR0ZW1wdCBhbm90aGVyIHJlcnVuIGlmIHdlJ3JlIGNhbGxlZCBpbiB0aGUgbWlkZGxlIG9mXG4gICAgICAgIC8vIGEgY2FjaGUgZXhwaXJhdGlvbi5cbiAgICAgICAgdGhpcy5fcmVydW5SZXF1ZXN0ZWQgPSBmYWxzZTtcbiAgICAgICAgYXdhaXQgdGhpcy5fdGltZXN0YW1wTW9kZWwuZXhwaXJlRW50cmllcyhJbmZpbml0eSk7IC8vIEV4cGlyZXMgYWxsLlxuICAgICAgfVxuICAgIH1cblxuICAgIC8qXG4gICAgICBDb3B5cmlnaHQgMjAxOCBHb29nbGUgTExDXG5cbiAgICAgIFVzZSBvZiB0aGlzIHNvdXJjZSBjb2RlIGlzIGdvdmVybmVkIGJ5IGFuIE1JVC1zdHlsZVxuICAgICAgbGljZW5zZSB0aGF0IGNhbiBiZSBmb3VuZCBpbiB0aGUgTElDRU5TRSBmaWxlIG9yIGF0XG4gICAgICBodHRwczovL29wZW5zb3VyY2Uub3JnL2xpY2Vuc2VzL01JVC5cbiAgICAqL1xuICAgIC8qKlxuICAgICAqIFRoaXMgcGx1Z2luIGNhbiBiZSB1c2VkIGluIGEgYHdvcmtib3gtc3RyYXRlZ3lgIHRvIHJlZ3VsYXJseSBlbmZvcmNlIGFcbiAgICAgKiBsaW1pdCBvbiB0aGUgYWdlIGFuZCAvIG9yIHRoZSBudW1iZXIgb2YgY2FjaGVkIHJlcXVlc3RzLlxuICAgICAqXG4gICAgICogSXQgY2FuIG9ubHkgYmUgdXNlZCB3aXRoIGB3b3JrYm94LXN0cmF0ZWd5YCBpbnN0YW5jZXMgdGhhdCBoYXZlIGFcbiAgICAgKiBbY3VzdG9tIGBjYWNoZU5hbWVgIHByb3BlcnR5IHNldF0oL3dlYi90b29scy93b3JrYm94L2d1aWRlcy9jb25maWd1cmUtd29ya2JveCNjdXN0b21fY2FjaGVfbmFtZXNfaW5fc3RyYXRlZ2llcykuXG4gICAgICogSW4gb3RoZXIgd29yZHMsIGl0IGNhbid0IGJlIHVzZWQgdG8gZXhwaXJlIGVudHJpZXMgaW4gc3RyYXRlZ3kgdGhhdCB1c2VzIHRoZVxuICAgICAqIGRlZmF1bHQgcnVudGltZSBjYWNoZSBuYW1lLlxuICAgICAqXG4gICAgICogV2hlbmV2ZXIgYSBjYWNoZWQgcmVzcG9uc2UgaXMgdXNlZCBvciB1cGRhdGVkLCB0aGlzIHBsdWdpbiB3aWxsIGxvb2tcbiAgICAgKiBhdCB0aGUgYXNzb2NpYXRlZCBjYWNoZSBhbmQgcmVtb3ZlIGFueSBvbGQgb3IgZXh0cmEgcmVzcG9uc2VzLlxuICAgICAqXG4gICAgICogV2hlbiB1c2luZyBgbWF4QWdlU2Vjb25kc2AsIHJlc3BvbnNlcyBtYXkgYmUgdXNlZCAqb25jZSogYWZ0ZXIgZXhwaXJpbmdcbiAgICAgKiBiZWNhdXNlIHRoZSBleHBpcmF0aW9uIGNsZWFuIHVwIHdpbGwgbm90IGhhdmUgb2NjdXJyZWQgdW50aWwgKmFmdGVyKiB0aGVcbiAgICAgKiBjYWNoZWQgcmVzcG9uc2UgaGFzIGJlZW4gdXNlZC4gSWYgdGhlIHJlc3BvbnNlIGhhcyBhIFwiRGF0ZVwiIGhlYWRlciwgdGhlblxuICAgICAqIGEgbGlnaHQgd2VpZ2h0IGV4cGlyYXRpb24gY2hlY2sgaXMgcGVyZm9ybWVkIGFuZCB0aGUgcmVzcG9uc2Ugd2lsbCBub3QgYmVcbiAgICAgKiB1c2VkIGltbWVkaWF0ZWx5LlxuICAgICAqXG4gICAgICogV2hlbiB1c2luZyBgbWF4RW50cmllc2AsIHRoZSBlbnRyeSBsZWFzdC1yZWNlbnRseSByZXF1ZXN0ZWQgd2lsbCBiZSByZW1vdmVkXG4gICAgICogZnJvbSB0aGUgY2FjaGUgZmlyc3QuXG4gICAgICpcbiAgICAgKiBAbWVtYmVyb2Ygd29ya2JveC1leHBpcmF0aW9uXG4gICAgICovXG4gICAgY2xhc3MgRXhwaXJhdGlvblBsdWdpbiB7XG4gICAgICAvKipcbiAgICAgICAqIEBwYXJhbSB7RXhwaXJhdGlvblBsdWdpbk9wdGlvbnN9IGNvbmZpZ1xuICAgICAgICogQHBhcmFtIHtudW1iZXJ9IFtjb25maWcubWF4RW50cmllc10gVGhlIG1heGltdW0gbnVtYmVyIG9mIGVudHJpZXMgdG8gY2FjaGUuXG4gICAgICAgKiBFbnRyaWVzIHVzZWQgdGhlIGxlYXN0IHdpbGwgYmUgcmVtb3ZlZCBhcyB0aGUgbWF4aW11bSBpcyByZWFjaGVkLlxuICAgICAgICogQHBhcmFtIHtudW1iZXJ9IFtjb25maWcubWF4QWdlU2Vjb25kc10gVGhlIG1heGltdW0gYWdlIG9mIGFuIGVudHJ5IGJlZm9yZVxuICAgICAgICogaXQncyB0cmVhdGVkIGFzIHN0YWxlIGFuZCByZW1vdmVkLlxuICAgICAgICogQHBhcmFtIHtPYmplY3R9IFtjb25maWcubWF0Y2hPcHRpb25zXSBUaGUgW2BDYWNoZVF1ZXJ5T3B0aW9uc2BdKGh0dHBzOi8vZGV2ZWxvcGVyLm1vemlsbGEub3JnL2VuLVVTL2RvY3MvV2ViL0FQSS9DYWNoZS9kZWxldGUjUGFyYW1ldGVycylcbiAgICAgICAqIHRoYXQgd2lsbCBiZSB1c2VkIHdoZW4gY2FsbGluZyBgZGVsZXRlKClgIG9uIHRoZSBjYWNoZS5cbiAgICAgICAqIEBwYXJhbSB7Ym9vbGVhbn0gW2NvbmZpZy5wdXJnZU9uUXVvdGFFcnJvcl0gV2hldGhlciB0byBvcHQgdGhpcyBjYWNoZSBpbiB0b1xuICAgICAgICogYXV0b21hdGljIGRlbGV0aW9uIGlmIHRoZSBhdmFpbGFibGUgc3RvcmFnZSBxdW90YSBoYXMgYmVlbiBleGNlZWRlZC5cbiAgICAgICAqL1xuICAgICAgY29uc3RydWN0b3IoY29uZmlnID0ge30pIHtcbiAgICAgICAgLyoqXG4gICAgICAgICAqIEEgXCJsaWZlY3ljbGVcIiBjYWxsYmFjayB0aGF0IHdpbGwgYmUgdHJpZ2dlcmVkIGF1dG9tYXRpY2FsbHkgYnkgdGhlXG4gICAgICAgICAqIGB3b3JrYm94LXN0cmF0ZWdpZXNgIGhhbmRsZXJzIHdoZW4gYSBgUmVzcG9uc2VgIGlzIGFib3V0IHRvIGJlIHJldHVybmVkXG4gICAgICAgICAqIGZyb20gYSBbQ2FjaGVdKGh0dHBzOi8vZGV2ZWxvcGVyLm1vemlsbGEub3JnL2VuLVVTL2RvY3MvV2ViL0FQSS9DYWNoZSkgdG9cbiAgICAgICAgICogdGhlIGhhbmRsZXIuIEl0IGFsbG93cyB0aGUgYFJlc3BvbnNlYCB0byBiZSBpbnNwZWN0ZWQgZm9yIGZyZXNobmVzcyBhbmRcbiAgICAgICAgICogcHJldmVudHMgaXQgZnJvbSBiZWluZyB1c2VkIGlmIHRoZSBgUmVzcG9uc2VgJ3MgYERhdGVgIGhlYWRlciB2YWx1ZSBpc1xuICAgICAgICAgKiBvbGRlciB0aGFuIHRoZSBjb25maWd1cmVkIGBtYXhBZ2VTZWNvbmRzYC5cbiAgICAgICAgICpcbiAgICAgICAgICogQHBhcmFtIHtPYmplY3R9IG9wdGlvbnNcbiAgICAgICAgICogQHBhcmFtIHtzdHJpbmd9IG9wdGlvbnMuY2FjaGVOYW1lIE5hbWUgb2YgdGhlIGNhY2hlIHRoZSByZXNwb25zZSBpcyBpbi5cbiAgICAgICAgICogQHBhcmFtIHtSZXNwb25zZX0gb3B0aW9ucy5jYWNoZWRSZXNwb25zZSBUaGUgYFJlc3BvbnNlYCBvYmplY3QgdGhhdCdzIGJlZW5cbiAgICAgICAgICogICAgIHJlYWQgZnJvbSBhIGNhY2hlIGFuZCB3aG9zZSBmcmVzaG5lc3Mgc2hvdWxkIGJlIGNoZWNrZWQuXG4gICAgICAgICAqIEByZXR1cm4ge1Jlc3BvbnNlfSBFaXRoZXIgdGhlIGBjYWNoZWRSZXNwb25zZWAsIGlmIGl0J3NcbiAgICAgICAgICogICAgIGZyZXNoLCBvciBgbnVsbGAgaWYgdGhlIGBSZXNwb25zZWAgaXMgb2xkZXIgdGhhbiBgbWF4QWdlU2Vjb25kc2AuXG4gICAgICAgICAqXG4gICAgICAgICAqIEBwcml2YXRlXG4gICAgICAgICAqL1xuICAgICAgICB0aGlzLmNhY2hlZFJlc3BvbnNlV2lsbEJlVXNlZCA9IGFzeW5jICh7XG4gICAgICAgICAgZXZlbnQsXG4gICAgICAgICAgcmVxdWVzdCxcbiAgICAgICAgICBjYWNoZU5hbWUsXG4gICAgICAgICAgY2FjaGVkUmVzcG9uc2VcbiAgICAgICAgfSkgPT4ge1xuICAgICAgICAgIGlmICghY2FjaGVkUmVzcG9uc2UpIHtcbiAgICAgICAgICAgIHJldHVybiBudWxsO1xuICAgICAgICAgIH1cbiAgICAgICAgICBjb25zdCBpc0ZyZXNoID0gdGhpcy5faXNSZXNwb25zZURhdGVGcmVzaChjYWNoZWRSZXNwb25zZSk7XG4gICAgICAgICAgLy8gRXhwaXJlIGVudHJpZXMgdG8gZW5zdXJlIHRoYXQgZXZlbiBpZiB0aGUgZXhwaXJhdGlvbiBkYXRlIGhhc1xuICAgICAgICAgIC8vIGV4cGlyZWQsIGl0J2xsIG9ubHkgYmUgdXNlZCBvbmNlLlxuICAgICAgICAgIGNvbnN0IGNhY2hlRXhwaXJhdGlvbiA9IHRoaXMuX2dldENhY2hlRXhwaXJhdGlvbihjYWNoZU5hbWUpO1xuICAgICAgICAgIGRvbnRXYWl0Rm9yKGNhY2hlRXhwaXJhdGlvbi5leHBpcmVFbnRyaWVzKCkpO1xuICAgICAgICAgIC8vIFVwZGF0ZSB0aGUgbWV0YWRhdGEgZm9yIHRoZSByZXF1ZXN0IFVSTCB0byB0aGUgY3VycmVudCB0aW1lc3RhbXAsXG4gICAgICAgICAgLy8gYnV0IGRvbid0IGBhd2FpdGAgaXQgYXMgd2UgZG9uJ3Qgd2FudCB0byBibG9jayB0aGUgcmVzcG9uc2UuXG4gICAgICAgICAgY29uc3QgdXBkYXRlVGltZXN0YW1wRG9uZSA9IGNhY2hlRXhwaXJhdGlvbi51cGRhdGVUaW1lc3RhbXAocmVxdWVzdC51cmwpO1xuICAgICAgICAgIGlmIChldmVudCkge1xuICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgZXZlbnQud2FpdFVudGlsKHVwZGF0ZVRpbWVzdGFtcERvbmUpO1xuICAgICAgICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIC8vIFRoZSBldmVudCBtYXkgbm90IGJlIGEgZmV0Y2ggZXZlbnQ7IG9ubHkgbG9nIHRoZSBVUkwgaWYgaXQgaXMuXG4gICAgICAgICAgICAgICAgaWYgKCdyZXF1ZXN0JyBpbiBldmVudCkge1xuICAgICAgICAgICAgICAgICAgbG9nZ2VyLndhcm4oYFVuYWJsZSB0byBlbnN1cmUgc2VydmljZSB3b3JrZXIgc3RheXMgYWxpdmUgd2hlbiBgICsgYHVwZGF0aW5nIGNhY2hlIGVudHJ5IGZvciBgICsgYCcke2dldEZyaWVuZGx5VVJMKGV2ZW50LnJlcXVlc3QudXJsKX0nLmApO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgIH1cbiAgICAgICAgICByZXR1cm4gaXNGcmVzaCA/IGNhY2hlZFJlc3BvbnNlIDogbnVsbDtcbiAgICAgICAgfTtcbiAgICAgICAgLyoqXG4gICAgICAgICAqIEEgXCJsaWZlY3ljbGVcIiBjYWxsYmFjayB0aGF0IHdpbGwgYmUgdHJpZ2dlcmVkIGF1dG9tYXRpY2FsbHkgYnkgdGhlXG4gICAgICAgICAqIGB3b3JrYm94LXN0cmF0ZWdpZXNgIGhhbmRsZXJzIHdoZW4gYW4gZW50cnkgaXMgYWRkZWQgdG8gYSBjYWNoZS5cbiAgICAgICAgICpcbiAgICAgICAgICogQHBhcmFtIHtPYmplY3R9IG9wdGlvbnNcbiAgICAgICAgICogQHBhcmFtIHtzdHJpbmd9IG9wdGlvbnMuY2FjaGVOYW1lIE5hbWUgb2YgdGhlIGNhY2hlIHRoYXQgd2FzIHVwZGF0ZWQuXG4gICAgICAgICAqIEBwYXJhbSB7c3RyaW5nfSBvcHRpb25zLnJlcXVlc3QgVGhlIFJlcXVlc3QgZm9yIHRoZSBjYWNoZWQgZW50cnkuXG4gICAgICAgICAqXG4gICAgICAgICAqIEBwcml2YXRlXG4gICAgICAgICAqL1xuICAgICAgICB0aGlzLmNhY2hlRGlkVXBkYXRlID0gYXN5bmMgKHtcbiAgICAgICAgICBjYWNoZU5hbWUsXG4gICAgICAgICAgcmVxdWVzdFxuICAgICAgICB9KSA9PiB7XG4gICAgICAgICAge1xuICAgICAgICAgICAgZmluYWxBc3NlcnRFeHBvcnRzLmlzVHlwZShjYWNoZU5hbWUsICdzdHJpbmcnLCB7XG4gICAgICAgICAgICAgIG1vZHVsZU5hbWU6ICd3b3JrYm94LWV4cGlyYXRpb24nLFxuICAgICAgICAgICAgICBjbGFzc05hbWU6ICdQbHVnaW4nLFxuICAgICAgICAgICAgICBmdW5jTmFtZTogJ2NhY2hlRGlkVXBkYXRlJyxcbiAgICAgICAgICAgICAgcGFyYW1OYW1lOiAnY2FjaGVOYW1lJ1xuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICBmaW5hbEFzc2VydEV4cG9ydHMuaXNJbnN0YW5jZShyZXF1ZXN0LCBSZXF1ZXN0LCB7XG4gICAgICAgICAgICAgIG1vZHVsZU5hbWU6ICd3b3JrYm94LWV4cGlyYXRpb24nLFxuICAgICAgICAgICAgICBjbGFzc05hbWU6ICdQbHVnaW4nLFxuICAgICAgICAgICAgICBmdW5jTmFtZTogJ2NhY2hlRGlkVXBkYXRlJyxcbiAgICAgICAgICAgICAgcGFyYW1OYW1lOiAncmVxdWVzdCdcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgIH1cbiAgICAgICAgICBjb25zdCBjYWNoZUV4cGlyYXRpb24gPSB0aGlzLl9nZXRDYWNoZUV4cGlyYXRpb24oY2FjaGVOYW1lKTtcbiAgICAgICAgICBhd2FpdCBjYWNoZUV4cGlyYXRpb24udXBkYXRlVGltZXN0YW1wKHJlcXVlc3QudXJsKTtcbiAgICAgICAgICBhd2FpdCBjYWNoZUV4cGlyYXRpb24uZXhwaXJlRW50cmllcygpO1xuICAgICAgICB9O1xuICAgICAgICB7XG4gICAgICAgICAgaWYgKCEoY29uZmlnLm1heEVudHJpZXMgfHwgY29uZmlnLm1heEFnZVNlY29uZHMpKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgV29ya2JveEVycm9yKCdtYXgtZW50cmllcy1vci1hZ2UtcmVxdWlyZWQnLCB7XG4gICAgICAgICAgICAgIG1vZHVsZU5hbWU6ICd3b3JrYm94LWV4cGlyYXRpb24nLFxuICAgICAgICAgICAgICBjbGFzc05hbWU6ICdQbHVnaW4nLFxuICAgICAgICAgICAgICBmdW5jTmFtZTogJ2NvbnN0cnVjdG9yJ1xuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgfVxuICAgICAgICAgIGlmIChjb25maWcubWF4RW50cmllcykge1xuICAgICAgICAgICAgZmluYWxBc3NlcnRFeHBvcnRzLmlzVHlwZShjb25maWcubWF4RW50cmllcywgJ251bWJlcicsIHtcbiAgICAgICAgICAgICAgbW9kdWxlTmFtZTogJ3dvcmtib3gtZXhwaXJhdGlvbicsXG4gICAgICAgICAgICAgIGNsYXNzTmFtZTogJ1BsdWdpbicsXG4gICAgICAgICAgICAgIGZ1bmNOYW1lOiAnY29uc3RydWN0b3InLFxuICAgICAgICAgICAgICBwYXJhbU5hbWU6ICdjb25maWcubWF4RW50cmllcydcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgIH1cbiAgICAgICAgICBpZiAoY29uZmlnLm1heEFnZVNlY29uZHMpIHtcbiAgICAgICAgICAgIGZpbmFsQXNzZXJ0RXhwb3J0cy5pc1R5cGUoY29uZmlnLm1heEFnZVNlY29uZHMsICdudW1iZXInLCB7XG4gICAgICAgICAgICAgIG1vZHVsZU5hbWU6ICd3b3JrYm94LWV4cGlyYXRpb24nLFxuICAgICAgICAgICAgICBjbGFzc05hbWU6ICdQbHVnaW4nLFxuICAgICAgICAgICAgICBmdW5jTmFtZTogJ2NvbnN0cnVjdG9yJyxcbiAgICAgICAgICAgICAgcGFyYW1OYW1lOiAnY29uZmlnLm1heEFnZVNlY29uZHMnXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgdGhpcy5fY29uZmlnID0gY29uZmlnO1xuICAgICAgICB0aGlzLl9tYXhBZ2VTZWNvbmRzID0gY29uZmlnLm1heEFnZVNlY29uZHM7XG4gICAgICAgIHRoaXMuX2NhY2hlRXhwaXJhdGlvbnMgPSBuZXcgTWFwKCk7XG4gICAgICAgIGlmIChjb25maWcucHVyZ2VPblF1b3RhRXJyb3IpIHtcbiAgICAgICAgICByZWdpc3RlclF1b3RhRXJyb3JDYWxsYmFjaygoKSA9PiB0aGlzLmRlbGV0ZUNhY2hlQW5kTWV0YWRhdGEoKSk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIC8qKlxuICAgICAgICogQSBzaW1wbGUgaGVscGVyIG1ldGhvZCB0byByZXR1cm4gYSBDYWNoZUV4cGlyYXRpb24gaW5zdGFuY2UgZm9yIGEgZ2l2ZW5cbiAgICAgICAqIGNhY2hlIG5hbWUuXG4gICAgICAgKlxuICAgICAgICogQHBhcmFtIHtzdHJpbmd9IGNhY2hlTmFtZVxuICAgICAgICogQHJldHVybiB7Q2FjaGVFeHBpcmF0aW9ufVxuICAgICAgICpcbiAgICAgICAqIEBwcml2YXRlXG4gICAgICAgKi9cbiAgICAgIF9nZXRDYWNoZUV4cGlyYXRpb24oY2FjaGVOYW1lKSB7XG4gICAgICAgIGlmIChjYWNoZU5hbWUgPT09IGNhY2hlTmFtZXMuZ2V0UnVudGltZU5hbWUoKSkge1xuICAgICAgICAgIHRocm93IG5ldyBXb3JrYm94RXJyb3IoJ2V4cGlyZS1jdXN0b20tY2FjaGVzLW9ubHknKTtcbiAgICAgICAgfVxuICAgICAgICBsZXQgY2FjaGVFeHBpcmF0aW9uID0gdGhpcy5fY2FjaGVFeHBpcmF0aW9ucy5nZXQoY2FjaGVOYW1lKTtcbiAgICAgICAgaWYgKCFjYWNoZUV4cGlyYXRpb24pIHtcbiAgICAgICAgICBjYWNoZUV4cGlyYXRpb24gPSBuZXcgQ2FjaGVFeHBpcmF0aW9uKGNhY2hlTmFtZSwgdGhpcy5fY29uZmlnKTtcbiAgICAgICAgICB0aGlzLl9jYWNoZUV4cGlyYXRpb25zLnNldChjYWNoZU5hbWUsIGNhY2hlRXhwaXJhdGlvbik7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIGNhY2hlRXhwaXJhdGlvbjtcbiAgICAgIH1cbiAgICAgIC8qKlxuICAgICAgICogQHBhcmFtIHtSZXNwb25zZX0gY2FjaGVkUmVzcG9uc2VcbiAgICAgICAqIEByZXR1cm4ge2Jvb2xlYW59XG4gICAgICAgKlxuICAgICAgICogQHByaXZhdGVcbiAgICAgICAqL1xuICAgICAgX2lzUmVzcG9uc2VEYXRlRnJlc2goY2FjaGVkUmVzcG9uc2UpIHtcbiAgICAgICAgaWYgKCF0aGlzLl9tYXhBZ2VTZWNvbmRzKSB7XG4gICAgICAgICAgLy8gV2UgYXJlbid0IGV4cGlyaW5nIGJ5IGFnZSwgc28gcmV0dXJuIHRydWUsIGl0J3MgZnJlc2hcbiAgICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgICAgfVxuICAgICAgICAvLyBDaGVjayBpZiB0aGUgJ2RhdGUnIGhlYWRlciB3aWxsIHN1ZmZpY2UgYSBxdWljayBleHBpcmF0aW9uIGNoZWNrLlxuICAgICAgICAvLyBTZWUgaHR0cHM6Ly9naXRodWIuY29tL0dvb2dsZUNocm9tZUxhYnMvc3ctdG9vbGJveC9pc3N1ZXMvMTY0IGZvclxuICAgICAgICAvLyBkaXNjdXNzaW9uLlxuICAgICAgICBjb25zdCBkYXRlSGVhZGVyVGltZXN0YW1wID0gdGhpcy5fZ2V0RGF0ZUhlYWRlclRpbWVzdGFtcChjYWNoZWRSZXNwb25zZSk7XG4gICAgICAgIGlmIChkYXRlSGVhZGVyVGltZXN0YW1wID09PSBudWxsKSB7XG4gICAgICAgICAgLy8gVW5hYmxlIHRvIHBhcnNlIGRhdGUsIHNvIGFzc3VtZSBpdCdzIGZyZXNoLlxuICAgICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgICB9XG4gICAgICAgIC8vIElmIHdlIGhhdmUgYSB2YWxpZCBoZWFkZXJUaW1lLCB0aGVuIG91ciByZXNwb25zZSBpcyBmcmVzaCBpZmYgdGhlXG4gICAgICAgIC8vIGhlYWRlclRpbWUgcGx1cyBtYXhBZ2VTZWNvbmRzIGlzIGdyZWF0ZXIgdGhhbiB0aGUgY3VycmVudCB0aW1lLlxuICAgICAgICBjb25zdCBub3cgPSBEYXRlLm5vdygpO1xuICAgICAgICByZXR1cm4gZGF0ZUhlYWRlclRpbWVzdGFtcCA+PSBub3cgLSB0aGlzLl9tYXhBZ2VTZWNvbmRzICogMTAwMDtcbiAgICAgIH1cbiAgICAgIC8qKlxuICAgICAgICogVGhpcyBtZXRob2Qgd2lsbCBleHRyYWN0IHRoZSBkYXRhIGhlYWRlciBhbmQgcGFyc2UgaXQgaW50byBhIHVzZWZ1bFxuICAgICAgICogdmFsdWUuXG4gICAgICAgKlxuICAgICAgICogQHBhcmFtIHtSZXNwb25zZX0gY2FjaGVkUmVzcG9uc2VcbiAgICAgICAqIEByZXR1cm4ge251bWJlcnxudWxsfVxuICAgICAgICpcbiAgICAgICAqIEBwcml2YXRlXG4gICAgICAgKi9cbiAgICAgIF9nZXREYXRlSGVhZGVyVGltZXN0YW1wKGNhY2hlZFJlc3BvbnNlKSB7XG4gICAgICAgIGlmICghY2FjaGVkUmVzcG9uc2UuaGVhZGVycy5oYXMoJ2RhdGUnKSkge1xuICAgICAgICAgIHJldHVybiBudWxsO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IGRhdGVIZWFkZXIgPSBjYWNoZWRSZXNwb25zZS5oZWFkZXJzLmdldCgnZGF0ZScpO1xuICAgICAgICBjb25zdCBwYXJzZWREYXRlID0gbmV3IERhdGUoZGF0ZUhlYWRlcik7XG4gICAgICAgIGNvbnN0IGhlYWRlclRpbWUgPSBwYXJzZWREYXRlLmdldFRpbWUoKTtcbiAgICAgICAgLy8gSWYgdGhlIERhdGUgaGVhZGVyIHdhcyBpbnZhbGlkIGZvciBzb21lIHJlYXNvbiwgcGFyc2VkRGF0ZS5nZXRUaW1lKClcbiAgICAgICAgLy8gd2lsbCByZXR1cm4gTmFOLlxuICAgICAgICBpZiAoaXNOYU4oaGVhZGVyVGltZSkpIHtcbiAgICAgICAgICByZXR1cm4gbnVsbDtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gaGVhZGVyVGltZTtcbiAgICAgIH1cbiAgICAgIC8qKlxuICAgICAgICogVGhpcyBpcyBhIGhlbHBlciBtZXRob2QgdGhhdCBwZXJmb3JtcyB0d28gb3BlcmF0aW9uczpcbiAgICAgICAqXG4gICAgICAgKiAtIERlbGV0ZXMgKmFsbCogdGhlIHVuZGVybHlpbmcgQ2FjaGUgaW5zdGFuY2VzIGFzc29jaWF0ZWQgd2l0aCB0aGlzIHBsdWdpblxuICAgICAgICogaW5zdGFuY2UsIGJ5IGNhbGxpbmcgY2FjaGVzLmRlbGV0ZSgpIG9uIHlvdXIgYmVoYWxmLlxuICAgICAgICogLSBEZWxldGVzIHRoZSBtZXRhZGF0YSBmcm9tIEluZGV4ZWREQiB1c2VkIHRvIGtlZXAgdHJhY2sgb2YgZXhwaXJhdGlvblxuICAgICAgICogZGV0YWlscyBmb3IgZWFjaCBDYWNoZSBpbnN0YW5jZS5cbiAgICAgICAqXG4gICAgICAgKiBXaGVuIHVzaW5nIGNhY2hlIGV4cGlyYXRpb24sIGNhbGxpbmcgdGhpcyBtZXRob2QgaXMgcHJlZmVyYWJsZSB0byBjYWxsaW5nXG4gICAgICAgKiBgY2FjaGVzLmRlbGV0ZSgpYCBkaXJlY3RseSwgc2luY2UgdGhpcyB3aWxsIGVuc3VyZSB0aGF0IHRoZSBJbmRleGVkREJcbiAgICAgICAqIG1ldGFkYXRhIGlzIGFsc28gY2xlYW5seSByZW1vdmVkIGFuZCBvcGVuIEluZGV4ZWREQiBpbnN0YW5jZXMgYXJlIGRlbGV0ZWQuXG4gICAgICAgKlxuICAgICAgICogTm90ZSB0aGF0IGlmIHlvdSdyZSAqbm90KiB1c2luZyBjYWNoZSBleHBpcmF0aW9uIGZvciBhIGdpdmVuIGNhY2hlLCBjYWxsaW5nXG4gICAgICAgKiBgY2FjaGVzLmRlbGV0ZSgpYCBhbmQgcGFzc2luZyBpbiB0aGUgY2FjaGUncyBuYW1lIHNob3VsZCBiZSBzdWZmaWNpZW50LlxuICAgICAgICogVGhlcmUgaXMgbm8gV29ya2JveC1zcGVjaWZpYyBtZXRob2QgbmVlZGVkIGZvciBjbGVhbnVwIGluIHRoYXQgY2FzZS5cbiAgICAgICAqL1xuICAgICAgYXN5bmMgZGVsZXRlQ2FjaGVBbmRNZXRhZGF0YSgpIHtcbiAgICAgICAgLy8gRG8gdGhpcyBvbmUgYXQgYSB0aW1lIGluc3RlYWQgb2YgYWxsIGF0IG9uY2UgdmlhIGBQcm9taXNlLmFsbCgpYCB0b1xuICAgICAgICAvLyByZWR1Y2UgdGhlIGNoYW5jZSBvZiBpbmNvbnNpc3RlbmN5IGlmIGEgcHJvbWlzZSByZWplY3RzLlxuICAgICAgICBmb3IgKGNvbnN0IFtjYWNoZU5hbWUsIGNhY2hlRXhwaXJhdGlvbl0gb2YgdGhpcy5fY2FjaGVFeHBpcmF0aW9ucykge1xuICAgICAgICAgIGF3YWl0IHNlbGYuY2FjaGVzLmRlbGV0ZShjYWNoZU5hbWUpO1xuICAgICAgICAgIGF3YWl0IGNhY2hlRXhwaXJhdGlvbi5kZWxldGUoKTtcbiAgICAgICAgfVxuICAgICAgICAvLyBSZXNldCB0aGlzLl9jYWNoZUV4cGlyYXRpb25zIHRvIGl0cyBpbml0aWFsIHN0YXRlLlxuICAgICAgICB0aGlzLl9jYWNoZUV4cGlyYXRpb25zID0gbmV3IE1hcCgpO1xuICAgICAgfVxuICAgIH1cblxuICAgIC8vIEB0cy1pZ25vcmVcbiAgICB0cnkge1xuICAgICAgc2VsZlsnd29ya2JveDpjYWNoZWFibGUtcmVzcG9uc2U6Ny40LjAnXSAmJiBfKCk7XG4gICAgfSBjYXRjaCAoZSkge31cblxuICAgIC8qXG4gICAgICBDb3B5cmlnaHQgMjAxOCBHb29nbGUgTExDXG5cbiAgICAgIFVzZSBvZiB0aGlzIHNvdXJjZSBjb2RlIGlzIGdvdmVybmVkIGJ5IGFuIE1JVC1zdHlsZVxuICAgICAgbGljZW5zZSB0aGF0IGNhbiBiZSBmb3VuZCBpbiB0aGUgTElDRU5TRSBmaWxlIG9yIGF0XG4gICAgICBodHRwczovL29wZW5zb3VyY2Uub3JnL2xpY2Vuc2VzL01JVC5cbiAgICAqL1xuICAgIC8qKlxuICAgICAqIFRoaXMgY2xhc3MgYWxsb3dzIHlvdSB0byBzZXQgdXAgcnVsZXMgZGV0ZXJtaW5pbmcgd2hhdFxuICAgICAqIHN0YXR1cyBjb2RlcyBhbmQvb3IgaGVhZGVycyBuZWVkIHRvIGJlIHByZXNlbnQgaW4gb3JkZXIgZm9yIGFcbiAgICAgKiBbYFJlc3BvbnNlYF0oaHR0cHM6Ly9kZXZlbG9wZXIubW96aWxsYS5vcmcvZW4tVVMvZG9jcy9XZWIvQVBJL1Jlc3BvbnNlKVxuICAgICAqIHRvIGJlIGNvbnNpZGVyZWQgY2FjaGVhYmxlLlxuICAgICAqXG4gICAgICogQG1lbWJlcm9mIHdvcmtib3gtY2FjaGVhYmxlLXJlc3BvbnNlXG4gICAgICovXG4gICAgY2xhc3MgQ2FjaGVhYmxlUmVzcG9uc2Uge1xuICAgICAgLyoqXG4gICAgICAgKiBUbyBjb25zdHJ1Y3QgYSBuZXcgQ2FjaGVhYmxlUmVzcG9uc2UgaW5zdGFuY2UgeW91IG11c3QgcHJvdmlkZSBhdCBsZWFzdFxuICAgICAgICogb25lIG9mIHRoZSBgY29uZmlnYCBwcm9wZXJ0aWVzLlxuICAgICAgICpcbiAgICAgICAqIElmIGJvdGggYHN0YXR1c2VzYCBhbmQgYGhlYWRlcnNgIGFyZSBzcGVjaWZpZWQsIHRoZW4gYm90aCBjb25kaXRpb25zIG11c3RcbiAgICAgICAqIGJlIG1ldCBmb3IgdGhlIGBSZXNwb25zZWAgdG8gYmUgY29uc2lkZXJlZCBjYWNoZWFibGUuXG4gICAgICAgKlxuICAgICAgICogQHBhcmFtIHtPYmplY3R9IGNvbmZpZ1xuICAgICAgICogQHBhcmFtIHtBcnJheTxudW1iZXI+fSBbY29uZmlnLnN0YXR1c2VzXSBPbmUgb3IgbW9yZSBzdGF0dXMgY29kZXMgdGhhdCBhXG4gICAgICAgKiBgUmVzcG9uc2VgIGNhbiBoYXZlIGFuZCBiZSBjb25zaWRlcmVkIGNhY2hlYWJsZS5cbiAgICAgICAqIEBwYXJhbSB7T2JqZWN0PHN0cmluZyxzdHJpbmc+fSBbY29uZmlnLmhlYWRlcnNdIEEgbWFwcGluZyBvZiBoZWFkZXIgbmFtZXNcbiAgICAgICAqIGFuZCBleHBlY3RlZCB2YWx1ZXMgdGhhdCBhIGBSZXNwb25zZWAgY2FuIGhhdmUgYW5kIGJlIGNvbnNpZGVyZWQgY2FjaGVhYmxlLlxuICAgICAgICogSWYgbXVsdGlwbGUgaGVhZGVycyBhcmUgcHJvdmlkZWQsIG9ubHkgb25lIG5lZWRzIHRvIGJlIHByZXNlbnQuXG4gICAgICAgKi9cbiAgICAgIGNvbnN0cnVjdG9yKGNvbmZpZyA9IHt9KSB7XG4gICAgICAgIHtcbiAgICAgICAgICBpZiAoIShjb25maWcuc3RhdHVzZXMgfHwgY29uZmlnLmhlYWRlcnMpKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgV29ya2JveEVycm9yKCdzdGF0dXNlcy1vci1oZWFkZXJzLXJlcXVpcmVkJywge1xuICAgICAgICAgICAgICBtb2R1bGVOYW1lOiAnd29ya2JveC1jYWNoZWFibGUtcmVzcG9uc2UnLFxuICAgICAgICAgICAgICBjbGFzc05hbWU6ICdDYWNoZWFibGVSZXNwb25zZScsXG4gICAgICAgICAgICAgIGZ1bmNOYW1lOiAnY29uc3RydWN0b3InXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICB9XG4gICAgICAgICAgaWYgKGNvbmZpZy5zdGF0dXNlcykge1xuICAgICAgICAgICAgZmluYWxBc3NlcnRFeHBvcnRzLmlzQXJyYXkoY29uZmlnLnN0YXR1c2VzLCB7XG4gICAgICAgICAgICAgIG1vZHVsZU5hbWU6ICd3b3JrYm94LWNhY2hlYWJsZS1yZXNwb25zZScsXG4gICAgICAgICAgICAgIGNsYXNzTmFtZTogJ0NhY2hlYWJsZVJlc3BvbnNlJyxcbiAgICAgICAgICAgICAgZnVuY05hbWU6ICdjb25zdHJ1Y3RvcicsXG4gICAgICAgICAgICAgIHBhcmFtTmFtZTogJ2NvbmZpZy5zdGF0dXNlcydcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgIH1cbiAgICAgICAgICBpZiAoY29uZmlnLmhlYWRlcnMpIHtcbiAgICAgICAgICAgIGZpbmFsQXNzZXJ0RXhwb3J0cy5pc1R5cGUoY29uZmlnLmhlYWRlcnMsICdvYmplY3QnLCB7XG4gICAgICAgICAgICAgIG1vZHVsZU5hbWU6ICd3b3JrYm94LWNhY2hlYWJsZS1yZXNwb25zZScsXG4gICAgICAgICAgICAgIGNsYXNzTmFtZTogJ0NhY2hlYWJsZVJlc3BvbnNlJyxcbiAgICAgICAgICAgICAgZnVuY05hbWU6ICdjb25zdHJ1Y3RvcicsXG4gICAgICAgICAgICAgIHBhcmFtTmFtZTogJ2NvbmZpZy5oZWFkZXJzJ1xuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIHRoaXMuX3N0YXR1c2VzID0gY29uZmlnLnN0YXR1c2VzO1xuICAgICAgICB0aGlzLl9oZWFkZXJzID0gY29uZmlnLmhlYWRlcnM7XG4gICAgICB9XG4gICAgICAvKipcbiAgICAgICAqIENoZWNrcyBhIHJlc3BvbnNlIHRvIHNlZSB3aGV0aGVyIGl0J3MgY2FjaGVhYmxlIG9yIG5vdCwgYmFzZWQgb24gdGhpc1xuICAgICAgICogb2JqZWN0J3MgY29uZmlndXJhdGlvbi5cbiAgICAgICAqXG4gICAgICAgKiBAcGFyYW0ge1Jlc3BvbnNlfSByZXNwb25zZSBUaGUgcmVzcG9uc2Ugd2hvc2UgY2FjaGVhYmlsaXR5IGlzIGJlaW5nXG4gICAgICAgKiBjaGVja2VkLlxuICAgICAgICogQHJldHVybiB7Ym9vbGVhbn0gYHRydWVgIGlmIHRoZSBgUmVzcG9uc2VgIGlzIGNhY2hlYWJsZSwgYW5kIGBmYWxzZWBcbiAgICAgICAqIG90aGVyd2lzZS5cbiAgICAgICAqL1xuICAgICAgaXNSZXNwb25zZUNhY2hlYWJsZShyZXNwb25zZSkge1xuICAgICAgICB7XG4gICAgICAgICAgZmluYWxBc3NlcnRFeHBvcnRzLmlzSW5zdGFuY2UocmVzcG9uc2UsIFJlc3BvbnNlLCB7XG4gICAgICAgICAgICBtb2R1bGVOYW1lOiAnd29ya2JveC1jYWNoZWFibGUtcmVzcG9uc2UnLFxuICAgICAgICAgICAgY2xhc3NOYW1lOiAnQ2FjaGVhYmxlUmVzcG9uc2UnLFxuICAgICAgICAgICAgZnVuY05hbWU6ICdpc1Jlc3BvbnNlQ2FjaGVhYmxlJyxcbiAgICAgICAgICAgIHBhcmFtTmFtZTogJ3Jlc3BvbnNlJ1xuICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgICAgIGxldCBjYWNoZWFibGUgPSB0cnVlO1xuICAgICAgICBpZiAodGhpcy5fc3RhdHVzZXMpIHtcbiAgICAgICAgICBjYWNoZWFibGUgPSB0aGlzLl9zdGF0dXNlcy5pbmNsdWRlcyhyZXNwb25zZS5zdGF0dXMpO1xuICAgICAgICB9XG4gICAgICAgIGlmICh0aGlzLl9oZWFkZXJzICYmIGNhY2hlYWJsZSkge1xuICAgICAgICAgIGNhY2hlYWJsZSA9IE9iamVjdC5rZXlzKHRoaXMuX2hlYWRlcnMpLnNvbWUoaGVhZGVyTmFtZSA9PiB7XG4gICAgICAgICAgICByZXR1cm4gcmVzcG9uc2UuaGVhZGVycy5nZXQoaGVhZGVyTmFtZSkgPT09IHRoaXMuX2hlYWRlcnNbaGVhZGVyTmFtZV07XG4gICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICAgICAge1xuICAgICAgICAgIGlmICghY2FjaGVhYmxlKSB7XG4gICAgICAgICAgICBsb2dnZXIuZ3JvdXBDb2xsYXBzZWQoYFRoZSByZXF1ZXN0IGZvciBgICsgYCcke2dldEZyaWVuZGx5VVJMKHJlc3BvbnNlLnVybCl9JyByZXR1cm5lZCBhIHJlc3BvbnNlIHRoYXQgZG9lcyBgICsgYG5vdCBtZWV0IHRoZSBjcml0ZXJpYSBmb3IgYmVpbmcgY2FjaGVkLmApO1xuICAgICAgICAgICAgbG9nZ2VyLmdyb3VwQ29sbGFwc2VkKGBWaWV3IGNhY2hlYWJpbGl0eSBjcml0ZXJpYSBoZXJlLmApO1xuICAgICAgICAgICAgbG9nZ2VyLmxvZyhgQ2FjaGVhYmxlIHN0YXR1c2VzOiBgICsgSlNPTi5zdHJpbmdpZnkodGhpcy5fc3RhdHVzZXMpKTtcbiAgICAgICAgICAgIGxvZ2dlci5sb2coYENhY2hlYWJsZSBoZWFkZXJzOiBgICsgSlNPTi5zdHJpbmdpZnkodGhpcy5faGVhZGVycywgbnVsbCwgMikpO1xuICAgICAgICAgICAgbG9nZ2VyLmdyb3VwRW5kKCk7XG4gICAgICAgICAgICBjb25zdCBsb2dGcmllbmRseUhlYWRlcnMgPSB7fTtcbiAgICAgICAgICAgIHJlc3BvbnNlLmhlYWRlcnMuZm9yRWFjaCgodmFsdWUsIGtleSkgPT4ge1xuICAgICAgICAgICAgICBsb2dGcmllbmRseUhlYWRlcnNba2V5XSA9IHZhbHVlO1xuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICBsb2dnZXIuZ3JvdXBDb2xsYXBzZWQoYFZpZXcgcmVzcG9uc2Ugc3RhdHVzIGFuZCBoZWFkZXJzIGhlcmUuYCk7XG4gICAgICAgICAgICBsb2dnZXIubG9nKGBSZXNwb25zZSBzdGF0dXM6ICR7cmVzcG9uc2Uuc3RhdHVzfWApO1xuICAgICAgICAgICAgbG9nZ2VyLmxvZyhgUmVzcG9uc2UgaGVhZGVyczogYCArIEpTT04uc3RyaW5naWZ5KGxvZ0ZyaWVuZGx5SGVhZGVycywgbnVsbCwgMikpO1xuICAgICAgICAgICAgbG9nZ2VyLmdyb3VwRW5kKCk7XG4gICAgICAgICAgICBsb2dnZXIuZ3JvdXBDb2xsYXBzZWQoYFZpZXcgZnVsbCByZXNwb25zZSBkZXRhaWxzIGhlcmUuYCk7XG4gICAgICAgICAgICBsb2dnZXIubG9nKHJlc3BvbnNlLmhlYWRlcnMpO1xuICAgICAgICAgICAgbG9nZ2VyLmxvZyhyZXNwb25zZSk7XG4gICAgICAgICAgICBsb2dnZXIuZ3JvdXBFbmQoKTtcbiAgICAgICAgICAgIGxvZ2dlci5ncm91cEVuZCgpO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gY2FjaGVhYmxlO1xuICAgICAgfVxuICAgIH1cblxuICAgIC8qXG4gICAgICBDb3B5cmlnaHQgMjAxOCBHb29nbGUgTExDXG5cbiAgICAgIFVzZSBvZiB0aGlzIHNvdXJjZSBjb2RlIGlzIGdvdmVybmVkIGJ5IGFuIE1JVC1zdHlsZVxuICAgICAgbGljZW5zZSB0aGF0IGNhbiBiZSBmb3VuZCBpbiB0aGUgTElDRU5TRSBmaWxlIG9yIGF0XG4gICAgICBodHRwczovL29wZW5zb3VyY2Uub3JnL2xpY2Vuc2VzL01JVC5cbiAgICAqL1xuICAgIC8qKlxuICAgICAqIEEgY2xhc3MgaW1wbGVtZW50aW5nIHRoZSBgY2FjaGVXaWxsVXBkYXRlYCBsaWZlY3ljbGUgY2FsbGJhY2suIFRoaXMgbWFrZXMgaXRcbiAgICAgKiBlYXNpZXIgdG8gYWRkIGluIGNhY2hlYWJpbGl0eSBjaGVja3MgdG8gcmVxdWVzdHMgbWFkZSB2aWEgV29ya2JveCdzIGJ1aWx0LWluXG4gICAgICogc3RyYXRlZ2llcy5cbiAgICAgKlxuICAgICAqIEBtZW1iZXJvZiB3b3JrYm94LWNhY2hlYWJsZS1yZXNwb25zZVxuICAgICAqL1xuICAgIGNsYXNzIENhY2hlYWJsZVJlc3BvbnNlUGx1Z2luIHtcbiAgICAgIC8qKlxuICAgICAgICogVG8gY29uc3RydWN0IGEgbmV3IENhY2hlYWJsZVJlc3BvbnNlUGx1Z2luIGluc3RhbmNlIHlvdSBtdXN0IHByb3ZpZGUgYXRcbiAgICAgICAqIGxlYXN0IG9uZSBvZiB0aGUgYGNvbmZpZ2AgcHJvcGVydGllcy5cbiAgICAgICAqXG4gICAgICAgKiBJZiBib3RoIGBzdGF0dXNlc2AgYW5kIGBoZWFkZXJzYCBhcmUgc3BlY2lmaWVkLCB0aGVuIGJvdGggY29uZGl0aW9ucyBtdXN0XG4gICAgICAgKiBiZSBtZXQgZm9yIHRoZSBgUmVzcG9uc2VgIHRvIGJlIGNvbnNpZGVyZWQgY2FjaGVhYmxlLlxuICAgICAgICpcbiAgICAgICAqIEBwYXJhbSB7T2JqZWN0fSBjb25maWdcbiAgICAgICAqIEBwYXJhbSB7QXJyYXk8bnVtYmVyPn0gW2NvbmZpZy5zdGF0dXNlc10gT25lIG9yIG1vcmUgc3RhdHVzIGNvZGVzIHRoYXQgYVxuICAgICAgICogYFJlc3BvbnNlYCBjYW4gaGF2ZSBhbmQgYmUgY29uc2lkZXJlZCBjYWNoZWFibGUuXG4gICAgICAgKiBAcGFyYW0ge09iamVjdDxzdHJpbmcsc3RyaW5nPn0gW2NvbmZpZy5oZWFkZXJzXSBBIG1hcHBpbmcgb2YgaGVhZGVyIG5hbWVzXG4gICAgICAgKiBhbmQgZXhwZWN0ZWQgdmFsdWVzIHRoYXQgYSBgUmVzcG9uc2VgIGNhbiBoYXZlIGFuZCBiZSBjb25zaWRlcmVkIGNhY2hlYWJsZS5cbiAgICAgICAqIElmIG11bHRpcGxlIGhlYWRlcnMgYXJlIHByb3ZpZGVkLCBvbmx5IG9uZSBuZWVkcyB0byBiZSBwcmVzZW50LlxuICAgICAgICovXG4gICAgICBjb25zdHJ1Y3Rvcihjb25maWcpIHtcbiAgICAgICAgLyoqXG4gICAgICAgICAqIEBwYXJhbSB7T2JqZWN0fSBvcHRpb25zXG4gICAgICAgICAqIEBwYXJhbSB7UmVzcG9uc2V9IG9wdGlvbnMucmVzcG9uc2VcbiAgICAgICAgICogQHJldHVybiB7UmVzcG9uc2V8bnVsbH1cbiAgICAgICAgICogQHByaXZhdGVcbiAgICAgICAgICovXG4gICAgICAgIHRoaXMuY2FjaGVXaWxsVXBkYXRlID0gYXN5bmMgKHtcbiAgICAgICAgICByZXNwb25zZVxuICAgICAgICB9KSA9PiB7XG4gICAgICAgICAgaWYgKHRoaXMuX2NhY2hlYWJsZVJlc3BvbnNlLmlzUmVzcG9uc2VDYWNoZWFibGUocmVzcG9uc2UpKSB7XG4gICAgICAgICAgICByZXR1cm4gcmVzcG9uc2U7XG4gICAgICAgICAgfVxuICAgICAgICAgIHJldHVybiBudWxsO1xuICAgICAgICB9O1xuICAgICAgICB0aGlzLl9jYWNoZWFibGVSZXNwb25zZSA9IG5ldyBDYWNoZWFibGVSZXNwb25zZShjb25maWcpO1xuICAgICAgfVxuICAgIH1cblxuICAgIC8vIEB0cy1pZ25vcmVcbiAgICB0cnkge1xuICAgICAgc2VsZlsnd29ya2JveDpzdHJhdGVnaWVzOjcuNC4wJ10gJiYgXygpO1xuICAgIH0gY2F0Y2ggKGUpIHt9XG5cbiAgICAvKlxuICAgICAgQ29weXJpZ2h0IDIwMTggR29vZ2xlIExMQ1xuXG4gICAgICBVc2Ugb2YgdGhpcyBzb3VyY2UgY29kZSBpcyBnb3Zlcm5lZCBieSBhbiBNSVQtc3R5bGVcbiAgICAgIGxpY2Vuc2UgdGhhdCBjYW4gYmUgZm91bmQgaW4gdGhlIExJQ0VOU0UgZmlsZSBvciBhdFxuICAgICAgaHR0cHM6Ly9vcGVuc291cmNlLm9yZy9saWNlbnNlcy9NSVQuXG4gICAgKi9cbiAgICBjb25zdCBjYWNoZU9rQW5kT3BhcXVlUGx1Z2luID0ge1xuICAgICAgLyoqXG4gICAgICAgKiBSZXR1cm5zIGEgdmFsaWQgcmVzcG9uc2UgKHRvIGFsbG93IGNhY2hpbmcpIGlmIHRoZSBzdGF0dXMgaXMgMjAwIChPSykgb3JcbiAgICAgICAqIDAgKG9wYXF1ZSkuXG4gICAgICAgKlxuICAgICAgICogQHBhcmFtIHtPYmplY3R9IG9wdGlvbnNcbiAgICAgICAqIEBwYXJhbSB7UmVzcG9uc2V9IG9wdGlvbnMucmVzcG9uc2VcbiAgICAgICAqIEByZXR1cm4ge1Jlc3BvbnNlfG51bGx9XG4gICAgICAgKlxuICAgICAgICogQHByaXZhdGVcbiAgICAgICAqL1xuICAgICAgY2FjaGVXaWxsVXBkYXRlOiBhc3luYyAoe1xuICAgICAgICByZXNwb25zZVxuICAgICAgfSkgPT4ge1xuICAgICAgICBpZiAocmVzcG9uc2Uuc3RhdHVzID09PSAyMDAgfHwgcmVzcG9uc2Uuc3RhdHVzID09PSAwKSB7XG4gICAgICAgICAgcmV0dXJuIHJlc3BvbnNlO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBudWxsO1xuICAgICAgfVxuICAgIH07XG5cbiAgICAvKlxuICAgICAgQ29weXJpZ2h0IDIwMjAgR29vZ2xlIExMQ1xuICAgICAgVXNlIG9mIHRoaXMgc291cmNlIGNvZGUgaXMgZ292ZXJuZWQgYnkgYW4gTUlULXN0eWxlXG4gICAgICBsaWNlbnNlIHRoYXQgY2FuIGJlIGZvdW5kIGluIHRoZSBMSUNFTlNFIGZpbGUgb3IgYXRcbiAgICAgIGh0dHBzOi8vb3BlbnNvdXJjZS5vcmcvbGljZW5zZXMvTUlULlxuICAgICovXG4gICAgZnVuY3Rpb24gc3RyaXBQYXJhbXMoZnVsbFVSTCwgaWdub3JlUGFyYW1zKSB7XG4gICAgICBjb25zdCBzdHJpcHBlZFVSTCA9IG5ldyBVUkwoZnVsbFVSTCk7XG4gICAgICBmb3IgKGNvbnN0IHBhcmFtIG9mIGlnbm9yZVBhcmFtcykge1xuICAgICAgICBzdHJpcHBlZFVSTC5zZWFyY2hQYXJhbXMuZGVsZXRlKHBhcmFtKTtcbiAgICAgIH1cbiAgICAgIHJldHVybiBzdHJpcHBlZFVSTC5ocmVmO1xuICAgIH1cbiAgICAvKipcbiAgICAgKiBNYXRjaGVzIGFuIGl0ZW0gaW4gdGhlIGNhY2hlLCBpZ25vcmluZyBzcGVjaWZpYyBVUkwgcGFyYW1zLiBUaGlzIGlzIHNpbWlsYXJcbiAgICAgKiB0byB0aGUgYGlnbm9yZVNlYXJjaGAgb3B0aW9uLCBidXQgaXQgYWxsb3dzIHlvdSB0byBpZ25vcmUganVzdCBzcGVjaWZpY1xuICAgICAqIHBhcmFtcyAod2hpbGUgY29udGludWluZyB0byBtYXRjaCBvbiB0aGUgb3RoZXJzKS5cbiAgICAgKlxuICAgICAqIEBwcml2YXRlXG4gICAgICogQHBhcmFtIHtDYWNoZX0gY2FjaGVcbiAgICAgKiBAcGFyYW0ge1JlcXVlc3R9IHJlcXVlc3RcbiAgICAgKiBAcGFyYW0ge09iamVjdH0gbWF0Y2hPcHRpb25zXG4gICAgICogQHBhcmFtIHtBcnJheTxzdHJpbmc+fSBpZ25vcmVQYXJhbXNcbiAgICAgKiBAcmV0dXJuIHtQcm9taXNlPFJlc3BvbnNlfHVuZGVmaW5lZD59XG4gICAgICovXG4gICAgYXN5bmMgZnVuY3Rpb24gY2FjaGVNYXRjaElnbm9yZVBhcmFtcyhjYWNoZSwgcmVxdWVzdCwgaWdub3JlUGFyYW1zLCBtYXRjaE9wdGlvbnMpIHtcbiAgICAgIGNvbnN0IHN0cmlwcGVkUmVxdWVzdFVSTCA9IHN0cmlwUGFyYW1zKHJlcXVlc3QudXJsLCBpZ25vcmVQYXJhbXMpO1xuICAgICAgLy8gSWYgdGhlIHJlcXVlc3QgZG9lc24ndCBpbmNsdWRlIGFueSBpZ25vcmVkIHBhcmFtcywgbWF0Y2ggYXMgbm9ybWFsLlxuICAgICAgaWYgKHJlcXVlc3QudXJsID09PSBzdHJpcHBlZFJlcXVlc3RVUkwpIHtcbiAgICAgICAgcmV0dXJuIGNhY2hlLm1hdGNoKHJlcXVlc3QsIG1hdGNoT3B0aW9ucyk7XG4gICAgICB9XG4gICAgICAvLyBPdGhlcndpc2UsIG1hdGNoIGJ5IGNvbXBhcmluZyBrZXlzXG4gICAgICBjb25zdCBrZXlzT3B0aW9ucyA9IE9iamVjdC5hc3NpZ24oT2JqZWN0LmFzc2lnbih7fSwgbWF0Y2hPcHRpb25zKSwge1xuICAgICAgICBpZ25vcmVTZWFyY2g6IHRydWVcbiAgICAgIH0pO1xuICAgICAgY29uc3QgY2FjaGVLZXlzID0gYXdhaXQgY2FjaGUua2V5cyhyZXF1ZXN0LCBrZXlzT3B0aW9ucyk7XG4gICAgICBmb3IgKGNvbnN0IGNhY2hlS2V5IG9mIGNhY2hlS2V5cykge1xuICAgICAgICBjb25zdCBzdHJpcHBlZENhY2hlS2V5VVJMID0gc3RyaXBQYXJhbXMoY2FjaGVLZXkudXJsLCBpZ25vcmVQYXJhbXMpO1xuICAgICAgICBpZiAoc3RyaXBwZWRSZXF1ZXN0VVJMID09PSBzdHJpcHBlZENhY2hlS2V5VVJMKSB7XG4gICAgICAgICAgcmV0dXJuIGNhY2hlLm1hdGNoKGNhY2hlS2V5LCBtYXRjaE9wdGlvbnMpO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgLypcbiAgICAgIENvcHlyaWdodCAyMDE4IEdvb2dsZSBMTENcblxuICAgICAgVXNlIG9mIHRoaXMgc291cmNlIGNvZGUgaXMgZ292ZXJuZWQgYnkgYW4gTUlULXN0eWxlXG4gICAgICBsaWNlbnNlIHRoYXQgY2FuIGJlIGZvdW5kIGluIHRoZSBMSUNFTlNFIGZpbGUgb3IgYXRcbiAgICAgIGh0dHBzOi8vb3BlbnNvdXJjZS5vcmcvbGljZW5zZXMvTUlULlxuICAgICovXG4gICAgLyoqXG4gICAgICogVGhlIERlZmVycmVkIGNsYXNzIGNvbXBvc2VzIFByb21pc2VzIGluIGEgd2F5IHRoYXQgYWxsb3dzIGZvciB0aGVtIHRvIGJlXG4gICAgICogcmVzb2x2ZWQgb3IgcmVqZWN0ZWQgZnJvbSBvdXRzaWRlIHRoZSBjb25zdHJ1Y3Rvci4gSW4gbW9zdCBjYXNlcyBwcm9taXNlc1xuICAgICAqIHNob3VsZCBiZSB1c2VkIGRpcmVjdGx5LCBidXQgRGVmZXJyZWRzIGNhbiBiZSBuZWNlc3Nhcnkgd2hlbiB0aGUgbG9naWMgdG9cbiAgICAgKiByZXNvbHZlIGEgcHJvbWlzZSBtdXN0IGJlIHNlcGFyYXRlLlxuICAgICAqXG4gICAgICogQHByaXZhdGVcbiAgICAgKi9cbiAgICBjbGFzcyBEZWZlcnJlZCB7XG4gICAgICAvKipcbiAgICAgICAqIENyZWF0ZXMgYSBwcm9taXNlIGFuZCBleHBvc2VzIGl0cyByZXNvbHZlIGFuZCByZWplY3QgZnVuY3Rpb25zIGFzIG1ldGhvZHMuXG4gICAgICAgKi9cbiAgICAgIGNvbnN0cnVjdG9yKCkge1xuICAgICAgICB0aGlzLnByb21pc2UgPSBuZXcgUHJvbWlzZSgocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XG4gICAgICAgICAgdGhpcy5yZXNvbHZlID0gcmVzb2x2ZTtcbiAgICAgICAgICB0aGlzLnJlamVjdCA9IHJlamVjdDtcbiAgICAgICAgfSk7XG4gICAgICB9XG4gICAgfVxuXG4gICAgLypcbiAgICAgIENvcHlyaWdodCAyMDE4IEdvb2dsZSBMTENcblxuICAgICAgVXNlIG9mIHRoaXMgc291cmNlIGNvZGUgaXMgZ292ZXJuZWQgYnkgYW4gTUlULXN0eWxlXG4gICAgICBsaWNlbnNlIHRoYXQgY2FuIGJlIGZvdW5kIGluIHRoZSBMSUNFTlNFIGZpbGUgb3IgYXRcbiAgICAgIGh0dHBzOi8vb3BlbnNvdXJjZS5vcmcvbGljZW5zZXMvTUlULlxuICAgICovXG4gICAgLyoqXG4gICAgICogUnVucyBhbGwgb2YgdGhlIGNhbGxiYWNrIGZ1bmN0aW9ucywgb25lIGF0IGEgdGltZSBzZXF1ZW50aWFsbHksIGluIHRoZSBvcmRlclxuICAgICAqIGluIHdoaWNoIHRoZXkgd2VyZSByZWdpc3RlcmVkLlxuICAgICAqXG4gICAgICogQG1lbWJlcm9mIHdvcmtib3gtY29yZVxuICAgICAqIEBwcml2YXRlXG4gICAgICovXG4gICAgYXN5bmMgZnVuY3Rpb24gZXhlY3V0ZVF1b3RhRXJyb3JDYWxsYmFja3MoKSB7XG4gICAgICB7XG4gICAgICAgIGxvZ2dlci5sb2coYEFib3V0IHRvIHJ1biAke3F1b3RhRXJyb3JDYWxsYmFja3Muc2l6ZX0gYCArIGBjYWxsYmFja3MgdG8gY2xlYW4gdXAgY2FjaGVzLmApO1xuICAgICAgfVxuICAgICAgZm9yIChjb25zdCBjYWxsYmFjayBvZiBxdW90YUVycm9yQ2FsbGJhY2tzKSB7XG4gICAgICAgIGF3YWl0IGNhbGxiYWNrKCk7XG4gICAgICAgIHtcbiAgICAgICAgICBsb2dnZXIubG9nKGNhbGxiYWNrLCAnaXMgY29tcGxldGUuJyk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIHtcbiAgICAgICAgbG9nZ2VyLmxvZygnRmluaXNoZWQgcnVubmluZyBjYWxsYmFja3MuJyk7XG4gICAgICB9XG4gICAgfVxuXG4gICAgLypcbiAgICAgIENvcHlyaWdodCAyMDE5IEdvb2dsZSBMTENcbiAgICAgIFVzZSBvZiB0aGlzIHNvdXJjZSBjb2RlIGlzIGdvdmVybmVkIGJ5IGFuIE1JVC1zdHlsZVxuICAgICAgbGljZW5zZSB0aGF0IGNhbiBiZSBmb3VuZCBpbiB0aGUgTElDRU5TRSBmaWxlIG9yIGF0XG4gICAgICBodHRwczovL29wZW5zb3VyY2Uub3JnL2xpY2Vuc2VzL01JVC5cbiAgICAqL1xuICAgIC8qKlxuICAgICAqIFJldHVybnMgYSBwcm9taXNlIHRoYXQgcmVzb2x2ZXMgYW5kIHRoZSBwYXNzZWQgbnVtYmVyIG9mIG1pbGxpc2Vjb25kcy5cbiAgICAgKiBUaGlzIHV0aWxpdHkgaXMgYW4gYXN5bmMvYXdhaXQtZnJpZW5kbHkgdmVyc2lvbiBvZiBgc2V0VGltZW91dGAuXG4gICAgICpcbiAgICAgKiBAcGFyYW0ge251bWJlcn0gbXNcbiAgICAgKiBAcmV0dXJuIHtQcm9taXNlfVxuICAgICAqIEBwcml2YXRlXG4gICAgICovXG4gICAgZnVuY3Rpb24gdGltZW91dChtcykge1xuICAgICAgcmV0dXJuIG5ldyBQcm9taXNlKHJlc29sdmUgPT4gc2V0VGltZW91dChyZXNvbHZlLCBtcykpO1xuICAgIH1cblxuICAgIC8qXG4gICAgICBDb3B5cmlnaHQgMjAyMCBHb29nbGUgTExDXG5cbiAgICAgIFVzZSBvZiB0aGlzIHNvdXJjZSBjb2RlIGlzIGdvdmVybmVkIGJ5IGFuIE1JVC1zdHlsZVxuICAgICAgbGljZW5zZSB0aGF0IGNhbiBiZSBmb3VuZCBpbiB0aGUgTElDRU5TRSBmaWxlIG9yIGF0XG4gICAgICBodHRwczovL29wZW5zb3VyY2Uub3JnL2xpY2Vuc2VzL01JVC5cbiAgICAqL1xuICAgIGZ1bmN0aW9uIHRvUmVxdWVzdChpbnB1dCkge1xuICAgICAgcmV0dXJuIHR5cGVvZiBpbnB1dCA9PT0gJ3N0cmluZycgPyBuZXcgUmVxdWVzdChpbnB1dCkgOiBpbnB1dDtcbiAgICB9XG4gICAgLyoqXG4gICAgICogQSBjbGFzcyBjcmVhdGVkIGV2ZXJ5IHRpbWUgYSBTdHJhdGVneSBpbnN0YW5jZSBjYWxsc1xuICAgICAqIHtAbGluayB3b3JrYm94LXN0cmF0ZWdpZXMuU3RyYXRlZ3l+aGFuZGxlfSBvclxuICAgICAqIHtAbGluayB3b3JrYm94LXN0cmF0ZWdpZXMuU3RyYXRlZ3l+aGFuZGxlQWxsfSB0aGF0IHdyYXBzIGFsbCBmZXRjaCBhbmRcbiAgICAgKiBjYWNoZSBhY3Rpb25zIGFyb3VuZCBwbHVnaW4gY2FsbGJhY2tzIGFuZCBrZWVwcyB0cmFjayBvZiB3aGVuIHRoZSBzdHJhdGVneVxuICAgICAqIGlzIFwiZG9uZVwiIChpLmUuIGFsbCBhZGRlZCBgZXZlbnQud2FpdFVudGlsKClgIHByb21pc2VzIGhhdmUgcmVzb2x2ZWQpLlxuICAgICAqXG4gICAgICogQG1lbWJlcm9mIHdvcmtib3gtc3RyYXRlZ2llc1xuICAgICAqL1xuICAgIGNsYXNzIFN0cmF0ZWd5SGFuZGxlciB7XG4gICAgICAvKipcbiAgICAgICAqIENyZWF0ZXMgYSBuZXcgaW5zdGFuY2UgYXNzb2NpYXRlZCB3aXRoIHRoZSBwYXNzZWQgc3RyYXRlZ3kgYW5kIGV2ZW50XG4gICAgICAgKiB0aGF0J3MgaGFuZGxpbmcgdGhlIHJlcXVlc3QuXG4gICAgICAgKlxuICAgICAgICogVGhlIGNvbnN0cnVjdG9yIGFsc28gaW5pdGlhbGl6ZXMgdGhlIHN0YXRlIHRoYXQgd2lsbCBiZSBwYXNzZWQgdG8gZWFjaCBvZlxuICAgICAgICogdGhlIHBsdWdpbnMgaGFuZGxpbmcgdGhpcyByZXF1ZXN0LlxuICAgICAgICpcbiAgICAgICAqIEBwYXJhbSB7d29ya2JveC1zdHJhdGVnaWVzLlN0cmF0ZWd5fSBzdHJhdGVneVxuICAgICAgICogQHBhcmFtIHtPYmplY3R9IG9wdGlvbnNcbiAgICAgICAqIEBwYXJhbSB7UmVxdWVzdHxzdHJpbmd9IG9wdGlvbnMucmVxdWVzdCBBIHJlcXVlc3QgdG8gcnVuIHRoaXMgc3RyYXRlZ3kgZm9yLlxuICAgICAgICogQHBhcmFtIHtFeHRlbmRhYmxlRXZlbnR9IG9wdGlvbnMuZXZlbnQgVGhlIGV2ZW50IGFzc29jaWF0ZWQgd2l0aCB0aGVcbiAgICAgICAqICAgICByZXF1ZXN0LlxuICAgICAgICogQHBhcmFtIHtVUkx9IFtvcHRpb25zLnVybF1cbiAgICAgICAqIEBwYXJhbSB7Kn0gW29wdGlvbnMucGFyYW1zXSBUaGUgcmV0dXJuIHZhbHVlIGZyb20gdGhlXG4gICAgICAgKiAgICAge0BsaW5rIHdvcmtib3gtcm91dGluZ35tYXRjaENhbGxiYWNrfSAoaWYgYXBwbGljYWJsZSkuXG4gICAgICAgKi9cbiAgICAgIGNvbnN0cnVjdG9yKHN0cmF0ZWd5LCBvcHRpb25zKSB7XG4gICAgICAgIHRoaXMuX2NhY2hlS2V5cyA9IHt9O1xuICAgICAgICAvKipcbiAgICAgICAgICogVGhlIHJlcXVlc3QgdGhlIHN0cmF0ZWd5IGlzIHBlcmZvcm1pbmcgKHBhc3NlZCB0byB0aGUgc3RyYXRlZ3knc1xuICAgICAgICAgKiBgaGFuZGxlKClgIG9yIGBoYW5kbGVBbGwoKWAgbWV0aG9kKS5cbiAgICAgICAgICogQG5hbWUgcmVxdWVzdFxuICAgICAgICAgKiBAaW5zdGFuY2VcbiAgICAgICAgICogQHR5cGUge1JlcXVlc3R9XG4gICAgICAgICAqIEBtZW1iZXJvZiB3b3JrYm94LXN0cmF0ZWdpZXMuU3RyYXRlZ3lIYW5kbGVyXG4gICAgICAgICAqL1xuICAgICAgICAvKipcbiAgICAgICAgICogVGhlIGV2ZW50IGFzc29jaWF0ZWQgd2l0aCB0aGlzIHJlcXVlc3QuXG4gICAgICAgICAqIEBuYW1lIGV2ZW50XG4gICAgICAgICAqIEBpbnN0YW5jZVxuICAgICAgICAgKiBAdHlwZSB7RXh0ZW5kYWJsZUV2ZW50fVxuICAgICAgICAgKiBAbWVtYmVyb2Ygd29ya2JveC1zdHJhdGVnaWVzLlN0cmF0ZWd5SGFuZGxlclxuICAgICAgICAgKi9cbiAgICAgICAgLyoqXG4gICAgICAgICAqIEEgYFVSTGAgaW5zdGFuY2Ugb2YgYHJlcXVlc3QudXJsYCAoaWYgcGFzc2VkIHRvIHRoZSBzdHJhdGVneSdzXG4gICAgICAgICAqIGBoYW5kbGUoKWAgb3IgYGhhbmRsZUFsbCgpYCBtZXRob2QpLlxuICAgICAgICAgKiBOb3RlOiB0aGUgYHVybGAgcGFyYW0gd2lsbCBiZSBwcmVzZW50IGlmIHRoZSBzdHJhdGVneSB3YXMgaW52b2tlZFxuICAgICAgICAgKiBmcm9tIGEgd29ya2JveCBgUm91dGVgIG9iamVjdC5cbiAgICAgICAgICogQG5hbWUgdXJsXG4gICAgICAgICAqIEBpbnN0YW5jZVxuICAgICAgICAgKiBAdHlwZSB7VVJMfHVuZGVmaW5lZH1cbiAgICAgICAgICogQG1lbWJlcm9mIHdvcmtib3gtc3RyYXRlZ2llcy5TdHJhdGVneUhhbmRsZXJcbiAgICAgICAgICovXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBBIGBwYXJhbWAgdmFsdWUgKGlmIHBhc3NlZCB0byB0aGUgc3RyYXRlZ3knc1xuICAgICAgICAgKiBgaGFuZGxlKClgIG9yIGBoYW5kbGVBbGwoKWAgbWV0aG9kKS5cbiAgICAgICAgICogTm90ZTogdGhlIGBwYXJhbWAgcGFyYW0gd2lsbCBiZSBwcmVzZW50IGlmIHRoZSBzdHJhdGVneSB3YXMgaW52b2tlZFxuICAgICAgICAgKiBmcm9tIGEgd29ya2JveCBgUm91dGVgIG9iamVjdCBhbmQgdGhlXG4gICAgICAgICAqIHtAbGluayB3b3JrYm94LXJvdXRpbmd+bWF0Y2hDYWxsYmFja30gcmV0dXJuZWRcbiAgICAgICAgICogYSB0cnV0aHkgdmFsdWUgKGl0IHdpbGwgYmUgdGhhdCB2YWx1ZSkuXG4gICAgICAgICAqIEBuYW1lIHBhcmFtc1xuICAgICAgICAgKiBAaW5zdGFuY2VcbiAgICAgICAgICogQHR5cGUgeyp8dW5kZWZpbmVkfVxuICAgICAgICAgKiBAbWVtYmVyb2Ygd29ya2JveC1zdHJhdGVnaWVzLlN0cmF0ZWd5SGFuZGxlclxuICAgICAgICAgKi9cbiAgICAgICAge1xuICAgICAgICAgIGZpbmFsQXNzZXJ0RXhwb3J0cy5pc0luc3RhbmNlKG9wdGlvbnMuZXZlbnQsIEV4dGVuZGFibGVFdmVudCwge1xuICAgICAgICAgICAgbW9kdWxlTmFtZTogJ3dvcmtib3gtc3RyYXRlZ2llcycsXG4gICAgICAgICAgICBjbGFzc05hbWU6ICdTdHJhdGVneUhhbmRsZXInLFxuICAgICAgICAgICAgZnVuY05hbWU6ICdjb25zdHJ1Y3RvcicsXG4gICAgICAgICAgICBwYXJhbU5hbWU6ICdvcHRpb25zLmV2ZW50J1xuICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgICAgIE9iamVjdC5hc3NpZ24odGhpcywgb3B0aW9ucyk7XG4gICAgICAgIHRoaXMuZXZlbnQgPSBvcHRpb25zLmV2ZW50O1xuICAgICAgICB0aGlzLl9zdHJhdGVneSA9IHN0cmF0ZWd5O1xuICAgICAgICB0aGlzLl9oYW5kbGVyRGVmZXJyZWQgPSBuZXcgRGVmZXJyZWQoKTtcbiAgICAgICAgdGhpcy5fZXh0ZW5kTGlmZXRpbWVQcm9taXNlcyA9IFtdO1xuICAgICAgICAvLyBDb3B5IHRoZSBwbHVnaW5zIGxpc3QgKHNpbmNlIGl0J3MgbXV0YWJsZSBvbiB0aGUgc3RyYXRlZ3kpLFxuICAgICAgICAvLyBzbyBhbnkgbXV0YXRpb25zIGRvbid0IGFmZmVjdCB0aGlzIGhhbmRsZXIgaW5zdGFuY2UuXG4gICAgICAgIHRoaXMuX3BsdWdpbnMgPSBbLi4uc3RyYXRlZ3kucGx1Z2luc107XG4gICAgICAgIHRoaXMuX3BsdWdpblN0YXRlTWFwID0gbmV3IE1hcCgpO1xuICAgICAgICBmb3IgKGNvbnN0IHBsdWdpbiBvZiB0aGlzLl9wbHVnaW5zKSB7XG4gICAgICAgICAgdGhpcy5fcGx1Z2luU3RhdGVNYXAuc2V0KHBsdWdpbiwge30pO1xuICAgICAgICB9XG4gICAgICAgIHRoaXMuZXZlbnQud2FpdFVudGlsKHRoaXMuX2hhbmRsZXJEZWZlcnJlZC5wcm9taXNlKTtcbiAgICAgIH1cbiAgICAgIC8qKlxuICAgICAgICogRmV0Y2hlcyBhIGdpdmVuIHJlcXVlc3QgKGFuZCBpbnZva2VzIGFueSBhcHBsaWNhYmxlIHBsdWdpbiBjYWxsYmFja1xuICAgICAgICogbWV0aG9kcykgdXNpbmcgdGhlIGBmZXRjaE9wdGlvbnNgIChmb3Igbm9uLW5hdmlnYXRpb24gcmVxdWVzdHMpIGFuZFxuICAgICAgICogYHBsdWdpbnNgIGRlZmluZWQgb24gdGhlIGBTdHJhdGVneWAgb2JqZWN0LlxuICAgICAgICpcbiAgICAgICAqIFRoZSBmb2xsb3dpbmcgcGx1Z2luIGxpZmVjeWNsZSBtZXRob2RzIGFyZSBpbnZva2VkIHdoZW4gdXNpbmcgdGhpcyBtZXRob2Q6XG4gICAgICAgKiAtIGByZXF1ZXN0V2lsbEZldGNoKClgXG4gICAgICAgKiAtIGBmZXRjaERpZFN1Y2NlZWQoKWBcbiAgICAgICAqIC0gYGZldGNoRGlkRmFpbCgpYFxuICAgICAgICpcbiAgICAgICAqIEBwYXJhbSB7UmVxdWVzdHxzdHJpbmd9IGlucHV0IFRoZSBVUkwgb3IgcmVxdWVzdCB0byBmZXRjaC5cbiAgICAgICAqIEByZXR1cm4ge1Byb21pc2U8UmVzcG9uc2U+fVxuICAgICAgICovXG4gICAgICBhc3luYyBmZXRjaChpbnB1dCkge1xuICAgICAgICBjb25zdCB7XG4gICAgICAgICAgZXZlbnRcbiAgICAgICAgfSA9IHRoaXM7XG4gICAgICAgIGxldCByZXF1ZXN0ID0gdG9SZXF1ZXN0KGlucHV0KTtcbiAgICAgICAgaWYgKHJlcXVlc3QubW9kZSA9PT0gJ25hdmlnYXRlJyAmJiBldmVudCBpbnN0YW5jZW9mIEZldGNoRXZlbnQgJiYgZXZlbnQucHJlbG9hZFJlc3BvbnNlKSB7XG4gICAgICAgICAgY29uc3QgcG9zc2libGVQcmVsb2FkUmVzcG9uc2UgPSBhd2FpdCBldmVudC5wcmVsb2FkUmVzcG9uc2U7XG4gICAgICAgICAgaWYgKHBvc3NpYmxlUHJlbG9hZFJlc3BvbnNlKSB7XG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgIGxvZ2dlci5sb2coYFVzaW5nIGEgcHJlbG9hZGVkIG5hdmlnYXRpb24gcmVzcG9uc2UgZm9yIGAgKyBgJyR7Z2V0RnJpZW5kbHlVUkwocmVxdWVzdC51cmwpfSdgKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHJldHVybiBwb3NzaWJsZVByZWxvYWRSZXNwb25zZTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgLy8gSWYgdGhlcmUgaXMgYSBmZXRjaERpZEZhaWwgcGx1Z2luLCB3ZSBuZWVkIHRvIHNhdmUgYSBjbG9uZSBvZiB0aGVcbiAgICAgICAgLy8gb3JpZ2luYWwgcmVxdWVzdCBiZWZvcmUgaXQncyBlaXRoZXIgbW9kaWZpZWQgYnkgYSByZXF1ZXN0V2lsbEZldGNoXG4gICAgICAgIC8vIHBsdWdpbiBvciBiZWZvcmUgdGhlIG9yaWdpbmFsIHJlcXVlc3QncyBib2R5IGlzIGNvbnN1bWVkIHZpYSBmZXRjaCgpLlxuICAgICAgICBjb25zdCBvcmlnaW5hbFJlcXVlc3QgPSB0aGlzLmhhc0NhbGxiYWNrKCdmZXRjaERpZEZhaWwnKSA/IHJlcXVlc3QuY2xvbmUoKSA6IG51bGw7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgZm9yIChjb25zdCBjYiBvZiB0aGlzLml0ZXJhdGVDYWxsYmFja3MoJ3JlcXVlc3RXaWxsRmV0Y2gnKSkge1xuICAgICAgICAgICAgcmVxdWVzdCA9IGF3YWl0IGNiKHtcbiAgICAgICAgICAgICAgcmVxdWVzdDogcmVxdWVzdC5jbG9uZSgpLFxuICAgICAgICAgICAgICBldmVudFxuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgfVxuICAgICAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgICAgICBpZiAoZXJyIGluc3RhbmNlb2YgRXJyb3IpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBXb3JrYm94RXJyb3IoJ3BsdWdpbi1lcnJvci1yZXF1ZXN0LXdpbGwtZmV0Y2gnLCB7XG4gICAgICAgICAgICAgIHRocm93bkVycm9yTWVzc2FnZTogZXJyLm1lc3NhZ2VcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICAvLyBUaGUgcmVxdWVzdCBjYW4gYmUgYWx0ZXJlZCBieSBwbHVnaW5zIHdpdGggYHJlcXVlc3RXaWxsRmV0Y2hgIG1ha2luZ1xuICAgICAgICAvLyB0aGUgb3JpZ2luYWwgcmVxdWVzdCAobW9zdCBsaWtlbHkgZnJvbSBhIGBmZXRjaGAgZXZlbnQpIGRpZmZlcmVudFxuICAgICAgICAvLyBmcm9tIHRoZSBSZXF1ZXN0IHdlIG1ha2UuIFBhc3MgYm90aCB0byBgZmV0Y2hEaWRGYWlsYCB0byBhaWQgZGVidWdnaW5nLlxuICAgICAgICBjb25zdCBwbHVnaW5GaWx0ZXJlZFJlcXVlc3QgPSByZXF1ZXN0LmNsb25lKCk7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgbGV0IGZldGNoUmVzcG9uc2U7XG4gICAgICAgICAgLy8gU2VlIGh0dHBzOi8vZ2l0aHViLmNvbS9Hb29nbGVDaHJvbWUvd29ya2JveC9pc3N1ZXMvMTc5NlxuICAgICAgICAgIGZldGNoUmVzcG9uc2UgPSBhd2FpdCBmZXRjaChyZXF1ZXN0LCByZXF1ZXN0Lm1vZGUgPT09ICduYXZpZ2F0ZScgPyB1bmRlZmluZWQgOiB0aGlzLl9zdHJhdGVneS5mZXRjaE9wdGlvbnMpO1xuICAgICAgICAgIGlmIChcImRldmVsb3BtZW50XCIgIT09ICdwcm9kdWN0aW9uJykge1xuICAgICAgICAgICAgbG9nZ2VyLmRlYnVnKGBOZXR3b3JrIHJlcXVlc3QgZm9yIGAgKyBgJyR7Z2V0RnJpZW5kbHlVUkwocmVxdWVzdC51cmwpfScgcmV0dXJuZWQgYSByZXNwb25zZSB3aXRoIGAgKyBgc3RhdHVzICcke2ZldGNoUmVzcG9uc2Uuc3RhdHVzfScuYCk7XG4gICAgICAgICAgfVxuICAgICAgICAgIGZvciAoY29uc3QgY2FsbGJhY2sgb2YgdGhpcy5pdGVyYXRlQ2FsbGJhY2tzKCdmZXRjaERpZFN1Y2NlZWQnKSkge1xuICAgICAgICAgICAgZmV0Y2hSZXNwb25zZSA9IGF3YWl0IGNhbGxiYWNrKHtcbiAgICAgICAgICAgICAgZXZlbnQsXG4gICAgICAgICAgICAgIHJlcXVlc3Q6IHBsdWdpbkZpbHRlcmVkUmVxdWVzdCxcbiAgICAgICAgICAgICAgcmVzcG9uc2U6IGZldGNoUmVzcG9uc2VcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgIH1cbiAgICAgICAgICByZXR1cm4gZmV0Y2hSZXNwb25zZTtcbiAgICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgICB7XG4gICAgICAgICAgICBsb2dnZXIubG9nKGBOZXR3b3JrIHJlcXVlc3QgZm9yIGAgKyBgJyR7Z2V0RnJpZW5kbHlVUkwocmVxdWVzdC51cmwpfScgdGhyZXcgYW4gZXJyb3IuYCwgZXJyb3IpO1xuICAgICAgICAgIH1cbiAgICAgICAgICAvLyBgb3JpZ2luYWxSZXF1ZXN0YCB3aWxsIG9ubHkgZXhpc3QgaWYgYSBgZmV0Y2hEaWRGYWlsYCBjYWxsYmFja1xuICAgICAgICAgIC8vIGlzIGJlaW5nIHVzZWQgKHNlZSBhYm92ZSkuXG4gICAgICAgICAgaWYgKG9yaWdpbmFsUmVxdWVzdCkge1xuICAgICAgICAgICAgYXdhaXQgdGhpcy5ydW5DYWxsYmFja3MoJ2ZldGNoRGlkRmFpbCcsIHtcbiAgICAgICAgICAgICAgZXJyb3I6IGVycm9yLFxuICAgICAgICAgICAgICBldmVudCxcbiAgICAgICAgICAgICAgb3JpZ2luYWxSZXF1ZXN0OiBvcmlnaW5hbFJlcXVlc3QuY2xvbmUoKSxcbiAgICAgICAgICAgICAgcmVxdWVzdDogcGx1Z2luRmlsdGVyZWRSZXF1ZXN0LmNsb25lKClcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgIH1cbiAgICAgICAgICB0aHJvdyBlcnJvcjtcbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgLyoqXG4gICAgICAgKiBDYWxscyBgdGhpcy5mZXRjaCgpYCBhbmQgKGluIHRoZSBiYWNrZ3JvdW5kKSBydW5zIGB0aGlzLmNhY2hlUHV0KClgIG9uXG4gICAgICAgKiB0aGUgcmVzcG9uc2UgZ2VuZXJhdGVkIGJ5IGB0aGlzLmZldGNoKClgLlxuICAgICAgICpcbiAgICAgICAqIFRoZSBjYWxsIHRvIGB0aGlzLmNhY2hlUHV0KClgIGF1dG9tYXRpY2FsbHkgaW52b2tlcyBgdGhpcy53YWl0VW50aWwoKWAsXG4gICAgICAgKiBzbyB5b3UgZG8gbm90IGhhdmUgdG8gbWFudWFsbHkgY2FsbCBgd2FpdFVudGlsKClgIG9uIHRoZSBldmVudC5cbiAgICAgICAqXG4gICAgICAgKiBAcGFyYW0ge1JlcXVlc3R8c3RyaW5nfSBpbnB1dCBUaGUgcmVxdWVzdCBvciBVUkwgdG8gZmV0Y2ggYW5kIGNhY2hlLlxuICAgICAgICogQHJldHVybiB7UHJvbWlzZTxSZXNwb25zZT59XG4gICAgICAgKi9cbiAgICAgIGFzeW5jIGZldGNoQW5kQ2FjaGVQdXQoaW5wdXQpIHtcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCB0aGlzLmZldGNoKGlucHV0KTtcbiAgICAgICAgY29uc3QgcmVzcG9uc2VDbG9uZSA9IHJlc3BvbnNlLmNsb25lKCk7XG4gICAgICAgIHZvaWQgdGhpcy53YWl0VW50aWwodGhpcy5jYWNoZVB1dChpbnB1dCwgcmVzcG9uc2VDbG9uZSkpO1xuICAgICAgICByZXR1cm4gcmVzcG9uc2U7XG4gICAgICB9XG4gICAgICAvKipcbiAgICAgICAqIE1hdGNoZXMgYSByZXF1ZXN0IGZyb20gdGhlIGNhY2hlIChhbmQgaW52b2tlcyBhbnkgYXBwbGljYWJsZSBwbHVnaW5cbiAgICAgICAqIGNhbGxiYWNrIG1ldGhvZHMpIHVzaW5nIHRoZSBgY2FjaGVOYW1lYCwgYG1hdGNoT3B0aW9uc2AsIGFuZCBgcGx1Z2luc2BcbiAgICAgICAqIGRlZmluZWQgb24gdGhlIHN0cmF0ZWd5IG9iamVjdC5cbiAgICAgICAqXG4gICAgICAgKiBUaGUgZm9sbG93aW5nIHBsdWdpbiBsaWZlY3ljbGUgbWV0aG9kcyBhcmUgaW52b2tlZCB3aGVuIHVzaW5nIHRoaXMgbWV0aG9kOlxuICAgICAgICogLSBjYWNoZUtleVdpbGxCZVVzZWQoKVxuICAgICAgICogLSBjYWNoZWRSZXNwb25zZVdpbGxCZVVzZWQoKVxuICAgICAgICpcbiAgICAgICAqIEBwYXJhbSB7UmVxdWVzdHxzdHJpbmd9IGtleSBUaGUgUmVxdWVzdCBvciBVUkwgdG8gdXNlIGFzIHRoZSBjYWNoZSBrZXkuXG4gICAgICAgKiBAcmV0dXJuIHtQcm9taXNlPFJlc3BvbnNlfHVuZGVmaW5lZD59IEEgbWF0Y2hpbmcgcmVzcG9uc2UsIGlmIGZvdW5kLlxuICAgICAgICovXG4gICAgICBhc3luYyBjYWNoZU1hdGNoKGtleSkge1xuICAgICAgICBjb25zdCByZXF1ZXN0ID0gdG9SZXF1ZXN0KGtleSk7XG4gICAgICAgIGxldCBjYWNoZWRSZXNwb25zZTtcbiAgICAgICAgY29uc3Qge1xuICAgICAgICAgIGNhY2hlTmFtZSxcbiAgICAgICAgICBtYXRjaE9wdGlvbnNcbiAgICAgICAgfSA9IHRoaXMuX3N0cmF0ZWd5O1xuICAgICAgICBjb25zdCBlZmZlY3RpdmVSZXF1ZXN0ID0gYXdhaXQgdGhpcy5nZXRDYWNoZUtleShyZXF1ZXN0LCAncmVhZCcpO1xuICAgICAgICBjb25zdCBtdWx0aU1hdGNoT3B0aW9ucyA9IE9iamVjdC5hc3NpZ24oT2JqZWN0LmFzc2lnbih7fSwgbWF0Y2hPcHRpb25zKSwge1xuICAgICAgICAgIGNhY2hlTmFtZVxuICAgICAgICB9KTtcbiAgICAgICAgY2FjaGVkUmVzcG9uc2UgPSBhd2FpdCBjYWNoZXMubWF0Y2goZWZmZWN0aXZlUmVxdWVzdCwgbXVsdGlNYXRjaE9wdGlvbnMpO1xuICAgICAgICB7XG4gICAgICAgICAgaWYgKGNhY2hlZFJlc3BvbnNlKSB7XG4gICAgICAgICAgICBsb2dnZXIuZGVidWcoYEZvdW5kIGEgY2FjaGVkIHJlc3BvbnNlIGluICcke2NhY2hlTmFtZX0nLmApO1xuICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBsb2dnZXIuZGVidWcoYE5vIGNhY2hlZCByZXNwb25zZSBmb3VuZCBpbiAnJHtjYWNoZU5hbWV9Jy5gKTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgZm9yIChjb25zdCBjYWxsYmFjayBvZiB0aGlzLml0ZXJhdGVDYWxsYmFja3MoJ2NhY2hlZFJlc3BvbnNlV2lsbEJlVXNlZCcpKSB7XG4gICAgICAgICAgY2FjaGVkUmVzcG9uc2UgPSAoYXdhaXQgY2FsbGJhY2soe1xuICAgICAgICAgICAgY2FjaGVOYW1lLFxuICAgICAgICAgICAgbWF0Y2hPcHRpb25zLFxuICAgICAgICAgICAgY2FjaGVkUmVzcG9uc2UsXG4gICAgICAgICAgICByZXF1ZXN0OiBlZmZlY3RpdmVSZXF1ZXN0LFxuICAgICAgICAgICAgZXZlbnQ6IHRoaXMuZXZlbnRcbiAgICAgICAgICB9KSkgfHwgdW5kZWZpbmVkO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBjYWNoZWRSZXNwb25zZTtcbiAgICAgIH1cbiAgICAgIC8qKlxuICAgICAgICogUHV0cyBhIHJlcXVlc3QvcmVzcG9uc2UgcGFpciBpbiB0aGUgY2FjaGUgKGFuZCBpbnZva2VzIGFueSBhcHBsaWNhYmxlXG4gICAgICAgKiBwbHVnaW4gY2FsbGJhY2sgbWV0aG9kcykgdXNpbmcgdGhlIGBjYWNoZU5hbWVgIGFuZCBgcGx1Z2luc2AgZGVmaW5lZCBvblxuICAgICAgICogdGhlIHN0cmF0ZWd5IG9iamVjdC5cbiAgICAgICAqXG4gICAgICAgKiBUaGUgZm9sbG93aW5nIHBsdWdpbiBsaWZlY3ljbGUgbWV0aG9kcyBhcmUgaW52b2tlZCB3aGVuIHVzaW5nIHRoaXMgbWV0aG9kOlxuICAgICAgICogLSBjYWNoZUtleVdpbGxCZVVzZWQoKVxuICAgICAgICogLSBjYWNoZVdpbGxVcGRhdGUoKVxuICAgICAgICogLSBjYWNoZURpZFVwZGF0ZSgpXG4gICAgICAgKlxuICAgICAgICogQHBhcmFtIHtSZXF1ZXN0fHN0cmluZ30ga2V5IFRoZSByZXF1ZXN0IG9yIFVSTCB0byB1c2UgYXMgdGhlIGNhY2hlIGtleS5cbiAgICAgICAqIEBwYXJhbSB7UmVzcG9uc2V9IHJlc3BvbnNlIFRoZSByZXNwb25zZSB0byBjYWNoZS5cbiAgICAgICAqIEByZXR1cm4ge1Byb21pc2U8Ym9vbGVhbj59IGBmYWxzZWAgaWYgYSBjYWNoZVdpbGxVcGRhdGUgY2F1c2VkIHRoZSByZXNwb25zZVxuICAgICAgICogbm90IGJlIGNhY2hlZCwgYW5kIGB0cnVlYCBvdGhlcndpc2UuXG4gICAgICAgKi9cbiAgICAgIGFzeW5jIGNhY2hlUHV0KGtleSwgcmVzcG9uc2UpIHtcbiAgICAgICAgY29uc3QgcmVxdWVzdCA9IHRvUmVxdWVzdChrZXkpO1xuICAgICAgICAvLyBSdW4gaW4gdGhlIG5leHQgdGFzayB0byBhdm9pZCBibG9ja2luZyBvdGhlciBjYWNoZSByZWFkcy5cbiAgICAgICAgLy8gaHR0cHM6Ly9naXRodWIuY29tL3czYy9TZXJ2aWNlV29ya2VyL2lzc3Vlcy8xMzk3XG4gICAgICAgIGF3YWl0IHRpbWVvdXQoMCk7XG4gICAgICAgIGNvbnN0IGVmZmVjdGl2ZVJlcXVlc3QgPSBhd2FpdCB0aGlzLmdldENhY2hlS2V5KHJlcXVlc3QsICd3cml0ZScpO1xuICAgICAgICB7XG4gICAgICAgICAgaWYgKGVmZmVjdGl2ZVJlcXVlc3QubWV0aG9kICYmIGVmZmVjdGl2ZVJlcXVlc3QubWV0aG9kICE9PSAnR0VUJykge1xuICAgICAgICAgICAgdGhyb3cgbmV3IFdvcmtib3hFcnJvcignYXR0ZW1wdC10by1jYWNoZS1ub24tZ2V0LXJlcXVlc3QnLCB7XG4gICAgICAgICAgICAgIHVybDogZ2V0RnJpZW5kbHlVUkwoZWZmZWN0aXZlUmVxdWVzdC51cmwpLFxuICAgICAgICAgICAgICBtZXRob2Q6IGVmZmVjdGl2ZVJlcXVlc3QubWV0aG9kXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICB9XG4gICAgICAgICAgLy8gU2VlIGh0dHBzOi8vZ2l0aHViLmNvbS9Hb29nbGVDaHJvbWUvd29ya2JveC9pc3N1ZXMvMjgxOFxuICAgICAgICAgIGNvbnN0IHZhcnkgPSByZXNwb25zZS5oZWFkZXJzLmdldCgnVmFyeScpO1xuICAgICAgICAgIGlmICh2YXJ5KSB7XG4gICAgICAgICAgICBsb2dnZXIuZGVidWcoYFRoZSByZXNwb25zZSBmb3IgJHtnZXRGcmllbmRseVVSTChlZmZlY3RpdmVSZXF1ZXN0LnVybCl9IGAgKyBgaGFzIGEgJ1Zhcnk6ICR7dmFyeX0nIGhlYWRlci4gYCArIGBDb25zaWRlciBzZXR0aW5nIHRoZSB7aWdub3JlVmFyeTogdHJ1ZX0gb3B0aW9uIG9uIHlvdXIgc3RyYXRlZ3kgYCArIGB0byBlbnN1cmUgY2FjaGUgbWF0Y2hpbmcgYW5kIGRlbGV0aW9uIHdvcmtzIGFzIGV4cGVjdGVkLmApO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBpZiAoIXJlc3BvbnNlKSB7XG4gICAgICAgICAge1xuICAgICAgICAgICAgbG9nZ2VyLmVycm9yKGBDYW5ub3QgY2FjaGUgbm9uLWV4aXN0ZW50IHJlc3BvbnNlIGZvciBgICsgYCcke2dldEZyaWVuZGx5VVJMKGVmZmVjdGl2ZVJlcXVlc3QudXJsKX0nLmApO1xuICAgICAgICAgIH1cbiAgICAgICAgICB0aHJvdyBuZXcgV29ya2JveEVycm9yKCdjYWNoZS1wdXQtd2l0aC1uby1yZXNwb25zZScsIHtcbiAgICAgICAgICAgIHVybDogZ2V0RnJpZW5kbHlVUkwoZWZmZWN0aXZlUmVxdWVzdC51cmwpXG4gICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgcmVzcG9uc2VUb0NhY2hlID0gYXdhaXQgdGhpcy5fZW5zdXJlUmVzcG9uc2VTYWZlVG9DYWNoZShyZXNwb25zZSk7XG4gICAgICAgIGlmICghcmVzcG9uc2VUb0NhY2hlKSB7XG4gICAgICAgICAge1xuICAgICAgICAgICAgbG9nZ2VyLmRlYnVnKGBSZXNwb25zZSAnJHtnZXRGcmllbmRseVVSTChlZmZlY3RpdmVSZXF1ZXN0LnVybCl9JyBgICsgYHdpbGwgbm90IGJlIGNhY2hlZC5gLCByZXNwb25zZVRvQ2FjaGUpO1xuICAgICAgICAgIH1cbiAgICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICAgIH1cbiAgICAgICAgY29uc3Qge1xuICAgICAgICAgIGNhY2hlTmFtZSxcbiAgICAgICAgICBtYXRjaE9wdGlvbnNcbiAgICAgICAgfSA9IHRoaXMuX3N0cmF0ZWd5O1xuICAgICAgICBjb25zdCBjYWNoZSA9IGF3YWl0IHNlbGYuY2FjaGVzLm9wZW4oY2FjaGVOYW1lKTtcbiAgICAgICAgY29uc3QgaGFzQ2FjaGVVcGRhdGVDYWxsYmFjayA9IHRoaXMuaGFzQ2FsbGJhY2soJ2NhY2hlRGlkVXBkYXRlJyk7XG4gICAgICAgIGNvbnN0IG9sZFJlc3BvbnNlID0gaGFzQ2FjaGVVcGRhdGVDYWxsYmFjayA/IGF3YWl0IGNhY2hlTWF0Y2hJZ25vcmVQYXJhbXMoXG4gICAgICAgIC8vIFRPRE8ocGhpbGlwd2FsdG9uKTogdGhlIGBfX1dCX1JFVklTSU9OX19gIHBhcmFtIGlzIGEgcHJlY2FjaGluZ1xuICAgICAgICAvLyBmZWF0dXJlLiBDb25zaWRlciBpbnRvIHdheXMgdG8gb25seSBhZGQgdGhpcyBiZWhhdmlvciBpZiB1c2luZ1xuICAgICAgICAvLyBwcmVjYWNoaW5nLlxuICAgICAgICBjYWNoZSwgZWZmZWN0aXZlUmVxdWVzdC5jbG9uZSgpLCBbJ19fV0JfUkVWSVNJT05fXyddLCBtYXRjaE9wdGlvbnMpIDogbnVsbDtcbiAgICAgICAge1xuICAgICAgICAgIGxvZ2dlci5kZWJ1ZyhgVXBkYXRpbmcgdGhlICcke2NhY2hlTmFtZX0nIGNhY2hlIHdpdGggYSBuZXcgUmVzcG9uc2UgYCArIGBmb3IgJHtnZXRGcmllbmRseVVSTChlZmZlY3RpdmVSZXF1ZXN0LnVybCl9LmApO1xuICAgICAgICB9XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgYXdhaXQgY2FjaGUucHV0KGVmZmVjdGl2ZVJlcXVlc3QsIGhhc0NhY2hlVXBkYXRlQ2FsbGJhY2sgPyByZXNwb25zZVRvQ2FjaGUuY2xvbmUoKSA6IHJlc3BvbnNlVG9DYWNoZSk7XG4gICAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgICAgaWYgKGVycm9yIGluc3RhbmNlb2YgRXJyb3IpIHtcbiAgICAgICAgICAgIC8vIFNlZSBodHRwczovL2RldmVsb3Blci5tb3ppbGxhLm9yZy9lbi1VUy9kb2NzL1dlYi9BUEkvRE9NRXhjZXB0aW9uI2V4Y2VwdGlvbi1RdW90YUV4Y2VlZGVkRXJyb3JcbiAgICAgICAgICAgIGlmIChlcnJvci5uYW1lID09PSAnUXVvdGFFeGNlZWRlZEVycm9yJykge1xuICAgICAgICAgICAgICBhd2FpdCBleGVjdXRlUXVvdGFFcnJvckNhbGxiYWNrcygpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgdGhyb3cgZXJyb3I7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGZvciAoY29uc3QgY2FsbGJhY2sgb2YgdGhpcy5pdGVyYXRlQ2FsbGJhY2tzKCdjYWNoZURpZFVwZGF0ZScpKSB7XG4gICAgICAgICAgYXdhaXQgY2FsbGJhY2soe1xuICAgICAgICAgICAgY2FjaGVOYW1lLFxuICAgICAgICAgICAgb2xkUmVzcG9uc2UsXG4gICAgICAgICAgICBuZXdSZXNwb25zZTogcmVzcG9uc2VUb0NhY2hlLmNsb25lKCksXG4gICAgICAgICAgICByZXF1ZXN0OiBlZmZlY3RpdmVSZXF1ZXN0LFxuICAgICAgICAgICAgZXZlbnQ6IHRoaXMuZXZlbnRcbiAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgIH1cbiAgICAgIC8qKlxuICAgICAgICogQ2hlY2tzIHRoZSBsaXN0IG9mIHBsdWdpbnMgZm9yIHRoZSBgY2FjaGVLZXlXaWxsQmVVc2VkYCBjYWxsYmFjaywgYW5kXG4gICAgICAgKiBleGVjdXRlcyBhbnkgb2YgdGhvc2UgY2FsbGJhY2tzIGZvdW5kIGluIHNlcXVlbmNlLiBUaGUgZmluYWwgYFJlcXVlc3RgXG4gICAgICAgKiBvYmplY3QgcmV0dXJuZWQgYnkgdGhlIGxhc3QgcGx1Z2luIGlzIHRyZWF0ZWQgYXMgdGhlIGNhY2hlIGtleSBmb3IgY2FjaGVcbiAgICAgICAqIHJlYWRzIGFuZC9vciB3cml0ZXMuIElmIG5vIGBjYWNoZUtleVdpbGxCZVVzZWRgIHBsdWdpbiBjYWxsYmFja3MgaGF2ZVxuICAgICAgICogYmVlbiByZWdpc3RlcmVkLCB0aGUgcGFzc2VkIHJlcXVlc3QgaXMgcmV0dXJuZWQgdW5tb2RpZmllZFxuICAgICAgICpcbiAgICAgICAqIEBwYXJhbSB7UmVxdWVzdH0gcmVxdWVzdFxuICAgICAgICogQHBhcmFtIHtzdHJpbmd9IG1vZGVcbiAgICAgICAqIEByZXR1cm4ge1Byb21pc2U8UmVxdWVzdD59XG4gICAgICAgKi9cbiAgICAgIGFzeW5jIGdldENhY2hlS2V5KHJlcXVlc3QsIG1vZGUpIHtcbiAgICAgICAgY29uc3Qga2V5ID0gYCR7cmVxdWVzdC51cmx9IHwgJHttb2RlfWA7XG4gICAgICAgIGlmICghdGhpcy5fY2FjaGVLZXlzW2tleV0pIHtcbiAgICAgICAgICBsZXQgZWZmZWN0aXZlUmVxdWVzdCA9IHJlcXVlc3Q7XG4gICAgICAgICAgZm9yIChjb25zdCBjYWxsYmFjayBvZiB0aGlzLml0ZXJhdGVDYWxsYmFja3MoJ2NhY2hlS2V5V2lsbEJlVXNlZCcpKSB7XG4gICAgICAgICAgICBlZmZlY3RpdmVSZXF1ZXN0ID0gdG9SZXF1ZXN0KGF3YWl0IGNhbGxiYWNrKHtcbiAgICAgICAgICAgICAgbW9kZSxcbiAgICAgICAgICAgICAgcmVxdWVzdDogZWZmZWN0aXZlUmVxdWVzdCxcbiAgICAgICAgICAgICAgZXZlbnQ6IHRoaXMuZXZlbnQsXG4gICAgICAgICAgICAgIC8vIHBhcmFtcyBoYXMgYSB0eXBlIGFueSBjYW4ndCBjaGFuZ2UgcmlnaHQgbm93LlxuICAgICAgICAgICAgICBwYXJhbXM6IHRoaXMucGFyYW1zIC8vIGVzbGludC1kaXNhYmxlLWxpbmVcbiAgICAgICAgICAgIH0pKTtcbiAgICAgICAgICB9XG4gICAgICAgICAgdGhpcy5fY2FjaGVLZXlzW2tleV0gPSBlZmZlY3RpdmVSZXF1ZXN0O1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiB0aGlzLl9jYWNoZUtleXNba2V5XTtcbiAgICAgIH1cbiAgICAgIC8qKlxuICAgICAgICogUmV0dXJucyB0cnVlIGlmIHRoZSBzdHJhdGVneSBoYXMgYXQgbGVhc3Qgb25lIHBsdWdpbiB3aXRoIHRoZSBnaXZlblxuICAgICAgICogY2FsbGJhY2suXG4gICAgICAgKlxuICAgICAgICogQHBhcmFtIHtzdHJpbmd9IG5hbWUgVGhlIG5hbWUgb2YgdGhlIGNhbGxiYWNrIHRvIGNoZWNrIGZvci5cbiAgICAgICAqIEByZXR1cm4ge2Jvb2xlYW59XG4gICAgICAgKi9cbiAgICAgIGhhc0NhbGxiYWNrKG5hbWUpIHtcbiAgICAgICAgZm9yIChjb25zdCBwbHVnaW4gb2YgdGhpcy5fc3RyYXRlZ3kucGx1Z2lucykge1xuICAgICAgICAgIGlmIChuYW1lIGluIHBsdWdpbikge1xuICAgICAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgIH1cbiAgICAgIC8qKlxuICAgICAgICogUnVucyBhbGwgcGx1Z2luIGNhbGxiYWNrcyBtYXRjaGluZyB0aGUgZ2l2ZW4gbmFtZSwgaW4gb3JkZXIsIHBhc3NpbmcgdGhlXG4gICAgICAgKiBnaXZlbiBwYXJhbSBvYmplY3QgKG1lcmdlZCBpdGggdGhlIGN1cnJlbnQgcGx1Z2luIHN0YXRlKSBhcyB0aGUgb25seVxuICAgICAgICogYXJndW1lbnQuXG4gICAgICAgKlxuICAgICAgICogTm90ZTogc2luY2UgdGhpcyBtZXRob2QgcnVucyBhbGwgcGx1Z2lucywgaXQncyBub3Qgc3VpdGFibGUgZm9yIGNhc2VzXG4gICAgICAgKiB3aGVyZSB0aGUgcmV0dXJuIHZhbHVlIG9mIGEgY2FsbGJhY2sgbmVlZHMgdG8gYmUgYXBwbGllZCBwcmlvciB0byBjYWxsaW5nXG4gICAgICAgKiB0aGUgbmV4dCBjYWxsYmFjay4gU2VlXG4gICAgICAgKiB7QGxpbmsgd29ya2JveC1zdHJhdGVnaWVzLlN0cmF0ZWd5SGFuZGxlciNpdGVyYXRlQ2FsbGJhY2tzfVxuICAgICAgICogYmVsb3cgZm9yIGhvdyB0byBoYW5kbGUgdGhhdCBjYXNlLlxuICAgICAgICpcbiAgICAgICAqIEBwYXJhbSB7c3RyaW5nfSBuYW1lIFRoZSBuYW1lIG9mIHRoZSBjYWxsYmFjayB0byBydW4gd2l0aGluIGVhY2ggcGx1Z2luLlxuICAgICAgICogQHBhcmFtIHtPYmplY3R9IHBhcmFtIFRoZSBvYmplY3QgdG8gcGFzcyBhcyB0aGUgZmlyc3QgKGFuZCBvbmx5KSBwYXJhbVxuICAgICAgICogICAgIHdoZW4gZXhlY3V0aW5nIGVhY2ggY2FsbGJhY2suIFRoaXMgb2JqZWN0IHdpbGwgYmUgbWVyZ2VkIHdpdGggdGhlXG4gICAgICAgKiAgICAgY3VycmVudCBwbHVnaW4gc3RhdGUgcHJpb3IgdG8gY2FsbGJhY2sgZXhlY3V0aW9uLlxuICAgICAgICovXG4gICAgICBhc3luYyBydW5DYWxsYmFja3MobmFtZSwgcGFyYW0pIHtcbiAgICAgICAgZm9yIChjb25zdCBjYWxsYmFjayBvZiB0aGlzLml0ZXJhdGVDYWxsYmFja3MobmFtZSkpIHtcbiAgICAgICAgICAvLyBUT0RPKHBoaWxpcHdhbHRvbik6IG5vdCBzdXJlIHdoeSBgYW55YCBpcyBuZWVkZWQuIEl0IHNlZW1zIGxpa2VcbiAgICAgICAgICAvLyB0aGlzIHNob3VsZCB3b3JrIHdpdGggYGFzIFdvcmtib3hQbHVnaW5DYWxsYmFja1BhcmFtW0NdYC5cbiAgICAgICAgICBhd2FpdCBjYWxsYmFjayhwYXJhbSk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIC8qKlxuICAgICAgICogQWNjZXB0cyBhIGNhbGxiYWNrIGFuZCByZXR1cm5zIGFuIGl0ZXJhYmxlIG9mIG1hdGNoaW5nIHBsdWdpbiBjYWxsYmFja3MsXG4gICAgICAgKiB3aGVyZSBlYWNoIGNhbGxiYWNrIGlzIHdyYXBwZWQgd2l0aCB0aGUgY3VycmVudCBoYW5kbGVyIHN0YXRlIChpLmUuIHdoZW5cbiAgICAgICAqIHlvdSBjYWxsIGVhY2ggY2FsbGJhY2ssIHdoYXRldmVyIG9iamVjdCBwYXJhbWV0ZXIgeW91IHBhc3MgaXQgd2lsbFxuICAgICAgICogYmUgbWVyZ2VkIHdpdGggdGhlIHBsdWdpbidzIGN1cnJlbnQgc3RhdGUpLlxuICAgICAgICpcbiAgICAgICAqIEBwYXJhbSB7c3RyaW5nfSBuYW1lIFRoZSBuYW1lIGZvIHRoZSBjYWxsYmFjayB0byBydW5cbiAgICAgICAqIEByZXR1cm4ge0FycmF5PEZ1bmN0aW9uPn1cbiAgICAgICAqL1xuICAgICAgKml0ZXJhdGVDYWxsYmFja3MobmFtZSkge1xuICAgICAgICBmb3IgKGNvbnN0IHBsdWdpbiBvZiB0aGlzLl9zdHJhdGVneS5wbHVnaW5zKSB7XG4gICAgICAgICAgaWYgKHR5cGVvZiBwbHVnaW5bbmFtZV0gPT09ICdmdW5jdGlvbicpIHtcbiAgICAgICAgICAgIGNvbnN0IHN0YXRlID0gdGhpcy5fcGx1Z2luU3RhdGVNYXAuZ2V0KHBsdWdpbik7XG4gICAgICAgICAgICBjb25zdCBzdGF0ZWZ1bENhbGxiYWNrID0gcGFyYW0gPT4ge1xuICAgICAgICAgICAgICBjb25zdCBzdGF0ZWZ1bFBhcmFtID0gT2JqZWN0LmFzc2lnbihPYmplY3QuYXNzaWduKHt9LCBwYXJhbSksIHtcbiAgICAgICAgICAgICAgICBzdGF0ZVxuICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgLy8gVE9ETyhwaGlsaXB3YWx0b24pOiBub3Qgc3VyZSB3aHkgYGFueWAgaXMgbmVlZGVkLiBJdCBzZWVtcyBsaWtlXG4gICAgICAgICAgICAgIC8vIHRoaXMgc2hvdWxkIHdvcmsgd2l0aCBgYXMgV29ya2JveFBsdWdpbkNhbGxiYWNrUGFyYW1bQ11gLlxuICAgICAgICAgICAgICByZXR1cm4gcGx1Z2luW25hbWVdKHN0YXRlZnVsUGFyYW0pO1xuICAgICAgICAgICAgfTtcbiAgICAgICAgICAgIHlpZWxkIHN0YXRlZnVsQ2FsbGJhY2s7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9XG4gICAgICAvKipcbiAgICAgICAqIEFkZHMgYSBwcm9taXNlIHRvIHRoZVxuICAgICAgICogW2V4dGVuZCBsaWZldGltZSBwcm9taXNlc117QGxpbmsgaHR0cHM6Ly93M2MuZ2l0aHViLmlvL1NlcnZpY2VXb3JrZXIvI2V4dGVuZGFibGVldmVudC1leHRlbmQtbGlmZXRpbWUtcHJvbWlzZXN9XG4gICAgICAgKiBvZiB0aGUgZXZlbnQgYXNzb2NpYXRlZCB3aXRoIHRoZSByZXF1ZXN0IGJlaW5nIGhhbmRsZWQgKHVzdWFsbHkgYVxuICAgICAgICogYEZldGNoRXZlbnRgKS5cbiAgICAgICAqXG4gICAgICAgKiBOb3RlOiB5b3UgY2FuIGF3YWl0XG4gICAgICAgKiB7QGxpbmsgd29ya2JveC1zdHJhdGVnaWVzLlN0cmF0ZWd5SGFuZGxlcn5kb25lV2FpdGluZ31cbiAgICAgICAqIHRvIGtub3cgd2hlbiBhbGwgYWRkZWQgcHJvbWlzZXMgaGF2ZSBzZXR0bGVkLlxuICAgICAgICpcbiAgICAgICAqIEBwYXJhbSB7UHJvbWlzZX0gcHJvbWlzZSBBIHByb21pc2UgdG8gYWRkIHRvIHRoZSBleHRlbmQgbGlmZXRpbWUgcHJvbWlzZXNcbiAgICAgICAqICAgICBvZiB0aGUgZXZlbnQgdGhhdCB0cmlnZ2VyZWQgdGhlIHJlcXVlc3QuXG4gICAgICAgKi9cbiAgICAgIHdhaXRVbnRpbChwcm9taXNlKSB7XG4gICAgICAgIHRoaXMuX2V4dGVuZExpZmV0aW1lUHJvbWlzZXMucHVzaChwcm9taXNlKTtcbiAgICAgICAgcmV0dXJuIHByb21pc2U7XG4gICAgICB9XG4gICAgICAvKipcbiAgICAgICAqIFJldHVybnMgYSBwcm9taXNlIHRoYXQgcmVzb2x2ZXMgb25jZSBhbGwgcHJvbWlzZXMgcGFzc2VkIHRvXG4gICAgICAgKiB7QGxpbmsgd29ya2JveC1zdHJhdGVnaWVzLlN0cmF0ZWd5SGFuZGxlcn53YWl0VW50aWx9XG4gICAgICAgKiBoYXZlIHNldHRsZWQuXG4gICAgICAgKlxuICAgICAgICogTm90ZTogYW55IHdvcmsgZG9uZSBhZnRlciBgZG9uZVdhaXRpbmcoKWAgc2V0dGxlcyBzaG91bGQgYmUgbWFudWFsbHlcbiAgICAgICAqIHBhc3NlZCB0byBhbiBldmVudCdzIGB3YWl0VW50aWwoKWAgbWV0aG9kIChub3QgdGhpcyBoYW5kbGVyJ3NcbiAgICAgICAqIGB3YWl0VW50aWwoKWAgbWV0aG9kKSwgb3RoZXJ3aXNlIHRoZSBzZXJ2aWNlIHdvcmtlciB0aHJlYWQgbWF5IGJlIGtpbGxlZFxuICAgICAgICogcHJpb3IgdG8geW91ciB3b3JrIGNvbXBsZXRpbmcuXG4gICAgICAgKi9cbiAgICAgIGFzeW5jIGRvbmVXYWl0aW5nKCkge1xuICAgICAgICB3aGlsZSAodGhpcy5fZXh0ZW5kTGlmZXRpbWVQcm9taXNlcy5sZW5ndGgpIHtcbiAgICAgICAgICBjb25zdCBwcm9taXNlcyA9IHRoaXMuX2V4dGVuZExpZmV0aW1lUHJvbWlzZXMuc3BsaWNlKDApO1xuICAgICAgICAgIGNvbnN0IHJlc3VsdCA9IGF3YWl0IFByb21pc2UuYWxsU2V0dGxlZChwcm9taXNlcyk7XG4gICAgICAgICAgY29uc3QgZmlyc3RSZWplY3Rpb24gPSByZXN1bHQuZmluZChpID0+IGkuc3RhdHVzID09PSAncmVqZWN0ZWQnKTtcbiAgICAgICAgICBpZiAoZmlyc3RSZWplY3Rpb24pIHtcbiAgICAgICAgICAgIHRocm93IGZpcnN0UmVqZWN0aW9uLnJlYXNvbjtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIC8qKlxuICAgICAgICogU3RvcHMgcnVubmluZyB0aGUgc3RyYXRlZ3kgYW5kIGltbWVkaWF0ZWx5IHJlc29sdmVzIGFueSBwZW5kaW5nXG4gICAgICAgKiBgd2FpdFVudGlsKClgIHByb21pc2VzLlxuICAgICAgICovXG4gICAgICBkZXN0cm95KCkge1xuICAgICAgICB0aGlzLl9oYW5kbGVyRGVmZXJyZWQucmVzb2x2ZShudWxsKTtcbiAgICAgIH1cbiAgICAgIC8qKlxuICAgICAgICogVGhpcyBtZXRob2Qgd2lsbCBjYWxsIGNhY2hlV2lsbFVwZGF0ZSBvbiB0aGUgYXZhaWxhYmxlIHBsdWdpbnMgKG9yIHVzZVxuICAgICAgICogc3RhdHVzID09PSAyMDApIHRvIGRldGVybWluZSBpZiB0aGUgUmVzcG9uc2UgaXMgc2FmZSBhbmQgdmFsaWQgdG8gY2FjaGUuXG4gICAgICAgKlxuICAgICAgICogQHBhcmFtIHtSZXF1ZXN0fSBvcHRpb25zLnJlcXVlc3RcbiAgICAgICAqIEBwYXJhbSB7UmVzcG9uc2V9IG9wdGlvbnMucmVzcG9uc2VcbiAgICAgICAqIEByZXR1cm4ge1Byb21pc2U8UmVzcG9uc2V8dW5kZWZpbmVkPn1cbiAgICAgICAqXG4gICAgICAgKiBAcHJpdmF0ZVxuICAgICAgICovXG4gICAgICBhc3luYyBfZW5zdXJlUmVzcG9uc2VTYWZlVG9DYWNoZShyZXNwb25zZSkge1xuICAgICAgICBsZXQgcmVzcG9uc2VUb0NhY2hlID0gcmVzcG9uc2U7XG4gICAgICAgIGxldCBwbHVnaW5zVXNlZCA9IGZhbHNlO1xuICAgICAgICBmb3IgKGNvbnN0IGNhbGxiYWNrIG9mIHRoaXMuaXRlcmF0ZUNhbGxiYWNrcygnY2FjaGVXaWxsVXBkYXRlJykpIHtcbiAgICAgICAgICByZXNwb25zZVRvQ2FjaGUgPSAoYXdhaXQgY2FsbGJhY2soe1xuICAgICAgICAgICAgcmVxdWVzdDogdGhpcy5yZXF1ZXN0LFxuICAgICAgICAgICAgcmVzcG9uc2U6IHJlc3BvbnNlVG9DYWNoZSxcbiAgICAgICAgICAgIGV2ZW50OiB0aGlzLmV2ZW50XG4gICAgICAgICAgfSkpIHx8IHVuZGVmaW5lZDtcbiAgICAgICAgICBwbHVnaW5zVXNlZCA9IHRydWU7XG4gICAgICAgICAgaWYgKCFyZXNwb25zZVRvQ2FjaGUpIHtcbiAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBpZiAoIXBsdWdpbnNVc2VkKSB7XG4gICAgICAgICAgaWYgKHJlc3BvbnNlVG9DYWNoZSAmJiByZXNwb25zZVRvQ2FjaGUuc3RhdHVzICE9PSAyMDApIHtcbiAgICAgICAgICAgIHJlc3BvbnNlVG9DYWNoZSA9IHVuZGVmaW5lZDtcbiAgICAgICAgICB9XG4gICAgICAgICAge1xuICAgICAgICAgICAgaWYgKHJlc3BvbnNlVG9DYWNoZSkge1xuICAgICAgICAgICAgICBpZiAocmVzcG9uc2VUb0NhY2hlLnN0YXR1cyAhPT0gMjAwKSB7XG4gICAgICAgICAgICAgICAgaWYgKHJlc3BvbnNlVG9DYWNoZS5zdGF0dXMgPT09IDApIHtcbiAgICAgICAgICAgICAgICAgIGxvZ2dlci53YXJuKGBUaGUgcmVzcG9uc2UgZm9yICcke3RoaXMucmVxdWVzdC51cmx9JyBgICsgYGlzIGFuIG9wYXF1ZSByZXNwb25zZS4gVGhlIGNhY2hpbmcgc3RyYXRlZ3kgdGhhdCB5b3UncmUgYCArIGB1c2luZyB3aWxsIG5vdCBjYWNoZSBvcGFxdWUgcmVzcG9uc2VzIGJ5IGRlZmF1bHQuYCk7XG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAgIGxvZ2dlci5kZWJ1ZyhgVGhlIHJlc3BvbnNlIGZvciAnJHt0aGlzLnJlcXVlc3QudXJsfScgYCArIGByZXR1cm5lZCBhIHN0YXR1cyBjb2RlIG9mICcke3Jlc3BvbnNlLnN0YXR1c30nIGFuZCB3b24ndCBgICsgYGJlIGNhY2hlZCBhcyBhIHJlc3VsdC5gKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlVG9DYWNoZTtcbiAgICAgIH1cbiAgICB9XG5cbiAgICAvKlxuICAgICAgQ29weXJpZ2h0IDIwMjAgR29vZ2xlIExMQ1xuXG4gICAgICBVc2Ugb2YgdGhpcyBzb3VyY2UgY29kZSBpcyBnb3Zlcm5lZCBieSBhbiBNSVQtc3R5bGVcbiAgICAgIGxpY2Vuc2UgdGhhdCBjYW4gYmUgZm91bmQgaW4gdGhlIExJQ0VOU0UgZmlsZSBvciBhdFxuICAgICAgaHR0cHM6Ly9vcGVuc291cmNlLm9yZy9saWNlbnNlcy9NSVQuXG4gICAgKi9cbiAgICAvKipcbiAgICAgKiBBbiBhYnN0cmFjdCBiYXNlIGNsYXNzIHRoYXQgYWxsIG90aGVyIHN0cmF0ZWd5IGNsYXNzZXMgbXVzdCBleHRlbmQgZnJvbTpcbiAgICAgKlxuICAgICAqIEBtZW1iZXJvZiB3b3JrYm94LXN0cmF0ZWdpZXNcbiAgICAgKi9cbiAgICBjbGFzcyBTdHJhdGVneSB7XG4gICAgICAvKipcbiAgICAgICAqIENyZWF0ZXMgYSBuZXcgaW5zdGFuY2Ugb2YgdGhlIHN0cmF0ZWd5IGFuZCBzZXRzIGFsbCBkb2N1bWVudGVkIG9wdGlvblxuICAgICAgICogcHJvcGVydGllcyBhcyBwdWJsaWMgaW5zdGFuY2UgcHJvcGVydGllcy5cbiAgICAgICAqXG4gICAgICAgKiBOb3RlOiBpZiBhIGN1c3RvbSBzdHJhdGVneSBjbGFzcyBleHRlbmRzIHRoZSBiYXNlIFN0cmF0ZWd5IGNsYXNzIGFuZCBkb2VzXG4gICAgICAgKiBub3QgbmVlZCBtb3JlIHRoYW4gdGhlc2UgcHJvcGVydGllcywgaXQgZG9lcyBub3QgbmVlZCB0byBkZWZpbmUgaXRzIG93blxuICAgICAgICogY29uc3RydWN0b3IuXG4gICAgICAgKlxuICAgICAgICogQHBhcmFtIHtPYmplY3R9IFtvcHRpb25zXVxuICAgICAgICogQHBhcmFtIHtzdHJpbmd9IFtvcHRpb25zLmNhY2hlTmFtZV0gQ2FjaGUgbmFtZSB0byBzdG9yZSBhbmQgcmV0cmlldmVcbiAgICAgICAqIHJlcXVlc3RzLiBEZWZhdWx0cyB0byB0aGUgY2FjaGUgbmFtZXMgcHJvdmlkZWQgYnlcbiAgICAgICAqIHtAbGluayB3b3JrYm94LWNvcmUuY2FjaGVOYW1lc30uXG4gICAgICAgKiBAcGFyYW0ge0FycmF5PE9iamVjdD59IFtvcHRpb25zLnBsdWdpbnNdIFtQbHVnaW5zXXtAbGluayBodHRwczovL2RldmVsb3BlcnMuZ29vZ2xlLmNvbS93ZWIvdG9vbHMvd29ya2JveC9ndWlkZXMvdXNpbmctcGx1Z2luc31cbiAgICAgICAqIHRvIHVzZSBpbiBjb25qdW5jdGlvbiB3aXRoIHRoaXMgY2FjaGluZyBzdHJhdGVneS5cbiAgICAgICAqIEBwYXJhbSB7T2JqZWN0fSBbb3B0aW9ucy5mZXRjaE9wdGlvbnNdIFZhbHVlcyBwYXNzZWQgYWxvbmcgdG8gdGhlXG4gICAgICAgKiBbYGluaXRgXShodHRwczovL2RldmVsb3Blci5tb3ppbGxhLm9yZy9lbi1VUy9kb2NzL1dlYi9BUEkvV2luZG93T3JXb3JrZXJHbG9iYWxTY29wZS9mZXRjaCNQYXJhbWV0ZXJzKVxuICAgICAgICogb2YgW25vbi1uYXZpZ2F0aW9uXShodHRwczovL2dpdGh1Yi5jb20vR29vZ2xlQ2hyb21lL3dvcmtib3gvaXNzdWVzLzE3OTYpXG4gICAgICAgKiBgZmV0Y2goKWAgcmVxdWVzdHMgbWFkZSBieSB0aGlzIHN0cmF0ZWd5LlxuICAgICAgICogQHBhcmFtIHtPYmplY3R9IFtvcHRpb25zLm1hdGNoT3B0aW9uc10gVGhlXG4gICAgICAgKiBbYENhY2hlUXVlcnlPcHRpb25zYF17QGxpbmsgaHR0cHM6Ly93M2MuZ2l0aHViLmlvL1NlcnZpY2VXb3JrZXIvI2RpY3RkZWYtY2FjaGVxdWVyeW9wdGlvbnN9XG4gICAgICAgKiBmb3IgYW55IGBjYWNoZS5tYXRjaCgpYCBvciBgY2FjaGUucHV0KClgIGNhbGxzIG1hZGUgYnkgdGhpcyBzdHJhdGVneS5cbiAgICAgICAqL1xuICAgICAgY29uc3RydWN0b3Iob3B0aW9ucyA9IHt9KSB7XG4gICAgICAgIC8qKlxuICAgICAgICAgKiBDYWNoZSBuYW1lIHRvIHN0b3JlIGFuZCByZXRyaWV2ZVxuICAgICAgICAgKiByZXF1ZXN0cy4gRGVmYXVsdHMgdG8gdGhlIGNhY2hlIG5hbWVzIHByb3ZpZGVkIGJ5XG4gICAgICAgICAqIHtAbGluayB3b3JrYm94LWNvcmUuY2FjaGVOYW1lc30uXG4gICAgICAgICAqXG4gICAgICAgICAqIEB0eXBlIHtzdHJpbmd9XG4gICAgICAgICAqL1xuICAgICAgICB0aGlzLmNhY2hlTmFtZSA9IGNhY2hlTmFtZXMuZ2V0UnVudGltZU5hbWUob3B0aW9ucy5jYWNoZU5hbWUpO1xuICAgICAgICAvKipcbiAgICAgICAgICogVGhlIGxpc3RcbiAgICAgICAgICogW1BsdWdpbnNde0BsaW5rIGh0dHBzOi8vZGV2ZWxvcGVycy5nb29nbGUuY29tL3dlYi90b29scy93b3JrYm94L2d1aWRlcy91c2luZy1wbHVnaW5zfVxuICAgICAgICAgKiB1c2VkIGJ5IHRoaXMgc3RyYXRlZ3kuXG4gICAgICAgICAqXG4gICAgICAgICAqIEB0eXBlIHtBcnJheTxPYmplY3Q+fVxuICAgICAgICAgKi9cbiAgICAgICAgdGhpcy5wbHVnaW5zID0gb3B0aW9ucy5wbHVnaW5zIHx8IFtdO1xuICAgICAgICAvKipcbiAgICAgICAgICogVmFsdWVzIHBhc3NlZCBhbG9uZyB0byB0aGVcbiAgICAgICAgICogW2Bpbml0YF17QGxpbmsgaHR0cHM6Ly9kZXZlbG9wZXIubW96aWxsYS5vcmcvZW4tVVMvZG9jcy9XZWIvQVBJL1dpbmRvd09yV29ya2VyR2xvYmFsU2NvcGUvZmV0Y2gjUGFyYW1ldGVyc31cbiAgICAgICAgICogb2YgYWxsIGZldGNoKCkgcmVxdWVzdHMgbWFkZSBieSB0aGlzIHN0cmF0ZWd5LlxuICAgICAgICAgKlxuICAgICAgICAgKiBAdHlwZSB7T2JqZWN0fVxuICAgICAgICAgKi9cbiAgICAgICAgdGhpcy5mZXRjaE9wdGlvbnMgPSBvcHRpb25zLmZldGNoT3B0aW9ucztcbiAgICAgICAgLyoqXG4gICAgICAgICAqIFRoZVxuICAgICAgICAgKiBbYENhY2hlUXVlcnlPcHRpb25zYF17QGxpbmsgaHR0cHM6Ly93M2MuZ2l0aHViLmlvL1NlcnZpY2VXb3JrZXIvI2RpY3RkZWYtY2FjaGVxdWVyeW9wdGlvbnN9XG4gICAgICAgICAqIGZvciBhbnkgYGNhY2hlLm1hdGNoKClgIG9yIGBjYWNoZS5wdXQoKWAgY2FsbHMgbWFkZSBieSB0aGlzIHN0cmF0ZWd5LlxuICAgICAgICAgKlxuICAgICAgICAgKiBAdHlwZSB7T2JqZWN0fVxuICAgICAgICAgKi9cbiAgICAgICAgdGhpcy5tYXRjaE9wdGlvbnMgPSBvcHRpb25zLm1hdGNoT3B0aW9ucztcbiAgICAgIH1cbiAgICAgIC8qKlxuICAgICAgICogUGVyZm9ybSBhIHJlcXVlc3Qgc3RyYXRlZ3kgYW5kIHJldHVybnMgYSBgUHJvbWlzZWAgdGhhdCB3aWxsIHJlc29sdmUgd2l0aFxuICAgICAgICogYSBgUmVzcG9uc2VgLCBpbnZva2luZyBhbGwgcmVsZXZhbnQgcGx1Z2luIGNhbGxiYWNrcy5cbiAgICAgICAqXG4gICAgICAgKiBXaGVuIGEgc3RyYXRlZ3kgaW5zdGFuY2UgaXMgcmVnaXN0ZXJlZCB3aXRoIGEgV29ya2JveFxuICAgICAgICoge0BsaW5rIHdvcmtib3gtcm91dGluZy5Sb3V0ZX0sIHRoaXMgbWV0aG9kIGlzIGF1dG9tYXRpY2FsbHlcbiAgICAgICAqIGNhbGxlZCB3aGVuIHRoZSByb3V0ZSBtYXRjaGVzLlxuICAgICAgICpcbiAgICAgICAqIEFsdGVybmF0aXZlbHksIHRoaXMgbWV0aG9kIGNhbiBiZSB1c2VkIGluIGEgc3RhbmRhbG9uZSBgRmV0Y2hFdmVudGBcbiAgICAgICAqIGxpc3RlbmVyIGJ5IHBhc3NpbmcgaXQgdG8gYGV2ZW50LnJlc3BvbmRXaXRoKClgLlxuICAgICAgICpcbiAgICAgICAqIEBwYXJhbSB7RmV0Y2hFdmVudHxPYmplY3R9IG9wdGlvbnMgQSBgRmV0Y2hFdmVudGAgb3IgYW4gb2JqZWN0IHdpdGggdGhlXG4gICAgICAgKiAgICAgcHJvcGVydGllcyBsaXN0ZWQgYmVsb3cuXG4gICAgICAgKiBAcGFyYW0ge1JlcXVlc3R8c3RyaW5nfSBvcHRpb25zLnJlcXVlc3QgQSByZXF1ZXN0IHRvIHJ1biB0aGlzIHN0cmF0ZWd5IGZvci5cbiAgICAgICAqIEBwYXJhbSB7RXh0ZW5kYWJsZUV2ZW50fSBvcHRpb25zLmV2ZW50IFRoZSBldmVudCBhc3NvY2lhdGVkIHdpdGggdGhlXG4gICAgICAgKiAgICAgcmVxdWVzdC5cbiAgICAgICAqIEBwYXJhbSB7VVJMfSBbb3B0aW9ucy51cmxdXG4gICAgICAgKiBAcGFyYW0geyp9IFtvcHRpb25zLnBhcmFtc11cbiAgICAgICAqL1xuICAgICAgaGFuZGxlKG9wdGlvbnMpIHtcbiAgICAgICAgY29uc3QgW3Jlc3BvbnNlRG9uZV0gPSB0aGlzLmhhbmRsZUFsbChvcHRpb25zKTtcbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlRG9uZTtcbiAgICAgIH1cbiAgICAgIC8qKlxuICAgICAgICogU2ltaWxhciB0byB7QGxpbmsgd29ya2JveC1zdHJhdGVnaWVzLlN0cmF0ZWd5fmhhbmRsZX0sIGJ1dFxuICAgICAgICogaW5zdGVhZCBvZiBqdXN0IHJldHVybmluZyBhIGBQcm9taXNlYCB0aGF0IHJlc29sdmVzIHRvIGEgYFJlc3BvbnNlYCBpdFxuICAgICAgICogaXQgd2lsbCByZXR1cm4gYW4gdHVwbGUgb2YgYFtyZXNwb25zZSwgZG9uZV1gIHByb21pc2VzLCB3aGVyZSB0aGUgZm9ybWVyXG4gICAgICAgKiAoYHJlc3BvbnNlYCkgaXMgZXF1aXZhbGVudCB0byB3aGF0IGBoYW5kbGUoKWAgcmV0dXJucywgYW5kIHRoZSBsYXR0ZXIgaXMgYVxuICAgICAgICogUHJvbWlzZSB0aGF0IHdpbGwgcmVzb2x2ZSBvbmNlIGFueSBwcm9taXNlcyB0aGF0IHdlcmUgYWRkZWQgdG9cbiAgICAgICAqIGBldmVudC53YWl0VW50aWwoKWAgYXMgcGFydCBvZiBwZXJmb3JtaW5nIHRoZSBzdHJhdGVneSBoYXZlIGNvbXBsZXRlZC5cbiAgICAgICAqXG4gICAgICAgKiBZb3UgY2FuIGF3YWl0IHRoZSBgZG9uZWAgcHJvbWlzZSB0byBlbnN1cmUgYW55IGV4dHJhIHdvcmsgcGVyZm9ybWVkIGJ5XG4gICAgICAgKiB0aGUgc3RyYXRlZ3kgKHVzdWFsbHkgY2FjaGluZyByZXNwb25zZXMpIGNvbXBsZXRlcyBzdWNjZXNzZnVsbHkuXG4gICAgICAgKlxuICAgICAgICogQHBhcmFtIHtGZXRjaEV2ZW50fE9iamVjdH0gb3B0aW9ucyBBIGBGZXRjaEV2ZW50YCBvciBhbiBvYmplY3Qgd2l0aCB0aGVcbiAgICAgICAqICAgICBwcm9wZXJ0aWVzIGxpc3RlZCBiZWxvdy5cbiAgICAgICAqIEBwYXJhbSB7UmVxdWVzdHxzdHJpbmd9IG9wdGlvbnMucmVxdWVzdCBBIHJlcXVlc3QgdG8gcnVuIHRoaXMgc3RyYXRlZ3kgZm9yLlxuICAgICAgICogQHBhcmFtIHtFeHRlbmRhYmxlRXZlbnR9IG9wdGlvbnMuZXZlbnQgVGhlIGV2ZW50IGFzc29jaWF0ZWQgd2l0aCB0aGVcbiAgICAgICAqICAgICByZXF1ZXN0LlxuICAgICAgICogQHBhcmFtIHtVUkx9IFtvcHRpb25zLnVybF1cbiAgICAgICAqIEBwYXJhbSB7Kn0gW29wdGlvbnMucGFyYW1zXVxuICAgICAgICogQHJldHVybiB7QXJyYXk8UHJvbWlzZT59IEEgdHVwbGUgb2YgW3Jlc3BvbnNlLCBkb25lXVxuICAgICAgICogICAgIHByb21pc2VzIHRoYXQgY2FuIGJlIHVzZWQgdG8gZGV0ZXJtaW5lIHdoZW4gdGhlIHJlc3BvbnNlIHJlc29sdmVzIGFzXG4gICAgICAgKiAgICAgd2VsbCBhcyB3aGVuIHRoZSBoYW5kbGVyIGhhcyBjb21wbGV0ZWQgYWxsIGl0cyB3b3JrLlxuICAgICAgICovXG4gICAgICBoYW5kbGVBbGwob3B0aW9ucykge1xuICAgICAgICAvLyBBbGxvdyBmb3IgZmxleGlibGUgb3B0aW9ucyB0byBiZSBwYXNzZWQuXG4gICAgICAgIGlmIChvcHRpb25zIGluc3RhbmNlb2YgRmV0Y2hFdmVudCkge1xuICAgICAgICAgIG9wdGlvbnMgPSB7XG4gICAgICAgICAgICBldmVudDogb3B0aW9ucyxcbiAgICAgICAgICAgIHJlcXVlc3Q6IG9wdGlvbnMucmVxdWVzdFxuICAgICAgICAgIH07XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgZXZlbnQgPSBvcHRpb25zLmV2ZW50O1xuICAgICAgICBjb25zdCByZXF1ZXN0ID0gdHlwZW9mIG9wdGlvbnMucmVxdWVzdCA9PT0gJ3N0cmluZycgPyBuZXcgUmVxdWVzdChvcHRpb25zLnJlcXVlc3QpIDogb3B0aW9ucy5yZXF1ZXN0O1xuICAgICAgICBjb25zdCBwYXJhbXMgPSAncGFyYW1zJyBpbiBvcHRpb25zID8gb3B0aW9ucy5wYXJhbXMgOiB1bmRlZmluZWQ7XG4gICAgICAgIGNvbnN0IGhhbmRsZXIgPSBuZXcgU3RyYXRlZ3lIYW5kbGVyKHRoaXMsIHtcbiAgICAgICAgICBldmVudCxcbiAgICAgICAgICByZXF1ZXN0LFxuICAgICAgICAgIHBhcmFtc1xuICAgICAgICB9KTtcbiAgICAgICAgY29uc3QgcmVzcG9uc2VEb25lID0gdGhpcy5fZ2V0UmVzcG9uc2UoaGFuZGxlciwgcmVxdWVzdCwgZXZlbnQpO1xuICAgICAgICBjb25zdCBoYW5kbGVyRG9uZSA9IHRoaXMuX2F3YWl0Q29tcGxldGUocmVzcG9uc2VEb25lLCBoYW5kbGVyLCByZXF1ZXN0LCBldmVudCk7XG4gICAgICAgIC8vIFJldHVybiBhbiBhcnJheSBvZiBwcm9taXNlcywgc3VpdGFibGUgZm9yIHVzZSB3aXRoIFByb21pc2UuYWxsKCkuXG4gICAgICAgIHJldHVybiBbcmVzcG9uc2VEb25lLCBoYW5kbGVyRG9uZV07XG4gICAgICB9XG4gICAgICBhc3luYyBfZ2V0UmVzcG9uc2UoaGFuZGxlciwgcmVxdWVzdCwgZXZlbnQpIHtcbiAgICAgICAgYXdhaXQgaGFuZGxlci5ydW5DYWxsYmFja3MoJ2hhbmRsZXJXaWxsU3RhcnQnLCB7XG4gICAgICAgICAgZXZlbnQsXG4gICAgICAgICAgcmVxdWVzdFxuICAgICAgICB9KTtcbiAgICAgICAgbGV0IHJlc3BvbnNlID0gdW5kZWZpbmVkO1xuICAgICAgICB0cnkge1xuICAgICAgICAgIHJlc3BvbnNlID0gYXdhaXQgdGhpcy5faGFuZGxlKHJlcXVlc3QsIGhhbmRsZXIpO1xuICAgICAgICAgIC8vIFRoZSBcIm9mZmljaWFsXCIgU3RyYXRlZ3kgc3ViY2xhc3NlcyBhbGwgdGhyb3cgdGhpcyBlcnJvciBhdXRvbWF0aWNhbGx5LFxuICAgICAgICAgIC8vIGJ1dCBpbiBjYXNlIGEgdGhpcmQtcGFydHkgU3RyYXRlZ3kgZG9lc24ndCwgZW5zdXJlIHRoYXQgd2UgaGF2ZSBhXG4gICAgICAgICAgLy8gY29uc2lzdGVudCBmYWlsdXJlIHdoZW4gdGhlcmUncyBubyByZXNwb25zZSBvciBhbiBlcnJvciByZXNwb25zZS5cbiAgICAgICAgICBpZiAoIXJlc3BvbnNlIHx8IHJlc3BvbnNlLnR5cGUgPT09ICdlcnJvcicpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBXb3JrYm94RXJyb3IoJ25vLXJlc3BvbnNlJywge1xuICAgICAgICAgICAgICB1cmw6IHJlcXVlc3QudXJsXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICB9XG4gICAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgICAgaWYgKGVycm9yIGluc3RhbmNlb2YgRXJyb3IpIHtcbiAgICAgICAgICAgIGZvciAoY29uc3QgY2FsbGJhY2sgb2YgaGFuZGxlci5pdGVyYXRlQ2FsbGJhY2tzKCdoYW5kbGVyRGlkRXJyb3InKSkge1xuICAgICAgICAgICAgICByZXNwb25zZSA9IGF3YWl0IGNhbGxiYWNrKHtcbiAgICAgICAgICAgICAgICBlcnJvcixcbiAgICAgICAgICAgICAgICBldmVudCxcbiAgICAgICAgICAgICAgICByZXF1ZXN0XG4gICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICBpZiAocmVzcG9uc2UpIHtcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgIH1cbiAgICAgICAgICBpZiAoIXJlc3BvbnNlKSB7XG4gICAgICAgICAgICB0aHJvdyBlcnJvcjtcbiAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgbG9nZ2VyLmxvZyhgV2hpbGUgcmVzcG9uZGluZyB0byAnJHtnZXRGcmllbmRseVVSTChyZXF1ZXN0LnVybCl9JywgYCArIGBhbiAke2Vycm9yIGluc3RhbmNlb2YgRXJyb3IgPyBlcnJvci50b1N0cmluZygpIDogJyd9IGVycm9yIG9jY3VycmVkLiBVc2luZyBhIGZhbGxiYWNrIHJlc3BvbnNlIHByb3ZpZGVkIGJ5IGAgKyBgYSBoYW5kbGVyRGlkRXJyb3IgcGx1Z2luLmApO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBmb3IgKGNvbnN0IGNhbGxiYWNrIG9mIGhhbmRsZXIuaXRlcmF0ZUNhbGxiYWNrcygnaGFuZGxlcldpbGxSZXNwb25kJykpIHtcbiAgICAgICAgICByZXNwb25zZSA9IGF3YWl0IGNhbGxiYWNrKHtcbiAgICAgICAgICAgIGV2ZW50LFxuICAgICAgICAgICAgcmVxdWVzdCxcbiAgICAgICAgICAgIHJlc3BvbnNlXG4gICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlO1xuICAgICAgfVxuICAgICAgYXN5bmMgX2F3YWl0Q29tcGxldGUocmVzcG9uc2VEb25lLCBoYW5kbGVyLCByZXF1ZXN0LCBldmVudCkge1xuICAgICAgICBsZXQgcmVzcG9uc2U7XG4gICAgICAgIGxldCBlcnJvcjtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICByZXNwb25zZSA9IGF3YWl0IHJlc3BvbnNlRG9uZTtcbiAgICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgICAvLyBJZ25vcmUgZXJyb3JzLCBhcyByZXNwb25zZSBlcnJvcnMgc2hvdWxkIGJlIGNhdWdodCB2aWEgdGhlIGByZXNwb25zZWBcbiAgICAgICAgICAvLyBwcm9taXNlIGFib3ZlLiBUaGUgYGRvbmVgIHByb21pc2Ugd2lsbCBvbmx5IHRocm93IGZvciBlcnJvcnMgaW5cbiAgICAgICAgICAvLyBwcm9taXNlcyBwYXNzZWQgdG8gYGhhbmRsZXIud2FpdFVudGlsKClgLlxuICAgICAgICB9XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgYXdhaXQgaGFuZGxlci5ydW5DYWxsYmFja3MoJ2hhbmRsZXJEaWRSZXNwb25kJywge1xuICAgICAgICAgICAgZXZlbnQsXG4gICAgICAgICAgICByZXF1ZXN0LFxuICAgICAgICAgICAgcmVzcG9uc2VcbiAgICAgICAgICB9KTtcbiAgICAgICAgICBhd2FpdCBoYW5kbGVyLmRvbmVXYWl0aW5nKCk7XG4gICAgICAgIH0gY2F0Y2ggKHdhaXRVbnRpbEVycm9yKSB7XG4gICAgICAgICAgaWYgKHdhaXRVbnRpbEVycm9yIGluc3RhbmNlb2YgRXJyb3IpIHtcbiAgICAgICAgICAgIGVycm9yID0gd2FpdFVudGlsRXJyb3I7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGF3YWl0IGhhbmRsZXIucnVuQ2FsbGJhY2tzKCdoYW5kbGVyRGlkQ29tcGxldGUnLCB7XG4gICAgICAgICAgZXZlbnQsXG4gICAgICAgICAgcmVxdWVzdCxcbiAgICAgICAgICByZXNwb25zZSxcbiAgICAgICAgICBlcnJvcjogZXJyb3JcbiAgICAgICAgfSk7XG4gICAgICAgIGhhbmRsZXIuZGVzdHJveSgpO1xuICAgICAgICBpZiAoZXJyb3IpIHtcbiAgICAgICAgICB0aHJvdyBlcnJvcjtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH1cbiAgICAvKipcbiAgICAgKiBDbGFzc2VzIGV4dGVuZGluZyB0aGUgYFN0cmF0ZWd5YCBiYXNlZCBjbGFzcyBzaG91bGQgaW1wbGVtZW50IHRoaXMgbWV0aG9kLFxuICAgICAqIGFuZCBsZXZlcmFnZSB0aGUge0BsaW5rIHdvcmtib3gtc3RyYXRlZ2llcy5TdHJhdGVneUhhbmRsZXJ9XG4gICAgICogYXJnIHRvIHBlcmZvcm0gYWxsIGZldGNoaW5nIGFuZCBjYWNoZSBsb2dpYywgd2hpY2ggd2lsbCBlbnN1cmUgYWxsIHJlbGV2YW50XG4gICAgICogY2FjaGUsIGNhY2hlIG9wdGlvbnMsIGZldGNoIG9wdGlvbnMgYW5kIHBsdWdpbnMgYXJlIHVzZWQgKHBlciB0aGUgY3VycmVudFxuICAgICAqIHN0cmF0ZWd5IGluc3RhbmNlKS5cbiAgICAgKlxuICAgICAqIEBuYW1lIF9oYW5kbGVcbiAgICAgKiBAaW5zdGFuY2VcbiAgICAgKiBAYWJzdHJhY3RcbiAgICAgKiBAZnVuY3Rpb25cbiAgICAgKiBAcGFyYW0ge1JlcXVlc3R9IHJlcXVlc3RcbiAgICAgKiBAcGFyYW0ge3dvcmtib3gtc3RyYXRlZ2llcy5TdHJhdGVneUhhbmRsZXJ9IGhhbmRsZXJcbiAgICAgKiBAcmV0dXJuIHtQcm9taXNlPFJlc3BvbnNlPn1cbiAgICAgKlxuICAgICAqIEBtZW1iZXJvZiB3b3JrYm94LXN0cmF0ZWdpZXMuU3RyYXRlZ3lcbiAgICAgKi9cblxuICAgIC8qXG4gICAgICBDb3B5cmlnaHQgMjAxOCBHb29nbGUgTExDXG5cbiAgICAgIFVzZSBvZiB0aGlzIHNvdXJjZSBjb2RlIGlzIGdvdmVybmVkIGJ5IGFuIE1JVC1zdHlsZVxuICAgICAgbGljZW5zZSB0aGF0IGNhbiBiZSBmb3VuZCBpbiB0aGUgTElDRU5TRSBmaWxlIG9yIGF0XG4gICAgICBodHRwczovL29wZW5zb3VyY2Uub3JnL2xpY2Vuc2VzL01JVC5cbiAgICAqL1xuICAgIGNvbnN0IG1lc3NhZ2VzID0ge1xuICAgICAgc3RyYXRlZ3lTdGFydDogKHN0cmF0ZWd5TmFtZSwgcmVxdWVzdCkgPT4gYFVzaW5nICR7c3RyYXRlZ3lOYW1lfSB0byByZXNwb25kIHRvICcke2dldEZyaWVuZGx5VVJMKHJlcXVlc3QudXJsKX0nYCxcbiAgICAgIHByaW50RmluYWxSZXNwb25zZTogcmVzcG9uc2UgPT4ge1xuICAgICAgICBpZiAocmVzcG9uc2UpIHtcbiAgICAgICAgICBsb2dnZXIuZ3JvdXBDb2xsYXBzZWQoYFZpZXcgdGhlIGZpbmFsIHJlc3BvbnNlIGhlcmUuYCk7XG4gICAgICAgICAgbG9nZ2VyLmxvZyhyZXNwb25zZSB8fCAnW05vIHJlc3BvbnNlIHJldHVybmVkXScpO1xuICAgICAgICAgIGxvZ2dlci5ncm91cEVuZCgpO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfTtcblxuICAgIC8qXG4gICAgICBDb3B5cmlnaHQgMjAxOCBHb29nbGUgTExDXG5cbiAgICAgIFVzZSBvZiB0aGlzIHNvdXJjZSBjb2RlIGlzIGdvdmVybmVkIGJ5IGFuIE1JVC1zdHlsZVxuICAgICAgbGljZW5zZSB0aGF0IGNhbiBiZSBmb3VuZCBpbiB0aGUgTElDRU5TRSBmaWxlIG9yIGF0XG4gICAgICBodHRwczovL29wZW5zb3VyY2Uub3JnL2xpY2Vuc2VzL01JVC5cbiAgICAqL1xuICAgIC8qKlxuICAgICAqIEFuIGltcGxlbWVudGF0aW9uIG9mIGFcbiAgICAgKiBbbmV0d29yayBmaXJzdF0oaHR0cHM6Ly9kZXZlbG9wZXIuY2hyb21lLmNvbS9kb2NzL3dvcmtib3gvY2FjaGluZy1zdHJhdGVnaWVzLW92ZXJ2aWV3LyNuZXR3b3JrLWZpcnN0LWZhbGxpbmctYmFjay10by1jYWNoZSlcbiAgICAgKiByZXF1ZXN0IHN0cmF0ZWd5LlxuICAgICAqXG4gICAgICogQnkgZGVmYXVsdCwgdGhpcyBzdHJhdGVneSB3aWxsIGNhY2hlIHJlc3BvbnNlcyB3aXRoIGEgMjAwIHN0YXR1cyBjb2RlIGFzXG4gICAgICogd2VsbCBhcyBbb3BhcXVlIHJlc3BvbnNlc10oaHR0cHM6Ly9kZXZlbG9wZXIuY2hyb21lLmNvbS9kb2NzL3dvcmtib3gvY2FjaGluZy1yZXNvdXJjZXMtZHVyaW5nLXJ1bnRpbWUvI29wYXF1ZS1yZXNwb25zZXMpLlxuICAgICAqIE9wYXF1ZSByZXNwb25zZXMgYXJlIGFyZSBjcm9zcy1vcmlnaW4gcmVxdWVzdHMgd2hlcmUgdGhlIHJlc3BvbnNlIGRvZXNuJ3RcbiAgICAgKiBzdXBwb3J0IFtDT1JTXShodHRwczovL2VuYWJsZS1jb3JzLm9yZy8pLlxuICAgICAqXG4gICAgICogSWYgdGhlIG5ldHdvcmsgcmVxdWVzdCBmYWlscywgYW5kIHRoZXJlIGlzIG5vIGNhY2hlIG1hdGNoLCB0aGlzIHdpbGwgdGhyb3dcbiAgICAgKiBhIGBXb3JrYm94RXJyb3JgIGV4Y2VwdGlvbi5cbiAgICAgKlxuICAgICAqIEBleHRlbmRzIHdvcmtib3gtc3RyYXRlZ2llcy5TdHJhdGVneVxuICAgICAqIEBtZW1iZXJvZiB3b3JrYm94LXN0cmF0ZWdpZXNcbiAgICAgKi9cbiAgICBjbGFzcyBOZXR3b3JrRmlyc3QgZXh0ZW5kcyBTdHJhdGVneSB7XG4gICAgICAvKipcbiAgICAgICAqIEBwYXJhbSB7T2JqZWN0fSBbb3B0aW9uc11cbiAgICAgICAqIEBwYXJhbSB7c3RyaW5nfSBbb3B0aW9ucy5jYWNoZU5hbWVdIENhY2hlIG5hbWUgdG8gc3RvcmUgYW5kIHJldHJpZXZlXG4gICAgICAgKiByZXF1ZXN0cy4gRGVmYXVsdHMgdG8gY2FjaGUgbmFtZXMgcHJvdmlkZWQgYnlcbiAgICAgICAqIHtAbGluayB3b3JrYm94LWNvcmUuY2FjaGVOYW1lc30uXG4gICAgICAgKiBAcGFyYW0ge0FycmF5PE9iamVjdD59IFtvcHRpb25zLnBsdWdpbnNdIFtQbHVnaW5zXXtAbGluayBodHRwczovL2RldmVsb3BlcnMuZ29vZ2xlLmNvbS93ZWIvdG9vbHMvd29ya2JveC9ndWlkZXMvdXNpbmctcGx1Z2luc31cbiAgICAgICAqIHRvIHVzZSBpbiBjb25qdW5jdGlvbiB3aXRoIHRoaXMgY2FjaGluZyBzdHJhdGVneS5cbiAgICAgICAqIEBwYXJhbSB7T2JqZWN0fSBbb3B0aW9ucy5mZXRjaE9wdGlvbnNdIFZhbHVlcyBwYXNzZWQgYWxvbmcgdG8gdGhlXG4gICAgICAgKiBbYGluaXRgXShodHRwczovL2RldmVsb3Blci5tb3ppbGxhLm9yZy9lbi1VUy9kb2NzL1dlYi9BUEkvV2luZG93T3JXb3JrZXJHbG9iYWxTY29wZS9mZXRjaCNQYXJhbWV0ZXJzKVxuICAgICAgICogb2YgW25vbi1uYXZpZ2F0aW9uXShodHRwczovL2dpdGh1Yi5jb20vR29vZ2xlQ2hyb21lL3dvcmtib3gvaXNzdWVzLzE3OTYpXG4gICAgICAgKiBgZmV0Y2goKWAgcmVxdWVzdHMgbWFkZSBieSB0aGlzIHN0cmF0ZWd5LlxuICAgICAgICogQHBhcmFtIHtPYmplY3R9IFtvcHRpb25zLm1hdGNoT3B0aW9uc10gW2BDYWNoZVF1ZXJ5T3B0aW9uc2BdKGh0dHBzOi8vdzNjLmdpdGh1Yi5pby9TZXJ2aWNlV29ya2VyLyNkaWN0ZGVmLWNhY2hlcXVlcnlvcHRpb25zKVxuICAgICAgICogQHBhcmFtIHtudW1iZXJ9IFtvcHRpb25zLm5ldHdvcmtUaW1lb3V0U2Vjb25kc10gSWYgc2V0LCBhbnkgbmV0d29yayByZXF1ZXN0c1xuICAgICAgICogdGhhdCBmYWlsIHRvIHJlc3BvbmQgd2l0aGluIHRoZSB0aW1lb3V0IHdpbGwgZmFsbGJhY2sgdG8gdGhlIGNhY2hlLlxuICAgICAgICpcbiAgICAgICAqIFRoaXMgb3B0aW9uIGNhbiBiZSB1c2VkIHRvIGNvbWJhdFxuICAgICAgICogXCJbbGllLWZpXXtAbGluayBodHRwczovL2RldmVsb3BlcnMuZ29vZ2xlLmNvbS93ZWIvZnVuZGFtZW50YWxzL3BlcmZvcm1hbmNlL3Bvb3ItY29ubmVjdGl2aXR5LyNsaWUtZml9XCJcbiAgICAgICAqIHNjZW5hcmlvcy5cbiAgICAgICAqL1xuICAgICAgY29uc3RydWN0b3Iob3B0aW9ucyA9IHt9KSB7XG4gICAgICAgIHN1cGVyKG9wdGlvbnMpO1xuICAgICAgICAvLyBJZiB0aGlzIGluc3RhbmNlIGNvbnRhaW5zIG5vIHBsdWdpbnMgd2l0aCBhICdjYWNoZVdpbGxVcGRhdGUnIGNhbGxiYWNrLFxuICAgICAgICAvLyBwcmVwZW5kIHRoZSBgY2FjaGVPa0FuZE9wYXF1ZVBsdWdpbmAgcGx1Z2luIHRvIHRoZSBwbHVnaW5zIGxpc3QuXG4gICAgICAgIGlmICghdGhpcy5wbHVnaW5zLnNvbWUocCA9PiAnY2FjaGVXaWxsVXBkYXRlJyBpbiBwKSkge1xuICAgICAgICAgIHRoaXMucGx1Z2lucy51bnNoaWZ0KGNhY2hlT2tBbmRPcGFxdWVQbHVnaW4pO1xuICAgICAgICB9XG4gICAgICAgIHRoaXMuX25ldHdvcmtUaW1lb3V0U2Vjb25kcyA9IG9wdGlvbnMubmV0d29ya1RpbWVvdXRTZWNvbmRzIHx8IDA7XG4gICAgICAgIHtcbiAgICAgICAgICBpZiAodGhpcy5fbmV0d29ya1RpbWVvdXRTZWNvbmRzKSB7XG4gICAgICAgICAgICBmaW5hbEFzc2VydEV4cG9ydHMuaXNUeXBlKHRoaXMuX25ldHdvcmtUaW1lb3V0U2Vjb25kcywgJ251bWJlcicsIHtcbiAgICAgICAgICAgICAgbW9kdWxlTmFtZTogJ3dvcmtib3gtc3RyYXRlZ2llcycsXG4gICAgICAgICAgICAgIGNsYXNzTmFtZTogdGhpcy5jb25zdHJ1Y3Rvci5uYW1lLFxuICAgICAgICAgICAgICBmdW5jTmFtZTogJ2NvbnN0cnVjdG9yJyxcbiAgICAgICAgICAgICAgcGFyYW1OYW1lOiAnbmV0d29ya1RpbWVvdXRTZWNvbmRzJ1xuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9XG4gICAgICAvKipcbiAgICAgICAqIEBwcml2YXRlXG4gICAgICAgKiBAcGFyYW0ge1JlcXVlc3R8c3RyaW5nfSByZXF1ZXN0IEEgcmVxdWVzdCB0byBydW4gdGhpcyBzdHJhdGVneSBmb3IuXG4gICAgICAgKiBAcGFyYW0ge3dvcmtib3gtc3RyYXRlZ2llcy5TdHJhdGVneUhhbmRsZXJ9IGhhbmRsZXIgVGhlIGV2ZW50IHRoYXRcbiAgICAgICAqICAgICB0cmlnZ2VyZWQgdGhlIHJlcXVlc3QuXG4gICAgICAgKiBAcmV0dXJuIHtQcm9taXNlPFJlc3BvbnNlPn1cbiAgICAgICAqL1xuICAgICAgYXN5bmMgX2hhbmRsZShyZXF1ZXN0LCBoYW5kbGVyKSB7XG4gICAgICAgIGNvbnN0IGxvZ3MgPSBbXTtcbiAgICAgICAge1xuICAgICAgICAgIGZpbmFsQXNzZXJ0RXhwb3J0cy5pc0luc3RhbmNlKHJlcXVlc3QsIFJlcXVlc3QsIHtcbiAgICAgICAgICAgIG1vZHVsZU5hbWU6ICd3b3JrYm94LXN0cmF0ZWdpZXMnLFxuICAgICAgICAgICAgY2xhc3NOYW1lOiB0aGlzLmNvbnN0cnVjdG9yLm5hbWUsXG4gICAgICAgICAgICBmdW5jTmFtZTogJ2hhbmRsZScsXG4gICAgICAgICAgICBwYXJhbU5hbWU6ICdtYWtlUmVxdWVzdCdcbiAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCBwcm9taXNlcyA9IFtdO1xuICAgICAgICBsZXQgdGltZW91dElkO1xuICAgICAgICBpZiAodGhpcy5fbmV0d29ya1RpbWVvdXRTZWNvbmRzKSB7XG4gICAgICAgICAgY29uc3Qge1xuICAgICAgICAgICAgaWQsXG4gICAgICAgICAgICBwcm9taXNlXG4gICAgICAgICAgfSA9IHRoaXMuX2dldFRpbWVvdXRQcm9taXNlKHtcbiAgICAgICAgICAgIHJlcXVlc3QsXG4gICAgICAgICAgICBsb2dzLFxuICAgICAgICAgICAgaGFuZGxlclxuICAgICAgICAgIH0pO1xuICAgICAgICAgIHRpbWVvdXRJZCA9IGlkO1xuICAgICAgICAgIHByb21pc2VzLnB1c2gocHJvbWlzZSk7XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgbmV0d29ya1Byb21pc2UgPSB0aGlzLl9nZXROZXR3b3JrUHJvbWlzZSh7XG4gICAgICAgICAgdGltZW91dElkLFxuICAgICAgICAgIHJlcXVlc3QsXG4gICAgICAgICAgbG9ncyxcbiAgICAgICAgICBoYW5kbGVyXG4gICAgICAgIH0pO1xuICAgICAgICBwcm9taXNlcy5wdXNoKG5ldHdvcmtQcm9taXNlKTtcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBoYW5kbGVyLndhaXRVbnRpbCgoYXN5bmMgKCkgPT4ge1xuICAgICAgICAgIC8vIFByb21pc2UucmFjZSgpIHdpbGwgcmVzb2x2ZSBhcyBzb29uIGFzIHRoZSBmaXJzdCBwcm9taXNlIHJlc29sdmVzLlxuICAgICAgICAgIHJldHVybiAoYXdhaXQgaGFuZGxlci53YWl0VW50aWwoUHJvbWlzZS5yYWNlKHByb21pc2VzKSkpIHx8IChcbiAgICAgICAgICAvLyBJZiBQcm9taXNlLnJhY2UoKSByZXNvbHZlZCB3aXRoIG51bGwsIGl0IG1pZ2h0IGJlIGR1ZSB0byBhIG5ldHdvcmtcbiAgICAgICAgICAvLyB0aW1lb3V0ICsgYSBjYWNoZSBtaXNzLiBJZiB0aGF0IHdlcmUgdG8gaGFwcGVuLCB3ZSdkIHJhdGhlciB3YWl0IHVudGlsXG4gICAgICAgICAgLy8gdGhlIG5ldHdvcmtQcm9taXNlIHJlc29sdmVzIGluc3RlYWQgb2YgcmV0dXJuaW5nIG51bGwuXG4gICAgICAgICAgLy8gTm90ZSB0aGF0IGl0J3MgZmluZSB0byBhd2FpdCBhbiBhbHJlYWR5LXJlc29sdmVkIHByb21pc2UsIHNvIHdlIGRvbid0XG4gICAgICAgICAgLy8gaGF2ZSB0byBjaGVjayB0byBzZWUgaWYgaXQncyBzdGlsbCBcImluIGZsaWdodFwiLlxuICAgICAgICAgIGF3YWl0IG5ldHdvcmtQcm9taXNlKTtcbiAgICAgICAgfSkoKSk7XG4gICAgICAgIHtcbiAgICAgICAgICBsb2dnZXIuZ3JvdXBDb2xsYXBzZWQobWVzc2FnZXMuc3RyYXRlZ3lTdGFydCh0aGlzLmNvbnN0cnVjdG9yLm5hbWUsIHJlcXVlc3QpKTtcbiAgICAgICAgICBmb3IgKGNvbnN0IGxvZyBvZiBsb2dzKSB7XG4gICAgICAgICAgICBsb2dnZXIubG9nKGxvZyk7XG4gICAgICAgICAgfVxuICAgICAgICAgIG1lc3NhZ2VzLnByaW50RmluYWxSZXNwb25zZShyZXNwb25zZSk7XG4gICAgICAgICAgbG9nZ2VyLmdyb3VwRW5kKCk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKCFyZXNwb25zZSkge1xuICAgICAgICAgIHRocm93IG5ldyBXb3JrYm94RXJyb3IoJ25vLXJlc3BvbnNlJywge1xuICAgICAgICAgICAgdXJsOiByZXF1ZXN0LnVybFxuICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiByZXNwb25zZTtcbiAgICAgIH1cbiAgICAgIC8qKlxuICAgICAgICogQHBhcmFtIHtPYmplY3R9IG9wdGlvbnNcbiAgICAgICAqIEBwYXJhbSB7UmVxdWVzdH0gb3B0aW9ucy5yZXF1ZXN0XG4gICAgICAgKiBAcGFyYW0ge0FycmF5fSBvcHRpb25zLmxvZ3MgQSByZWZlcmVuY2UgdG8gdGhlIGxvZ3MgYXJyYXlcbiAgICAgICAqIEBwYXJhbSB7RXZlbnR9IG9wdGlvbnMuZXZlbnRcbiAgICAgICAqIEByZXR1cm4ge1Byb21pc2U8UmVzcG9uc2U+fVxuICAgICAgICpcbiAgICAgICAqIEBwcml2YXRlXG4gICAgICAgKi9cbiAgICAgIF9nZXRUaW1lb3V0UHJvbWlzZSh7XG4gICAgICAgIHJlcXVlc3QsXG4gICAgICAgIGxvZ3MsXG4gICAgICAgIGhhbmRsZXJcbiAgICAgIH0pIHtcbiAgICAgICAgbGV0IHRpbWVvdXRJZDtcbiAgICAgICAgY29uc3QgdGltZW91dFByb21pc2UgPSBuZXcgUHJvbWlzZShyZXNvbHZlID0+IHtcbiAgICAgICAgICBjb25zdCBvbk5ldHdvcmtUaW1lb3V0ID0gYXN5bmMgKCkgPT4ge1xuICAgICAgICAgICAge1xuICAgICAgICAgICAgICBsb2dzLnB1c2goYFRpbWluZyBvdXQgdGhlIG5ldHdvcmsgcmVzcG9uc2UgYXQgYCArIGAke3RoaXMuX25ldHdvcmtUaW1lb3V0U2Vjb25kc30gc2Vjb25kcy5gKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHJlc29sdmUoYXdhaXQgaGFuZGxlci5jYWNoZU1hdGNoKHJlcXVlc3QpKTtcbiAgICAgICAgICB9O1xuICAgICAgICAgIHRpbWVvdXRJZCA9IHNldFRpbWVvdXQob25OZXR3b3JrVGltZW91dCwgdGhpcy5fbmV0d29ya1RpbWVvdXRTZWNvbmRzICogMTAwMCk7XG4gICAgICAgIH0pO1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgIHByb21pc2U6IHRpbWVvdXRQcm9taXNlLFxuICAgICAgICAgIGlkOiB0aW1lb3V0SWRcbiAgICAgICAgfTtcbiAgICAgIH1cbiAgICAgIC8qKlxuICAgICAgICogQHBhcmFtIHtPYmplY3R9IG9wdGlvbnNcbiAgICAgICAqIEBwYXJhbSB7bnVtYmVyfHVuZGVmaW5lZH0gb3B0aW9ucy50aW1lb3V0SWRcbiAgICAgICAqIEBwYXJhbSB7UmVxdWVzdH0gb3B0aW9ucy5yZXF1ZXN0XG4gICAgICAgKiBAcGFyYW0ge0FycmF5fSBvcHRpb25zLmxvZ3MgQSByZWZlcmVuY2UgdG8gdGhlIGxvZ3MgQXJyYXkuXG4gICAgICAgKiBAcGFyYW0ge0V2ZW50fSBvcHRpb25zLmV2ZW50XG4gICAgICAgKiBAcmV0dXJuIHtQcm9taXNlPFJlc3BvbnNlPn1cbiAgICAgICAqXG4gICAgICAgKiBAcHJpdmF0ZVxuICAgICAgICovXG4gICAgICBhc3luYyBfZ2V0TmV0d29ya1Byb21pc2Uoe1xuICAgICAgICB0aW1lb3V0SWQsXG4gICAgICAgIHJlcXVlc3QsXG4gICAgICAgIGxvZ3MsXG4gICAgICAgIGhhbmRsZXJcbiAgICAgIH0pIHtcbiAgICAgICAgbGV0IGVycm9yO1xuICAgICAgICBsZXQgcmVzcG9uc2U7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgcmVzcG9uc2UgPSBhd2FpdCBoYW5kbGVyLmZldGNoQW5kQ2FjaGVQdXQocmVxdWVzdCk7XG4gICAgICAgIH0gY2F0Y2ggKGZldGNoRXJyb3IpIHtcbiAgICAgICAgICBpZiAoZmV0Y2hFcnJvciBpbnN0YW5jZW9mIEVycm9yKSB7XG4gICAgICAgICAgICBlcnJvciA9IGZldGNoRXJyb3I7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGlmICh0aW1lb3V0SWQpIHtcbiAgICAgICAgICBjbGVhclRpbWVvdXQodGltZW91dElkKTtcbiAgICAgICAgfVxuICAgICAgICB7XG4gICAgICAgICAgaWYgKHJlc3BvbnNlKSB7XG4gICAgICAgICAgICBsb2dzLnB1c2goYEdvdCByZXNwb25zZSBmcm9tIG5ldHdvcmsuYCk7XG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIGxvZ3MucHVzaChgVW5hYmxlIHRvIGdldCBhIHJlc3BvbnNlIGZyb20gdGhlIG5ldHdvcmsuIFdpbGwgcmVzcG9uZCBgICsgYHdpdGggYSBjYWNoZWQgcmVzcG9uc2UuYCk7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGlmIChlcnJvciB8fCAhcmVzcG9uc2UpIHtcbiAgICAgICAgICByZXNwb25zZSA9IGF3YWl0IGhhbmRsZXIuY2FjaGVNYXRjaChyZXF1ZXN0KTtcbiAgICAgICAgICB7XG4gICAgICAgICAgICBpZiAocmVzcG9uc2UpIHtcbiAgICAgICAgICAgICAgbG9ncy5wdXNoKGBGb3VuZCBhIGNhY2hlZCByZXNwb25zZSBpbiB0aGUgJyR7dGhpcy5jYWNoZU5hbWV9J2AgKyBgIGNhY2hlLmApO1xuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgbG9ncy5wdXNoKGBObyByZXNwb25zZSBmb3VuZCBpbiB0aGUgJyR7dGhpcy5jYWNoZU5hbWV9JyBjYWNoZS5gKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlO1xuICAgICAgfVxuICAgIH1cblxuICAgIC8qXG4gICAgICBDb3B5cmlnaHQgMjAxOSBHb29nbGUgTExDXG5cbiAgICAgIFVzZSBvZiB0aGlzIHNvdXJjZSBjb2RlIGlzIGdvdmVybmVkIGJ5IGFuIE1JVC1zdHlsZVxuICAgICAgbGljZW5zZSB0aGF0IGNhbiBiZSBmb3VuZCBpbiB0aGUgTElDRU5TRSBmaWxlIG9yIGF0XG4gICAgICBodHRwczovL29wZW5zb3VyY2Uub3JnL2xpY2Vuc2VzL01JVC5cbiAgICAqL1xuICAgIC8qKlxuICAgICAqIENsYWltIGFueSBjdXJyZW50bHkgYXZhaWxhYmxlIGNsaWVudHMgb25jZSB0aGUgc2VydmljZSB3b3JrZXJcbiAgICAgKiBiZWNvbWVzIGFjdGl2ZS4gVGhpcyBpcyBub3JtYWxseSB1c2VkIGluIGNvbmp1bmN0aW9uIHdpdGggYHNraXBXYWl0aW5nKClgLlxuICAgICAqXG4gICAgICogQG1lbWJlcm9mIHdvcmtib3gtY29yZVxuICAgICAqL1xuICAgIGZ1bmN0aW9uIGNsaWVudHNDbGFpbSgpIHtcbiAgICAgIHNlbGYuYWRkRXZlbnRMaXN0ZW5lcignYWN0aXZhdGUnLCAoKSA9PiBzZWxmLmNsaWVudHMuY2xhaW0oKSk7XG4gICAgfVxuXG4gICAgLypcbiAgICAgIENvcHlyaWdodCAyMDIwIEdvb2dsZSBMTENcbiAgICAgIFVzZSBvZiB0aGlzIHNvdXJjZSBjb2RlIGlzIGdvdmVybmVkIGJ5IGFuIE1JVC1zdHlsZVxuICAgICAgbGljZW5zZSB0aGF0IGNhbiBiZSBmb3VuZCBpbiB0aGUgTElDRU5TRSBmaWxlIG9yIGF0XG4gICAgICBodHRwczovL29wZW5zb3VyY2Uub3JnL2xpY2Vuc2VzL01JVC5cbiAgICAqL1xuICAgIC8qKlxuICAgICAqIEEgdXRpbGl0eSBtZXRob2QgdGhhdCBtYWtlcyBpdCBlYXNpZXIgdG8gdXNlIGBldmVudC53YWl0VW50aWxgIHdpdGhcbiAgICAgKiBhc3luYyBmdW5jdGlvbnMgYW5kIHJldHVybiB0aGUgcmVzdWx0LlxuICAgICAqXG4gICAgICogQHBhcmFtIHtFeHRlbmRhYmxlRXZlbnR9IGV2ZW50XG4gICAgICogQHBhcmFtIHtGdW5jdGlvbn0gYXN5bmNGblxuICAgICAqIEByZXR1cm4ge0Z1bmN0aW9ufVxuICAgICAqIEBwcml2YXRlXG4gICAgICovXG4gICAgZnVuY3Rpb24gd2FpdFVudGlsKGV2ZW50LCBhc3luY0ZuKSB7XG4gICAgICBjb25zdCByZXR1cm5Qcm9taXNlID0gYXN5bmNGbigpO1xuICAgICAgZXZlbnQud2FpdFVudGlsKHJldHVyblByb21pc2UpO1xuICAgICAgcmV0dXJuIHJldHVyblByb21pc2U7XG4gICAgfVxuXG4gICAgLy8gQHRzLWlnbm9yZVxuICAgIHRyeSB7XG4gICAgICBzZWxmWyd3b3JrYm94OnByZWNhY2hpbmc6Ny40LjAnXSAmJiBfKCk7XG4gICAgfSBjYXRjaCAoZSkge31cblxuICAgIC8qXG4gICAgICBDb3B5cmlnaHQgMjAxOCBHb29nbGUgTExDXG5cbiAgICAgIFVzZSBvZiB0aGlzIHNvdXJjZSBjb2RlIGlzIGdvdmVybmVkIGJ5IGFuIE1JVC1zdHlsZVxuICAgICAgbGljZW5zZSB0aGF0IGNhbiBiZSBmb3VuZCBpbiB0aGUgTElDRU5TRSBmaWxlIG9yIGF0XG4gICAgICBodHRwczovL29wZW5zb3VyY2Uub3JnL2xpY2Vuc2VzL01JVC5cbiAgICAqL1xuICAgIC8vIE5hbWUgb2YgdGhlIHNlYXJjaCBwYXJhbWV0ZXIgdXNlZCB0byBzdG9yZSByZXZpc2lvbiBpbmZvLlxuICAgIGNvbnN0IFJFVklTSU9OX1NFQVJDSF9QQVJBTSA9ICdfX1dCX1JFVklTSU9OX18nO1xuICAgIC8qKlxuICAgICAqIENvbnZlcnRzIGEgbWFuaWZlc3QgZW50cnkgaW50byBhIHZlcnNpb25lZCBVUkwgc3VpdGFibGUgZm9yIHByZWNhY2hpbmcuXG4gICAgICpcbiAgICAgKiBAcGFyYW0ge09iamVjdHxzdHJpbmd9IGVudHJ5XG4gICAgICogQHJldHVybiB7c3RyaW5nfSBBIFVSTCB3aXRoIHZlcnNpb25pbmcgaW5mby5cbiAgICAgKlxuICAgICAqIEBwcml2YXRlXG4gICAgICogQG1lbWJlcm9mIHdvcmtib3gtcHJlY2FjaGluZ1xuICAgICAqL1xuICAgIGZ1bmN0aW9uIGNyZWF0ZUNhY2hlS2V5KGVudHJ5KSB7XG4gICAgICBpZiAoIWVudHJ5KSB7XG4gICAgICAgIHRocm93IG5ldyBXb3JrYm94RXJyb3IoJ2FkZC10by1jYWNoZS1saXN0LXVuZXhwZWN0ZWQtdHlwZScsIHtcbiAgICAgICAgICBlbnRyeVxuICAgICAgICB9KTtcbiAgICAgIH1cbiAgICAgIC8vIElmIGEgcHJlY2FjaGUgbWFuaWZlc3QgZW50cnkgaXMgYSBzdHJpbmcsIGl0J3MgYXNzdW1lZCB0byBiZSBhIHZlcnNpb25lZFxuICAgICAgLy8gVVJMLCBsaWtlICcvYXBwLmFiY2QxMjM0LmpzJy4gUmV0dXJuIGFzLWlzLlxuICAgICAgaWYgKHR5cGVvZiBlbnRyeSA9PT0gJ3N0cmluZycpIHtcbiAgICAgICAgY29uc3QgdXJsT2JqZWN0ID0gbmV3IFVSTChlbnRyeSwgbG9jYXRpb24uaHJlZik7XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgY2FjaGVLZXk6IHVybE9iamVjdC5ocmVmLFxuICAgICAgICAgIHVybDogdXJsT2JqZWN0LmhyZWZcbiAgICAgICAgfTtcbiAgICAgIH1cbiAgICAgIGNvbnN0IHtcbiAgICAgICAgcmV2aXNpb24sXG4gICAgICAgIHVybFxuICAgICAgfSA9IGVudHJ5O1xuICAgICAgaWYgKCF1cmwpIHtcbiAgICAgICAgdGhyb3cgbmV3IFdvcmtib3hFcnJvcignYWRkLXRvLWNhY2hlLWxpc3QtdW5leHBlY3RlZC10eXBlJywge1xuICAgICAgICAgIGVudHJ5XG4gICAgICAgIH0pO1xuICAgICAgfVxuICAgICAgLy8gSWYgdGhlcmUncyBqdXN0IGEgVVJMIGFuZCBubyByZXZpc2lvbiwgdGhlbiBpdCdzIGFsc28gYXNzdW1lZCB0byBiZSBhXG4gICAgICAvLyB2ZXJzaW9uZWQgVVJMLlxuICAgICAgaWYgKCFyZXZpc2lvbikge1xuICAgICAgICBjb25zdCB1cmxPYmplY3QgPSBuZXcgVVJMKHVybCwgbG9jYXRpb24uaHJlZik7XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgY2FjaGVLZXk6IHVybE9iamVjdC5ocmVmLFxuICAgICAgICAgIHVybDogdXJsT2JqZWN0LmhyZWZcbiAgICAgICAgfTtcbiAgICAgIH1cbiAgICAgIC8vIE90aGVyd2lzZSwgY29uc3RydWN0IGEgcHJvcGVybHkgdmVyc2lvbmVkIFVSTCB1c2luZyB0aGUgY3VzdG9tIFdvcmtib3hcbiAgICAgIC8vIHNlYXJjaCBwYXJhbWV0ZXIgYWxvbmcgd2l0aCB0aGUgcmV2aXNpb24gaW5mby5cbiAgICAgIGNvbnN0IGNhY2hlS2V5VVJMID0gbmV3IFVSTCh1cmwsIGxvY2F0aW9uLmhyZWYpO1xuICAgICAgY29uc3Qgb3JpZ2luYWxVUkwgPSBuZXcgVVJMKHVybCwgbG9jYXRpb24uaHJlZik7XG4gICAgICBjYWNoZUtleVVSTC5zZWFyY2hQYXJhbXMuc2V0KFJFVklTSU9OX1NFQVJDSF9QQVJBTSwgcmV2aXNpb24pO1xuICAgICAgcmV0dXJuIHtcbiAgICAgICAgY2FjaGVLZXk6IGNhY2hlS2V5VVJMLmhyZWYsXG4gICAgICAgIHVybDogb3JpZ2luYWxVUkwuaHJlZlxuICAgICAgfTtcbiAgICB9XG5cbiAgICAvKlxuICAgICAgQ29weXJpZ2h0IDIwMjAgR29vZ2xlIExMQ1xuXG4gICAgICBVc2Ugb2YgdGhpcyBzb3VyY2UgY29kZSBpcyBnb3Zlcm5lZCBieSBhbiBNSVQtc3R5bGVcbiAgICAgIGxpY2Vuc2UgdGhhdCBjYW4gYmUgZm91bmQgaW4gdGhlIExJQ0VOU0UgZmlsZSBvciBhdFxuICAgICAgaHR0cHM6Ly9vcGVuc291cmNlLm9yZy9saWNlbnNlcy9NSVQuXG4gICAgKi9cbiAgICAvKipcbiAgICAgKiBBIHBsdWdpbiwgZGVzaWduZWQgdG8gYmUgdXNlZCB3aXRoIFByZWNhY2hlQ29udHJvbGxlciwgdG8gZGV0ZXJtaW5lIHRoZVxuICAgICAqIG9mIGFzc2V0cyB0aGF0IHdlcmUgdXBkYXRlZCAob3Igbm90IHVwZGF0ZWQpIGR1cmluZyB0aGUgaW5zdGFsbCBldmVudC5cbiAgICAgKlxuICAgICAqIEBwcml2YXRlXG4gICAgICovXG4gICAgY2xhc3MgUHJlY2FjaGVJbnN0YWxsUmVwb3J0UGx1Z2luIHtcbiAgICAgIGNvbnN0cnVjdG9yKCkge1xuICAgICAgICB0aGlzLnVwZGF0ZWRVUkxzID0gW107XG4gICAgICAgIHRoaXMubm90VXBkYXRlZFVSTHMgPSBbXTtcbiAgICAgICAgdGhpcy5oYW5kbGVyV2lsbFN0YXJ0ID0gYXN5bmMgKHtcbiAgICAgICAgICByZXF1ZXN0LFxuICAgICAgICAgIHN0YXRlXG4gICAgICAgIH0pID0+IHtcbiAgICAgICAgICAvLyBUT0RPOiBgc3RhdGVgIHNob3VsZCBuZXZlciBiZSB1bmRlZmluZWQuLi5cbiAgICAgICAgICBpZiAoc3RhdGUpIHtcbiAgICAgICAgICAgIHN0YXRlLm9yaWdpbmFsUmVxdWVzdCA9IHJlcXVlc3Q7XG4gICAgICAgICAgfVxuICAgICAgICB9O1xuICAgICAgICB0aGlzLmNhY2hlZFJlc3BvbnNlV2lsbEJlVXNlZCA9IGFzeW5jICh7XG4gICAgICAgICAgZXZlbnQsXG4gICAgICAgICAgc3RhdGUsXG4gICAgICAgICAgY2FjaGVkUmVzcG9uc2VcbiAgICAgICAgfSkgPT4ge1xuICAgICAgICAgIGlmIChldmVudC50eXBlID09PSAnaW5zdGFsbCcpIHtcbiAgICAgICAgICAgIGlmIChzdGF0ZSAmJiBzdGF0ZS5vcmlnaW5hbFJlcXVlc3QgJiYgc3RhdGUub3JpZ2luYWxSZXF1ZXN0IGluc3RhbmNlb2YgUmVxdWVzdCkge1xuICAgICAgICAgICAgICAvLyBUT0RPOiBgc3RhdGVgIHNob3VsZCBuZXZlciBiZSB1bmRlZmluZWQuLi5cbiAgICAgICAgICAgICAgY29uc3QgdXJsID0gc3RhdGUub3JpZ2luYWxSZXF1ZXN0LnVybDtcbiAgICAgICAgICAgICAgaWYgKGNhY2hlZFJlc3BvbnNlKSB7XG4gICAgICAgICAgICAgICAgdGhpcy5ub3RVcGRhdGVkVVJMcy5wdXNoKHVybCk7XG4gICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgdGhpcy51cGRhdGVkVVJMcy5wdXNoKHVybCk7XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICAgICAgcmV0dXJuIGNhY2hlZFJlc3BvbnNlO1xuICAgICAgICB9O1xuICAgICAgfVxuICAgIH1cblxuICAgIC8qXG4gICAgICBDb3B5cmlnaHQgMjAyMCBHb29nbGUgTExDXG5cbiAgICAgIFVzZSBvZiB0aGlzIHNvdXJjZSBjb2RlIGlzIGdvdmVybmVkIGJ5IGFuIE1JVC1zdHlsZVxuICAgICAgbGljZW5zZSB0aGF0IGNhbiBiZSBmb3VuZCBpbiB0aGUgTElDRU5TRSBmaWxlIG9yIGF0XG4gICAgICBodHRwczovL29wZW5zb3VyY2Uub3JnL2xpY2Vuc2VzL01JVC5cbiAgICAqL1xuICAgIC8qKlxuICAgICAqIEEgcGx1Z2luLCBkZXNpZ25lZCB0byBiZSB1c2VkIHdpdGggUHJlY2FjaGVDb250cm9sbGVyLCB0byB0cmFuc2xhdGUgVVJMcyBpbnRvXG4gICAgICogdGhlIGNvcnJlc3BvbmRpbmcgY2FjaGUga2V5LCBiYXNlZCBvbiB0aGUgY3VycmVudCByZXZpc2lvbiBpbmZvLlxuICAgICAqXG4gICAgICogQHByaXZhdGVcbiAgICAgKi9cbiAgICBjbGFzcyBQcmVjYWNoZUNhY2hlS2V5UGx1Z2luIHtcbiAgICAgIGNvbnN0cnVjdG9yKHtcbiAgICAgICAgcHJlY2FjaGVDb250cm9sbGVyXG4gICAgICB9KSB7XG4gICAgICAgIHRoaXMuY2FjaGVLZXlXaWxsQmVVc2VkID0gYXN5bmMgKHtcbiAgICAgICAgICByZXF1ZXN0LFxuICAgICAgICAgIHBhcmFtc1xuICAgICAgICB9KSA9PiB7XG4gICAgICAgICAgLy8gUGFyYW1zIGlzIHR5cGUgYW55LCBjYW4ndCBjaGFuZ2UgcmlnaHQgbm93LlxuICAgICAgICAgIC8qIGVzbGludC1kaXNhYmxlICovXG4gICAgICAgICAgY29uc3QgY2FjaGVLZXkgPSAocGFyYW1zID09PSBudWxsIHx8IHBhcmFtcyA9PT0gdm9pZCAwID8gdm9pZCAwIDogcGFyYW1zLmNhY2hlS2V5KSB8fCB0aGlzLl9wcmVjYWNoZUNvbnRyb2xsZXIuZ2V0Q2FjaGVLZXlGb3JVUkwocmVxdWVzdC51cmwpO1xuICAgICAgICAgIC8qIGVzbGludC1lbmFibGUgKi9cbiAgICAgICAgICByZXR1cm4gY2FjaGVLZXkgPyBuZXcgUmVxdWVzdChjYWNoZUtleSwge1xuICAgICAgICAgICAgaGVhZGVyczogcmVxdWVzdC5oZWFkZXJzXG4gICAgICAgICAgfSkgOiByZXF1ZXN0O1xuICAgICAgICB9O1xuICAgICAgICB0aGlzLl9wcmVjYWNoZUNvbnRyb2xsZXIgPSBwcmVjYWNoZUNvbnRyb2xsZXI7XG4gICAgICB9XG4gICAgfVxuXG4gICAgLypcbiAgICAgIENvcHlyaWdodCAyMDE4IEdvb2dsZSBMTENcblxuICAgICAgVXNlIG9mIHRoaXMgc291cmNlIGNvZGUgaXMgZ292ZXJuZWQgYnkgYW4gTUlULXN0eWxlXG4gICAgICBsaWNlbnNlIHRoYXQgY2FuIGJlIGZvdW5kIGluIHRoZSBMSUNFTlNFIGZpbGUgb3IgYXRcbiAgICAgIGh0dHBzOi8vb3BlbnNvdXJjZS5vcmcvbGljZW5zZXMvTUlULlxuICAgICovXG4gICAgLyoqXG4gICAgICogQHBhcmFtIHtzdHJpbmd9IGdyb3VwVGl0bGVcbiAgICAgKiBAcGFyYW0ge0FycmF5PHN0cmluZz59IGRlbGV0ZWRVUkxzXG4gICAgICpcbiAgICAgKiBAcHJpdmF0ZVxuICAgICAqL1xuICAgIGNvbnN0IGxvZ0dyb3VwID0gKGdyb3VwVGl0bGUsIGRlbGV0ZWRVUkxzKSA9PiB7XG4gICAgICBsb2dnZXIuZ3JvdXBDb2xsYXBzZWQoZ3JvdXBUaXRsZSk7XG4gICAgICBmb3IgKGNvbnN0IHVybCBvZiBkZWxldGVkVVJMcykge1xuICAgICAgICBsb2dnZXIubG9nKHVybCk7XG4gICAgICB9XG4gICAgICBsb2dnZXIuZ3JvdXBFbmQoKTtcbiAgICB9O1xuICAgIC8qKlxuICAgICAqIEBwYXJhbSB7QXJyYXk8c3RyaW5nPn0gZGVsZXRlZFVSTHNcbiAgICAgKlxuICAgICAqIEBwcml2YXRlXG4gICAgICogQG1lbWJlcm9mIHdvcmtib3gtcHJlY2FjaGluZ1xuICAgICAqL1xuICAgIGZ1bmN0aW9uIHByaW50Q2xlYW51cERldGFpbHMoZGVsZXRlZFVSTHMpIHtcbiAgICAgIGNvbnN0IGRlbGV0aW9uQ291bnQgPSBkZWxldGVkVVJMcy5sZW5ndGg7XG4gICAgICBpZiAoZGVsZXRpb25Db3VudCA+IDApIHtcbiAgICAgICAgbG9nZ2VyLmdyb3VwQ29sbGFwc2VkKGBEdXJpbmcgcHJlY2FjaGluZyBjbGVhbnVwLCBgICsgYCR7ZGVsZXRpb25Db3VudH0gY2FjaGVkIGAgKyBgcmVxdWVzdCR7ZGVsZXRpb25Db3VudCA9PT0gMSA/ICcgd2FzJyA6ICdzIHdlcmUnfSBkZWxldGVkLmApO1xuICAgICAgICBsb2dHcm91cCgnRGVsZXRlZCBDYWNoZSBSZXF1ZXN0cycsIGRlbGV0ZWRVUkxzKTtcbiAgICAgICAgbG9nZ2VyLmdyb3VwRW5kKCk7XG4gICAgICB9XG4gICAgfVxuXG4gICAgLypcbiAgICAgIENvcHlyaWdodCAyMDE4IEdvb2dsZSBMTENcblxuICAgICAgVXNlIG9mIHRoaXMgc291cmNlIGNvZGUgaXMgZ292ZXJuZWQgYnkgYW4gTUlULXN0eWxlXG4gICAgICBsaWNlbnNlIHRoYXQgY2FuIGJlIGZvdW5kIGluIHRoZSBMSUNFTlNFIGZpbGUgb3IgYXRcbiAgICAgIGh0dHBzOi8vb3BlbnNvdXJjZS5vcmcvbGljZW5zZXMvTUlULlxuICAgICovXG4gICAgLyoqXG4gICAgICogQHBhcmFtIHtzdHJpbmd9IGdyb3VwVGl0bGVcbiAgICAgKiBAcGFyYW0ge0FycmF5PHN0cmluZz59IHVybHNcbiAgICAgKlxuICAgICAqIEBwcml2YXRlXG4gICAgICovXG4gICAgZnVuY3Rpb24gX25lc3RlZEdyb3VwKGdyb3VwVGl0bGUsIHVybHMpIHtcbiAgICAgIGlmICh1cmxzLmxlbmd0aCA9PT0gMCkge1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgICBsb2dnZXIuZ3JvdXBDb2xsYXBzZWQoZ3JvdXBUaXRsZSk7XG4gICAgICBmb3IgKGNvbnN0IHVybCBvZiB1cmxzKSB7XG4gICAgICAgIGxvZ2dlci5sb2codXJsKTtcbiAgICAgIH1cbiAgICAgIGxvZ2dlci5ncm91cEVuZCgpO1xuICAgIH1cbiAgICAvKipcbiAgICAgKiBAcGFyYW0ge0FycmF5PHN0cmluZz59IHVybHNUb1ByZWNhY2hlXG4gICAgICogQHBhcmFtIHtBcnJheTxzdHJpbmc+fSB1cmxzQWxyZWFkeVByZWNhY2hlZFxuICAgICAqXG4gICAgICogQHByaXZhdGVcbiAgICAgKiBAbWVtYmVyb2Ygd29ya2JveC1wcmVjYWNoaW5nXG4gICAgICovXG4gICAgZnVuY3Rpb24gcHJpbnRJbnN0YWxsRGV0YWlscyh1cmxzVG9QcmVjYWNoZSwgdXJsc0FscmVhZHlQcmVjYWNoZWQpIHtcbiAgICAgIGNvbnN0IHByZWNhY2hlZENvdW50ID0gdXJsc1RvUHJlY2FjaGUubGVuZ3RoO1xuICAgICAgY29uc3QgYWxyZWFkeVByZWNhY2hlZENvdW50ID0gdXJsc0FscmVhZHlQcmVjYWNoZWQubGVuZ3RoO1xuICAgICAgaWYgKHByZWNhY2hlZENvdW50IHx8IGFscmVhZHlQcmVjYWNoZWRDb3VudCkge1xuICAgICAgICBsZXQgbWVzc2FnZSA9IGBQcmVjYWNoaW5nICR7cHJlY2FjaGVkQ291bnR9IGZpbGUke3ByZWNhY2hlZENvdW50ID09PSAxID8gJycgOiAncyd9LmA7XG4gICAgICAgIGlmIChhbHJlYWR5UHJlY2FjaGVkQ291bnQgPiAwKSB7XG4gICAgICAgICAgbWVzc2FnZSArPSBgICR7YWxyZWFkeVByZWNhY2hlZENvdW50fSBgICsgYGZpbGUke2FscmVhZHlQcmVjYWNoZWRDb3VudCA9PT0gMSA/ICcgaXMnIDogJ3MgYXJlJ30gYWxyZWFkeSBjYWNoZWQuYDtcbiAgICAgICAgfVxuICAgICAgICBsb2dnZXIuZ3JvdXBDb2xsYXBzZWQobWVzc2FnZSk7XG4gICAgICAgIF9uZXN0ZWRHcm91cChgVmlldyBuZXdseSBwcmVjYWNoZWQgVVJMcy5gLCB1cmxzVG9QcmVjYWNoZSk7XG4gICAgICAgIF9uZXN0ZWRHcm91cChgVmlldyBwcmV2aW91c2x5IHByZWNhY2hlZCBVUkxzLmAsIHVybHNBbHJlYWR5UHJlY2FjaGVkKTtcbiAgICAgICAgbG9nZ2VyLmdyb3VwRW5kKCk7XG4gICAgICB9XG4gICAgfVxuXG4gICAgLypcbiAgICAgIENvcHlyaWdodCAyMDE5IEdvb2dsZSBMTENcblxuICAgICAgVXNlIG9mIHRoaXMgc291cmNlIGNvZGUgaXMgZ292ZXJuZWQgYnkgYW4gTUlULXN0eWxlXG4gICAgICBsaWNlbnNlIHRoYXQgY2FuIGJlIGZvdW5kIGluIHRoZSBMSUNFTlNFIGZpbGUgb3IgYXRcbiAgICAgIGh0dHBzOi8vb3BlbnNvdXJjZS5vcmcvbGljZW5zZXMvTUlULlxuICAgICovXG4gICAgbGV0IHN1cHBvcnRTdGF0dXM7XG4gICAgLyoqXG4gICAgICogQSB1dGlsaXR5IGZ1bmN0aW9uIHRoYXQgZGV0ZXJtaW5lcyB3aGV0aGVyIHRoZSBjdXJyZW50IGJyb3dzZXIgc3VwcG9ydHNcbiAgICAgKiBjb25zdHJ1Y3RpbmcgYSBuZXcgYFJlc3BvbnNlYCBmcm9tIGEgYHJlc3BvbnNlLmJvZHlgIHN0cmVhbS5cbiAgICAgKlxuICAgICAqIEByZXR1cm4ge2Jvb2xlYW59IGB0cnVlYCwgaWYgdGhlIGN1cnJlbnQgYnJvd3NlciBjYW4gc3VjY2Vzc2Z1bGx5XG4gICAgICogICAgIGNvbnN0cnVjdCBhIGBSZXNwb25zZWAgZnJvbSBhIGByZXNwb25zZS5ib2R5YCBzdHJlYW0sIGBmYWxzZWAgb3RoZXJ3aXNlLlxuICAgICAqXG4gICAgICogQHByaXZhdGVcbiAgICAgKi9cbiAgICBmdW5jdGlvbiBjYW5Db25zdHJ1Y3RSZXNwb25zZUZyb21Cb2R5U3RyZWFtKCkge1xuICAgICAgaWYgKHN1cHBvcnRTdGF0dXMgPT09IHVuZGVmaW5lZCkge1xuICAgICAgICBjb25zdCB0ZXN0UmVzcG9uc2UgPSBuZXcgUmVzcG9uc2UoJycpO1xuICAgICAgICBpZiAoJ2JvZHknIGluIHRlc3RSZXNwb25zZSkge1xuICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICBuZXcgUmVzcG9uc2UodGVzdFJlc3BvbnNlLmJvZHkpO1xuICAgICAgICAgICAgc3VwcG9ydFN0YXR1cyA9IHRydWU7XG4gICAgICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgICAgIHN1cHBvcnRTdGF0dXMgPSBmYWxzZTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgc3VwcG9ydFN0YXR1cyA9IGZhbHNlO1xuICAgICAgfVxuICAgICAgcmV0dXJuIHN1cHBvcnRTdGF0dXM7XG4gICAgfVxuXG4gICAgLypcbiAgICAgIENvcHlyaWdodCAyMDE5IEdvb2dsZSBMTENcblxuICAgICAgVXNlIG9mIHRoaXMgc291cmNlIGNvZGUgaXMgZ292ZXJuZWQgYnkgYW4gTUlULXN0eWxlXG4gICAgICBsaWNlbnNlIHRoYXQgY2FuIGJlIGZvdW5kIGluIHRoZSBMSUNFTlNFIGZpbGUgb3IgYXRcbiAgICAgIGh0dHBzOi8vb3BlbnNvdXJjZS5vcmcvbGljZW5zZXMvTUlULlxuICAgICovXG4gICAgLyoqXG4gICAgICogQWxsb3dzIGRldmVsb3BlcnMgdG8gY29weSBhIHJlc3BvbnNlIGFuZCBtb2RpZnkgaXRzIGBoZWFkZXJzYCwgYHN0YXR1c2AsXG4gICAgICogb3IgYHN0YXR1c1RleHRgIHZhbHVlcyAodGhlIHZhbHVlcyBzZXR0YWJsZSB2aWEgYVxuICAgICAqIFtgUmVzcG9uc2VJbml0YF17QGxpbmsgaHR0cHM6Ly9kZXZlbG9wZXIubW96aWxsYS5vcmcvZW4tVVMvZG9jcy9XZWIvQVBJL1Jlc3BvbnNlL1Jlc3BvbnNlI1N5bnRheH1cbiAgICAgKiBvYmplY3QgaW4gdGhlIGNvbnN0cnVjdG9yKS5cbiAgICAgKiBUbyBtb2RpZnkgdGhlc2UgdmFsdWVzLCBwYXNzIGEgZnVuY3Rpb24gYXMgdGhlIHNlY29uZCBhcmd1bWVudC4gVGhhdFxuICAgICAqIGZ1bmN0aW9uIHdpbGwgYmUgaW52b2tlZCB3aXRoIGEgc2luZ2xlIG9iamVjdCB3aXRoIHRoZSByZXNwb25zZSBwcm9wZXJ0aWVzXG4gICAgICogYHtoZWFkZXJzLCBzdGF0dXMsIHN0YXR1c1RleHR9YC4gVGhlIHJldHVybiB2YWx1ZSBvZiB0aGlzIGZ1bmN0aW9uIHdpbGxcbiAgICAgKiBiZSB1c2VkIGFzIHRoZSBgUmVzcG9uc2VJbml0YCBmb3IgdGhlIG5ldyBgUmVzcG9uc2VgLiBUbyBjaGFuZ2UgdGhlIHZhbHVlc1xuICAgICAqIGVpdGhlciBtb2RpZnkgdGhlIHBhc3NlZCBwYXJhbWV0ZXIocykgYW5kIHJldHVybiBpdCwgb3IgcmV0dXJuIGEgdG90YWxseVxuICAgICAqIG5ldyBvYmplY3QuXG4gICAgICpcbiAgICAgKiBUaGlzIG1ldGhvZCBpcyBpbnRlbnRpb25hbGx5IGxpbWl0ZWQgdG8gc2FtZS1vcmlnaW4gcmVzcG9uc2VzLCByZWdhcmRsZXNzIG9mXG4gICAgICogd2hldGhlciBDT1JTIHdhcyB1c2VkIG9yIG5vdC5cbiAgICAgKlxuICAgICAqIEBwYXJhbSB7UmVzcG9uc2V9IHJlc3BvbnNlXG4gICAgICogQHBhcmFtIHtGdW5jdGlvbn0gbW9kaWZpZXJcbiAgICAgKiBAbWVtYmVyb2Ygd29ya2JveC1jb3JlXG4gICAgICovXG4gICAgYXN5bmMgZnVuY3Rpb24gY29weVJlc3BvbnNlKHJlc3BvbnNlLCBtb2RpZmllcikge1xuICAgICAgbGV0IG9yaWdpbiA9IG51bGw7XG4gICAgICAvLyBJZiByZXNwb25zZS51cmwgaXNuJ3Qgc2V0LCBhc3N1bWUgaXQncyBjcm9zcy1vcmlnaW4gYW5kIGtlZXAgb3JpZ2luIG51bGwuXG4gICAgICBpZiAocmVzcG9uc2UudXJsKSB7XG4gICAgICAgIGNvbnN0IHJlc3BvbnNlVVJMID0gbmV3IFVSTChyZXNwb25zZS51cmwpO1xuICAgICAgICBvcmlnaW4gPSByZXNwb25zZVVSTC5vcmlnaW47XG4gICAgICB9XG4gICAgICBpZiAob3JpZ2luICE9PSBzZWxmLmxvY2F0aW9uLm9yaWdpbikge1xuICAgICAgICB0aHJvdyBuZXcgV29ya2JveEVycm9yKCdjcm9zcy1vcmlnaW4tY29weS1yZXNwb25zZScsIHtcbiAgICAgICAgICBvcmlnaW5cbiAgICAgICAgfSk7XG4gICAgICB9XG4gICAgICBjb25zdCBjbG9uZWRSZXNwb25zZSA9IHJlc3BvbnNlLmNsb25lKCk7XG4gICAgICAvLyBDcmVhdGUgYSBmcmVzaCBgUmVzcG9uc2VJbml0YCBvYmplY3QgYnkgY2xvbmluZyB0aGUgaGVhZGVycy5cbiAgICAgIGNvbnN0IHJlc3BvbnNlSW5pdCA9IHtcbiAgICAgICAgaGVhZGVyczogbmV3IEhlYWRlcnMoY2xvbmVkUmVzcG9uc2UuaGVhZGVycyksXG4gICAgICAgIHN0YXR1czogY2xvbmVkUmVzcG9uc2Uuc3RhdHVzLFxuICAgICAgICBzdGF0dXNUZXh0OiBjbG9uZWRSZXNwb25zZS5zdGF0dXNUZXh0XG4gICAgICB9O1xuICAgICAgLy8gQXBwbHkgYW55IHVzZXIgbW9kaWZpY2F0aW9ucy5cbiAgICAgIGNvbnN0IG1vZGlmaWVkUmVzcG9uc2VJbml0ID0gcmVzcG9uc2VJbml0O1xuICAgICAgLy8gQ3JlYXRlIHRoZSBuZXcgcmVzcG9uc2UgZnJvbSB0aGUgYm9keSBzdHJlYW0gYW5kIGBSZXNwb25zZUluaXRgXG4gICAgICAvLyBtb2RpZmljYXRpb25zLiBOb3RlOiBub3QgYWxsIGJyb3dzZXJzIHN1cHBvcnQgdGhlIFJlc3BvbnNlLmJvZHkgc3RyZWFtLFxuICAgICAgLy8gc28gZmFsbCBiYWNrIHRvIHJlYWRpbmcgdGhlIGVudGlyZSBib2R5IGludG8gbWVtb3J5IGFzIGEgYmxvYi5cbiAgICAgIGNvbnN0IGJvZHkgPSBjYW5Db25zdHJ1Y3RSZXNwb25zZUZyb21Cb2R5U3RyZWFtKCkgPyBjbG9uZWRSZXNwb25zZS5ib2R5IDogYXdhaXQgY2xvbmVkUmVzcG9uc2UuYmxvYigpO1xuICAgICAgcmV0dXJuIG5ldyBSZXNwb25zZShib2R5LCBtb2RpZmllZFJlc3BvbnNlSW5pdCk7XG4gICAgfVxuXG4gICAgLypcbiAgICAgIENvcHlyaWdodCAyMDIwIEdvb2dsZSBMTENcblxuICAgICAgVXNlIG9mIHRoaXMgc291cmNlIGNvZGUgaXMgZ292ZXJuZWQgYnkgYW4gTUlULXN0eWxlXG4gICAgICBsaWNlbnNlIHRoYXQgY2FuIGJlIGZvdW5kIGluIHRoZSBMSUNFTlNFIGZpbGUgb3IgYXRcbiAgICAgIGh0dHBzOi8vb3BlbnNvdXJjZS5vcmcvbGljZW5zZXMvTUlULlxuICAgICovXG4gICAgLyoqXG4gICAgICogQSB7QGxpbmsgd29ya2JveC1zdHJhdGVnaWVzLlN0cmF0ZWd5fSBpbXBsZW1lbnRhdGlvblxuICAgICAqIHNwZWNpZmljYWxseSBkZXNpZ25lZCB0byB3b3JrIHdpdGhcbiAgICAgKiB7QGxpbmsgd29ya2JveC1wcmVjYWNoaW5nLlByZWNhY2hlQ29udHJvbGxlcn1cbiAgICAgKiB0byBib3RoIGNhY2hlIGFuZCBmZXRjaCBwcmVjYWNoZWQgYXNzZXRzLlxuICAgICAqXG4gICAgICogTm90ZTogYW4gaW5zdGFuY2Ugb2YgdGhpcyBjbGFzcyBpcyBjcmVhdGVkIGF1dG9tYXRpY2FsbHkgd2hlbiBjcmVhdGluZyBhXG4gICAgICogYFByZWNhY2hlQ29udHJvbGxlcmA7IGl0J3MgZ2VuZXJhbGx5IG5vdCBuZWNlc3NhcnkgdG8gY3JlYXRlIHRoaXMgeW91cnNlbGYuXG4gICAgICpcbiAgICAgKiBAZXh0ZW5kcyB3b3JrYm94LXN0cmF0ZWdpZXMuU3RyYXRlZ3lcbiAgICAgKiBAbWVtYmVyb2Ygd29ya2JveC1wcmVjYWNoaW5nXG4gICAgICovXG4gICAgY2xhc3MgUHJlY2FjaGVTdHJhdGVneSBleHRlbmRzIFN0cmF0ZWd5IHtcbiAgICAgIC8qKlxuICAgICAgICpcbiAgICAgICAqIEBwYXJhbSB7T2JqZWN0fSBbb3B0aW9uc11cbiAgICAgICAqIEBwYXJhbSB7c3RyaW5nfSBbb3B0aW9ucy5jYWNoZU5hbWVdIENhY2hlIG5hbWUgdG8gc3RvcmUgYW5kIHJldHJpZXZlXG4gICAgICAgKiByZXF1ZXN0cy4gRGVmYXVsdHMgdG8gdGhlIGNhY2hlIG5hbWVzIHByb3ZpZGVkIGJ5XG4gICAgICAgKiB7QGxpbmsgd29ya2JveC1jb3JlLmNhY2hlTmFtZXN9LlxuICAgICAgICogQHBhcmFtIHtBcnJheTxPYmplY3Q+fSBbb3B0aW9ucy5wbHVnaW5zXSB7QGxpbmsgaHR0cHM6Ly9kZXZlbG9wZXJzLmdvb2dsZS5jb20vd2ViL3Rvb2xzL3dvcmtib3gvZ3VpZGVzL3VzaW5nLXBsdWdpbnN8UGx1Z2luc31cbiAgICAgICAqIHRvIHVzZSBpbiBjb25qdW5jdGlvbiB3aXRoIHRoaXMgY2FjaGluZyBzdHJhdGVneS5cbiAgICAgICAqIEBwYXJhbSB7T2JqZWN0fSBbb3B0aW9ucy5mZXRjaE9wdGlvbnNdIFZhbHVlcyBwYXNzZWQgYWxvbmcgdG8gdGhlXG4gICAgICAgKiB7QGxpbmsgaHR0cHM6Ly9kZXZlbG9wZXIubW96aWxsYS5vcmcvZW4tVVMvZG9jcy9XZWIvQVBJL1dpbmRvd09yV29ya2VyR2xvYmFsU2NvcGUvZmV0Y2gjUGFyYW1ldGVyc3xpbml0fVxuICAgICAgICogb2YgYWxsIGZldGNoKCkgcmVxdWVzdHMgbWFkZSBieSB0aGlzIHN0cmF0ZWd5LlxuICAgICAgICogQHBhcmFtIHtPYmplY3R9IFtvcHRpb25zLm1hdGNoT3B0aW9uc10gVGhlXG4gICAgICAgKiB7QGxpbmsgaHR0cHM6Ly93M2MuZ2l0aHViLmlvL1NlcnZpY2VXb3JrZXIvI2RpY3RkZWYtY2FjaGVxdWVyeW9wdGlvbnN8Q2FjaGVRdWVyeU9wdGlvbnN9XG4gICAgICAgKiBmb3IgYW55IGBjYWNoZS5tYXRjaCgpYCBvciBgY2FjaGUucHV0KClgIGNhbGxzIG1hZGUgYnkgdGhpcyBzdHJhdGVneS5cbiAgICAgICAqIEBwYXJhbSB7Ym9vbGVhbn0gW29wdGlvbnMuZmFsbGJhY2tUb05ldHdvcms9dHJ1ZV0gV2hldGhlciB0byBhdHRlbXB0IHRvXG4gICAgICAgKiBnZXQgdGhlIHJlc3BvbnNlIGZyb20gdGhlIG5ldHdvcmsgaWYgdGhlcmUncyBhIHByZWNhY2hlIG1pc3MuXG4gICAgICAgKi9cbiAgICAgIGNvbnN0cnVjdG9yKG9wdGlvbnMgPSB7fSkge1xuICAgICAgICBvcHRpb25zLmNhY2hlTmFtZSA9IGNhY2hlTmFtZXMuZ2V0UHJlY2FjaGVOYW1lKG9wdGlvbnMuY2FjaGVOYW1lKTtcbiAgICAgICAgc3VwZXIob3B0aW9ucyk7XG4gICAgICAgIHRoaXMuX2ZhbGxiYWNrVG9OZXR3b3JrID0gb3B0aW9ucy5mYWxsYmFja1RvTmV0d29yayA9PT0gZmFsc2UgPyBmYWxzZSA6IHRydWU7XG4gICAgICAgIC8vIFJlZGlyZWN0ZWQgcmVzcG9uc2VzIGNhbm5vdCBiZSB1c2VkIHRvIHNhdGlzZnkgYSBuYXZpZ2F0aW9uIHJlcXVlc3QsIHNvXG4gICAgICAgIC8vIGFueSByZWRpcmVjdGVkIHJlc3BvbnNlIG11c3QgYmUgXCJjb3BpZWRcIiByYXRoZXIgdGhhbiBjbG9uZWQsIHNvIHRoZSBuZXdcbiAgICAgICAgLy8gcmVzcG9uc2UgZG9lc24ndCBjb250YWluIHRoZSBgcmVkaXJlY3RlZGAgZmxhZy4gU2VlOlxuICAgICAgICAvLyBodHRwczovL2J1Z3MuY2hyb21pdW0ub3JnL3AvY2hyb21pdW0vaXNzdWVzL2RldGFpbD9pZD02NjkzNjMmZGVzYz0yI2MxXG4gICAgICAgIHRoaXMucGx1Z2lucy5wdXNoKFByZWNhY2hlU3RyYXRlZ3kuY29weVJlZGlyZWN0ZWRDYWNoZWFibGVSZXNwb25zZXNQbHVnaW4pO1xuICAgICAgfVxuICAgICAgLyoqXG4gICAgICAgKiBAcHJpdmF0ZVxuICAgICAgICogQHBhcmFtIHtSZXF1ZXN0fHN0cmluZ30gcmVxdWVzdCBBIHJlcXVlc3QgdG8gcnVuIHRoaXMgc3RyYXRlZ3kgZm9yLlxuICAgICAgICogQHBhcmFtIHt3b3JrYm94LXN0cmF0ZWdpZXMuU3RyYXRlZ3lIYW5kbGVyfSBoYW5kbGVyIFRoZSBldmVudCB0aGF0XG4gICAgICAgKiAgICAgdHJpZ2dlcmVkIHRoZSByZXF1ZXN0LlxuICAgICAgICogQHJldHVybiB7UHJvbWlzZTxSZXNwb25zZT59XG4gICAgICAgKi9cbiAgICAgIGFzeW5jIF9oYW5kbGUocmVxdWVzdCwgaGFuZGxlcikge1xuICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGhhbmRsZXIuY2FjaGVNYXRjaChyZXF1ZXN0KTtcbiAgICAgICAgaWYgKHJlc3BvbnNlKSB7XG4gICAgICAgICAgcmV0dXJuIHJlc3BvbnNlO1xuICAgICAgICB9XG4gICAgICAgIC8vIElmIHRoaXMgaXMgYW4gYGluc3RhbGxgIGV2ZW50IGZvciBhbiBlbnRyeSB0aGF0IGlzbid0IGFscmVhZHkgY2FjaGVkLFxuICAgICAgICAvLyB0aGVuIHBvcHVsYXRlIHRoZSBjYWNoZS5cbiAgICAgICAgaWYgKGhhbmRsZXIuZXZlbnQgJiYgaGFuZGxlci5ldmVudC50eXBlID09PSAnaW5zdGFsbCcpIHtcbiAgICAgICAgICByZXR1cm4gYXdhaXQgdGhpcy5faGFuZGxlSW5zdGFsbChyZXF1ZXN0LCBoYW5kbGVyKTtcbiAgICAgICAgfVxuICAgICAgICAvLyBHZXR0aW5nIGhlcmUgbWVhbnMgc29tZXRoaW5nIHdlbnQgd3JvbmcuIEFuIGVudHJ5IHRoYXQgc2hvdWxkIGhhdmUgYmVlblxuICAgICAgICAvLyBwcmVjYWNoZWQgd2Fzbid0IGZvdW5kIGluIHRoZSBjYWNoZS5cbiAgICAgICAgcmV0dXJuIGF3YWl0IHRoaXMuX2hhbmRsZUZldGNoKHJlcXVlc3QsIGhhbmRsZXIpO1xuICAgICAgfVxuICAgICAgYXN5bmMgX2hhbmRsZUZldGNoKHJlcXVlc3QsIGhhbmRsZXIpIHtcbiAgICAgICAgbGV0IHJlc3BvbnNlO1xuICAgICAgICBjb25zdCBwYXJhbXMgPSBoYW5kbGVyLnBhcmFtcyB8fCB7fTtcbiAgICAgICAgLy8gRmFsbCBiYWNrIHRvIHRoZSBuZXR3b3JrIGlmIHdlJ3JlIGNvbmZpZ3VyZWQgdG8gZG8gc28uXG4gICAgICAgIGlmICh0aGlzLl9mYWxsYmFja1RvTmV0d29yaykge1xuICAgICAgICAgIHtcbiAgICAgICAgICAgIGxvZ2dlci53YXJuKGBUaGUgcHJlY2FjaGVkIHJlc3BvbnNlIGZvciBgICsgYCR7Z2V0RnJpZW5kbHlVUkwocmVxdWVzdC51cmwpfSBpbiAke3RoaXMuY2FjaGVOYW1lfSB3YXMgbm90IGAgKyBgZm91bmQuIEZhbGxpbmcgYmFjayB0byB0aGUgbmV0d29yay5gKTtcbiAgICAgICAgICB9XG4gICAgICAgICAgY29uc3QgaW50ZWdyaXR5SW5NYW5pZmVzdCA9IHBhcmFtcy5pbnRlZ3JpdHk7XG4gICAgICAgICAgY29uc3QgaW50ZWdyaXR5SW5SZXF1ZXN0ID0gcmVxdWVzdC5pbnRlZ3JpdHk7XG4gICAgICAgICAgY29uc3Qgbm9JbnRlZ3JpdHlDb25mbGljdCA9ICFpbnRlZ3JpdHlJblJlcXVlc3QgfHwgaW50ZWdyaXR5SW5SZXF1ZXN0ID09PSBpbnRlZ3JpdHlJbk1hbmlmZXN0O1xuICAgICAgICAgIC8vIERvIG5vdCBhZGQgaW50ZWdyaXR5IGlmIHRoZSBvcmlnaW5hbCByZXF1ZXN0IGlzIG5vLWNvcnNcbiAgICAgICAgICAvLyBTZWUgaHR0cHM6Ly9naXRodWIuY29tL0dvb2dsZUNocm9tZS93b3JrYm94L2lzc3Vlcy8zMDk2XG4gICAgICAgICAgcmVzcG9uc2UgPSBhd2FpdCBoYW5kbGVyLmZldGNoKG5ldyBSZXF1ZXN0KHJlcXVlc3QsIHtcbiAgICAgICAgICAgIGludGVncml0eTogcmVxdWVzdC5tb2RlICE9PSAnbm8tY29ycycgPyBpbnRlZ3JpdHlJblJlcXVlc3QgfHwgaW50ZWdyaXR5SW5NYW5pZmVzdCA6IHVuZGVmaW5lZFxuICAgICAgICAgIH0pKTtcbiAgICAgICAgICAvLyBJdCdzIG9ubHkgXCJzYWZlXCIgdG8gcmVwYWlyIHRoZSBjYWNoZSBpZiB3ZSdyZSB1c2luZyBTUkkgdG8gZ3VhcmFudGVlXG4gICAgICAgICAgLy8gdGhhdCB0aGUgcmVzcG9uc2UgbWF0Y2hlcyB0aGUgcHJlY2FjaGUgbWFuaWZlc3QncyBleHBlY3RhdGlvbnMsXG4gICAgICAgICAgLy8gYW5kIHRoZXJlJ3MgZWl0aGVyIGEpIG5vIGludGVncml0eSBwcm9wZXJ0eSBpbiB0aGUgaW5jb21pbmcgcmVxdWVzdFxuICAgICAgICAgIC8vIG9yIGIpIHRoZXJlIGlzIGFuIGludGVncml0eSwgYW5kIGl0IG1hdGNoZXMgdGhlIHByZWNhY2hlIG1hbmlmZXN0LlxuICAgICAgICAgIC8vIFNlZSBodHRwczovL2dpdGh1Yi5jb20vR29vZ2xlQ2hyb21lL3dvcmtib3gvaXNzdWVzLzI4NThcbiAgICAgICAgICAvLyBBbHNvIGlmIHRoZSBvcmlnaW5hbCByZXF1ZXN0IHVzZXJzIG5vLWNvcnMgd2UgZG9uJ3QgdXNlIGludGVncml0eS5cbiAgICAgICAgICAvLyBTZWUgaHR0cHM6Ly9naXRodWIuY29tL0dvb2dsZUNocm9tZS93b3JrYm94L2lzc3Vlcy8zMDk2XG4gICAgICAgICAgaWYgKGludGVncml0eUluTWFuaWZlc3QgJiYgbm9JbnRlZ3JpdHlDb25mbGljdCAmJiByZXF1ZXN0Lm1vZGUgIT09ICduby1jb3JzJykge1xuICAgICAgICAgICAgdGhpcy5fdXNlRGVmYXVsdENhY2hlYWJpbGl0eVBsdWdpbklmTmVlZGVkKCk7XG4gICAgICAgICAgICBjb25zdCB3YXNDYWNoZWQgPSBhd2FpdCBoYW5kbGVyLmNhY2hlUHV0KHJlcXVlc3QsIHJlc3BvbnNlLmNsb25lKCkpO1xuICAgICAgICAgICAge1xuICAgICAgICAgICAgICBpZiAod2FzQ2FjaGVkKSB7XG4gICAgICAgICAgICAgICAgbG9nZ2VyLmxvZyhgQSByZXNwb25zZSBmb3IgJHtnZXRGcmllbmRseVVSTChyZXF1ZXN0LnVybCl9IGAgKyBgd2FzIHVzZWQgdG8gXCJyZXBhaXJcIiB0aGUgcHJlY2FjaGUuYCk7XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgLy8gVGhpcyBzaG91bGRuJ3Qgbm9ybWFsbHkgaGFwcGVuLCBidXQgdGhlcmUgYXJlIGVkZ2UgY2FzZXM6XG4gICAgICAgICAgLy8gaHR0cHM6Ly9naXRodWIuY29tL0dvb2dsZUNocm9tZS93b3JrYm94L2lzc3Vlcy8xNDQxXG4gICAgICAgICAgdGhyb3cgbmV3IFdvcmtib3hFcnJvcignbWlzc2luZy1wcmVjYWNoZS1lbnRyeScsIHtcbiAgICAgICAgICAgIGNhY2hlTmFtZTogdGhpcy5jYWNoZU5hbWUsXG4gICAgICAgICAgICB1cmw6IHJlcXVlc3QudXJsXG4gICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICAgICAge1xuICAgICAgICAgIGNvbnN0IGNhY2hlS2V5ID0gcGFyYW1zLmNhY2hlS2V5IHx8IChhd2FpdCBoYW5kbGVyLmdldENhY2hlS2V5KHJlcXVlc3QsICdyZWFkJykpO1xuICAgICAgICAgIC8vIFdvcmtib3ggaXMgZ29pbmcgdG8gaGFuZGxlIHRoZSByb3V0ZS5cbiAgICAgICAgICAvLyBwcmludCB0aGUgcm91dGluZyBkZXRhaWxzIHRvIHRoZSBjb25zb2xlLlxuICAgICAgICAgIGxvZ2dlci5ncm91cENvbGxhcHNlZChgUHJlY2FjaGluZyBpcyByZXNwb25kaW5nIHRvOiBgICsgZ2V0RnJpZW5kbHlVUkwocmVxdWVzdC51cmwpKTtcbiAgICAgICAgICBsb2dnZXIubG9nKGBTZXJ2aW5nIHRoZSBwcmVjYWNoZWQgdXJsOiAke2dldEZyaWVuZGx5VVJMKGNhY2hlS2V5IGluc3RhbmNlb2YgUmVxdWVzdCA/IGNhY2hlS2V5LnVybCA6IGNhY2hlS2V5KX1gKTtcbiAgICAgICAgICBsb2dnZXIuZ3JvdXBDb2xsYXBzZWQoYFZpZXcgcmVxdWVzdCBkZXRhaWxzIGhlcmUuYCk7XG4gICAgICAgICAgbG9nZ2VyLmxvZyhyZXF1ZXN0KTtcbiAgICAgICAgICBsb2dnZXIuZ3JvdXBFbmQoKTtcbiAgICAgICAgICBsb2dnZXIuZ3JvdXBDb2xsYXBzZWQoYFZpZXcgcmVzcG9uc2UgZGV0YWlscyBoZXJlLmApO1xuICAgICAgICAgIGxvZ2dlci5sb2cocmVzcG9uc2UpO1xuICAgICAgICAgIGxvZ2dlci5ncm91cEVuZCgpO1xuICAgICAgICAgIGxvZ2dlci5ncm91cEVuZCgpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiByZXNwb25zZTtcbiAgICAgIH1cbiAgICAgIGFzeW5jIF9oYW5kbGVJbnN0YWxsKHJlcXVlc3QsIGhhbmRsZXIpIHtcbiAgICAgICAgdGhpcy5fdXNlRGVmYXVsdENhY2hlYWJpbGl0eVBsdWdpbklmTmVlZGVkKCk7XG4gICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgaGFuZGxlci5mZXRjaChyZXF1ZXN0KTtcbiAgICAgICAgLy8gTWFrZSBzdXJlIHdlIGRlZmVyIGNhY2hlUHV0KCkgdW50aWwgYWZ0ZXIgd2Uga25vdyB0aGUgcmVzcG9uc2VcbiAgICAgICAgLy8gc2hvdWxkIGJlIGNhY2hlZDsgc2VlIGh0dHBzOi8vZ2l0aHViLmNvbS9Hb29nbGVDaHJvbWUvd29ya2JveC9pc3N1ZXMvMjczN1xuICAgICAgICBjb25zdCB3YXNDYWNoZWQgPSBhd2FpdCBoYW5kbGVyLmNhY2hlUHV0KHJlcXVlc3QsIHJlc3BvbnNlLmNsb25lKCkpO1xuICAgICAgICBpZiAoIXdhc0NhY2hlZCkge1xuICAgICAgICAgIC8vIFRocm93aW5nIGhlcmUgd2lsbCBsZWFkIHRvIHRoZSBgaW5zdGFsbGAgaGFuZGxlciBmYWlsaW5nLCB3aGljaFxuICAgICAgICAgIC8vIHdlIHdhbnQgdG8gZG8gaWYgKmFueSogb2YgdGhlIHJlc3BvbnNlcyBhcmVuJ3Qgc2FmZSB0byBjYWNoZS5cbiAgICAgICAgICB0aHJvdyBuZXcgV29ya2JveEVycm9yKCdiYWQtcHJlY2FjaGluZy1yZXNwb25zZScsIHtcbiAgICAgICAgICAgIHVybDogcmVxdWVzdC51cmwsXG4gICAgICAgICAgICBzdGF0dXM6IHJlc3BvbnNlLnN0YXR1c1xuICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiByZXNwb25zZTtcbiAgICAgIH1cbiAgICAgIC8qKlxuICAgICAgICogVGhpcyBtZXRob2QgaXMgY29tcGxleCwgYXMgdGhlcmUgYSBudW1iZXIgb2YgdGhpbmdzIHRvIGFjY291bnQgZm9yOlxuICAgICAgICpcbiAgICAgICAqIFRoZSBgcGx1Z2luc2AgYXJyYXkgY2FuIGJlIHNldCBhdCBjb25zdHJ1Y3Rpb24sIGFuZC9vciBpdCBtaWdodCBiZSBhZGRlZCB0b1xuICAgICAgICogdG8gYXQgYW55IHRpbWUgYmVmb3JlIHRoZSBzdHJhdGVneSBpcyB1c2VkLlxuICAgICAgICpcbiAgICAgICAqIEF0IHRoZSB0aW1lIHRoZSBzdHJhdGVneSBpcyB1c2VkIChpLmUuIGR1cmluZyBhbiBgaW5zdGFsbGAgZXZlbnQpLCB0aGVyZVxuICAgICAgICogbmVlZHMgdG8gYmUgYXQgbGVhc3Qgb25lIHBsdWdpbiB0aGF0IGltcGxlbWVudHMgYGNhY2hlV2lsbFVwZGF0ZWAgaW4gdGhlXG4gICAgICAgKiBhcnJheSwgb3RoZXIgdGhhbiBgY29weVJlZGlyZWN0ZWRDYWNoZWFibGVSZXNwb25zZXNQbHVnaW5gLlxuICAgICAgICpcbiAgICAgICAqIC0gSWYgdGhpcyBtZXRob2QgaXMgY2FsbGVkIGFuZCB0aGVyZSBhcmUgbm8gc3VpdGFibGUgYGNhY2hlV2lsbFVwZGF0ZWBcbiAgICAgICAqIHBsdWdpbnMsIHdlIG5lZWQgdG8gYWRkIGBkZWZhdWx0UHJlY2FjaGVDYWNoZWFiaWxpdHlQbHVnaW5gLlxuICAgICAgICpcbiAgICAgICAqIC0gSWYgdGhpcyBtZXRob2QgaXMgY2FsbGVkIGFuZCB0aGVyZSBpcyBleGFjdGx5IG9uZSBgY2FjaGVXaWxsVXBkYXRlYCwgdGhlblxuICAgICAgICogd2UgZG9uJ3QgaGF2ZSB0byBkbyBhbnl0aGluZyAodGhpcyBtaWdodCBiZSBhIHByZXZpb3VzbHkgYWRkZWRcbiAgICAgICAqIGBkZWZhdWx0UHJlY2FjaGVDYWNoZWFiaWxpdHlQbHVnaW5gLCBvciBpdCBtaWdodCBiZSBhIGN1c3RvbSBwbHVnaW4pLlxuICAgICAgICpcbiAgICAgICAqIC0gSWYgdGhpcyBtZXRob2QgaXMgY2FsbGVkIGFuZCB0aGVyZSBpcyBtb3JlIHRoYW4gb25lIGBjYWNoZVdpbGxVcGRhdGVgLFxuICAgICAgICogdGhlbiB3ZSBuZWVkIHRvIGNoZWNrIGlmIG9uZSBpcyBgZGVmYXVsdFByZWNhY2hlQ2FjaGVhYmlsaXR5UGx1Z2luYC4gSWYgc28sXG4gICAgICAgKiB3ZSBuZWVkIHRvIHJlbW92ZSBpdC4gKFRoaXMgc2l0dWF0aW9uIGlzIHVubGlrZWx5LCBidXQgaXQgY291bGQgaGFwcGVuIGlmXG4gICAgICAgKiB0aGUgc3RyYXRlZ3kgaXMgdXNlZCBtdWx0aXBsZSB0aW1lcywgdGhlIGZpcnN0IHdpdGhvdXQgYSBgY2FjaGVXaWxsVXBkYXRlYCxcbiAgICAgICAqIGFuZCB0aGVuIGxhdGVyIG9uIGFmdGVyIG1hbnVhbGx5IGFkZGluZyBhIGN1c3RvbSBgY2FjaGVXaWxsVXBkYXRlYC4pXG4gICAgICAgKlxuICAgICAgICogU2VlIGh0dHBzOi8vZ2l0aHViLmNvbS9Hb29nbGVDaHJvbWUvd29ya2JveC9pc3N1ZXMvMjczNyBmb3IgbW9yZSBjb250ZXh0LlxuICAgICAgICpcbiAgICAgICAqIEBwcml2YXRlXG4gICAgICAgKi9cbiAgICAgIF91c2VEZWZhdWx0Q2FjaGVhYmlsaXR5UGx1Z2luSWZOZWVkZWQoKSB7XG4gICAgICAgIGxldCBkZWZhdWx0UGx1Z2luSW5kZXggPSBudWxsO1xuICAgICAgICBsZXQgY2FjaGVXaWxsVXBkYXRlUGx1Z2luQ291bnQgPSAwO1xuICAgICAgICBmb3IgKGNvbnN0IFtpbmRleCwgcGx1Z2luXSBvZiB0aGlzLnBsdWdpbnMuZW50cmllcygpKSB7XG4gICAgICAgICAgLy8gSWdub3JlIHRoZSBjb3B5IHJlZGlyZWN0ZWQgcGx1Z2luIHdoZW4gZGV0ZXJtaW5pbmcgd2hhdCB0byBkby5cbiAgICAgICAgICBpZiAocGx1Z2luID09PSBQcmVjYWNoZVN0cmF0ZWd5LmNvcHlSZWRpcmVjdGVkQ2FjaGVhYmxlUmVzcG9uc2VzUGx1Z2luKSB7XG4gICAgICAgICAgICBjb250aW51ZTtcbiAgICAgICAgICB9XG4gICAgICAgICAgLy8gU2F2ZSB0aGUgZGVmYXVsdCBwbHVnaW4ncyBpbmRleCwgaW4gY2FzZSBpdCBuZWVkcyB0byBiZSByZW1vdmVkLlxuICAgICAgICAgIGlmIChwbHVnaW4gPT09IFByZWNhY2hlU3RyYXRlZ3kuZGVmYXVsdFByZWNhY2hlQ2FjaGVhYmlsaXR5UGx1Z2luKSB7XG4gICAgICAgICAgICBkZWZhdWx0UGx1Z2luSW5kZXggPSBpbmRleDtcbiAgICAgICAgICB9XG4gICAgICAgICAgaWYgKHBsdWdpbi5jYWNoZVdpbGxVcGRhdGUpIHtcbiAgICAgICAgICAgIGNhY2hlV2lsbFVwZGF0ZVBsdWdpbkNvdW50Kys7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGlmIChjYWNoZVdpbGxVcGRhdGVQbHVnaW5Db3VudCA9PT0gMCkge1xuICAgICAgICAgIHRoaXMucGx1Z2lucy5wdXNoKFByZWNhY2hlU3RyYXRlZ3kuZGVmYXVsdFByZWNhY2hlQ2FjaGVhYmlsaXR5UGx1Z2luKTtcbiAgICAgICAgfSBlbHNlIGlmIChjYWNoZVdpbGxVcGRhdGVQbHVnaW5Db3VudCA+IDEgJiYgZGVmYXVsdFBsdWdpbkluZGV4ICE9PSBudWxsKSB7XG4gICAgICAgICAgLy8gT25seSByZW1vdmUgdGhlIGRlZmF1bHQgcGx1Z2luOyBtdWx0aXBsZSBjdXN0b20gcGx1Z2lucyBhcmUgYWxsb3dlZC5cbiAgICAgICAgICB0aGlzLnBsdWdpbnMuc3BsaWNlKGRlZmF1bHRQbHVnaW5JbmRleCwgMSk7XG4gICAgICAgIH1cbiAgICAgICAgLy8gTm90aGluZyBuZWVkcyB0byBiZSBkb25lIGlmIGNhY2hlV2lsbFVwZGF0ZVBsdWdpbkNvdW50IGlzIDFcbiAgICAgIH1cbiAgICB9XG4gICAgUHJlY2FjaGVTdHJhdGVneS5kZWZhdWx0UHJlY2FjaGVDYWNoZWFiaWxpdHlQbHVnaW4gPSB7XG4gICAgICBhc3luYyBjYWNoZVdpbGxVcGRhdGUoe1xuICAgICAgICByZXNwb25zZVxuICAgICAgfSkge1xuICAgICAgICBpZiAoIXJlc3BvbnNlIHx8IHJlc3BvbnNlLnN0YXR1cyA+PSA0MDApIHtcbiAgICAgICAgICByZXR1cm4gbnVsbDtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gcmVzcG9uc2U7XG4gICAgICB9XG4gICAgfTtcbiAgICBQcmVjYWNoZVN0cmF0ZWd5LmNvcHlSZWRpcmVjdGVkQ2FjaGVhYmxlUmVzcG9uc2VzUGx1Z2luID0ge1xuICAgICAgYXN5bmMgY2FjaGVXaWxsVXBkYXRlKHtcbiAgICAgICAgcmVzcG9uc2VcbiAgICAgIH0pIHtcbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlLnJlZGlyZWN0ZWQgPyBhd2FpdCBjb3B5UmVzcG9uc2UocmVzcG9uc2UpIDogcmVzcG9uc2U7XG4gICAgICB9XG4gICAgfTtcblxuICAgIC8qXG4gICAgICBDb3B5cmlnaHQgMjAxOSBHb29nbGUgTExDXG5cbiAgICAgIFVzZSBvZiB0aGlzIHNvdXJjZSBjb2RlIGlzIGdvdmVybmVkIGJ5IGFuIE1JVC1zdHlsZVxuICAgICAgbGljZW5zZSB0aGF0IGNhbiBiZSBmb3VuZCBpbiB0aGUgTElDRU5TRSBmaWxlIG9yIGF0XG4gICAgICBodHRwczovL29wZW5zb3VyY2Uub3JnL2xpY2Vuc2VzL01JVC5cbiAgICAqL1xuICAgIC8qKlxuICAgICAqIFBlcmZvcm1zIGVmZmljaWVudCBwcmVjYWNoaW5nIG9mIGFzc2V0cy5cbiAgICAgKlxuICAgICAqIEBtZW1iZXJvZiB3b3JrYm94LXByZWNhY2hpbmdcbiAgICAgKi9cbiAgICBjbGFzcyBQcmVjYWNoZUNvbnRyb2xsZXIge1xuICAgICAgLyoqXG4gICAgICAgKiBDcmVhdGUgYSBuZXcgUHJlY2FjaGVDb250cm9sbGVyLlxuICAgICAgICpcbiAgICAgICAqIEBwYXJhbSB7T2JqZWN0fSBbb3B0aW9uc11cbiAgICAgICAqIEBwYXJhbSB7c3RyaW5nfSBbb3B0aW9ucy5jYWNoZU5hbWVdIFRoZSBjYWNoZSB0byB1c2UgZm9yIHByZWNhY2hpbmcuXG4gICAgICAgKiBAcGFyYW0ge3N0cmluZ30gW29wdGlvbnMucGx1Z2luc10gUGx1Z2lucyB0byB1c2Ugd2hlbiBwcmVjYWNoaW5nIGFzIHdlbGxcbiAgICAgICAqIGFzIHJlc3BvbmRpbmcgdG8gZmV0Y2ggZXZlbnRzIGZvciBwcmVjYWNoZWQgYXNzZXRzLlxuICAgICAgICogQHBhcmFtIHtib29sZWFufSBbb3B0aW9ucy5mYWxsYmFja1RvTmV0d29yaz10cnVlXSBXaGV0aGVyIHRvIGF0dGVtcHQgdG9cbiAgICAgICAqIGdldCB0aGUgcmVzcG9uc2UgZnJvbSB0aGUgbmV0d29yayBpZiB0aGVyZSdzIGEgcHJlY2FjaGUgbWlzcy5cbiAgICAgICAqL1xuICAgICAgY29uc3RydWN0b3Ioe1xuICAgICAgICBjYWNoZU5hbWUsXG4gICAgICAgIHBsdWdpbnMgPSBbXSxcbiAgICAgICAgZmFsbGJhY2tUb05ldHdvcmsgPSB0cnVlXG4gICAgICB9ID0ge30pIHtcbiAgICAgICAgdGhpcy5fdXJsc1RvQ2FjaGVLZXlzID0gbmV3IE1hcCgpO1xuICAgICAgICB0aGlzLl91cmxzVG9DYWNoZU1vZGVzID0gbmV3IE1hcCgpO1xuICAgICAgICB0aGlzLl9jYWNoZUtleXNUb0ludGVncml0aWVzID0gbmV3IE1hcCgpO1xuICAgICAgICB0aGlzLl9zdHJhdGVneSA9IG5ldyBQcmVjYWNoZVN0cmF0ZWd5KHtcbiAgICAgICAgICBjYWNoZU5hbWU6IGNhY2hlTmFtZXMuZ2V0UHJlY2FjaGVOYW1lKGNhY2hlTmFtZSksXG4gICAgICAgICAgcGx1Z2luczogWy4uLnBsdWdpbnMsIG5ldyBQcmVjYWNoZUNhY2hlS2V5UGx1Z2luKHtcbiAgICAgICAgICAgIHByZWNhY2hlQ29udHJvbGxlcjogdGhpc1xuICAgICAgICAgIH0pXSxcbiAgICAgICAgICBmYWxsYmFja1RvTmV0d29ya1xuICAgICAgICB9KTtcbiAgICAgICAgLy8gQmluZCB0aGUgaW5zdGFsbCBhbmQgYWN0aXZhdGUgbWV0aG9kcyB0byB0aGUgaW5zdGFuY2UuXG4gICAgICAgIHRoaXMuaW5zdGFsbCA9IHRoaXMuaW5zdGFsbC5iaW5kKHRoaXMpO1xuICAgICAgICB0aGlzLmFjdGl2YXRlID0gdGhpcy5hY3RpdmF0ZS5iaW5kKHRoaXMpO1xuICAgICAgfVxuICAgICAgLyoqXG4gICAgICAgKiBAdHlwZSB7d29ya2JveC1wcmVjYWNoaW5nLlByZWNhY2hlU3RyYXRlZ3l9IFRoZSBzdHJhdGVneSBjcmVhdGVkIGJ5IHRoaXMgY29udHJvbGxlciBhbmRcbiAgICAgICAqIHVzZWQgdG8gY2FjaGUgYXNzZXRzIGFuZCByZXNwb25kIHRvIGZldGNoIGV2ZW50cy5cbiAgICAgICAqL1xuICAgICAgZ2V0IHN0cmF0ZWd5KCkge1xuICAgICAgICByZXR1cm4gdGhpcy5fc3RyYXRlZ3k7XG4gICAgICB9XG4gICAgICAvKipcbiAgICAgICAqIEFkZHMgaXRlbXMgdG8gdGhlIHByZWNhY2hlIGxpc3QsIHJlbW92aW5nIGFueSBkdXBsaWNhdGVzIGFuZFxuICAgICAgICogc3RvcmVzIHRoZSBmaWxlcyBpbiB0aGVcbiAgICAgICAqIHtAbGluayB3b3JrYm94LWNvcmUuY2FjaGVOYW1lc3xcInByZWNhY2hlIGNhY2hlXCJ9IHdoZW4gdGhlIHNlcnZpY2VcbiAgICAgICAqIHdvcmtlciBpbnN0YWxscy5cbiAgICAgICAqXG4gICAgICAgKiBUaGlzIG1ldGhvZCBjYW4gYmUgY2FsbGVkIG11bHRpcGxlIHRpbWVzLlxuICAgICAgICpcbiAgICAgICAqIEBwYXJhbSB7QXJyYXk8T2JqZWN0fHN0cmluZz59IFtlbnRyaWVzPVtdXSBBcnJheSBvZiBlbnRyaWVzIHRvIHByZWNhY2hlLlxuICAgICAgICovXG4gICAgICBwcmVjYWNoZShlbnRyaWVzKSB7XG4gICAgICAgIHRoaXMuYWRkVG9DYWNoZUxpc3QoZW50cmllcyk7XG4gICAgICAgIGlmICghdGhpcy5faW5zdGFsbEFuZEFjdGl2ZUxpc3RlbmVyc0FkZGVkKSB7XG4gICAgICAgICAgc2VsZi5hZGRFdmVudExpc3RlbmVyKCdpbnN0YWxsJywgdGhpcy5pbnN0YWxsKTtcbiAgICAgICAgICBzZWxmLmFkZEV2ZW50TGlzdGVuZXIoJ2FjdGl2YXRlJywgdGhpcy5hY3RpdmF0ZSk7XG4gICAgICAgICAgdGhpcy5faW5zdGFsbEFuZEFjdGl2ZUxpc3RlbmVyc0FkZGVkID0gdHJ1ZTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgLyoqXG4gICAgICAgKiBUaGlzIG1ldGhvZCB3aWxsIGFkZCBpdGVtcyB0byB0aGUgcHJlY2FjaGUgbGlzdCwgcmVtb3ZpbmcgZHVwbGljYXRlc1xuICAgICAgICogYW5kIGVuc3VyaW5nIHRoZSBpbmZvcm1hdGlvbiBpcyB2YWxpZC5cbiAgICAgICAqXG4gICAgICAgKiBAcGFyYW0ge0FycmF5PHdvcmtib3gtcHJlY2FjaGluZy5QcmVjYWNoZUNvbnRyb2xsZXIuUHJlY2FjaGVFbnRyeXxzdHJpbmc+fSBlbnRyaWVzXG4gICAgICAgKiAgICAgQXJyYXkgb2YgZW50cmllcyB0byBwcmVjYWNoZS5cbiAgICAgICAqL1xuICAgICAgYWRkVG9DYWNoZUxpc3QoZW50cmllcykge1xuICAgICAgICB7XG4gICAgICAgICAgZmluYWxBc3NlcnRFeHBvcnRzLmlzQXJyYXkoZW50cmllcywge1xuICAgICAgICAgICAgbW9kdWxlTmFtZTogJ3dvcmtib3gtcHJlY2FjaGluZycsXG4gICAgICAgICAgICBjbGFzc05hbWU6ICdQcmVjYWNoZUNvbnRyb2xsZXInLFxuICAgICAgICAgICAgZnVuY05hbWU6ICdhZGRUb0NhY2hlTGlzdCcsXG4gICAgICAgICAgICBwYXJhbU5hbWU6ICdlbnRyaWVzJ1xuICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IHVybHNUb1dhcm5BYm91dCA9IFtdO1xuICAgICAgICBmb3IgKGNvbnN0IGVudHJ5IG9mIGVudHJpZXMpIHtcbiAgICAgICAgICAvLyBTZWUgaHR0cHM6Ly9naXRodWIuY29tL0dvb2dsZUNocm9tZS93b3JrYm94L2lzc3Vlcy8yMjU5XG4gICAgICAgICAgaWYgKHR5cGVvZiBlbnRyeSA9PT0gJ3N0cmluZycpIHtcbiAgICAgICAgICAgIHVybHNUb1dhcm5BYm91dC5wdXNoKGVudHJ5KTtcbiAgICAgICAgICB9IGVsc2UgaWYgKGVudHJ5ICYmIGVudHJ5LnJldmlzaW9uID09PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICAgIHVybHNUb1dhcm5BYm91dC5wdXNoKGVudHJ5LnVybCk7XG4gICAgICAgICAgfVxuICAgICAgICAgIGNvbnN0IHtcbiAgICAgICAgICAgIGNhY2hlS2V5LFxuICAgICAgICAgICAgdXJsXG4gICAgICAgICAgfSA9IGNyZWF0ZUNhY2hlS2V5KGVudHJ5KTtcbiAgICAgICAgICBjb25zdCBjYWNoZU1vZGUgPSB0eXBlb2YgZW50cnkgIT09ICdzdHJpbmcnICYmIGVudHJ5LnJldmlzaW9uID8gJ3JlbG9hZCcgOiAnZGVmYXVsdCc7XG4gICAgICAgICAgaWYgKHRoaXMuX3VybHNUb0NhY2hlS2V5cy5oYXModXJsKSAmJiB0aGlzLl91cmxzVG9DYWNoZUtleXMuZ2V0KHVybCkgIT09IGNhY2hlS2V5KSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgV29ya2JveEVycm9yKCdhZGQtdG8tY2FjaGUtbGlzdC1jb25mbGljdGluZy1lbnRyaWVzJywge1xuICAgICAgICAgICAgICBmaXJzdEVudHJ5OiB0aGlzLl91cmxzVG9DYWNoZUtleXMuZ2V0KHVybCksXG4gICAgICAgICAgICAgIHNlY29uZEVudHJ5OiBjYWNoZUtleVxuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgfVxuICAgICAgICAgIGlmICh0eXBlb2YgZW50cnkgIT09ICdzdHJpbmcnICYmIGVudHJ5LmludGVncml0eSkge1xuICAgICAgICAgICAgaWYgKHRoaXMuX2NhY2hlS2V5c1RvSW50ZWdyaXRpZXMuaGFzKGNhY2hlS2V5KSAmJiB0aGlzLl9jYWNoZUtleXNUb0ludGVncml0aWVzLmdldChjYWNoZUtleSkgIT09IGVudHJ5LmludGVncml0eSkge1xuICAgICAgICAgICAgICB0aHJvdyBuZXcgV29ya2JveEVycm9yKCdhZGQtdG8tY2FjaGUtbGlzdC1jb25mbGljdGluZy1pbnRlZ3JpdGllcycsIHtcbiAgICAgICAgICAgICAgICB1cmxcbiAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICB0aGlzLl9jYWNoZUtleXNUb0ludGVncml0aWVzLnNldChjYWNoZUtleSwgZW50cnkuaW50ZWdyaXR5KTtcbiAgICAgICAgICB9XG4gICAgICAgICAgdGhpcy5fdXJsc1RvQ2FjaGVLZXlzLnNldCh1cmwsIGNhY2hlS2V5KTtcbiAgICAgICAgICB0aGlzLl91cmxzVG9DYWNoZU1vZGVzLnNldCh1cmwsIGNhY2hlTW9kZSk7XG4gICAgICAgICAgaWYgKHVybHNUb1dhcm5BYm91dC5sZW5ndGggPiAwKSB7XG4gICAgICAgICAgICBjb25zdCB3YXJuaW5nTWVzc2FnZSA9IGBXb3JrYm94IGlzIHByZWNhY2hpbmcgVVJMcyB3aXRob3V0IHJldmlzaW9uIGAgKyBgaW5mbzogJHt1cmxzVG9XYXJuQWJvdXQuam9pbignLCAnKX1cXG5UaGlzIGlzIGdlbmVyYWxseSBOT1Qgc2FmZS4gYCArIGBMZWFybiBtb3JlIGF0IGh0dHBzOi8vYml0Lmx5L3diLXByZWNhY2hlYDtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgbG9nZ2VyLndhcm4od2FybmluZ01lc3NhZ2UpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgLyoqXG4gICAgICAgKiBQcmVjYWNoZXMgbmV3IGFuZCB1cGRhdGVkIGFzc2V0cy4gQ2FsbCB0aGlzIG1ldGhvZCBmcm9tIHRoZSBzZXJ2aWNlIHdvcmtlclxuICAgICAgICogaW5zdGFsbCBldmVudC5cbiAgICAgICAqXG4gICAgICAgKiBOb3RlOiB0aGlzIG1ldGhvZCBjYWxscyBgZXZlbnQud2FpdFVudGlsKClgIGZvciB5b3UsIHNvIHlvdSBkbyBub3QgbmVlZFxuICAgICAgICogdG8gY2FsbCBpdCB5b3Vyc2VsZiBpbiB5b3VyIGV2ZW50IGhhbmRsZXJzLlxuICAgICAgICpcbiAgICAgICAqIEBwYXJhbSB7RXh0ZW5kYWJsZUV2ZW50fSBldmVudFxuICAgICAgICogQHJldHVybiB7UHJvbWlzZTx3b3JrYm94LXByZWNhY2hpbmcuSW5zdGFsbFJlc3VsdD59XG4gICAgICAgKi9cbiAgICAgIGluc3RhbGwoZXZlbnQpIHtcbiAgICAgICAgLy8gd2FpdFVudGlsIHJldHVybnMgUHJvbWlzZTxhbnk+XG4gICAgICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBAdHlwZXNjcmlwdC1lc2xpbnQvbm8tdW5zYWZlLXJldHVyblxuICAgICAgICByZXR1cm4gd2FpdFVudGlsKGV2ZW50LCBhc3luYyAoKSA9PiB7XG4gICAgICAgICAgY29uc3QgaW5zdGFsbFJlcG9ydFBsdWdpbiA9IG5ldyBQcmVjYWNoZUluc3RhbGxSZXBvcnRQbHVnaW4oKTtcbiAgICAgICAgICB0aGlzLnN0cmF0ZWd5LnBsdWdpbnMucHVzaChpbnN0YWxsUmVwb3J0UGx1Z2luKTtcbiAgICAgICAgICAvLyBDYWNoZSBlbnRyaWVzIG9uZSBhdCBhIHRpbWUuXG4gICAgICAgICAgLy8gU2VlIGh0dHBzOi8vZ2l0aHViLmNvbS9Hb29nbGVDaHJvbWUvd29ya2JveC9pc3N1ZXMvMjUyOFxuICAgICAgICAgIGZvciAoY29uc3QgW3VybCwgY2FjaGVLZXldIG9mIHRoaXMuX3VybHNUb0NhY2hlS2V5cykge1xuICAgICAgICAgICAgY29uc3QgaW50ZWdyaXR5ID0gdGhpcy5fY2FjaGVLZXlzVG9JbnRlZ3JpdGllcy5nZXQoY2FjaGVLZXkpO1xuICAgICAgICAgICAgY29uc3QgY2FjaGVNb2RlID0gdGhpcy5fdXJsc1RvQ2FjaGVNb2Rlcy5nZXQodXJsKTtcbiAgICAgICAgICAgIGNvbnN0IHJlcXVlc3QgPSBuZXcgUmVxdWVzdCh1cmwsIHtcbiAgICAgICAgICAgICAgaW50ZWdyaXR5LFxuICAgICAgICAgICAgICBjYWNoZTogY2FjaGVNb2RlLFxuICAgICAgICAgICAgICBjcmVkZW50aWFsczogJ3NhbWUtb3JpZ2luJ1xuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICBhd2FpdCBQcm9taXNlLmFsbCh0aGlzLnN0cmF0ZWd5LmhhbmRsZUFsbCh7XG4gICAgICAgICAgICAgIHBhcmFtczoge1xuICAgICAgICAgICAgICAgIGNhY2hlS2V5XG4gICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgIHJlcXVlc3QsXG4gICAgICAgICAgICAgIGV2ZW50XG4gICAgICAgICAgICB9KSk7XG4gICAgICAgICAgfVxuICAgICAgICAgIGNvbnN0IHtcbiAgICAgICAgICAgIHVwZGF0ZWRVUkxzLFxuICAgICAgICAgICAgbm90VXBkYXRlZFVSTHNcbiAgICAgICAgICB9ID0gaW5zdGFsbFJlcG9ydFBsdWdpbjtcbiAgICAgICAgICB7XG4gICAgICAgICAgICBwcmludEluc3RhbGxEZXRhaWxzKHVwZGF0ZWRVUkxzLCBub3RVcGRhdGVkVVJMcyk7XG4gICAgICAgICAgfVxuICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICB1cGRhdGVkVVJMcyxcbiAgICAgICAgICAgIG5vdFVwZGF0ZWRVUkxzXG4gICAgICAgICAgfTtcbiAgICAgICAgfSk7XG4gICAgICB9XG4gICAgICAvKipcbiAgICAgICAqIERlbGV0ZXMgYXNzZXRzIHRoYXQgYXJlIG5vIGxvbmdlciBwcmVzZW50IGluIHRoZSBjdXJyZW50IHByZWNhY2hlIG1hbmlmZXN0LlxuICAgICAgICogQ2FsbCB0aGlzIG1ldGhvZCBmcm9tIHRoZSBzZXJ2aWNlIHdvcmtlciBhY3RpdmF0ZSBldmVudC5cbiAgICAgICAqXG4gICAgICAgKiBOb3RlOiB0aGlzIG1ldGhvZCBjYWxscyBgZXZlbnQud2FpdFVudGlsKClgIGZvciB5b3UsIHNvIHlvdSBkbyBub3QgbmVlZFxuICAgICAgICogdG8gY2FsbCBpdCB5b3Vyc2VsZiBpbiB5b3VyIGV2ZW50IGhhbmRsZXJzLlxuICAgICAgICpcbiAgICAgICAqIEBwYXJhbSB7RXh0ZW5kYWJsZUV2ZW50fSBldmVudFxuICAgICAgICogQHJldHVybiB7UHJvbWlzZTx3b3JrYm94LXByZWNhY2hpbmcuQ2xlYW51cFJlc3VsdD59XG4gICAgICAgKi9cbiAgICAgIGFjdGl2YXRlKGV2ZW50KSB7XG4gICAgICAgIC8vIHdhaXRVbnRpbCByZXR1cm5zIFByb21pc2U8YW55PlxuICAgICAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgQHR5cGVzY3JpcHQtZXNsaW50L25vLXVuc2FmZS1yZXR1cm5cbiAgICAgICAgcmV0dXJuIHdhaXRVbnRpbChldmVudCwgYXN5bmMgKCkgPT4ge1xuICAgICAgICAgIGNvbnN0IGNhY2hlID0gYXdhaXQgc2VsZi5jYWNoZXMub3Blbih0aGlzLnN0cmF0ZWd5LmNhY2hlTmFtZSk7XG4gICAgICAgICAgY29uc3QgY3VycmVudGx5Q2FjaGVkUmVxdWVzdHMgPSBhd2FpdCBjYWNoZS5rZXlzKCk7XG4gICAgICAgICAgY29uc3QgZXhwZWN0ZWRDYWNoZUtleXMgPSBuZXcgU2V0KHRoaXMuX3VybHNUb0NhY2hlS2V5cy52YWx1ZXMoKSk7XG4gICAgICAgICAgY29uc3QgZGVsZXRlZFVSTHMgPSBbXTtcbiAgICAgICAgICBmb3IgKGNvbnN0IHJlcXVlc3Qgb2YgY3VycmVudGx5Q2FjaGVkUmVxdWVzdHMpIHtcbiAgICAgICAgICAgIGlmICghZXhwZWN0ZWRDYWNoZUtleXMuaGFzKHJlcXVlc3QudXJsKSkge1xuICAgICAgICAgICAgICBhd2FpdCBjYWNoZS5kZWxldGUocmVxdWVzdCk7XG4gICAgICAgICAgICAgIGRlbGV0ZWRVUkxzLnB1c2gocmVxdWVzdC51cmwpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH1cbiAgICAgICAgICB7XG4gICAgICAgICAgICBwcmludENsZWFudXBEZXRhaWxzKGRlbGV0ZWRVUkxzKTtcbiAgICAgICAgICB9XG4gICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIGRlbGV0ZWRVUkxzXG4gICAgICAgICAgfTtcbiAgICAgICAgfSk7XG4gICAgICB9XG4gICAgICAvKipcbiAgICAgICAqIFJldHVybnMgYSBtYXBwaW5nIG9mIGEgcHJlY2FjaGVkIFVSTCB0byB0aGUgY29ycmVzcG9uZGluZyBjYWNoZSBrZXksIHRha2luZ1xuICAgICAgICogaW50byBhY2NvdW50IHRoZSByZXZpc2lvbiBpbmZvcm1hdGlvbiBmb3IgdGhlIFVSTC5cbiAgICAgICAqXG4gICAgICAgKiBAcmV0dXJuIHtNYXA8c3RyaW5nLCBzdHJpbmc+fSBBIFVSTCB0byBjYWNoZSBrZXkgbWFwcGluZy5cbiAgICAgICAqL1xuICAgICAgZ2V0VVJMc1RvQ2FjaGVLZXlzKCkge1xuICAgICAgICByZXR1cm4gdGhpcy5fdXJsc1RvQ2FjaGVLZXlzO1xuICAgICAgfVxuICAgICAgLyoqXG4gICAgICAgKiBSZXR1cm5zIGEgbGlzdCBvZiBhbGwgdGhlIFVSTHMgdGhhdCBoYXZlIGJlZW4gcHJlY2FjaGVkIGJ5IHRoZSBjdXJyZW50XG4gICAgICAgKiBzZXJ2aWNlIHdvcmtlci5cbiAgICAgICAqXG4gICAgICAgKiBAcmV0dXJuIHtBcnJheTxzdHJpbmc+fSBUaGUgcHJlY2FjaGVkIFVSTHMuXG4gICAgICAgKi9cbiAgICAgIGdldENhY2hlZFVSTHMoKSB7XG4gICAgICAgIHJldHVybiBbLi4udGhpcy5fdXJsc1RvQ2FjaGVLZXlzLmtleXMoKV07XG4gICAgICB9XG4gICAgICAvKipcbiAgICAgICAqIFJldHVybnMgdGhlIGNhY2hlIGtleSB1c2VkIGZvciBzdG9yaW5nIGEgZ2l2ZW4gVVJMLiBJZiB0aGF0IFVSTCBpc1xuICAgICAgICogdW52ZXJzaW9uZWQsIGxpa2UgYC9pbmRleC5odG1sJywgdGhlbiB0aGUgY2FjaGUga2V5IHdpbGwgYmUgdGhlIG9yaWdpbmFsXG4gICAgICAgKiBVUkwgd2l0aCBhIHNlYXJjaCBwYXJhbWV0ZXIgYXBwZW5kZWQgdG8gaXQuXG4gICAgICAgKlxuICAgICAgICogQHBhcmFtIHtzdHJpbmd9IHVybCBBIFVSTCB3aG9zZSBjYWNoZSBrZXkgeW91IHdhbnQgdG8gbG9vayB1cC5cbiAgICAgICAqIEByZXR1cm4ge3N0cmluZ30gVGhlIHZlcnNpb25lZCBVUkwgdGhhdCBjb3JyZXNwb25kcyB0byBhIGNhY2hlIGtleVxuICAgICAgICogZm9yIHRoZSBvcmlnaW5hbCBVUkwsIG9yIHVuZGVmaW5lZCBpZiB0aGF0IFVSTCBpc24ndCBwcmVjYWNoZWQuXG4gICAgICAgKi9cbiAgICAgIGdldENhY2hlS2V5Rm9yVVJMKHVybCkge1xuICAgICAgICBjb25zdCB1cmxPYmplY3QgPSBuZXcgVVJMKHVybCwgbG9jYXRpb24uaHJlZik7XG4gICAgICAgIHJldHVybiB0aGlzLl91cmxzVG9DYWNoZUtleXMuZ2V0KHVybE9iamVjdC5ocmVmKTtcbiAgICAgIH1cbiAgICAgIC8qKlxuICAgICAgICogQHBhcmFtIHtzdHJpbmd9IHVybCBBIGNhY2hlIGtleSB3aG9zZSBTUkkgeW91IHdhbnQgdG8gbG9vayB1cC5cbiAgICAgICAqIEByZXR1cm4ge3N0cmluZ30gVGhlIHN1YnJlc291cmNlIGludGVncml0eSBhc3NvY2lhdGVkIHdpdGggdGhlIGNhY2hlIGtleSxcbiAgICAgICAqIG9yIHVuZGVmaW5lZCBpZiBpdCdzIG5vdCBzZXQuXG4gICAgICAgKi9cbiAgICAgIGdldEludGVncml0eUZvckNhY2hlS2V5KGNhY2hlS2V5KSB7XG4gICAgICAgIHJldHVybiB0aGlzLl9jYWNoZUtleXNUb0ludGVncml0aWVzLmdldChjYWNoZUtleSk7XG4gICAgICB9XG4gICAgICAvKipcbiAgICAgICAqIFRoaXMgYWN0cyBhcyBhIGRyb3AtaW4gcmVwbGFjZW1lbnQgZm9yXG4gICAgICAgKiBbYGNhY2hlLm1hdGNoKClgXShodHRwczovL2RldmVsb3Blci5tb3ppbGxhLm9yZy9lbi1VUy9kb2NzL1dlYi9BUEkvQ2FjaGUvbWF0Y2gpXG4gICAgICAgKiB3aXRoIHRoZSBmb2xsb3dpbmcgZGlmZmVyZW5jZXM6XG4gICAgICAgKlxuICAgICAgICogLSBJdCBrbm93cyB3aGF0IHRoZSBuYW1lIG9mIHRoZSBwcmVjYWNoZSBpcywgYW5kIG9ubHkgY2hlY2tzIGluIHRoYXQgY2FjaGUuXG4gICAgICAgKiAtIEl0IGFsbG93cyB5b3UgdG8gcGFzcyBpbiBhbiBcIm9yaWdpbmFsXCIgVVJMIHdpdGhvdXQgdmVyc2lvbmluZyBwYXJhbWV0ZXJzLFxuICAgICAgICogYW5kIGl0IHdpbGwgYXV0b21hdGljYWxseSBsb29rIHVwIHRoZSBjb3JyZWN0IGNhY2hlIGtleSBmb3IgdGhlIGN1cnJlbnRseVxuICAgICAgICogYWN0aXZlIHJldmlzaW9uIG9mIHRoYXQgVVJMLlxuICAgICAgICpcbiAgICAgICAqIEUuZy4sIGBtYXRjaFByZWNhY2hlKCdpbmRleC5odG1sJylgIHdpbGwgZmluZCB0aGUgY29ycmVjdCBwcmVjYWNoZWRcbiAgICAgICAqIHJlc3BvbnNlIGZvciB0aGUgY3VycmVudGx5IGFjdGl2ZSBzZXJ2aWNlIHdvcmtlciwgZXZlbiBpZiB0aGUgYWN0dWFsIGNhY2hlXG4gICAgICAgKiBrZXkgaXMgYCcvaW5kZXguaHRtbD9fX1dCX1JFVklTSU9OX189MTIzNGFiY2QnYC5cbiAgICAgICAqXG4gICAgICAgKiBAcGFyYW0ge3N0cmluZ3xSZXF1ZXN0fSByZXF1ZXN0IFRoZSBrZXkgKHdpdGhvdXQgcmV2aXNpb25pbmcgcGFyYW1ldGVycylcbiAgICAgICAqIHRvIGxvb2sgdXAgaW4gdGhlIHByZWNhY2hlLlxuICAgICAgICogQHJldHVybiB7UHJvbWlzZTxSZXNwb25zZXx1bmRlZmluZWQ+fVxuICAgICAgICovXG4gICAgICBhc3luYyBtYXRjaFByZWNhY2hlKHJlcXVlc3QpIHtcbiAgICAgICAgY29uc3QgdXJsID0gcmVxdWVzdCBpbnN0YW5jZW9mIFJlcXVlc3QgPyByZXF1ZXN0LnVybCA6IHJlcXVlc3Q7XG4gICAgICAgIGNvbnN0IGNhY2hlS2V5ID0gdGhpcy5nZXRDYWNoZUtleUZvclVSTCh1cmwpO1xuICAgICAgICBpZiAoY2FjaGVLZXkpIHtcbiAgICAgICAgICBjb25zdCBjYWNoZSA9IGF3YWl0IHNlbGYuY2FjaGVzLm9wZW4odGhpcy5zdHJhdGVneS5jYWNoZU5hbWUpO1xuICAgICAgICAgIHJldHVybiBjYWNoZS5tYXRjaChjYWNoZUtleSk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHVuZGVmaW5lZDtcbiAgICAgIH1cbiAgICAgIC8qKlxuICAgICAgICogUmV0dXJucyBhIGZ1bmN0aW9uIHRoYXQgbG9va3MgdXAgYHVybGAgaW4gdGhlIHByZWNhY2hlICh0YWtpbmcgaW50b1xuICAgICAgICogYWNjb3VudCByZXZpc2lvbiBpbmZvcm1hdGlvbiksIGFuZCByZXR1cm5zIHRoZSBjb3JyZXNwb25kaW5nIGBSZXNwb25zZWAuXG4gICAgICAgKlxuICAgICAgICogQHBhcmFtIHtzdHJpbmd9IHVybCBUaGUgcHJlY2FjaGVkIFVSTCB3aGljaCB3aWxsIGJlIHVzZWQgdG8gbG9va3VwIHRoZVxuICAgICAgICogYFJlc3BvbnNlYC5cbiAgICAgICAqIEByZXR1cm4ge3dvcmtib3gtcm91dGluZ35oYW5kbGVyQ2FsbGJhY2t9XG4gICAgICAgKi9cbiAgICAgIGNyZWF0ZUhhbmRsZXJCb3VuZFRvVVJMKHVybCkge1xuICAgICAgICBjb25zdCBjYWNoZUtleSA9IHRoaXMuZ2V0Q2FjaGVLZXlGb3JVUkwodXJsKTtcbiAgICAgICAgaWYgKCFjYWNoZUtleSkge1xuICAgICAgICAgIHRocm93IG5ldyBXb3JrYm94RXJyb3IoJ25vbi1wcmVjYWNoZWQtdXJsJywge1xuICAgICAgICAgICAgdXJsXG4gICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIG9wdGlvbnMgPT4ge1xuICAgICAgICAgIG9wdGlvbnMucmVxdWVzdCA9IG5ldyBSZXF1ZXN0KHVybCk7XG4gICAgICAgICAgb3B0aW9ucy5wYXJhbXMgPSBPYmplY3QuYXNzaWduKHtcbiAgICAgICAgICAgIGNhY2hlS2V5XG4gICAgICAgICAgfSwgb3B0aW9ucy5wYXJhbXMpO1xuICAgICAgICAgIHJldHVybiB0aGlzLnN0cmF0ZWd5LmhhbmRsZShvcHRpb25zKTtcbiAgICAgICAgfTtcbiAgICAgIH1cbiAgICB9XG5cbiAgICAvKlxuICAgICAgQ29weXJpZ2h0IDIwMTkgR29vZ2xlIExMQ1xuXG4gICAgICBVc2Ugb2YgdGhpcyBzb3VyY2UgY29kZSBpcyBnb3Zlcm5lZCBieSBhbiBNSVQtc3R5bGVcbiAgICAgIGxpY2Vuc2UgdGhhdCBjYW4gYmUgZm91bmQgaW4gdGhlIExJQ0VOU0UgZmlsZSBvciBhdFxuICAgICAgaHR0cHM6Ly9vcGVuc291cmNlLm9yZy9saWNlbnNlcy9NSVQuXG4gICAgKi9cbiAgICBsZXQgcHJlY2FjaGVDb250cm9sbGVyO1xuICAgIC8qKlxuICAgICAqIEByZXR1cm4ge1ByZWNhY2hlQ29udHJvbGxlcn1cbiAgICAgKiBAcHJpdmF0ZVxuICAgICAqL1xuICAgIGNvbnN0IGdldE9yQ3JlYXRlUHJlY2FjaGVDb250cm9sbGVyID0gKCkgPT4ge1xuICAgICAgaWYgKCFwcmVjYWNoZUNvbnRyb2xsZXIpIHtcbiAgICAgICAgcHJlY2FjaGVDb250cm9sbGVyID0gbmV3IFByZWNhY2hlQ29udHJvbGxlcigpO1xuICAgICAgfVxuICAgICAgcmV0dXJuIHByZWNhY2hlQ29udHJvbGxlcjtcbiAgICB9O1xuXG4gICAgLypcbiAgICAgIENvcHlyaWdodCAyMDE4IEdvb2dsZSBMTENcblxuICAgICAgVXNlIG9mIHRoaXMgc291cmNlIGNvZGUgaXMgZ292ZXJuZWQgYnkgYW4gTUlULXN0eWxlXG4gICAgICBsaWNlbnNlIHRoYXQgY2FuIGJlIGZvdW5kIGluIHRoZSBMSUNFTlNFIGZpbGUgb3IgYXRcbiAgICAgIGh0dHBzOi8vb3BlbnNvdXJjZS5vcmcvbGljZW5zZXMvTUlULlxuICAgICovXG4gICAgLyoqXG4gICAgICogUmVtb3ZlcyBhbnkgVVJMIHNlYXJjaCBwYXJhbWV0ZXJzIHRoYXQgc2hvdWxkIGJlIGlnbm9yZWQuXG4gICAgICpcbiAgICAgKiBAcGFyYW0ge1VSTH0gdXJsT2JqZWN0IFRoZSBvcmlnaW5hbCBVUkwuXG4gICAgICogQHBhcmFtIHtBcnJheTxSZWdFeHA+fSBpZ25vcmVVUkxQYXJhbWV0ZXJzTWF0Y2hpbmcgUmVnRXhwcyB0byB0ZXN0IGFnYWluc3RcbiAgICAgKiBlYWNoIHNlYXJjaCBwYXJhbWV0ZXIgbmFtZS4gTWF0Y2hlcyBtZWFuIHRoYXQgdGhlIHNlYXJjaCBwYXJhbWV0ZXIgc2hvdWxkIGJlXG4gICAgICogaWdub3JlZC5cbiAgICAgKiBAcmV0dXJuIHtVUkx9IFRoZSBVUkwgd2l0aCBhbnkgaWdub3JlZCBzZWFyY2ggcGFyYW1ldGVycyByZW1vdmVkLlxuICAgICAqXG4gICAgICogQHByaXZhdGVcbiAgICAgKiBAbWVtYmVyb2Ygd29ya2JveC1wcmVjYWNoaW5nXG4gICAgICovXG4gICAgZnVuY3Rpb24gcmVtb3ZlSWdub3JlZFNlYXJjaFBhcmFtcyh1cmxPYmplY3QsIGlnbm9yZVVSTFBhcmFtZXRlcnNNYXRjaGluZyA9IFtdKSB7XG4gICAgICAvLyBDb252ZXJ0IHRoZSBpdGVyYWJsZSBpbnRvIGFuIGFycmF5IGF0IHRoZSBzdGFydCBvZiB0aGUgbG9vcCB0byBtYWtlIHN1cmVcbiAgICAgIC8vIGRlbGV0aW9uIGRvZXNuJ3QgbWVzcyB1cCBpdGVyYXRpb24uXG4gICAgICBmb3IgKGNvbnN0IHBhcmFtTmFtZSBvZiBbLi4udXJsT2JqZWN0LnNlYXJjaFBhcmFtcy5rZXlzKCldKSB7XG4gICAgICAgIGlmIChpZ25vcmVVUkxQYXJhbWV0ZXJzTWF0Y2hpbmcuc29tZShyZWdFeHAgPT4gcmVnRXhwLnRlc3QocGFyYW1OYW1lKSkpIHtcbiAgICAgICAgICB1cmxPYmplY3Quc2VhcmNoUGFyYW1zLmRlbGV0ZShwYXJhbU5hbWUpO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICByZXR1cm4gdXJsT2JqZWN0O1xuICAgIH1cblxuICAgIC8qXG4gICAgICBDb3B5cmlnaHQgMjAxOSBHb29nbGUgTExDXG5cbiAgICAgIFVzZSBvZiB0aGlzIHNvdXJjZSBjb2RlIGlzIGdvdmVybmVkIGJ5IGFuIE1JVC1zdHlsZVxuICAgICAgbGljZW5zZSB0aGF0IGNhbiBiZSBmb3VuZCBpbiB0aGUgTElDRU5TRSBmaWxlIG9yIGF0XG4gICAgICBodHRwczovL29wZW5zb3VyY2Uub3JnL2xpY2Vuc2VzL01JVC5cbiAgICAqL1xuICAgIC8qKlxuICAgICAqIEdlbmVyYXRvciBmdW5jdGlvbiB0aGF0IHlpZWxkcyBwb3NzaWJsZSB2YXJpYXRpb25zIG9uIHRoZSBvcmlnaW5hbCBVUkwgdG9cbiAgICAgKiBjaGVjaywgb25lIGF0IGEgdGltZS5cbiAgICAgKlxuICAgICAqIEBwYXJhbSB7c3RyaW5nfSB1cmxcbiAgICAgKiBAcGFyYW0ge09iamVjdH0gb3B0aW9uc1xuICAgICAqXG4gICAgICogQHByaXZhdGVcbiAgICAgKiBAbWVtYmVyb2Ygd29ya2JveC1wcmVjYWNoaW5nXG4gICAgICovXG4gICAgZnVuY3Rpb24qIGdlbmVyYXRlVVJMVmFyaWF0aW9ucyh1cmwsIHtcbiAgICAgIGlnbm9yZVVSTFBhcmFtZXRlcnNNYXRjaGluZyA9IFsvXnV0bV8vLCAvXmZiY2xpZCQvXSxcbiAgICAgIGRpcmVjdG9yeUluZGV4ID0gJ2luZGV4Lmh0bWwnLFxuICAgICAgY2xlYW5VUkxzID0gdHJ1ZSxcbiAgICAgIHVybE1hbmlwdWxhdGlvblxuICAgIH0gPSB7fSkge1xuICAgICAgY29uc3QgdXJsT2JqZWN0ID0gbmV3IFVSTCh1cmwsIGxvY2F0aW9uLmhyZWYpO1xuICAgICAgdXJsT2JqZWN0Lmhhc2ggPSAnJztcbiAgICAgIHlpZWxkIHVybE9iamVjdC5ocmVmO1xuICAgICAgY29uc3QgdXJsV2l0aG91dElnbm9yZWRQYXJhbXMgPSByZW1vdmVJZ25vcmVkU2VhcmNoUGFyYW1zKHVybE9iamVjdCwgaWdub3JlVVJMUGFyYW1ldGVyc01hdGNoaW5nKTtcbiAgICAgIHlpZWxkIHVybFdpdGhvdXRJZ25vcmVkUGFyYW1zLmhyZWY7XG4gICAgICBpZiAoZGlyZWN0b3J5SW5kZXggJiYgdXJsV2l0aG91dElnbm9yZWRQYXJhbXMucGF0aG5hbWUuZW5kc1dpdGgoJy8nKSkge1xuICAgICAgICBjb25zdCBkaXJlY3RvcnlVUkwgPSBuZXcgVVJMKHVybFdpdGhvdXRJZ25vcmVkUGFyYW1zLmhyZWYpO1xuICAgICAgICBkaXJlY3RvcnlVUkwucGF0aG5hbWUgKz0gZGlyZWN0b3J5SW5kZXg7XG4gICAgICAgIHlpZWxkIGRpcmVjdG9yeVVSTC5ocmVmO1xuICAgICAgfVxuICAgICAgaWYgKGNsZWFuVVJMcykge1xuICAgICAgICBjb25zdCBjbGVhblVSTCA9IG5ldyBVUkwodXJsV2l0aG91dElnbm9yZWRQYXJhbXMuaHJlZik7XG4gICAgICAgIGNsZWFuVVJMLnBhdGhuYW1lICs9ICcuaHRtbCc7XG4gICAgICAgIHlpZWxkIGNsZWFuVVJMLmhyZWY7XG4gICAgICB9XG4gICAgICBpZiAodXJsTWFuaXB1bGF0aW9uKSB7XG4gICAgICAgIGNvbnN0IGFkZGl0aW9uYWxVUkxzID0gdXJsTWFuaXB1bGF0aW9uKHtcbiAgICAgICAgICB1cmw6IHVybE9iamVjdFxuICAgICAgICB9KTtcbiAgICAgICAgZm9yIChjb25zdCB1cmxUb0F0dGVtcHQgb2YgYWRkaXRpb25hbFVSTHMpIHtcbiAgICAgICAgICB5aWVsZCB1cmxUb0F0dGVtcHQuaHJlZjtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH1cblxuICAgIC8qXG4gICAgICBDb3B5cmlnaHQgMjAyMCBHb29nbGUgTExDXG5cbiAgICAgIFVzZSBvZiB0aGlzIHNvdXJjZSBjb2RlIGlzIGdvdmVybmVkIGJ5IGFuIE1JVC1zdHlsZVxuICAgICAgbGljZW5zZSB0aGF0IGNhbiBiZSBmb3VuZCBpbiB0aGUgTElDRU5TRSBmaWxlIG9yIGF0XG4gICAgICBodHRwczovL29wZW5zb3VyY2Uub3JnL2xpY2Vuc2VzL01JVC5cbiAgICAqL1xuICAgIC8qKlxuICAgICAqIEEgc3ViY2xhc3Mgb2Yge0BsaW5rIHdvcmtib3gtcm91dGluZy5Sb3V0ZX0gdGhhdCB0YWtlcyBhXG4gICAgICoge0BsaW5rIHdvcmtib3gtcHJlY2FjaGluZy5QcmVjYWNoZUNvbnRyb2xsZXJ9XG4gICAgICogaW5zdGFuY2UgYW5kIHVzZXMgaXQgdG8gbWF0Y2ggaW5jb21pbmcgcmVxdWVzdHMgYW5kIGhhbmRsZSBmZXRjaGluZ1xuICAgICAqIHJlc3BvbnNlcyBmcm9tIHRoZSBwcmVjYWNoZS5cbiAgICAgKlxuICAgICAqIEBtZW1iZXJvZiB3b3JrYm94LXByZWNhY2hpbmdcbiAgICAgKiBAZXh0ZW5kcyB3b3JrYm94LXJvdXRpbmcuUm91dGVcbiAgICAgKi9cbiAgICBjbGFzcyBQcmVjYWNoZVJvdXRlIGV4dGVuZHMgUm91dGUge1xuICAgICAgLyoqXG4gICAgICAgKiBAcGFyYW0ge1ByZWNhY2hlQ29udHJvbGxlcn0gcHJlY2FjaGVDb250cm9sbGVyIEEgYFByZWNhY2hlQ29udHJvbGxlcmBcbiAgICAgICAqIGluc3RhbmNlIHVzZWQgdG8gYm90aCBtYXRjaCByZXF1ZXN0cyBhbmQgcmVzcG9uZCB0byBmZXRjaCBldmVudHMuXG4gICAgICAgKiBAcGFyYW0ge09iamVjdH0gW29wdGlvbnNdIE9wdGlvbnMgdG8gY29udHJvbCBob3cgcmVxdWVzdHMgYXJlIG1hdGNoZWRcbiAgICAgICAqIGFnYWluc3QgdGhlIGxpc3Qgb2YgcHJlY2FjaGVkIFVSTHMuXG4gICAgICAgKiBAcGFyYW0ge3N0cmluZ30gW29wdGlvbnMuZGlyZWN0b3J5SW5kZXg9aW5kZXguaHRtbF0gVGhlIGBkaXJlY3RvcnlJbmRleGAgd2lsbFxuICAgICAgICogY2hlY2sgY2FjaGUgZW50cmllcyBmb3IgYSBVUkxzIGVuZGluZyB3aXRoICcvJyB0byBzZWUgaWYgdGhlcmUgaXMgYSBoaXQgd2hlblxuICAgICAgICogYXBwZW5kaW5nIHRoZSBgZGlyZWN0b3J5SW5kZXhgIHZhbHVlLlxuICAgICAgICogQHBhcmFtIHtBcnJheTxSZWdFeHA+fSBbb3B0aW9ucy5pZ25vcmVVUkxQYXJhbWV0ZXJzTWF0Y2hpbmc9Wy9edXRtXy8sIC9eZmJjbGlkJC9dXSBBblxuICAgICAgICogYXJyYXkgb2YgcmVnZXgncyB0byByZW1vdmUgc2VhcmNoIHBhcmFtcyB3aGVuIGxvb2tpbmcgZm9yIGEgY2FjaGUgbWF0Y2guXG4gICAgICAgKiBAcGFyYW0ge2Jvb2xlYW59IFtvcHRpb25zLmNsZWFuVVJMcz10cnVlXSBUaGUgYGNsZWFuVVJMc2Agb3B0aW9uIHdpbGxcbiAgICAgICAqIGNoZWNrIHRoZSBjYWNoZSBmb3IgdGhlIFVSTCB3aXRoIGEgYC5odG1sYCBhZGRlZCB0byB0aGUgZW5kIG9mIHRoZSBlbmQuXG4gICAgICAgKiBAcGFyYW0ge3dvcmtib3gtcHJlY2FjaGluZ351cmxNYW5pcHVsYXRpb259IFtvcHRpb25zLnVybE1hbmlwdWxhdGlvbl1cbiAgICAgICAqIFRoaXMgaXMgYSBmdW5jdGlvbiB0aGF0IHNob3VsZCB0YWtlIGEgVVJMIGFuZCByZXR1cm4gYW4gYXJyYXkgb2ZcbiAgICAgICAqIGFsdGVybmF0aXZlIFVSTHMgdGhhdCBzaG91bGQgYmUgY2hlY2tlZCBmb3IgcHJlY2FjaGUgbWF0Y2hlcy5cbiAgICAgICAqL1xuICAgICAgY29uc3RydWN0b3IocHJlY2FjaGVDb250cm9sbGVyLCBvcHRpb25zKSB7XG4gICAgICAgIGNvbnN0IG1hdGNoID0gKHtcbiAgICAgICAgICByZXF1ZXN0XG4gICAgICAgIH0pID0+IHtcbiAgICAgICAgICBjb25zdCB1cmxzVG9DYWNoZUtleXMgPSBwcmVjYWNoZUNvbnRyb2xsZXIuZ2V0VVJMc1RvQ2FjaGVLZXlzKCk7XG4gICAgICAgICAgZm9yIChjb25zdCBwb3NzaWJsZVVSTCBvZiBnZW5lcmF0ZVVSTFZhcmlhdGlvbnMocmVxdWVzdC51cmwsIG9wdGlvbnMpKSB7XG4gICAgICAgICAgICBjb25zdCBjYWNoZUtleSA9IHVybHNUb0NhY2hlS2V5cy5nZXQocG9zc2libGVVUkwpO1xuICAgICAgICAgICAgaWYgKGNhY2hlS2V5KSB7XG4gICAgICAgICAgICAgIGNvbnN0IGludGVncml0eSA9IHByZWNhY2hlQ29udHJvbGxlci5nZXRJbnRlZ3JpdHlGb3JDYWNoZUtleShjYWNoZUtleSk7XG4gICAgICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICAgICAgY2FjaGVLZXksXG4gICAgICAgICAgICAgICAgaW50ZWdyaXR5XG4gICAgICAgICAgICAgIH07XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfVxuICAgICAgICAgIHtcbiAgICAgICAgICAgIGxvZ2dlci5kZWJ1ZyhgUHJlY2FjaGluZyBkaWQgbm90IGZpbmQgYSBtYXRjaCBmb3IgYCArIGdldEZyaWVuZGx5VVJMKHJlcXVlc3QudXJsKSk7XG4gICAgICAgICAgfVxuICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfTtcbiAgICAgICAgc3VwZXIobWF0Y2gsIHByZWNhY2hlQ29udHJvbGxlci5zdHJhdGVneSk7XG4gICAgICB9XG4gICAgfVxuXG4gICAgLypcbiAgICAgIENvcHlyaWdodCAyMDE5IEdvb2dsZSBMTENcbiAgICAgIFVzZSBvZiB0aGlzIHNvdXJjZSBjb2RlIGlzIGdvdmVybmVkIGJ5IGFuIE1JVC1zdHlsZVxuICAgICAgbGljZW5zZSB0aGF0IGNhbiBiZSBmb3VuZCBpbiB0aGUgTElDRU5TRSBmaWxlIG9yIGF0XG4gICAgICBodHRwczovL29wZW5zb3VyY2Uub3JnL2xpY2Vuc2VzL01JVC5cbiAgICAqL1xuICAgIC8qKlxuICAgICAqIEFkZCBhIGBmZXRjaGAgbGlzdGVuZXIgdG8gdGhlIHNlcnZpY2Ugd29ya2VyIHRoYXQgd2lsbFxuICAgICAqIHJlc3BvbmQgdG9cbiAgICAgKiBbbmV0d29yayByZXF1ZXN0c117QGxpbmsgaHR0cHM6Ly9kZXZlbG9wZXIubW96aWxsYS5vcmcvZW4tVVMvZG9jcy9XZWIvQVBJL1NlcnZpY2VfV29ya2VyX0FQSS9Vc2luZ19TZXJ2aWNlX1dvcmtlcnMjQ3VzdG9tX3Jlc3BvbnNlc190b19yZXF1ZXN0c31cbiAgICAgKiB3aXRoIHByZWNhY2hlZCBhc3NldHMuXG4gICAgICpcbiAgICAgKiBSZXF1ZXN0cyBmb3IgYXNzZXRzIHRoYXQgYXJlbid0IHByZWNhY2hlZCwgdGhlIGBGZXRjaEV2ZW50YCB3aWxsIG5vdCBiZVxuICAgICAqIHJlc3BvbmRlZCB0bywgYWxsb3dpbmcgdGhlIGV2ZW50IHRvIGZhbGwgdGhyb3VnaCB0byBvdGhlciBgZmV0Y2hgIGV2ZW50XG4gICAgICogbGlzdGVuZXJzLlxuICAgICAqXG4gICAgICogQHBhcmFtIHtPYmplY3R9IFtvcHRpb25zXSBTZWUgdGhlIHtAbGluayB3b3JrYm94LXByZWNhY2hpbmcuUHJlY2FjaGVSb3V0ZX1cbiAgICAgKiBvcHRpb25zLlxuICAgICAqXG4gICAgICogQG1lbWJlcm9mIHdvcmtib3gtcHJlY2FjaGluZ1xuICAgICAqL1xuICAgIGZ1bmN0aW9uIGFkZFJvdXRlKG9wdGlvbnMpIHtcbiAgICAgIGNvbnN0IHByZWNhY2hlQ29udHJvbGxlciA9IGdldE9yQ3JlYXRlUHJlY2FjaGVDb250cm9sbGVyKCk7XG4gICAgICBjb25zdCBwcmVjYWNoZVJvdXRlID0gbmV3IFByZWNhY2hlUm91dGUocHJlY2FjaGVDb250cm9sbGVyLCBvcHRpb25zKTtcbiAgICAgIHJlZ2lzdGVyUm91dGUocHJlY2FjaGVSb3V0ZSk7XG4gICAgfVxuXG4gICAgLypcbiAgICAgIENvcHlyaWdodCAyMDE5IEdvb2dsZSBMTENcblxuICAgICAgVXNlIG9mIHRoaXMgc291cmNlIGNvZGUgaXMgZ292ZXJuZWQgYnkgYW4gTUlULXN0eWxlXG4gICAgICBsaWNlbnNlIHRoYXQgY2FuIGJlIGZvdW5kIGluIHRoZSBMSUNFTlNFIGZpbGUgb3IgYXRcbiAgICAgIGh0dHBzOi8vb3BlbnNvdXJjZS5vcmcvbGljZW5zZXMvTUlULlxuICAgICovXG4gICAgLyoqXG4gICAgICogQWRkcyBpdGVtcyB0byB0aGUgcHJlY2FjaGUgbGlzdCwgcmVtb3ZpbmcgYW55IGR1cGxpY2F0ZXMgYW5kXG4gICAgICogc3RvcmVzIHRoZSBmaWxlcyBpbiB0aGVcbiAgICAgKiB7QGxpbmsgd29ya2JveC1jb3JlLmNhY2hlTmFtZXN8XCJwcmVjYWNoZSBjYWNoZVwifSB3aGVuIHRoZSBzZXJ2aWNlXG4gICAgICogd29ya2VyIGluc3RhbGxzLlxuICAgICAqXG4gICAgICogVGhpcyBtZXRob2QgY2FuIGJlIGNhbGxlZCBtdWx0aXBsZSB0aW1lcy5cbiAgICAgKlxuICAgICAqIFBsZWFzZSBub3RlOiBUaGlzIG1ldGhvZCAqKndpbGwgbm90Kiogc2VydmUgYW55IG9mIHRoZSBjYWNoZWQgZmlsZXMgZm9yIHlvdS5cbiAgICAgKiBJdCBvbmx5IHByZWNhY2hlcyBmaWxlcy4gVG8gcmVzcG9uZCB0byBhIG5ldHdvcmsgcmVxdWVzdCB5b3UgY2FsbFxuICAgICAqIHtAbGluayB3b3JrYm94LXByZWNhY2hpbmcuYWRkUm91dGV9LlxuICAgICAqXG4gICAgICogSWYgeW91IGhhdmUgYSBzaW5nbGUgYXJyYXkgb2YgZmlsZXMgdG8gcHJlY2FjaGUsIHlvdSBjYW4ganVzdCBjYWxsXG4gICAgICoge0BsaW5rIHdvcmtib3gtcHJlY2FjaGluZy5wcmVjYWNoZUFuZFJvdXRlfS5cbiAgICAgKlxuICAgICAqIEBwYXJhbSB7QXJyYXk8T2JqZWN0fHN0cmluZz59IFtlbnRyaWVzPVtdXSBBcnJheSBvZiBlbnRyaWVzIHRvIHByZWNhY2hlLlxuICAgICAqXG4gICAgICogQG1lbWJlcm9mIHdvcmtib3gtcHJlY2FjaGluZ1xuICAgICAqL1xuICAgIGZ1bmN0aW9uIHByZWNhY2hlKGVudHJpZXMpIHtcbiAgICAgIGNvbnN0IHByZWNhY2hlQ29udHJvbGxlciA9IGdldE9yQ3JlYXRlUHJlY2FjaGVDb250cm9sbGVyKCk7XG4gICAgICBwcmVjYWNoZUNvbnRyb2xsZXIucHJlY2FjaGUoZW50cmllcyk7XG4gICAgfVxuXG4gICAgLypcbiAgICAgIENvcHlyaWdodCAyMDE5IEdvb2dsZSBMTENcblxuICAgICAgVXNlIG9mIHRoaXMgc291cmNlIGNvZGUgaXMgZ292ZXJuZWQgYnkgYW4gTUlULXN0eWxlXG4gICAgICBsaWNlbnNlIHRoYXQgY2FuIGJlIGZvdW5kIGluIHRoZSBMSUNFTlNFIGZpbGUgb3IgYXRcbiAgICAgIGh0dHBzOi8vb3BlbnNvdXJjZS5vcmcvbGljZW5zZXMvTUlULlxuICAgICovXG4gICAgLyoqXG4gICAgICogVGhpcyBtZXRob2Qgd2lsbCBhZGQgZW50cmllcyB0byB0aGUgcHJlY2FjaGUgbGlzdCBhbmQgYWRkIGEgcm91dGUgdG9cbiAgICAgKiByZXNwb25kIHRvIGZldGNoIGV2ZW50cy5cbiAgICAgKlxuICAgICAqIFRoaXMgaXMgYSBjb252ZW5pZW5jZSBtZXRob2QgdGhhdCB3aWxsIGNhbGxcbiAgICAgKiB7QGxpbmsgd29ya2JveC1wcmVjYWNoaW5nLnByZWNhY2hlfSBhbmRcbiAgICAgKiB7QGxpbmsgd29ya2JveC1wcmVjYWNoaW5nLmFkZFJvdXRlfSBpbiBhIHNpbmdsZSBjYWxsLlxuICAgICAqXG4gICAgICogQHBhcmFtIHtBcnJheTxPYmplY3R8c3RyaW5nPn0gZW50cmllcyBBcnJheSBvZiBlbnRyaWVzIHRvIHByZWNhY2hlLlxuICAgICAqIEBwYXJhbSB7T2JqZWN0fSBbb3B0aW9uc10gU2VlIHRoZVxuICAgICAqIHtAbGluayB3b3JrYm94LXByZWNhY2hpbmcuUHJlY2FjaGVSb3V0ZX0gb3B0aW9ucy5cbiAgICAgKlxuICAgICAqIEBtZW1iZXJvZiB3b3JrYm94LXByZWNhY2hpbmdcbiAgICAgKi9cbiAgICBmdW5jdGlvbiBwcmVjYWNoZUFuZFJvdXRlKGVudHJpZXMsIG9wdGlvbnMpIHtcbiAgICAgIHByZWNhY2hlKGVudHJpZXMpO1xuICAgICAgYWRkUm91dGUob3B0aW9ucyk7XG4gICAgfVxuXG4gICAgLypcbiAgICAgIENvcHlyaWdodCAyMDE4IEdvb2dsZSBMTENcblxuICAgICAgVXNlIG9mIHRoaXMgc291cmNlIGNvZGUgaXMgZ292ZXJuZWQgYnkgYW4gTUlULXN0eWxlXG4gICAgICBsaWNlbnNlIHRoYXQgY2FuIGJlIGZvdW5kIGluIHRoZSBMSUNFTlNFIGZpbGUgb3IgYXRcbiAgICAgIGh0dHBzOi8vb3BlbnNvdXJjZS5vcmcvbGljZW5zZXMvTUlULlxuICAgICovXG4gICAgY29uc3QgU1VCU1RSSU5HX1RPX0ZJTkQgPSAnLXByZWNhY2hlLSc7XG4gICAgLyoqXG4gICAgICogQ2xlYW5zIHVwIGluY29tcGF0aWJsZSBwcmVjYWNoZXMgdGhhdCB3ZXJlIGNyZWF0ZWQgYnkgb2xkZXIgdmVyc2lvbnMgb2ZcbiAgICAgKiBXb3JrYm94LCBieSBhIHNlcnZpY2Ugd29ya2VyIHJlZ2lzdGVyZWQgdW5kZXIgdGhlIGN1cnJlbnQgc2NvcGUuXG4gICAgICpcbiAgICAgKiBUaGlzIGlzIG1lYW50IHRvIGJlIGNhbGxlZCBhcyBwYXJ0IG9mIHRoZSBgYWN0aXZhdGVgIGV2ZW50LlxuICAgICAqXG4gICAgICogVGhpcyBzaG91bGQgYmUgc2FmZSB0byB1c2UgYXMgbG9uZyBhcyB5b3UgZG9uJ3QgaW5jbHVkZSBgc3Vic3RyaW5nVG9GaW5kYFxuICAgICAqIChkZWZhdWx0aW5nIHRvIGAtcHJlY2FjaGUtYCkgaW4geW91ciBub24tcHJlY2FjaGUgY2FjaGUgbmFtZXMuXG4gICAgICpcbiAgICAgKiBAcGFyYW0ge3N0cmluZ30gY3VycmVudFByZWNhY2hlTmFtZSBUaGUgY2FjaGUgbmFtZSBjdXJyZW50bHkgaW4gdXNlIGZvclxuICAgICAqIHByZWNhY2hpbmcuIFRoaXMgY2FjaGUgd29uJ3QgYmUgZGVsZXRlZC5cbiAgICAgKiBAcGFyYW0ge3N0cmluZ30gW3N1YnN0cmluZ1RvRmluZD0nLXByZWNhY2hlLSddIENhY2hlIG5hbWVzIHdoaWNoIGluY2x1ZGUgdGhpc1xuICAgICAqIHN1YnN0cmluZyB3aWxsIGJlIGRlbGV0ZWQgKGV4Y2x1ZGluZyBgY3VycmVudFByZWNhY2hlTmFtZWApLlxuICAgICAqIEByZXR1cm4ge0FycmF5PHN0cmluZz59IEEgbGlzdCBvZiBhbGwgdGhlIGNhY2hlIG5hbWVzIHRoYXQgd2VyZSBkZWxldGVkLlxuICAgICAqXG4gICAgICogQHByaXZhdGVcbiAgICAgKiBAbWVtYmVyb2Ygd29ya2JveC1wcmVjYWNoaW5nXG4gICAgICovXG4gICAgY29uc3QgZGVsZXRlT3V0ZGF0ZWRDYWNoZXMgPSBhc3luYyAoY3VycmVudFByZWNhY2hlTmFtZSwgc3Vic3RyaW5nVG9GaW5kID0gU1VCU1RSSU5HX1RPX0ZJTkQpID0+IHtcbiAgICAgIGNvbnN0IGNhY2hlTmFtZXMgPSBhd2FpdCBzZWxmLmNhY2hlcy5rZXlzKCk7XG4gICAgICBjb25zdCBjYWNoZU5hbWVzVG9EZWxldGUgPSBjYWNoZU5hbWVzLmZpbHRlcihjYWNoZU5hbWUgPT4ge1xuICAgICAgICByZXR1cm4gY2FjaGVOYW1lLmluY2x1ZGVzKHN1YnN0cmluZ1RvRmluZCkgJiYgY2FjaGVOYW1lLmluY2x1ZGVzKHNlbGYucmVnaXN0cmF0aW9uLnNjb3BlKSAmJiBjYWNoZU5hbWUgIT09IGN1cnJlbnRQcmVjYWNoZU5hbWU7XG4gICAgICB9KTtcbiAgICAgIGF3YWl0IFByb21pc2UuYWxsKGNhY2hlTmFtZXNUb0RlbGV0ZS5tYXAoY2FjaGVOYW1lID0+IHNlbGYuY2FjaGVzLmRlbGV0ZShjYWNoZU5hbWUpKSk7XG4gICAgICByZXR1cm4gY2FjaGVOYW1lc1RvRGVsZXRlO1xuICAgIH07XG5cbiAgICAvKlxuICAgICAgQ29weXJpZ2h0IDIwMTkgR29vZ2xlIExMQ1xuXG4gICAgICBVc2Ugb2YgdGhpcyBzb3VyY2UgY29kZSBpcyBnb3Zlcm5lZCBieSBhbiBNSVQtc3R5bGVcbiAgICAgIGxpY2Vuc2UgdGhhdCBjYW4gYmUgZm91bmQgaW4gdGhlIExJQ0VOU0UgZmlsZSBvciBhdFxuICAgICAgaHR0cHM6Ly9vcGVuc291cmNlLm9yZy9saWNlbnNlcy9NSVQuXG4gICAgKi9cbiAgICAvKipcbiAgICAgKiBBZGRzIGFuIGBhY3RpdmF0ZWAgZXZlbnQgbGlzdGVuZXIgd2hpY2ggd2lsbCBjbGVhbiB1cCBpbmNvbXBhdGlibGVcbiAgICAgKiBwcmVjYWNoZXMgdGhhdCB3ZXJlIGNyZWF0ZWQgYnkgb2xkZXIgdmVyc2lvbnMgb2YgV29ya2JveC5cbiAgICAgKlxuICAgICAqIEBtZW1iZXJvZiB3b3JrYm94LXByZWNhY2hpbmdcbiAgICAgKi9cbiAgICBmdW5jdGlvbiBjbGVhbnVwT3V0ZGF0ZWRDYWNoZXMoKSB7XG4gICAgICAvLyBTZWUgaHR0cHM6Ly9naXRodWIuY29tL01pY3Jvc29mdC9UeXBlU2NyaXB0L2lzc3Vlcy8yODM1NyNpc3N1ZWNvbW1lbnQtNDM2NDg0NzA1XG4gICAgICBzZWxmLmFkZEV2ZW50TGlzdGVuZXIoJ2FjdGl2YXRlJywgZXZlbnQgPT4ge1xuICAgICAgICBjb25zdCBjYWNoZU5hbWUgPSBjYWNoZU5hbWVzLmdldFByZWNhY2hlTmFtZSgpO1xuICAgICAgICBldmVudC53YWl0VW50aWwoZGVsZXRlT3V0ZGF0ZWRDYWNoZXMoY2FjaGVOYW1lKS50aGVuKGNhY2hlc0RlbGV0ZWQgPT4ge1xuICAgICAgICAgIHtcbiAgICAgICAgICAgIGlmIChjYWNoZXNEZWxldGVkLmxlbmd0aCA+IDApIHtcbiAgICAgICAgICAgICAgbG9nZ2VyLmxvZyhgVGhlIGZvbGxvd2luZyBvdXQtb2YtZGF0ZSBwcmVjYWNoZXMgd2VyZSBjbGVhbmVkIHVwIGAgKyBgYXV0b21hdGljYWxseTpgLCBjYWNoZXNEZWxldGVkKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICAgIH0pKTtcbiAgICAgIH0pO1xuICAgIH1cblxuICAgIC8qXG4gICAgICBDb3B5cmlnaHQgMjAxOCBHb29nbGUgTExDXG5cbiAgICAgIFVzZSBvZiB0aGlzIHNvdXJjZSBjb2RlIGlzIGdvdmVybmVkIGJ5IGFuIE1JVC1zdHlsZVxuICAgICAgbGljZW5zZSB0aGF0IGNhbiBiZSBmb3VuZCBpbiB0aGUgTElDRU5TRSBmaWxlIG9yIGF0XG4gICAgICBodHRwczovL29wZW5zb3VyY2Uub3JnL2xpY2Vuc2VzL01JVC5cbiAgICAqL1xuICAgIC8qKlxuICAgICAqIE5hdmlnYXRpb25Sb3V0ZSBtYWtlcyBpdCBlYXN5IHRvIGNyZWF0ZSBhXG4gICAgICoge0BsaW5rIHdvcmtib3gtcm91dGluZy5Sb3V0ZX0gdGhhdCBtYXRjaGVzIGZvciBicm93c2VyXG4gICAgICogW25hdmlnYXRpb24gcmVxdWVzdHNde0BsaW5rIGh0dHBzOi8vZGV2ZWxvcGVycy5nb29nbGUuY29tL3dlYi9mdW5kYW1lbnRhbHMvcHJpbWVycy9zZXJ2aWNlLXdvcmtlcnMvaGlnaC1wZXJmb3JtYW5jZS1sb2FkaW5nI2ZpcnN0X3doYXRfYXJlX25hdmlnYXRpb25fcmVxdWVzdHN9LlxuICAgICAqXG4gICAgICogSXQgd2lsbCBvbmx5IG1hdGNoIGluY29taW5nIFJlcXVlc3RzIHdob3NlXG4gICAgICoge0BsaW5rIGh0dHBzOi8vZmV0Y2guc3BlYy53aGF0d2cub3JnLyNjb25jZXB0LXJlcXVlc3QtbW9kZXxtb2RlfVxuICAgICAqIGlzIHNldCB0byBgbmF2aWdhdGVgLlxuICAgICAqXG4gICAgICogWW91IGNhbiBvcHRpb25hbGx5IG9ubHkgYXBwbHkgdGhpcyByb3V0ZSB0byBhIHN1YnNldCBvZiBuYXZpZ2F0aW9uIHJlcXVlc3RzXG4gICAgICogYnkgdXNpbmcgb25lIG9yIGJvdGggb2YgdGhlIGBkZW55bGlzdGAgYW5kIGBhbGxvd2xpc3RgIHBhcmFtZXRlcnMuXG4gICAgICpcbiAgICAgKiBAbWVtYmVyb2Ygd29ya2JveC1yb3V0aW5nXG4gICAgICogQGV4dGVuZHMgd29ya2JveC1yb3V0aW5nLlJvdXRlXG4gICAgICovXG4gICAgY2xhc3MgTmF2aWdhdGlvblJvdXRlIGV4dGVuZHMgUm91dGUge1xuICAgICAgLyoqXG4gICAgICAgKiBJZiBib3RoIGBkZW55bGlzdGAgYW5kIGBhbGxvd2xpc3RgIGFyZSBwcm92aWRlZCwgdGhlIGBkZW55bGlzdGAgd2lsbFxuICAgICAgICogdGFrZSBwcmVjZWRlbmNlIGFuZCB0aGUgcmVxdWVzdCB3aWxsIG5vdCBtYXRjaCB0aGlzIHJvdXRlLlxuICAgICAgICpcbiAgICAgICAqIFRoZSByZWd1bGFyIGV4cHJlc3Npb25zIGluIGBhbGxvd2xpc3RgIGFuZCBgZGVueWxpc3RgXG4gICAgICAgKiBhcmUgbWF0Y2hlZCBhZ2FpbnN0IHRoZSBjb25jYXRlbmF0ZWRcbiAgICAgICAqIFtgcGF0aG5hbWVgXXtAbGluayBodHRwczovL2RldmVsb3Blci5tb3ppbGxhLm9yZy9lbi1VUy9kb2NzL1dlYi9BUEkvSFRNTEh5cGVybGlua0VsZW1lbnRVdGlscy9wYXRobmFtZX1cbiAgICAgICAqIGFuZCBbYHNlYXJjaGBde0BsaW5rIGh0dHBzOi8vZGV2ZWxvcGVyLm1vemlsbGEub3JnL2VuLVVTL2RvY3MvV2ViL0FQSS9IVE1MSHlwZXJsaW5rRWxlbWVudFV0aWxzL3NlYXJjaH1cbiAgICAgICAqIHBvcnRpb25zIG9mIHRoZSByZXF1ZXN0ZWQgVVJMLlxuICAgICAgICpcbiAgICAgICAqICpOb3RlKjogVGhlc2UgUmVnRXhwcyBtYXkgYmUgZXZhbHVhdGVkIGFnYWluc3QgZXZlcnkgZGVzdGluYXRpb24gVVJMIGR1cmluZ1xuICAgICAgICogYSBuYXZpZ2F0aW9uLiBBdm9pZCB1c2luZ1xuICAgICAgICogW2NvbXBsZXggUmVnRXhwc10oaHR0cHM6Ly9naXRodWIuY29tL0dvb2dsZUNocm9tZS93b3JrYm94L2lzc3Vlcy8zMDc3KSxcbiAgICAgICAqIG9yIGVsc2UgeW91ciB1c2VycyBtYXkgc2VlIGRlbGF5cyB3aGVuIG5hdmlnYXRpbmcgeW91ciBzaXRlLlxuICAgICAgICpcbiAgICAgICAqIEBwYXJhbSB7d29ya2JveC1yb3V0aW5nfmhhbmRsZXJDYWxsYmFja30gaGFuZGxlciBBIGNhbGxiYWNrXG4gICAgICAgKiBmdW5jdGlvbiB0aGF0IHJldHVybnMgYSBQcm9taXNlIHJlc3VsdGluZyBpbiBhIFJlc3BvbnNlLlxuICAgICAgICogQHBhcmFtIHtPYmplY3R9IG9wdGlvbnNcbiAgICAgICAqIEBwYXJhbSB7QXJyYXk8UmVnRXhwPn0gW29wdGlvbnMuZGVueWxpc3RdIElmIGFueSBvZiB0aGVzZSBwYXR0ZXJucyBtYXRjaCxcbiAgICAgICAqIHRoZSByb3V0ZSB3aWxsIG5vdCBoYW5kbGUgdGhlIHJlcXVlc3QgKGV2ZW4gaWYgYSBhbGxvd2xpc3QgUmVnRXhwIG1hdGNoZXMpLlxuICAgICAgICogQHBhcmFtIHtBcnJheTxSZWdFeHA+fSBbb3B0aW9ucy5hbGxvd2xpc3Q9Wy8uL11dIElmIGFueSBvZiB0aGVzZSBwYXR0ZXJuc1xuICAgICAgICogbWF0Y2ggdGhlIFVSTCdzIHBhdGhuYW1lIGFuZCBzZWFyY2ggcGFyYW1ldGVyLCB0aGUgcm91dGUgd2lsbCBoYW5kbGUgdGhlXG4gICAgICAgKiByZXF1ZXN0IChhc3N1bWluZyB0aGUgZGVueWxpc3QgZG9lc24ndCBtYXRjaCkuXG4gICAgICAgKi9cbiAgICAgIGNvbnN0cnVjdG9yKGhhbmRsZXIsIHtcbiAgICAgICAgYWxsb3dsaXN0ID0gWy8uL10sXG4gICAgICAgIGRlbnlsaXN0ID0gW11cbiAgICAgIH0gPSB7fSkge1xuICAgICAgICB7XG4gICAgICAgICAgZmluYWxBc3NlcnRFeHBvcnRzLmlzQXJyYXlPZkNsYXNzKGFsbG93bGlzdCwgUmVnRXhwLCB7XG4gICAgICAgICAgICBtb2R1bGVOYW1lOiAnd29ya2JveC1yb3V0aW5nJyxcbiAgICAgICAgICAgIGNsYXNzTmFtZTogJ05hdmlnYXRpb25Sb3V0ZScsXG4gICAgICAgICAgICBmdW5jTmFtZTogJ2NvbnN0cnVjdG9yJyxcbiAgICAgICAgICAgIHBhcmFtTmFtZTogJ29wdGlvbnMuYWxsb3dsaXN0J1xuICAgICAgICAgIH0pO1xuICAgICAgICAgIGZpbmFsQXNzZXJ0RXhwb3J0cy5pc0FycmF5T2ZDbGFzcyhkZW55bGlzdCwgUmVnRXhwLCB7XG4gICAgICAgICAgICBtb2R1bGVOYW1lOiAnd29ya2JveC1yb3V0aW5nJyxcbiAgICAgICAgICAgIGNsYXNzTmFtZTogJ05hdmlnYXRpb25Sb3V0ZScsXG4gICAgICAgICAgICBmdW5jTmFtZTogJ2NvbnN0cnVjdG9yJyxcbiAgICAgICAgICAgIHBhcmFtTmFtZTogJ29wdGlvbnMuZGVueWxpc3QnXG4gICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICAgICAgc3VwZXIob3B0aW9ucyA9PiB0aGlzLl9tYXRjaChvcHRpb25zKSwgaGFuZGxlcik7XG4gICAgICAgIHRoaXMuX2FsbG93bGlzdCA9IGFsbG93bGlzdDtcbiAgICAgICAgdGhpcy5fZGVueWxpc3QgPSBkZW55bGlzdDtcbiAgICAgIH1cbiAgICAgIC8qKlxuICAgICAgICogUm91dGVzIG1hdGNoIGhhbmRsZXIuXG4gICAgICAgKlxuICAgICAgICogQHBhcmFtIHtPYmplY3R9IG9wdGlvbnNcbiAgICAgICAqIEBwYXJhbSB7VVJMfSBvcHRpb25zLnVybFxuICAgICAgICogQHBhcmFtIHtSZXF1ZXN0fSBvcHRpb25zLnJlcXVlc3RcbiAgICAgICAqIEByZXR1cm4ge2Jvb2xlYW59XG4gICAgICAgKlxuICAgICAgICogQHByaXZhdGVcbiAgICAgICAqL1xuICAgICAgX21hdGNoKHtcbiAgICAgICAgdXJsLFxuICAgICAgICByZXF1ZXN0XG4gICAgICB9KSB7XG4gICAgICAgIGlmIChyZXF1ZXN0ICYmIHJlcXVlc3QubW9kZSAhPT0gJ25hdmlnYXRlJykge1xuICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCBwYXRobmFtZUFuZFNlYXJjaCA9IHVybC5wYXRobmFtZSArIHVybC5zZWFyY2g7XG4gICAgICAgIGZvciAoY29uc3QgcmVnRXhwIG9mIHRoaXMuX2RlbnlsaXN0KSB7XG4gICAgICAgICAgaWYgKHJlZ0V4cC50ZXN0KHBhdGhuYW1lQW5kU2VhcmNoKSkge1xuICAgICAgICAgICAge1xuICAgICAgICAgICAgICBsb2dnZXIubG9nKGBUaGUgbmF2aWdhdGlvbiByb3V0ZSAke3BhdGhuYW1lQW5kU2VhcmNofSBpcyBub3QgYCArIGBiZWluZyB1c2VkLCBzaW5jZSB0aGUgVVJMIG1hdGNoZXMgdGhpcyBkZW55bGlzdCBwYXR0ZXJuOiBgICsgYCR7cmVnRXhwLnRvU3RyaW5nKCl9YCk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGlmICh0aGlzLl9hbGxvd2xpc3Quc29tZShyZWdFeHAgPT4gcmVnRXhwLnRlc3QocGF0aG5hbWVBbmRTZWFyY2gpKSkge1xuICAgICAgICAgIHtcbiAgICAgICAgICAgIGxvZ2dlci5kZWJ1ZyhgVGhlIG5hdmlnYXRpb24gcm91dGUgJHtwYXRobmFtZUFuZFNlYXJjaH0gYCArIGBpcyBiZWluZyB1c2VkLmApO1xuICAgICAgICAgIH1cbiAgICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgICAgfVxuICAgICAgICB7XG4gICAgICAgICAgbG9nZ2VyLmxvZyhgVGhlIG5hdmlnYXRpb24gcm91dGUgJHtwYXRobmFtZUFuZFNlYXJjaH0gaXMgbm90IGAgKyBgYmVpbmcgdXNlZCwgc2luY2UgdGhlIFVSTCBiZWluZyBuYXZpZ2F0ZWQgdG8gZG9lc24ndCBgICsgYG1hdGNoIHRoZSBhbGxvd2xpc3QuYCk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgfVxuICAgIH1cblxuICAgIC8qXG4gICAgICBDb3B5cmlnaHQgMjAxOSBHb29nbGUgTExDXG5cbiAgICAgIFVzZSBvZiB0aGlzIHNvdXJjZSBjb2RlIGlzIGdvdmVybmVkIGJ5IGFuIE1JVC1zdHlsZVxuICAgICAgbGljZW5zZSB0aGF0IGNhbiBiZSBmb3VuZCBpbiB0aGUgTElDRU5TRSBmaWxlIG9yIGF0XG4gICAgICBodHRwczovL29wZW5zb3VyY2Uub3JnL2xpY2Vuc2VzL01JVC5cbiAgICAqL1xuICAgIC8qKlxuICAgICAqIEhlbHBlciBmdW5jdGlvbiB0aGF0IGNhbGxzXG4gICAgICoge0BsaW5rIFByZWNhY2hlQ29udHJvbGxlciNjcmVhdGVIYW5kbGVyQm91bmRUb1VSTH0gb24gdGhlIGRlZmF1bHRcbiAgICAgKiB7QGxpbmsgUHJlY2FjaGVDb250cm9sbGVyfSBpbnN0YW5jZS5cbiAgICAgKlxuICAgICAqIElmIHlvdSBhcmUgY3JlYXRpbmcgeW91ciBvd24ge0BsaW5rIFByZWNhY2hlQ29udHJvbGxlcn0sIHRoZW4gY2FsbCB0aGVcbiAgICAgKiB7QGxpbmsgUHJlY2FjaGVDb250cm9sbGVyI2NyZWF0ZUhhbmRsZXJCb3VuZFRvVVJMfSBvbiB0aGF0IGluc3RhbmNlLFxuICAgICAqIGluc3RlYWQgb2YgdXNpbmcgdGhpcyBmdW5jdGlvbi5cbiAgICAgKlxuICAgICAqIEBwYXJhbSB7c3RyaW5nfSB1cmwgVGhlIHByZWNhY2hlZCBVUkwgd2hpY2ggd2lsbCBiZSB1c2VkIHRvIGxvb2t1cCB0aGVcbiAgICAgKiBgUmVzcG9uc2VgLlxuICAgICAqIEBwYXJhbSB7Ym9vbGVhbn0gW2ZhbGxiYWNrVG9OZXR3b3JrPXRydWVdIFdoZXRoZXIgdG8gYXR0ZW1wdCB0byBnZXQgdGhlXG4gICAgICogcmVzcG9uc2UgZnJvbSB0aGUgbmV0d29yayBpZiB0aGVyZSdzIGEgcHJlY2FjaGUgbWlzcy5cbiAgICAgKiBAcmV0dXJuIHt3b3JrYm94LXJvdXRpbmd+aGFuZGxlckNhbGxiYWNrfVxuICAgICAqXG4gICAgICogQG1lbWJlcm9mIHdvcmtib3gtcHJlY2FjaGluZ1xuICAgICAqL1xuICAgIGZ1bmN0aW9uIGNyZWF0ZUhhbmRsZXJCb3VuZFRvVVJMKHVybCkge1xuICAgICAgY29uc3QgcHJlY2FjaGVDb250cm9sbGVyID0gZ2V0T3JDcmVhdGVQcmVjYWNoZUNvbnRyb2xsZXIoKTtcbiAgICAgIHJldHVybiBwcmVjYWNoZUNvbnRyb2xsZXIuY3JlYXRlSGFuZGxlckJvdW5kVG9VUkwodXJsKTtcbiAgICB9XG5cbiAgICBleHBvcnRzLkNhY2hlYWJsZVJlc3BvbnNlUGx1Z2luID0gQ2FjaGVhYmxlUmVzcG9uc2VQbHVnaW47XG4gICAgZXhwb3J0cy5FeHBpcmF0aW9uUGx1Z2luID0gRXhwaXJhdGlvblBsdWdpbjtcbiAgICBleHBvcnRzLk5hdmlnYXRpb25Sb3V0ZSA9IE5hdmlnYXRpb25Sb3V0ZTtcbiAgICBleHBvcnRzLk5ldHdvcmtGaXJzdCA9IE5ldHdvcmtGaXJzdDtcbiAgICBleHBvcnRzLmNsZWFudXBPdXRkYXRlZENhY2hlcyA9IGNsZWFudXBPdXRkYXRlZENhY2hlcztcbiAgICBleHBvcnRzLmNsaWVudHNDbGFpbSA9IGNsaWVudHNDbGFpbTtcbiAgICBleHBvcnRzLmNyZWF0ZUhhbmRsZXJCb3VuZFRvVVJMID0gY3JlYXRlSGFuZGxlckJvdW5kVG9VUkw7XG4gICAgZXhwb3J0cy5wcmVjYWNoZUFuZFJvdXRlID0gcHJlY2FjaGVBbmRSb3V0ZTtcbiAgICBleHBvcnRzLnJlZ2lzdGVyUm91dGUgPSByZWdpc3RlclJvdXRlO1xuXG59KSk7XG4vLyMgc291cmNlTWFwcGluZ1VSTD13b3JrYm94LTk3MDEyNGU2LmpzLm1hcFxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9d29ya2JveC05NzAxMjRlNi5qcy5tYXBcbiJdfQ==